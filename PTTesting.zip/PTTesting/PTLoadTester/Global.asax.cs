using System;
using System.Web;

namespace PTLoadTester
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            // Increase default connection limit for concurrent HTTP requests
            System.Net.ServicePointManager.DefaultConnectionLimit = 500;
            System.Net.ServicePointManager.Expect100Continue = false;
            System.Net.ServicePointManager.UseNagleAlgorithm = false;

            // Virtual users block on synchronous HTTP calls; without enough ready threads the
            // thread pool injects them slowly and requests time out client-side despite 200s in IIS.
            int workers, iocp;
            System.Threading.ThreadPool.GetMinThreads(out workers, out iocp);
            System.Threading.ThreadPool.SetMinThreads(Math.Max(workers, 500), Math.Max(iocp, 500));
        }

        protected void Session_Start(object sender, EventArgs e) { }
        protected void Application_BeginRequest(object sender, EventArgs e) { }
        protected void Application_AuthenticateRequest(object sender, EventArgs e) { }
        protected void Application_Error(object sender, EventArgs e) { }
        protected void Session_End(object sender, EventArgs e) { }
        protected void Application_End(object sender, EventArgs e) { }
    }
}
