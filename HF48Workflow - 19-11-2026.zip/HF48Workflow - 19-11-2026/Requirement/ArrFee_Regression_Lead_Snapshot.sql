USE [LMS_DEV]
GO
SET NOCOUNT ON;

DECLARE @RegressionLeads TABLE
(
    InputOrder INT IDENTITY(1,1) NOT NULL,
    RequestedGroup NVARCHAR(30) NOT NULL,
    LeadNo NVARCHAR(100) NOT NULL
);

INSERT INTO @RegressionLeads(RequestedGroup, LeadNo)
VALUES
    (N'Start reference', N'LD-0005122'),
    (N'Non-Pre-approval', N'LD-00126593'),
    (N'Non-Pre-approval', N'LD-00126592'),
    (N'Non-Pre-approval', N'LD-00126590'),
    (N'Non-Pre-approval', N'LD-00126589'),
    (N'Non-Pre-approval', N'LD-00126587'),
    (N'Non-Pre-approval', N'LD-00126585'),
    (N'Non-Pre-approval', N'LD-00126584'),
    (N'Non-Pre-approval', N'LD-00126580'),
    (N'Non-Pre-approval', N'LD-00126578'),
    (N'Non-Pre-approval', N'LD-00126577'),
    (N'Non-Pre-approval', N'LD-00126572'),
    (N'Non-Pre-approval', N'LD-00126571'),
    (N'Non-Pre-approval', N'LD-00126563'),
    (N'Non-Pre-approval', N'LD-00126562'),
    (N'Non-Pre-approval', N'LD-00126558'),
    (N'Non-Pre-approval', N'LD-00126557'),
    (N'Non-Pre-approval', N'LD-00126555'),
    (N'Non-Pre-approval', N'LD-00126551'),
    (N'Non-Pre-approval', N'LD-00126550'),
    (N'Non-Pre-approval', N'LD-00126546'),
    (N'Non-Pre-approval', N'LD-00126545'),
    (N'Non-Pre-approval', N'LD-00126544'),
    (N'Non-Pre-approval', N'LD-00126539'),
    (N'Non-Pre-approval', N'LD-00126537'),
    (N'Non-Pre-approval', N'LD-00126532'),
    (N'Non-Pre-approval', N'LD-00126531'),
    (N'Non-Pre-approval', N'LD-00126528'),
    (N'Non-Pre-approval', N'LD-00126522'),
    (N'Non-Pre-approval', N'LD-00126519'),
    (N'Non-Pre-approval', N'LD-00126511'),
    (N'Non-Pre-approval', N'LD-00126508'),
    (N'Non-Pre-approval', N'LD-00126503'),
    (N'Non-Pre-approval', N'LD-00126500'),
    (N'Non-Pre-approval', N'LD-00126494'),
    (N'Non-Pre-approval', N'LD-00126481'),
    (N'Non-Pre-approval', N'LD-00126479'),
    (N'Non-Pre-approval', N'LD-00126474'),
    (N'Non-Pre-approval', N'LD-00126464'),
    (N'Non-Pre-approval', N'LD-00126462'),
    (N'Non-Pre-approval', N'LD-00126460'),
    (N'Non-Pre-approval', N'LD-00126459'),
    (N'Non-Pre-approval', N'LD-00126457'),
    (N'Non-Pre-approval', N'LD-00126456'),
    (N'Non-Pre-approval', N'LD-00126454'),
    (N'Non-Pre-approval', N'LD-00126453'),
    (N'Non-Pre-approval', N'LD-00126451'),
    (N'Non-Pre-approval', N'LD-00126448'),
    (N'Non-Pre-approval', N'LD-00126443'),
    (N'Non-Pre-approval', N'LD-00126380'),
    (N'Non-Pre-approval', N'LD-00126372'),
    (N'Non-Pre-approval', N'LD-00126328'),
    (N'Non-Pre-approval', N'LD-00126264'),
    (N'Non-Pre-approval', N'LD-00126229'),
    (N'Non-Pre-approval', N'LD-00126228'),
    (N'Non-Pre-approval', N'LD-00126191'),
    (N'Non-Pre-approval', N'LD-00126120'),
    (N'Non-Pre-approval', N'LD-00126106'),
    (N'Non-Pre-approval', N'LD-00126101'),
    (N'Non-Pre-approval', N'LD-00126099'),
    (N'Non-Pre-approval', N'LD-00126093'),
    (N'Non-Pre-approval', N'LD-00126082'),
    (N'Non-Pre-approval', N'LD-00126080'),
    (N'Non-Pre-approval', N'LD-00126076'),
    (N'Non-Pre-approval', N'LD-00126065'),
    (N'Non-Pre-approval', N'LD-00126064'),
    (N'Non-Pre-approval', N'LD-00126055'),
    (N'Non-Pre-approval', N'LD-00126054'),
    (N'Non-Pre-approval', N'LD-00126051'),
    (N'Non-Pre-approval', N'LD-00126049'),
    (N'Non-Pre-approval', N'LD-00126046'),
    (N'Non-Pre-approval', N'LD-00126045'),
    (N'Non-Pre-approval', N'LD-00126043'),
    (N'Non-Pre-approval', N'LD-00126038'),
    (N'Non-Pre-approval', N'LD-00126035'),
    (N'Non-Pre-approval', N'LD-00126032'),
    (N'Non-Pre-approval', N'LD-00126031'),
    (N'Non-Pre-approval', N'LD-00126026'),
    (N'Non-Pre-approval', N'LD-00126025'),
    (N'Non-Pre-approval', N'LD-00126023'),
    (N'Non-Pre-approval', N'LD-00126019'),
    (N'Non-Pre-approval', N'LD-00126016'),
    (N'Non-Pre-approval', N'LD-00126014'),
    (N'Non-Pre-approval', N'LD-00126013'),
    (N'Non-Pre-approval', N'LD-00126011'),
    (N'Non-Pre-approval', N'LD-00126010'),
    (N'Non-Pre-approval', N'LD-00126009'),
    (N'Non-Pre-approval', N'LD-00125996'),
    (N'Non-Pre-approval', N'LD-00125990'),
    (N'Non-Pre-approval', N'LD-00125989'),
    (N'Non-Pre-approval', N'LD-00125988'),
    (N'Non-Pre-approval', N'LD-00125970'),
    (N'Non-Pre-approval', N'LD-00125968'),
    (N'Non-Pre-approval', N'LD-00125965'),
    (N'Non-Pre-approval', N'LD-00125959'),
    (N'Non-Pre-approval', N'LD-00125957'),
    (N'Non-Pre-approval', N'LD-00125952'),
    (N'Non-Pre-approval', N'LD-00125950'),
    (N'Pre-approval', N'LD-00091794'),
    (N'Pre-approval', N'LD-00091787'),
    (N'Pre-approval', N'LD-00091786'),
    (N'Pre-approval', N'LD-00091764'),
    (N'Pre-approval', N'LD-00091754'),
    (N'Pre-approval', N'LD-00091741'),
    (N'Pre-approval', N'LD-00091729'),
    (N'Pre-approval', N'LD-00091541'),
    (N'Pre-approval', N'LD-00091540'),
    (N'Pre-approval', N'LD-00091536'),
    (N'Pre-approval', N'LD-00091533'),
    (N'Pre-approval', N'LD-00091529'),
    (N'Pre-approval', N'LD-00091528'),
    (N'Pre-approval', N'LD-00091518'),
    (N'Pre-approval', N'LD-00091502'),
    (N'Pre-approval', N'LD-00091485'),
    (N'Pre-approval', N'LD-00091481'),
    (N'Pre-approval', N'LD-00091460'),
    (N'Pre-approval', N'LD-00091454'),
    (N'Pre-approval', N'LD-00091453'),
    (N'Pre-approval', N'LD-00091445'),
    (N'Pre-approval', N'LD-00091444'),
    (N'Pre-approval', N'LD-00091431'),
    (N'Pre-approval', N'LD-00091429'),
    (N'Pre-approval', N'LD-00091426'),
    (N'Pre-approval', N'LD-00091424'),
    (N'Pre-approval', N'LD-00091421'),
    (N'Pre-approval', N'LD-00091420'),
    (N'Pre-approval', N'LD-00091417'),
    (N'Pre-approval', N'LD-00091416'),
    (N'Pre-approval', N'LD-00091413'),
    (N'Pre-approval', N'LD-00091412'),
    (N'Pre-approval', N'LD-00091408'),
    (N'Pre-approval', N'LD-00091406'),
    (N'Pre-approval', N'LD-00091404'),
    (N'Pre-approval', N'LD-00091401'),
    (N'Pre-approval', N'LD-00091399'),
    (N'Pre-approval', N'LD-00091395'),
    (N'Pre-approval', N'LD-00106168'),
    (N'Pre-approval', N'LD-00091285'),
    (N'Pre-approval', N'LD-00091367'),
    (N'Pre-approval', N'LD-00091365'),
    (N'Pre-approval', N'LD-00091350'),
    (N'Pre-approval', N'LD-00091353'),
    (N'Pre-approval', N'LD-00091348'),
    (N'Pre-approval', N'LD-00091344'),
    (N'Pre-approval', N'LD-00091340'),
    (N'Pre-approval', N'LD-00127504'),
    (N'Pre-approval', N'LD-00127503'),
    (N'Pre-approval', N'LD-00127501'),
    (N'Pre-approval', N'LD-00127499'),
    (N'Pre-approval', N'LD-00127497'),
    (N'Pre-approval', N'LD-00127494'),
    (N'Pre-approval', N'LD-00127493'),
    (N'Pre-approval', N'LD-00127492'),
    (N'Pre-approval', N'LD-00127491'),
    (N'Pre-approval', N'LD-00127490'),
    (N'Pre-approval', N'LD-00127489'),
    (N'Pre-approval', N'LD-00127488'),
    (N'Pre-approval', N'LD-00127486'),
    (N'Pre-approval', N'LD-00127485'),
    (N'Pre-approval', N'LD-00127483'),
    (N'Pre-approval', N'LD-00127478'),
    (N'Pre-approval', N'LD-00127477'),
    (N'Pre-approval', N'LD-00127476'),
    (N'Pre-approval', N'LD-00127472'),
    (N'Pre-approval', N'LD-00127471'),
    (N'Pre-approval', N'LD-00127470'),
    (N'Pre-approval', N'LD-00127467'),
    (N'Pre-approval', N'LD-00127465'),
    (N'Pre-approval', N'LD-00127462'),
    (N'Pre-approval', N'LD-00127457'),
    (N'Pre-approval', N'LD-00127455'),
    (N'Pre-approval', N'LD-00127452'),
    (N'Pre-approval', N'LD-00127449'),
    (N'Pre-approval', N'LD-00127448'),
    (N'Pre-approval', N'LD-00127446'),
    (N'Pre-approval', N'LD-00127445'),
    (N'Pre-approval', N'LD-00127443'),
    (N'Pre-approval', N'LD-00127441'),
    (N'Pre-approval', N'LD-00127439'),
    (N'Pre-approval', N'LD-00127438'),
    (N'Pre-approval', N'LD-00127436'),
    (N'Pre-approval', N'LD-00127435'),
    (N'Pre-approval', N'LD-00127432'),
    (N'Pre-approval', N'LD-00127431'),
    (N'Pre-approval', N'LD-00127430'),
    (N'Pre-approval', N'LD-00127429'),
    (N'Pre-approval', N'LD-00127428'),
    (N'Pre-approval', N'LD-00127427'),
    (N'Pre-approval', N'LD-00127426'),
    (N'Pre-approval', N'LD-00127425'),
    (N'Pre-approval', N'LD-00127422'),
    (N'Pre-approval', N'LD-00127421'),
    (N'Pre-approval', N'LD-00127418'),
    (N'Pre-approval', N'LD-00127417'),
    (N'Pre-approval', N'LD-00127416');

;WITH RankedLeads AS
(
    SELECT
        RequestedGroup,
        LeadNo,
        ROW_NUMBER() OVER (PARTITION BY RequestedGroup ORDER BY InputOrder) AS GroupRow
    FROM @RegressionLeads
),
SelectedLeads AS
(
    SELECT RequestedGroup, LeadNo FROM RankedLeads WHERE RequestedGroup=N'Start reference'
    UNION ALL
    SELECT RequestedGroup, LeadNo FROM RankedLeads WHERE RequestedGroup=N'Non-Pre-approval' AND GroupRow <= 34
    UNION ALL
    SELECT RequestedGroup, LeadNo FROM RankedLeads WHERE RequestedGroup=N'Pre-approval' AND GroupRow <= 35
)
SELECT TOP (70)
    supplied.RequestedGroup,
    supplied.LeadNo,
    CASE WHEN ld.Lead_No IS NULL THEN N'Not found' ELSE N'Found' END AS LeadRecordStatus,
    CASE WHEN ldp.property_projectid = N'PRE_APPROVAL' THEN N'Pre-approval' ELSE N'Non-pre-approval' END AS ActualProjectScenario,
    ldf.lead_product AS ProductType,
    ldf.LEAD_FIN_REFINANCETYPE AS ProductSubType,
    ld.CUSTOMER_RES_TYPE AS ResidencyType,
    CASE WHEN ISNULL(ldo.staffyn, N'') IN (N'', N'0') THEN N'No' ELSE ldo.staffyn END AS StaffYN,
    ldo.Relationship_with_bank AS RelationshipWithBank,
    ld.Lead_Source_OF_Submission AS SourceSubmission,
    ldp.property_projectid AS ProjectId,
    ldp.Property_DeveloperName AS DeveloperName,
    ldf.finance_amount AS FinanceAmount,
    ldf.lead_fin_Equity_amt AS EquityReleaseAmount,
    ldf.MBRE_AMOUNT AS GHPAmount_MBRE,
    ldf.lead_fin_promotiontype AS PromotionName,
    promotion.DiscountPerc AS PromotionDiscountPercent,
    promotion.Status AS PromotionMasterStatus,
    promotionConfig.IsEnabled AS PromotionConfigEnabled,
    promotionConfig.UseMasterDiscount,
    promotionConfig.SkipMinFee,
    promotionConfig.SkipMaxFee,
    feeMaster.FEE_FV,
    feeMaster.FEE_Equity,
    feeMaster.FEE_MBRE,
    feeMaster.MIN_FEE,
    feeMaster.MAX_FEE,
    feeMaster.Status AS FeeMasterStatus,
    feeMaster.Is_VAT_Applicable
FROM SelectedLeads supplied
LEFT JOIN dbo.LEAD_DETAILS ld ON ld.LEAD_NO = supplied.LeadNo
LEFT JOIN dbo.LEAD_DETAILS_FINANCE ldf ON ldf.LEAD_NO = supplied.LeadNo
LEFT JOIN dbo.LEAD_DETAILS_OTHERS ldo ON ldo.LEAD_NO = supplied.LeadNo
LEFT JOIN dbo.LEAD_DETAILS_PROPERTY ldp ON ldp.LEAD_NO = supplied.LeadNo
OUTER APPLY
(
    SELECT TOP (1) pm.DiscountPerc, pm.Status, pm.StartDate, pm.EndDate
    FROM dbo.Lead_Promotion_master pm
    WHERE pm.PromotionName = ldf.lead_fin_promotiontype
    ORDER BY CASE WHEN pm.Status = N'A' THEN 0 ELSE 1 END, pm.SRNO DESC
) promotion
OUTER APPLY
(
    SELECT TOP (1) pc.IsEnabled, pc.UseMasterDiscount, pc.SkipMinFee, pc.SkipMaxFee
    FROM dbo.LEAD_ARR_FEE_PROMOTION_CONFIG pc
    WHERE pc.PromotionName = ldf.lead_fin_promotiontype
) promotionConfig
OUTER APPLY
(
    SELECT TOP (1)
        fm.FEE_FV, fm.FEE_OPV, fm.FEE_APV, fm.FEE_Buyout, fm.FEE_Topup,
        fm.FEE_Equity, fm.FEE_Cashout, fm.FEE_MBRE, fm.FEE_APP, fm.FEE_ACC,
        fm.MIN_FEE, fm.MAX_FEE, fm.Status, fm.Is_VAT_Applicable
    FROM dbo.LEAD_ARR_FEE_MASTER fm
    WHERE fm.PRODUCT_TYPE = ldf.lead_product
      AND fm.Product_SubTYPE = ldf.LEAD_FIN_REFINANCETYPE
      AND fm.Residency_Type = ld.CUSTOMER_RES_TYPE
      AND fm.Staff = CASE WHEN ISNULL(ldo.staffyn, N'') IN (N'', N'0') THEN N'No' ELSE ldo.staffyn END
    ORDER BY CASE WHEN ISNULL(fm.Status, N'A') = N'A' THEN 0 ELSE 1 END
) feeMaster
ORDER BY
    CASE supplied.RequestedGroup WHEN N'Start reference' THEN 0 WHEN N'Non-Pre-approval' THEN 1 ELSE 2 END,
    supplied.LeadNo;
