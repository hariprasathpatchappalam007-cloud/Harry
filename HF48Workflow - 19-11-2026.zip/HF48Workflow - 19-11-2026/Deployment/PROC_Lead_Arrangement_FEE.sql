ALTER proc [dbo].[PROC_Lead_Arrangement_FEE]
@REFNO nvarchar(100)=null
as
BEGIN
	set quoted_identifier off
	create table #List
	(
	PRODUCT_TYPE nvarchar(150), Product_SubTYPE nvarchar(150), Residency_Type nvarchar(100), StaffYN nvarchar(100),
	promotiontype nvarchar(100), FEE_FV numeric(20,4), FEE_OPV numeric(20,4), FEE_APV numeric(20,4),
	FEE_Buyout numeric(20,4), FEE_Topup numeric(20,4), FEE_Equity numeric(20,4), FEE_Cashout numeric(20,4),
	FEE_MBRE numeric(20,4), AMT_FV numeric(20,4), AMT_OPV numeric(20,4), AMT_APV numeric(20,4),
	AMT_Buyout numeric(20,4), AMT_Topup numeric(20,4), AMT_Equity numeric(20,4), AMT_Cashout numeric(20,4),
	AMT_MBRE numeric(20,4), FEE_APP numeric(20,2), FEE_ACC numeric(20,2), MIN_FEE numeric(20,2),
	MAX_FEE numeric(20,2), ARRANGEMENT_FEE_APP numeric(20,2), ARRANGEMENT_FEE_ACC numeric(20,2),
	ARRANGEMENT_FEE numeric(20,2), RECCOUNT int,
	Remarks nvarchar(100), ErrorMsg nvarchar(200)
	)

	declare @found int
	declare @Employment_Type nvarchar(100)
	declare @PRODUCT_TYPE nvarchar(100)
	declare @Product_SubTYPE nvarchar(100)
	declare @CUSTOMER_RES_TYPE nvarchar(100)
	declare @FEE_FV numeric(20,4)
	declare @FEE_OPV numeric(20,4)
	declare @FEE_APV numeric(20,4)
	declare @FEE_Buyout numeric(20,4)
	declare @FEE_Topup numeric(20,4)
	declare @FEE_Equity numeric(20,4)
	declare @FEE_Cashout numeric(20,4)
	declare @FEE_MBRE numeric(20,4)
	declare @FEE_APP numeric(20,2)
	declare @FEE_ACC numeric(20,2)
	declare @MIN_FEE numeric(20,2)
	declare @MAX_FEE numeric(20,2)

	declare @AMT_FV numeric(20,4)
	declare @AMT_OPV numeric(20,4)
	declare @AMT_APV numeric(20,4)
	declare @AMT_Buyout numeric(20,4)
	declare @AMT_Topup numeric(20,4)
	declare @AMT_Equity numeric(20,4)
	declare @AMT_Cashout numeric(20,4)
	declare @AMT_MBRE numeric(20,4)

	declare @CAL_AMT_FV numeric(20,4)
	declare @CAL_AMT_OPV numeric(20,4)
	declare @CAL_AMT_APV numeric(20,4)
	declare @CAL_AMT_Buyout numeric(20,4)
	declare @CAL_AMT_Topup numeric(20,4)
	declare @CAL_AMT_Equity numeric(20,4)
	declare @CAL_AMT_Cashout numeric(20,4)
	declare @CAL_AMT_MBRE numeric(20,4)
	declare @ARRANGEMENT_FEE_APP numeric(20,2)
	declare @ARRANGEMENT_FEE_ACC numeric(20,2)
	declare @ARRANGEMENT_FEE numeric(20,2)
	declare @promotiontype nvarchar(100)
	declare @Is_VAT_Applicable Bit
	declare @Relationship_with_bank nvarchar(100)
	declare @STLRateApplicable bit = 0
	declare @STLFeeRate numeric(20,4)

	select
		@PRODUCT_TYPE = lead_product,
		@Product_SubTYPE = LEAD_FIN_REFINANCETYPE,
		@AMT_FV=isnull(finance_amount,0),
		@AMT_OPV = isnull(lead_prop_org_value,0),
		@AMT_APV = isnull(lead_prop_appr_value,0),
		@AMT_Buyout=isnull(lead_fin_buyout_repay_amt,0),
		@AMT_Topup=isnull(lead_fin_topup_amt,0),
		@AMT_Equity=isnull(lead_fin_Equity_amt,0),
		@AMT_Cashout=isnull(lead_fin_cashout_amt,0),
		@AMT_MBRE = isnull(MBRE_AMOUNT,0),
		@promotiontype = lead_fin_promotiontype
	from lead_details_finance where lead_no = @REFNO

	declare @StaffYN nvarchar(100)
	select @StaffYN = staffyn,
		@Relationship_with_bank = Relationship_with_bank
	from lead_details_others
	where lead_no = @REFNO
	select @CUSTOMER_RES_TYPE = CUSTOMER_RES_TYPE from lead_details where lead_no = @REFNO

	if isnull(@StaffYN,'') = '' set @StaffYN = 'No'
	if isnull(@StaffYN,'') = '0' set @StaffYN = 'No'

	select @STLRateApplicable = IsApplicable, @STLFeeRate = FeeRate
	from dbo.LEAD_STL_NSTL_FEE_CONFIG
	where RelationshipType = UPPER(LTRIM(RTRIM(ISNULL(@Relationship_with_bank,''))))

	select @Is_VAT_Applicable = isnull(Is_VAT_Applicable,0) from LEAD_ARR_FEE_MASTER
	Where
		PRODUCT_TYPE=@PRODUCT_TYPE and Product_SubTYPE = @Product_SubTYPE and
		Residency_Type = @CUSTOMER_RES_TYPE and Staff = @StaffYN and
		ISNULL(Status,'A')='A'

	select @found=count(1) from LEAD_ARR_FEE_MASTER where PRODUCT_TYPE = @PRODUCT_TYPE
		and Product_SubTYPE = @Product_SubTYPE and Residency_Type = @CUSTOMER_RES_TYPE and Staff = @StaffYN
		and ISNULL(Status,'A')='A'
	--Madesh Made changes on 11/7/2021 for UAT fix for product type and product sub type-->added msg

	print 'test1'
	--select @PRODUCT_TYPE, @Product_SubTYPE, @CUSTOMER_RES_TYPE, @StaffYN, @found
	declare @TextError nvarchar(1000)
	if(@Product_SubTYPE='None' or @Product_SubTYPE='0' or @Product_SubTYPE='' or @PRODUCT_TYPE='None' or @PRODUCT_TYPE='' or @PRODUCT_TYPE='0' )
	BEGIN
		set @TextError='Please Update the Product Type and Product Sub Type and process the application'
	END
	else if @found = 0
	begin
		/*
		EXEC sp_addmessage
		@msgnum = 60000,
		@severity = 16,
		@msgtext = 'Arrangement fee not defined, Please contact Product Team',
		@lang = 'us_english',
		@replace= 'replace'
		*/
		declare @Text nvarchar(1000)
		set @text = 'Arrangement fee not defined for product - ' + @PRODUCT_TYPE + ',' + @Product_SubTYPE + '. Please raise this to product team.'
		---changed by rajesh kumar 04/02/2026 -> to fix error message
		RAISERROR (@text,16,1)
		return
	end
	print 'test2'
	select
		@FEE_FV=FEE_FV,
		@FEE_OPV=FEE_OPV,
		@FEE_APV=FEE_APV,
		@FEE_Buyout=FEE_Buyout,
		@FEE_Topup=FEE_Topup,
		@FEE_Equity=FEE_Equity,
		@FEE_Cashout=FEE_Cashout,
		@FEE_MBRE=FEE_MBRE,
		@FEE_APP=FEE_APP,
		@FEE_ACC=FEE_ACC,
		@MIN_FEE=MIN_FEE,
		@MAX_FEE=MAX_FEE
	from LEAD_ARR_FEE_MASTER where PRODUCT_TYPE = @PRODUCT_TYPE and Product_SubTYPE = @Product_SubTYPE and Residency_Type = @CUSTOMER_RES_TYPE and Staff = @StaffYN
		and ISNULL(Status,'A')='A'
	print 'test3'
	print 'test4'

	begin
		set @CAL_AMT_FV = (@FEE_FV/100) * @AMT_FV
		set @CAL_AMT_OPV = (@FEE_OPV/100) * @AMT_OPV
		set @CAL_AMT_APV = (@FEE_APV/100) * @AMT_APV
		set @CAL_AMT_Buyout = (@FEE_Buyout/100) * @AMT_Buyout
		set @CAL_AMT_Topup = (@FEE_Topup/100) * @AMT_Topup
		set @CAL_AMT_Equity = (@FEE_Equity/100) * @AMT_Equity
		set @CAL_AMT_Cashout = (@FEE_Cashout/100) * @AMT_Cashout
		set @CAL_AMT_MBRE = (@FEE_MBRE/100) * @AMT_MBRE

		set @ARRANGEMENT_FEE = @CAL_AMT_FV + @CAL_AMT_OPV + @CAL_AMT_APV + @CAL_AMT_Buyout + @CAL_AMT_Topup + @CAL_AMT_Equity + @CAL_AMT_Cashout + @CAL_AMT_MBRE

		if @ARRANGEMENT_FEE < @MIN_FEE
			set @ARRANGEMENT_FEE = @MIN_FEE

		if @ARRANGEMENT_FEE > @MAX_FEE
			set @ARRANGEMENT_FEE = @MAX_FEE

		set @ARRANGEMENT_FEE_APP = @ARRANGEMENT_FEE * (@FEE_APP /100)
		set @ARRANGEMENT_FEE_ACC = @ARRANGEMENT_FEE * (@FEE_ACC /100)
	end

	if ISNULL(@STLRateApplicable,0) = 1
	begin
		set @FEE_FV = @STLFeeRate
		set @ARRANGEMENT_FEE = (@AMT_FV * @STLFeeRate) / 100
		set @ARRANGEMENT_FEE_APP = @ARRANGEMENT_FEE * (@FEE_APP / 100)
		set @ARRANGEMENT_FEE_ACC = @ARRANGEMENT_FEE - @ARRANGEMENT_FEE_APP
	end

	declare @DiscountPerc numeric(20,2)
	declare @Temp_ARRANGEMENT_FEE numeric(20,2)

	set @DiscountPerc = 0
	if ISNULL(@STLRateApplicable,0) = 0
	begin
		select top 1 @DiscountPerc = ISNULL(DiscountPerc,0)
		from Lead_Promotion_master
		where PromotionName = @promotiontype
			and ISNULL(Status,'A') = 'A'
			and (StartDate IS NULL OR StartDate <= GETDATE())
			and (EndDate IS NULL OR EndDate >= GETDATE())
		order by SRNO desc

		set @Temp_ARRANGEMENT_FEE = @ARRANGEMENT_FEE - (@ARRANGEMENT_FEE * @DiscountPerc / 100)
		set @ARRANGEMENT_FEE = @Temp_ARRANGEMENT_FEE
		set @ARRANGEMENT_FEE_ACC = @Temp_ARRANGEMENT_FEE - @ARRANGEMENT_FEE_APP
	end

	--START ---------------------------------------------------------------------------

	--10-12-2017 Raheel Ahmed > VAT Implementation

	if @Is_VAT_Applicable = 1
	Begin
		Declare @VAT_Percentage numeric(20,5)
		select @VAT_Percentage = displayvalue from frm_gnarr where code = 'LEAD_CONSTANT' and [Value] = 'VAT_PERCENTAGE'

		print 'BEFORE VAT'
		print @ARRANGEMENT_FEE
		print @ARRANGEMENT_FEE_APP
		print @ARRANGEMENT_FEE_ACC

		--Check Is_VAT_Applicable for product and sub product
		set @ARRANGEMENT_FEE = @ARRANGEMENT_FEE + (@ARRANGEMENT_FEE * (@VAT_Percentage/100.0))
		set @ARRANGEMENT_FEE_APP = @ARRANGEMENT_FEE_APP + (@ARRANGEMENT_FEE_APP * (@VAT_Percentage/100.0))
		set @ARRANGEMENT_FEE_ACC = @ARRANGEMENT_FEE_ACC + (@ARRANGEMENT_FEE_ACC * (@VAT_Percentage/100.0))

		print 'AFTER VAT'
		print @VAT_Percentage
		print @ARRANGEMENT_FEE
		print @ARRANGEMENT_FEE_APP
		print @ARRANGEMENT_FEE_ACC
	End

	--END -----------------------------------------------------------------------------

	insert into #List(
		PRODUCT_TYPE,
		Product_SubTYPE,
		Residency_Type,
		StaffYN,
		promotiontype,

		FEE_FV,
		FEE_OPV,
		FEE_APV,
		FEE_Buyout,
		FEE_Topup,
		FEE_Equity,
		FEE_Cashout,
		FEE_MBRE,

		AMT_FV,
		AMT_OPV,
		AMT_APV,
		AMT_Buyout,
		AMT_Topup,
		AMT_Equity,
		AMT_Cashout,
		AMT_MBRE,

		FEE_APP,
		FEE_ACC,
		MIN_FEE,
		MAX_FEE,
		ARRANGEMENT_FEE_APP,
		ARRANGEMENT_FEE_ACC,
		ARRANGEMENT_FEE,
		RECCOUNT,
		Remarks,
		--Madesh Made changes on 11/7/2021 for UAT fix for product type and product sub type-->added msg
		ErrorMsg
	)
	values(
		@PRODUCT_TYPE,
		@Product_SubTYPE,
		@CUSTOMER_RES_TYPE,
		@StaffYN,
		@promotiontype,

		@FEE_FV,
		@FEE_OPV,
		@FEE_APV,
		@FEE_Buyout,
		@FEE_Topup,
		@FEE_Equity,
		@FEE_Cashout,
		@FEE_MBRE,

		@AMT_FV,
		@AMT_OPV,
		@AMT_APV,
		@AMT_Buyout,
		@AMT_Topup,
		@AMT_Equity,
		@AMT_Cashout,
		@AMT_MBRE,

		@FEE_APP,
		@FEE_ACC,
		@MIN_FEE,
		@MAX_FEE,
		isnull(@ARRANGEMENT_FEE_APP,0),
		isnull(@ARRANGEMENT_FEE_ACC,0),
		isnull(@ARRANGEMENT_FEE,0),
		null,
		null,
		--Madesh Made changes on 11/7/2021 for UAT fix for product type and product sub type-->added msg
		@TextError
	)

	select * from #list
	Drop table #list

END
