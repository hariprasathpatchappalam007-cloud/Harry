using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class ArrangementFeeRegression : Page
    {
        private const int MaxCases = 70;
        private const int MaxMatrixCases = 100;
        private const string ResultsSessionKey = "ArrangementFeeRegressionResults";
        private bool _isFileDownload;
        private static readonly string DefaultLeadCases = String.Join(Environment.NewLine, new string[]
        {
            "LD-00126494", "LD-00126500", "LD-00126503", "LD-00126508", "LD-00126511", "LD-00126519", "LD-00126522",
            "LD-00126528", "LD-00126531", "LD-00126532", "LD-00126537", "LD-00126539", "LD-00126544", "LD-00126545",
            "LD-00126546", "LD-00126550", "LD-00126551", "LD-00126555", "LD-00126557", "LD-00126558", "LD-00126562",
            "LD-00126563", "LD-00126571", "LD-00126572", "LD-00126577", "LD-00126578", "LD-00126580", "LD-00126584",
            "LD-00126585", "LD-00126587", "LD-00126589", "LD-00126590", "LD-00126592", "LD-00126593", "LD-00091404",
            "LD-00091406", "LD-00091408", "LD-00091412", "LD-00091413", "LD-00091416", "LD-00091417", "LD-00091420",
            "LD-00091421", "LD-00091424", "LD-00091426", "LD-00091429", "LD-00091431", "LD-00091444", "LD-00091445",
            "LD-00091453", "LD-00091454", "LD-00091460", "LD-00091481", "LD-00091485", "LD-00091502", "LD-00091518",
            "LD-00091528", "LD-00091529", "LD-00091533", "LD-00091536", "LD-00091540", "LD-00091541", "LD-00091729",
            "LD-00091741", "LD-00091754", "LD-00091764", "LD-00091786", "LD-00091787", "LD-00091794"
        });

        private string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtLeadCases.Text = DefaultLeadCases;
                txtFixtureLead.Text = String.Empty;
                BindResults(Session[ResultsSessionKey] as DataTable);
            }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (!_isFileDownload) base.Render(writer);
        }

        protected void Run_Click(object sender, EventArgs e)
        {
            try
            {
                List<RegressionCase> cases = ParseCases(txtLeadCases.Text);
                if (cases.Count == 0) throw new ArgumentException("Enter at least one lead number.");

                DataTable results = null;
                DataTable failures = CreateFailureTable();
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();
                    foreach (RegressionCase testCase in cases)
                    {
                        try
                        {
                            DataTable result = ExecuteProcedure(connection, null, testCase.LeadNo, testCase.Scenario);
                            if (result.Rows.Count == 0) throw new InvalidOperationException("The procedure returned no rows.");
                            if (results == null)
                            {
                                results = result.Clone();
                                results.Columns.Add("RunStatus", typeof(string));
                                results.Columns.Add("RunError", typeof(string));
                            }
                            foreach (DataRow sourceRow in result.Rows)
                            {
                                DataRow targetRow = results.NewRow();
                                foreach (DataColumn column in result.Columns)
                                    targetRow[column.ColumnName] = sourceRow[column.ColumnName];
                                targetRow["RunStatus"] = "Success";
                                targetRow["RunError"] = String.Empty;
                                results.Rows.Add(targetRow);
                            }
                        }
                        catch (Exception ex)
                        {
                            DataRow failure = failures.NewRow();
                            failure["Lead_No"] = testCase.LeadNo;
                            failure["Scenario"] = testCase.Scenario;
                            failure["RunStatus"] = "Error";
                            failure["RunError"] = ex.Message;
                            failures.Rows.Add(failure);
                        }
                    }
                }

                if (results == null)
                {
                    results = failures;
                }
                else
                {
                    foreach (DataRow failure in failures.Rows)
                    {
                        DataRow targetRow = results.NewRow();
                        if (results.Columns.Contains("Lead_No")) targetRow["Lead_No"] = failure["Lead_No"];
                        if (results.Columns.Contains("Scenario")) targetRow["Scenario"] = failure["Scenario"];
                        targetRow["RunStatus"] = failure["RunStatus"];
                        targetRow["RunError"] = failure["RunError"];
                        results.Rows.Add(targetRow);
                    }
                }

                Session[ResultsSessionKey] = results;
                gvResults.PageIndex = 0;
                BindResults(results);
                int errorCount = failures.Rows.Count;
                ShowMessage(cases.Count.ToString(CultureInfo.InvariantCulture) + " case(s) run; " +
                    (cases.Count - errorCount).ToString(CultureInfo.InvariantCulture) + " succeeded, " +
                    errorCount.ToString(CultureInfo.InvariantCulture) + " failed.", errorCount == 0);
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, false);
            }
        }

        protected void RunMatrix_Click(object sender, EventArgs e)
        {
            try
            {
                Server.ScriptTimeout = 3600;
                string fixtureLead = (txtFixtureLead.Text ?? String.Empty).Trim();
                if (!Regex.IsMatch(fixtureLead, "^LD-[0-9]+$", RegexOptions.IgnoreCase))
                    throw new ArgumentException("Enter a valid fixture lead number.");

                DataTable results = null;
                DataTable failures = CreateFailureTable();
                int caseCount = 0;
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();
                    ValidateFixtureLead(connection, fixtureLead);
                    List<RegressionCase> cases = BuildFullMatrix(connection, fixtureLead);
                    if (cases.Count == 0) throw new InvalidOperationException("No active arrangement-fee rows were found.");
                    if (cases.Count > MaxMatrixCases) throw new InvalidOperationException("Generated matrix exceeds the 100-case safety limit.");

                    foreach (RegressionCase testCase in cases)
                    {
                        caseCount++;
                        try
                        {
                            DataTable procedureResult = ExecuteMatrixCase(connection, testCase);
                            if (procedureResult.Rows.Count == 0) throw new InvalidOperationException("The procedure returned no rows.");
                            if (results == null)
                            {
                                results = procedureResult.Clone();
                                results.Columns.Add("RunStatus", typeof(string));
                                results.Columns.Add("RunError", typeof(string));
                            }
                            foreach (DataRow sourceRow in procedureResult.Rows)
                            {
                                DataRow targetRow = results.NewRow();
                                foreach (DataColumn column in procedureResult.Columns)
                                    targetRow[column.ColumnName] = sourceRow[column.ColumnName];
                                targetRow["RunStatus"] = "Success";
                                targetRow["RunError"] = String.Empty;
                                results.Rows.Add(targetRow);
                            }
                        }
                        catch (Exception ex)
                        {
                            DataRow failure = failures.NewRow();
                            failure["Lead_No"] = fixtureLead;
                            failure["Scenario"] = testCase.Scenario;
                            failure["RunStatus"] = "Error";
                            failure["RunError"] = ex.Message;
                            failures.Rows.Add(failure);
                        }
                    }
                }

                results = MergeFailures(results, failures);
                Session[ResultsSessionKey] = results;
                gvResults.PageIndex = 0;
                BindResults(results);
                ShowMessage(caseCount.ToString(CultureInfo.InvariantCulture) + " matrix case(s) run; " +
                    (caseCount - failures.Rows.Count).ToString(CultureInfo.InvariantCulture) + " succeeded, " +
                    failures.Rows.Count.ToString(CultureInfo.InvariantCulture) + " failed. Each fixture change was rolled back.",
                    failures.Rows.Count == 0);
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, false);
            }
        }

        private void ValidateFixtureLead(SqlConnection connection, string leadNo)
        {
            const string query = @"
SELECT CASE WHEN EXISTS (SELECT 1 FROM dbo.LEAD_DETAILS_FINANCE WHERE Lead_No=@LeadNo)
 AND EXISTS (SELECT 1 FROM dbo.LEAD_DETAILS WHERE Lead_No=@LeadNo)
 AND EXISTS (SELECT 1 FROM dbo.LEAD_DETAILS_OTHERS WHERE Lead_No=@LeadNo)
 AND EXISTS (SELECT 1 FROM dbo.LEAD_DETAILS_PROPERTY WHERE Lead_No=@LeadNo)
 THEN 1 ELSE 0 END;";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.Add("@LeadNo", SqlDbType.NVarChar, 100).Value = leadNo;
                if (Convert.ToInt32(command.ExecuteScalar(), CultureInfo.InvariantCulture) != 1)
                    throw new ArgumentException("Fixture lead must have finance, customer, others and property rows.");
            }
        }

        private List<RegressionCase> BuildFullMatrix(SqlConnection connection, string fixtureLead)
        {
            DataTable feeRows = ReadTable(connection,
                "SELECT PRODUCT_TYPE,Product_SubTYPE,Residency_Type,Staff " +
                "FROM dbo.LEAD_ARR_FEE_MASTER WHERE ISNULL(Status,N'A')=N'A' " +
                "ORDER BY PRODUCT_TYPE,Product_SubTYPE,Residency_Type,Staff");
            DataTable promotionRows = ReadTable(connection,
                "SELECT PromotionName FROM dbo.Lead_Promotion_master WHERE PromotionName IS NOT NULL AND ISNULL(Status,N'A')=N'A' " +
                "UNION SELECT PromotionName FROM dbo.LEAD_ARR_FEE_PROMOTION_CONFIG WHERE PromotionName IS NOT NULL AND IsEnabled=1 " +
                "UNION SELECT PromotionName FROM dbo.LEAD_ARR_FEE_PROMOTION_RULE WHERE IsEnabled=1 " +
                "ORDER BY PromotionName");
            List<string> promotionNames = new List<string>();
            foreach (DataRow row in promotionRows.Rows)
            {
                string name = Value(row, "PromotionName");
                if (name.Length > 0) promotionNames.Add(name);
            }

            if (promotionNames.Count > 31)
                throw new InvalidOperationException("More than 31 active promotion names are configured; reduce the active set or split the run to stay within 100 cases.");

            List<RegressionCase> cases = new List<RegressionCase>();
            List<DataRow> representatives = SelectMasterRepresentatives(feeRows);
            foreach (DataRow row in representatives)
            {
                cases.Add(CreateMatrixCase(fixtureLead, cases.Count + 1, "MASTER", Value(row, "PRODUCT_TYPE"),
                    Value(row, "Product_SubTYPE"), Value(row, "Residency_Type"), Value(row, "Staff"),
                    "NSTL", "Regular", 1000000m,
                    Value(row, "PRODUCT_TYPE") == "Equity Release" ? 500000m : 0m, 0m,
                    String.Empty, "SELF", "REGRESSION"));
            }

            foreach (string promotionName in promotionNames)
            {
                DataRow promotionFeeRow = SelectPromotionFeeRow(feeRows, promotionName);
                string productType = Value(promotionFeeRow, "PRODUCT_TYPE");
                string subType = Value(promotionFeeRow, "Product_SubTYPE");
                string residency = Value(promotionFeeRow, "Residency_Type");
                string staff = Value(promotionFeeRow, "Staff");
                string relationship = promotionName.IndexOf("NSTL", StringComparison.OrdinalIgnoreCase) >= 0
                    ? "NSTL"
                    : promotionName.IndexOf("STL", StringComparison.OrdinalIgnoreCase) >= 0 ? "STL" : "NSTL";
                string source = promotionName.StartsWith("Aggregator-", StringComparison.OrdinalIgnoreCase) ? "AGGREGATOR" : "SELF";
                string conversionProduct = promotionName.IndexOf("DIB Sustainable", StringComparison.OrdinalIgnoreCase) >= 0 ? "MB-REGRESSION" : "REGRESSION";
                cases.Add(CreateMatrixCase(fixtureLead, cases.Count + 1, "PROMOTION", productType, subType,
                    residency, staff, relationship, "Regular", 1000000m,
                    productType == "Equity Release" ? 500000m : 0m, 0m,
                    promotionName, source, conversionProduct));
            }

            string[] preApprovalPromotionNames = new string[]
            {
                "Processing Fee Promotion", "Processing Fee Promotion 0.50%", "APC Promotion",
                "TopUp Promotion", "Aggregator-NSTL-Equity Release", "Abu Dhabi Promotion"
            };
            foreach (string promotionName in preApprovalPromotionNames)
            {
                DataRow promotionFeeRow = SelectPromotionFeeRow(feeRows, promotionName);
                string productType = Value(promotionFeeRow, "PRODUCT_TYPE");
                string relationship = promotionName.IndexOf("STL", StringComparison.OrdinalIgnoreCase) >= 0
                    && promotionName.IndexOf("NSTL", StringComparison.OrdinalIgnoreCase) < 0 ? "STL" : "NSTL";
                string source = promotionName.StartsWith("Aggregator-", StringComparison.OrdinalIgnoreCase) ? "AGGREGATOR" : "SELF";
                cases.Add(CreateMatrixCase(fixtureLead, cases.Count + 1, "PROMOTION-PRE-APPROVAL", productType,
                    Value(promotionFeeRow, "Product_SubTYPE"), Value(promotionFeeRow, "Residency_Type"),
                    Value(promotionFeeRow, "Staff"), relationship, "PRE_APPROVAL", 1000000m,
                    productType == "Equity Release" ? 500000m : 0m, 0m,
                    promotionName, source, "REGRESSION"));
            }

            DataRow standardResident = SelectFeeRow(feeRows, "Standard Ijara", "Standard", "Resident", "No");
            DataRow standardNonResident = SelectFeeRow(feeRows, "Standard Ijara", "Standard", "Non-Resident", "No");
            DataRow standardStaff = SelectFeeRow(feeRows, "Standard Ijara", "Standard", "Resident", "Yes");
            DataRow equityFinal = SelectFeeRow(feeRows, "Equity Release", "Final Payment", "Resident", "No");
            DataRow equityNonResident = SelectFeeRow(feeRows, "Equity Release", "Final Payment", "Non-Resident", "No");
            DataRow equityTopupStaff = SelectFeeRow(feeRows, "Equity Release", "Topup", "Resident", "Yes");
            DataRow equityFinalStaff = SelectFeeRow(feeRows, "Equity Release", "Final Payment", "Resident", "Yes");

            AddMatrixCase(cases, fixtureLead, "AXIS|NSTL|Regular", standardResident, "NSTL", "Regular", 1000000m, 0m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "AXIS|STL|Regular", standardResident, "STL", "Regular", 1000000m, 0m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "AXIS|NSTL|PreApproval", standardResident, "NSTL", "PRE_APPROVAL", 1000000m, 0m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "AXIS|STL|PreApproval", standardResident, "STL", "PRE_APPROVAL", 1000000m, 0m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "CAP|NSTL|Resident|Minimum", standardResident, "NSTL", "Regular", 100000m, 0m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "CAP|NSTL|Resident|Maximum", standardResident, "NSTL", "Regular", 20000000m, 0m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "CAP|NSTL|NonResident|NoMax", standardNonResident, "NSTL", "Regular", 20000000m, 0m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "CAP|NSTL|CompanyResident", SelectFeeRow(feeRows, "Standard Ijara", "Standard", "Resident - Company", "No"), "NSTL", "Regular", 20000000m, 0m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "ER|NonAggregator|NSTL|Minimum", equityFinal, "NSTL", "Regular", 100000m, 100000m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "ER|NonAggregator|NSTL|AboveMinimum", equityFinal, "NSTL", "Regular", 1000000m, 1000000m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "ER|NonAggregator|NonResident|NoMax", equityNonResident, "NSTL", "Regular", 20000000m, 20000000m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "ER|Aggregator|NSTL|Minimum", equityFinal, "NSTL", "Regular", 100000m, 100000m, 0m, "Aggregator-NSTL-Equity Release", "AGGREGATOR", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "ER|Aggregator|NSTL|AboveMinimum", equityFinal, "NSTL", "Regular", 1000000m, 1000000m, 0m, "Aggregator-NSTL-Equity Release", "AGGREGATOR", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "GHP|NSTL|Nil", standardResident, "NSTL", "Regular", 1000000m, 0m, 100000m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "GHP|STL|Nil", standardResident, "STL", "Regular", 1000000m, 0m, 100000m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "ER|Aggregator|STL|GHP", equityFinal, "STL", "Regular", 1000000m, 1000000m, 100000m, "Aggregator-STL-Equity Release", "AGGREGATOR", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "ER|Aggregator|NSTL|GHP", equityFinal, "NSTL", "Regular", 1000000m, 1000000m, 100000m, "Aggregator-NSTL-Equity Release", "AGGREGATOR", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "ER|Aggregator|AbuDhabiExclusion", equityFinal, "NSTL", "Regular", 1000000m, 1000000m, 0m, "Abu Dhabi Promotion", "AGGREGATOR", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "STAFF|Standard|NSTL", standardStaff, "NSTL", "Regular", 1000000m, 0m, 0m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "STAFF|EquityReleaseTopup|NSTL", equityTopupStaff, "NSTL", "Regular", 1000000m, 500000m, 0m, "TopUp Promotion", "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "STAFF|GHP|NSTL", standardStaff, "NSTL", "Regular", 1000000m, 0m, 100000m, String.Empty, "SELF", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "STAFF|EquityReleaseGHP|AggregatorNSTL", equityTopupStaff, "NSTL", "Regular", 1000000m, 500000m, 100000m, "Aggregator-NSTL-Equity Release", "AGGREGATOR", "REGRESSION");
            AddMatrixCase(cases, fixtureLead, "STAFF|EquityRelease|NSTL", equityFinalStaff, "NSTL", "Regular", 1000000m, 500000m, 0m, String.Empty, "SELF", "REGRESSION");

            string[] conversionPrefixes = new string[] { "MB", "NB", "TW" };
            string[] sustainablePromotions = new string[] { "DIB Sustainable STL Promotion", "DIB Sustainable NSTL Promotion" };
            foreach (string promotionName in sustainablePromotions)
            foreach (string prefix in conversionPrefixes)
            {
                AddMatrixCase(cases, fixtureLead, "CONVERSION|" + promotionName + "|" + prefix, standardResident,
                    promotionName.IndexOf(" NSTL ", StringComparison.OrdinalIgnoreCase) >= 0 ? "NSTL" : "STL",
                    "Regular", 1000000m, 0m, 0m, promotionName, "SELF", prefix + "-REGRESSION");
            }

            if (cases.Count > MaxMatrixCases)
                throw new InvalidOperationException("The selected matrix design exceeds the 100-case limit.");
            return cases;
        }

        private static List<DataRow> SelectMasterRepresentatives(DataTable feeRows)
        {
            Dictionary<string, List<DataRow>> groups = new Dictionary<string, List<DataRow>>(StringComparer.OrdinalIgnoreCase);
            List<string> groupOrder = new List<string>();
            foreach (DataRow row in feeRows.Rows)
            {
                string key = Value(row, "PRODUCT_TYPE") + "|" + Value(row, "Product_SubTYPE");
                if (!groups.ContainsKey(key))
                {
                    groups[key] = new List<DataRow>();
                    groupOrder.Add(key);
                }
                groups[key].Add(row);
            }

            List<DataRow> selected = new List<DataRow>();
            HashSet<string> selectedKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string key in groupOrder)
            {
                List<DataRow> rows = groups[key];
                DataRow preferred = FindRow(rows, "Resident", "No");
                if (preferred == null) preferred = FindRow(rows, null, "No");
                if (preferred == null && rows.Count > 0) preferred = rows[0];
                if (preferred != null && selectedKeys.Add(MasterRowKey(preferred)))
                    selected.Add(preferred);
            }

            foreach (DataRow row in feeRows.Rows)
            {
                if (selectedKeys.Add(MasterRowKey(row))) selected.Add(row);
            }
            return selected;
        }

        private static DataRow FindRow(List<DataRow> rows, string residency, string staff)
        {
            foreach (DataRow row in rows)
            {
                if ((residency == null || String.Equals(Value(row, "Residency_Type"), residency, StringComparison.OrdinalIgnoreCase)) &&
                    String.Equals(Value(row, "Staff"), staff, StringComparison.OrdinalIgnoreCase)) return row;
            }
            return null;
        }

        private static string MasterRowKey(DataRow row)
        {
            return Value(row, "PRODUCT_TYPE") + "|" + Value(row, "Product_SubTYPE") + "|" +
                Value(row, "Residency_Type") + "|" + Value(row, "Staff");
        }

        private static DataRow SelectPromotionFeeRow(DataTable feeRows, string promotionName)
        {
            string productType = "Standard Ijara";
            string subType = "Standard";
            if (promotionName.IndexOf("Abu Dhabi", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                subType = "Final Payment";
            }
            else if (promotionName.IndexOf("TopUp", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                productType = "Equity Release";
                subType = "Topup";
            }
            else if (promotionName.IndexOf("APC", StringComparison.OrdinalIgnoreCase) >= 0 ||
                promotionName.IndexOf("Aggregator", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                productType = "Equity Release";
                subType = "Final Payment";
            }
            else if (promotionName.IndexOf("Buyout", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                productType = "Standard Ijara";
                subType = "Buyout";
            }
            else if (promotionName.IndexOf("OPF", StringComparison.OrdinalIgnoreCase) >= 0 ||
                promotionName.IndexOf("SLS", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                productType = "Forward Ijara";
                subType = "OPF";
            }

            DataRow row = SelectFeeRow(feeRows, productType, subType, "Resident", "No");
            if (row == null) row = SelectFeeRow(feeRows, "Standard Ijara", "Standard", "Resident", "No");
            if (row == null) throw new InvalidOperationException("No active fee-master row is available for promotion scenario " + promotionName + ".");
            return row;
        }

        private static DataRow SelectFeeRow(DataTable feeRows, string productType, string subType, string residency, string staff)
        {
            foreach (DataRow row in feeRows.Rows)
            {
                if (String.Equals(Value(row, "PRODUCT_TYPE"), productType, StringComparison.OrdinalIgnoreCase) &&
                    String.Equals(Value(row, "Product_SubTYPE"), subType, StringComparison.OrdinalIgnoreCase) &&
                    String.Equals(Value(row, "Residency_Type"), residency, StringComparison.OrdinalIgnoreCase) &&
                    String.Equals(Value(row, "Staff"), staff, StringComparison.OrdinalIgnoreCase)) return row;
            }
            return null;
        }

        private static void AddMatrixCase(List<RegressionCase> cases, string fixtureLead, string label,
            DataRow masterRow, string relationship, string projectMode, decimal financeAmount,
            decimal equityAmount, decimal ghpAmount, string promotionName, string source, string conversionProduct)
        {
            if (masterRow == null) throw new InvalidOperationException("A fee-master row needed for scenario " + label + " was not found.");
            cases.Add(CreateMatrixCase(fixtureLead, cases.Count + 1, label,
                Value(masterRow, "PRODUCT_TYPE"), Value(masterRow, "Product_SubTYPE"),
                Value(masterRow, "Residency_Type"), Value(masterRow, "Staff"), relationship,
                projectMode, financeAmount, equityAmount, ghpAmount, promotionName, source, conversionProduct));
        }

        private static RegressionCase CreateMatrixCase(string fixtureLead, int caseNumber, string caseKind,
            string productType, string subType, string residency, string staff, string relationship,
            string projectMode, decimal financeAmount, decimal equityAmount, decimal ghpAmount,
            string promotionName, string source, string conversionProduct)
        {
            string projectId = projectMode == "PRE_APPROVAL" ? "PRE_APPROVAL" : String.Empty;
            string scenario = String.Format(CultureInfo.InvariantCulture,
                "M{0:D5}|{1}|{2}/{3}|{4}|{5}|{6}|{7}|{8}|FV={9}", caseNumber, caseKind,
                productType, subType, residency, staff, relationship, projectMode,
                String.IsNullOrEmpty(promotionName) ? "BASE" : promotionName, financeAmount);
            if (scenario.Length > 200) scenario = scenario.Substring(0, 200);
            decimal buyoutAmount = subType.IndexOf("Buyout", StringComparison.OrdinalIgnoreCase) >= 0 ? 500000m : 0m;
            decimal topupAmount = subType.IndexOf("Topup", StringComparison.OrdinalIgnoreCase) >= 0 ? 100000m : 0m;
            decimal cashoutAmount = productType == "Equity Release" && (buyoutAmount > 0 || topupAmount > 0) ? 250000m : 0m;
            return new RegressionCase(fixtureLead, scenario, productType, subType, residency, staff,
                relationship, source, projectId, conversionProduct, promotionName, financeAmount,
                300000m, 350000m, buyoutAmount, topupAmount, equityAmount, cashoutAmount, ghpAmount);
        }

        private static string Value(DataRow row, string column)
        {
            return row[column] == DBNull.Value ? String.Empty : Convert.ToString(row[column], CultureInfo.InvariantCulture);
        }

        private static DataTable MergeFailures(DataTable results, DataTable failures)
        {
            if (results == null) return failures;
            foreach (DataRow failure in failures.Rows)
            {
                DataRow targetRow = results.NewRow();
                if (results.Columns.Contains("Lead_No")) targetRow["Lead_No"] = failure["Lead_No"];
                if (results.Columns.Contains("Scenario")) targetRow["Scenario"] = failure["Scenario"];
                targetRow["RunStatus"] = failure["RunStatus"];
                targetRow["RunError"] = failure["RunError"];
                results.Rows.Add(targetRow);
            }
            return results;
        }

        private DataTable ReadTable(SqlConnection connection, string query)
        {
            DataTable table = new DataTable();
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.CommandTimeout = 120;
                adapter.Fill(table);
            }
            return table;
        }

        private DataTable ExecuteMatrixCase(SqlConnection connection, RegressionCase testCase)
        {
            using (SqlTransaction transaction = connection.BeginTransaction())
            {
                try
                {
                    ApplyFixtureOverrides(connection, transaction, testCase);
                    DataTable result = ExecuteProcedure(connection, transaction, testCase.LeadNo, testCase.Scenario);
                    transaction.Rollback();
                    return result;
                }
                catch
                {
                    try { if (transaction.Connection != null) transaction.Rollback(); }
                    catch { }
                    throw;
                }
            }
        }

        private static void ApplyFixtureOverrides(SqlConnection connection, SqlTransaction transaction, RegressionCase testCase)
        {
            const string updateSql = @"
UPDATE dbo.LEAD_DETAILS_FINANCE
SET lead_product=@ProductType,LEAD_FIN_REFINANCETYPE=@ProductSubType,
    finance_amount=@FinanceAmount,lead_prop_org_value=@OriginalPropertyValue,
    lead_prop_appr_value=@AppraisedPropertyValue,lead_fin_buyout_repay_amt=@BuyoutAmount,
    lead_fin_topup_amt=@TopupAmount,lead_fin_Equity_amt=@EquityAmount,
    lead_fin_cashout_amt=@CashoutAmount,MBRE_AMOUNT=@GHPAmount,
    Lead_Conversion_Product=@ConversionProduct,
    lead_fin_promotiontype=NULLIF(@PromotionName,N'')
WHERE Lead_No=@LeadNo;
IF @@ROWCOUNT=0 THROW 51900,'Fixture lead has no LEAD_DETAILS_FINANCE row.',1;

UPDATE dbo.LEAD_DETAILS
SET CUSTOMER_RES_TYPE=@ResidencyType,Lead_Source_OF_Submission=@SourceSubmission
WHERE Lead_No=@LeadNo;
IF @@ROWCOUNT=0 THROW 51901,'Fixture lead has no LEAD_DETAILS row.',1;

UPDATE dbo.LEAD_DETAILS_OTHERS
SET staffyn=@StaffYN,Relationship_with_bank=@RelationshipWithBank
WHERE Lead_No=@LeadNo;
IF @@ROWCOUNT=0 THROW 51902,'Fixture lead has no LEAD_DETAILS_OTHERS row.',1;

UPDATE dbo.LEAD_DETAILS_PROPERTY
SET property_projectid=NULLIF(@ProjectId,N'')
WHERE Lead_No=@LeadNo;
IF @@ROWCOUNT=0 THROW 51903,'Fixture lead has no LEAD_DETAILS_PROPERTY row.',1;";

            using (SqlCommand command = new SqlCommand(updateSql, connection, transaction))
            {
                command.CommandType = CommandType.Text;
                command.CommandTimeout = 30;
                command.Parameters.Add("@LeadNo", SqlDbType.NVarChar, 100).Value = testCase.LeadNo;
                command.Parameters.Add("@ProductType", SqlDbType.NVarChar, 300).Value = testCase.ProductType;
                command.Parameters.Add("@ProductSubType", SqlDbType.NVarChar, 300).Value = testCase.ProductSubType;
                command.Parameters.Add("@FinanceAmount", SqlDbType.Decimal).Value = testCase.FinanceAmount;
                command.Parameters.Add("@OriginalPropertyValue", SqlDbType.Decimal).Value = testCase.OriginalPropertyValue;
                command.Parameters.Add("@AppraisedPropertyValue", SqlDbType.Decimal).Value = testCase.AppraisedPropertyValue;
                command.Parameters.Add("@BuyoutAmount", SqlDbType.Decimal).Value = testCase.BuyoutAmount;
                command.Parameters.Add("@TopupAmount", SqlDbType.Decimal).Value = testCase.TopupAmount;
                command.Parameters.Add("@EquityAmount", SqlDbType.Decimal).Value = testCase.EquityAmount;
                command.Parameters.Add("@CashoutAmount", SqlDbType.Decimal).Value = testCase.CashoutAmount;
                command.Parameters.Add("@GHPAmount", SqlDbType.Decimal).Value = testCase.GHPAmount;
                command.Parameters.Add("@ConversionProduct", SqlDbType.NVarChar, 300).Value = testCase.ConversionProduct;
                command.Parameters.Add("@PromotionName", SqlDbType.NVarChar, 200).Value = testCase.PromotionName;
                command.Parameters.Add("@ResidencyType", SqlDbType.NVarChar, 200).Value = testCase.ResidencyType;
                command.Parameters.Add("@SourceSubmission", SqlDbType.NVarChar, 100).Value = testCase.SourceSubmission;
                command.Parameters.Add("@StaffYN", SqlDbType.NVarChar, 100).Value = testCase.StaffYN;
                command.Parameters.Add("@RelationshipWithBank", SqlDbType.NVarChar, 100).Value = testCase.RelationshipWithBank;
                command.Parameters.Add("@ProjectId", SqlDbType.NVarChar, 100).Value = testCase.ProjectId;
                command.ExecuteNonQuery();
            }
        }

        private DataTable ExecuteProcedure(SqlConnection connection, SqlTransaction transaction, string leadNo, string scenario)
        {
            DataTable result = new DataTable();
            using (SqlCommand command = new SqlCommand("dbo.PROC_Lead_Arrangement_FEE", connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.Transaction = transaction;
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 120;
                command.Parameters.Add("@REFNO", SqlDbType.NVarChar, 100).Value = leadNo;
                command.Parameters.Add("@Scenario", SqlDbType.NVarChar, 200).Value = String.IsNullOrEmpty(scenario)
                    ? (object)DBNull.Value
                    : scenario;
                adapter.Fill(result);
            }
            return result;
        }

        private static List<RegressionCase> ParseCases(string input)
        {
            List<RegressionCase> cases = new List<RegressionCase>();
            HashSet<string> uniqueLeadNumbers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string[] lines = (input ?? String.Empty).Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string line in lines)
            {
                string value = (line ?? String.Empty).Trim();
                if (value.Length == 0) continue;
                string[] parts = value.Split(new char[] { '|' }, 2);
                string leadNo = parts[0].Trim();
                string scenario = parts.Length > 1 ? parts[1].Trim() : String.Empty;
                if (!Regex.IsMatch(leadNo, "^LD-[0-9]+$", RegexOptions.IgnoreCase))
                    throw new ArgumentException("Invalid lead number: " + leadNo);
                if (scenario.Length > 200) throw new ArgumentException("Scenario labels must not exceed 200 characters.");
                if (!uniqueLeadNumbers.Add(leadNo)) throw new ArgumentException("Duplicate lead number: " + leadNo);
                cases.Add(new RegressionCase(leadNo, scenario));
                if (cases.Count > MaxCases) throw new ArgumentException("Run no more than 70 cases at a time.");
            }
            return cases;
        }

        private static DataTable CreateFailureTable()
        {
            DataTable failures = new DataTable();
            failures.Columns.Add("Lead_No", typeof(string));
            failures.Columns.Add("Scenario", typeof(string));
            failures.Columns.Add("RunStatus", typeof(string));
            failures.Columns.Add("RunError", typeof(string));
            return failures;
        }

        protected void ResultsPage(object sender, GridViewPageEventArgs e)
        {
            gvResults.PageIndex = e.NewPageIndex;
            BindResults(Session[ResultsSessionKey] as DataTable);
        }

        private void BindResults(DataTable data)
        {
            gvResults.DataSource = data;
            gvResults.DataBind();
        }

        protected void Export_Click(object sender, EventArgs e)
        {
            DataTable data = Session[ResultsSessionKey] as DataTable;
            if (data == null || data.Rows.Count == 0)
            {
                ShowMessage("Run the regression cases before exporting.", false);
                return;
            }

            StringBuilder csv = new StringBuilder();
            for (int columnIndex = 0; columnIndex < data.Columns.Count; columnIndex++)
            {
                if (columnIndex > 0) csv.Append(',');
                csv.Append(CsvCell(data.Columns[columnIndex].ColumnName));
            }
            csv.AppendLine();
            foreach (DataRow row in data.Rows)
            {
                for (int columnIndex = 0; columnIndex < data.Columns.Count; columnIndex++)
                {
                    if (columnIndex > 0) csv.Append(',');
                    string value = row[columnIndex] == DBNull.Value
                        ? String.Empty
                        : Convert.ToString(row[columnIndex], CultureInfo.InvariantCulture);
                    csv.Append(CsvCell(value));
                }
                csv.AppendLine();
            }

            _isFileDownload = true;
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.ContentEncoding = Encoding.UTF8;
            Response.AddHeader("Content-Disposition", "attachment; filename=ArrangementFeeRegression_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".csv");
            Response.BinaryWrite(new UTF8Encoding(true).GetBytes(csv.ToString()));
            Response.Flush();
            Context.ApplicationInstance.CompleteRequest();
        }

        private static string CsvCell(string value)
        {
            string text = value ?? String.Empty;
            if (text.Length > 0 && (text[0] == '=' || text[0] == '+' || text[0] == '-' || text[0] == '@' || text[0] == '\t'))
                text = "'" + text;
            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }

        private void ShowMessage(string message, bool success)
        {
            lblMessage.Visible = true;
            lblMessage.Text = HttpUtility.HtmlEncode(message);
            lblMessage.CssClass = success ? "message success" : "message error";
        }

        private sealed class RegressionCase
        {
            public string LeadNo;
            public string Scenario;
            public string ProductType;
            public string ProductSubType;
            public string ResidencyType;
            public string StaffYN;
            public string RelationshipWithBank;
            public string SourceSubmission;
            public string ProjectId;
            public string ConversionProduct;
            public string PromotionName;
            public decimal FinanceAmount;
            public decimal OriginalPropertyValue;
            public decimal AppraisedPropertyValue;
            public decimal BuyoutAmount;
            public decimal TopupAmount;
            public decimal EquityAmount;
            public decimal CashoutAmount;
            public decimal GHPAmount;

            public RegressionCase(string leadNo, string scenario)
            {
                LeadNo = leadNo;
                Scenario = scenario;
                ProductType = null;
                ProductSubType = null;
                ResidencyType = null;
                StaffYN = null;
                RelationshipWithBank = null;
                SourceSubmission = null;
                ProjectId = null;
                ConversionProduct = null;
                PromotionName = null;
                FinanceAmount = 0m;
                OriginalPropertyValue = 0m;
                AppraisedPropertyValue = 0m;
                BuyoutAmount = 0m;
                TopupAmount = 0m;
                EquityAmount = 0m;
                CashoutAmount = 0m;
                GHPAmount = 0m;
            }

            public RegressionCase(string leadNo, string scenario, string productType, string productSubType,
                string residencyType, string staffYN, string relationshipWithBank, string sourceSubmission,
                string projectId, string conversionProduct, string promotionName, decimal financeAmount,
                decimal originalPropertyValue, decimal appraisedPropertyValue, decimal buyoutAmount,
                decimal topupAmount, decimal equityAmount, decimal cashoutAmount, decimal ghpAmount)
            {
                LeadNo = leadNo;
                Scenario = scenario;
                ProductType = productType;
                ProductSubType = productSubType;
                ResidencyType = residencyType;
                StaffYN = staffYN;
                RelationshipWithBank = relationshipWithBank;
                SourceSubmission = sourceSubmission;
                ProjectId = projectId;
                ConversionProduct = conversionProduct;
                PromotionName = promotionName;
                FinanceAmount = financeAmount;
                OriginalPropertyValue = originalPropertyValue;
                AppraisedPropertyValue = appraisedPropertyValue;
                BuyoutAmount = buyoutAmount;
                TopupAmount = topupAmount;
                EquityAmount = equityAmount;
                CashoutAmount = cashoutAmount;
                GHPAmount = ghpAmount;
            }
        }
    }
}
