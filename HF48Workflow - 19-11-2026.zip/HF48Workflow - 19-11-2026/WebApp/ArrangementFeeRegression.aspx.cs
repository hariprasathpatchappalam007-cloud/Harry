using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class ArrangementFeeRegression : Page
    {
        private const int MaxCases = 70;
        private const string ResultsSessionKey = "ArrangementFeeRegressionResults";
        private bool _isFileDownload;
        private static readonly string DefaultLeadCases = String.Join(Environment.NewLine, new string[]
        {
            "LD-00126494", "LD-00126500", "LD-00126503", "LD-00126508", "LD-00126511", "LD-00126519", "LD-00126522",
            "LD-00126528", "LD-00126531", "LD-00126532", "LD-00126537", "LD-00126539", "LD-00126544", "LD-00126545",
            "LD-00126546", "LD-00126550", "LD-00126551", "LD-00126555", "LD-00126557", "LD-00126558", "LD-00126562",
            "LD-00126563", "LD-00126571", "LD-00126572", "LD-00126577", "LD-00126578", "LD-00126580", "LD-00126584",
            "LD-00126585", "LD-00126587", "LD-00126589", "LD-00126590", "LD-00126592", "LD-00126593", "LD-00091404",
            "LD-00091406", "LD-00091408", "LD-00091412", "LD-00091413", "LD-00091416", "LD-00091417", "LD-00091420",
            "LD-00091421", "LD-00091424", "LD-00091426", "LD-00091429", "LD-00091431", "LD-00091444", "LD-00091445",
            "LD-00091453", "LD-00091454", "LD-00091460", "LD-00091481", "LD-00091485", "LD-00091502", "LD-00091518",
            "LD-00091528", "LD-00091529", "LD-00091533", "LD-00091536", "LD-00091540", "LD-00091541", "LD-00091729",
            "LD-00091741", "LD-00091754", "LD-00091764", "LD-00091786", "LD-00091787", "LD-00091794"
        });

        private string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtLeadCases.Text = DefaultLeadCases;
                BindResults(Session[ResultsSessionKey] as DataTable);
            }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (!_isFileDownload) base.Render(writer);
        }

        protected void Run_Click(object sender, EventArgs e)
        {
            try
            {
                List<RegressionCase> cases = ParseCases(txtLeadCases.Text);
                if (cases.Count == 0) throw new ArgumentException("Enter at least one lead number.");

                DataTable results = null;
                DataTable failures = CreateFailureTable();
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();
                    foreach (RegressionCase testCase in cases)
                    {
                        try
                        {
                            DataTable result = ExecuteProcedure(connection, testCase);
                            if (result.Rows.Count == 0) throw new InvalidOperationException("The procedure returned no rows.");
                            if (results == null)
                            {
                                results = result.Clone();
                                results.Columns.Add("RunStatus", typeof(string));
                                results.Columns.Add("RunError", typeof(string));
                            }
                            foreach (DataRow sourceRow in result.Rows)
                            {
                                DataRow targetRow = results.NewRow();
                                foreach (DataColumn column in result.Columns)
                                    targetRow[column.ColumnName] = sourceRow[column.ColumnName];
                                targetRow["RunStatus"] = "Success";
                                targetRow["RunError"] = String.Empty;
                                results.Rows.Add(targetRow);
                            }
                        }
                        catch (Exception ex)
                        {
                            DataRow failure = failures.NewRow();
                            failure["Lead_No"] = testCase.LeadNo;
                            failure["Scenario"] = testCase.Scenario;
                            failure["RunStatus"] = "Error";
                            failure["RunError"] = ex.Message;
                            failures.Rows.Add(failure);
                        }
                    }
                }

                if (results == null)
                {
                    results = failures;
                }
                else
                {
                    foreach (DataRow failure in failures.Rows)
                    {
                        DataRow targetRow = results.NewRow();
                        if (results.Columns.Contains("Lead_No")) targetRow["Lead_No"] = failure["Lead_No"];
                        if (results.Columns.Contains("Scenario")) targetRow["Scenario"] = failure["Scenario"];
                        targetRow["RunStatus"] = failure["RunStatus"];
                        targetRow["RunError"] = failure["RunError"];
                        results.Rows.Add(targetRow);
                    }
                }

                Session[ResultsSessionKey] = results;
                gvResults.PageIndex = 0;
                BindResults(results);
                int errorCount = failures.Rows.Count;
                ShowMessage(cases.Count.ToString(CultureInfo.InvariantCulture) + " case(s) run; " +
                    (cases.Count - errorCount).ToString(CultureInfo.InvariantCulture) + " succeeded, " +
                    errorCount.ToString(CultureInfo.InvariantCulture) + " failed.", errorCount == 0);
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, false);
            }
        }

        private DataTable ExecuteProcedure(SqlConnection connection, RegressionCase testCase)
        {
            DataTable result = new DataTable();
            using (SqlCommand command = new SqlCommand("dbo.PROC_Lead_Arrangement_FEE", connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 120;
                command.Parameters.Add("@REFNO", SqlDbType.NVarChar, 100).Value = testCase.LeadNo;
                command.Parameters.Add("@Scenario", SqlDbType.NVarChar, 200).Value = String.IsNullOrEmpty(testCase.Scenario)
                    ? (object)DBNull.Value
                    : testCase.Scenario;
                adapter.Fill(result);
            }
            return result;
        }

        private static List<RegressionCase> ParseCases(string input)
        {
            List<RegressionCase> cases = new List<RegressionCase>();
            HashSet<string> uniqueLeadNumbers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string[] lines = (input ?? String.Empty).Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string line in lines)
            {
                string value = (line ?? String.Empty).Trim();
                if (value.Length == 0) continue;
                string[] parts = value.Split(new char[] { '|' }, 2);
                string leadNo = parts[0].Trim();
                string scenario = parts.Length > 1 ? parts[1].Trim() : String.Empty;
                if (!Regex.IsMatch(leadNo, "^LD-[0-9]+$", RegexOptions.IgnoreCase))
                    throw new ArgumentException("Invalid lead number: " + leadNo);
                if (scenario.Length > 200) throw new ArgumentException("Scenario labels must not exceed 200 characters.");
                if (!uniqueLeadNumbers.Add(leadNo)) throw new ArgumentException("Duplicate lead number: " + leadNo);
                cases.Add(new RegressionCase(leadNo, scenario));
                if (cases.Count > MaxCases) throw new ArgumentException("Run no more than 70 cases at a time.");
            }
            return cases;
        }

        private static DataTable CreateFailureTable()
        {
            DataTable failures = new DataTable();
            failures.Columns.Add("Lead_No", typeof(string));
            failures.Columns.Add("Scenario", typeof(string));
            failures.Columns.Add("RunStatus", typeof(string));
            failures.Columns.Add("RunError", typeof(string));
            return failures;
        }

        protected void ResultsPage(object sender, GridViewPageEventArgs e)
        {
            gvResults.PageIndex = e.NewPageIndex;
            BindResults(Session[ResultsSessionKey] as DataTable);
        }

        private void BindResults(DataTable data)
        {
            gvResults.DataSource = data;
            gvResults.DataBind();
        }

        protected void Export_Click(object sender, EventArgs e)
        {
            DataTable data = Session[ResultsSessionKey] as DataTable;
            if (data == null || data.Rows.Count == 0)
            {
                ShowMessage("Run the regression cases before exporting.", false);
                return;
            }

            StringBuilder csv = new StringBuilder();
            for (int columnIndex = 0; columnIndex < data.Columns.Count; columnIndex++)
            {
                if (columnIndex > 0) csv.Append(',');
                csv.Append(CsvCell(data.Columns[columnIndex].ColumnName));
            }
            csv.AppendLine();
            foreach (DataRow row in data.Rows)
            {
                for (int columnIndex = 0; columnIndex < data.Columns.Count; columnIndex++)
                {
                    if (columnIndex > 0) csv.Append(',');
                    string value = row[columnIndex] == DBNull.Value
                        ? String.Empty
                        : Convert.ToString(row[columnIndex], CultureInfo.InvariantCulture);
                    csv.Append(CsvCell(value));
                }
                csv.AppendLine();
            }

            _isFileDownload = true;
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.ContentEncoding = Encoding.UTF8;
            Response.AddHeader("Content-Disposition", "attachment; filename=ArrangementFeeRegression_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".csv");
            Response.BinaryWrite(new UTF8Encoding(true).GetBytes(csv.ToString()));
            Response.Flush();
            Context.ApplicationInstance.CompleteRequest();
        }

        private static string CsvCell(string value)
        {
            string text = value ?? String.Empty;
            if (text.Length > 0 && (text[0] == '=' || text[0] == '+' || text[0] == '-' || text[0] == '@' || text[0] == '\t'))
                text = "'" + text;
            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }

        private void ShowMessage(string message, bool success)
        {
            lblMessage.Visible = true;
            lblMessage.Text = HttpUtility.HtmlEncode(message);
            lblMessage.CssClass = success ? "message success" : "message error";
        }

        private sealed class RegressionCase
        {
            public string LeadNo;
            public string Scenario;

            public RegressionCase(string leadNo, string scenario)
            {
                LeadNo = leadNo;
                Scenario = scenario;
            }
        }
    }
}
