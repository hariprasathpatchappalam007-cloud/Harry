namespace HF48Workflow
{
    public partial class ArrangementFeeRegression
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.TextBox txtLeadCases;
        protected global::System.Web.UI.WebControls.TextBox txtFixtureLead;
        protected global::System.Web.UI.WebControls.Button btnRun;
        protected global::System.Web.UI.WebControls.Button btnRunMatrix;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.GridView gvResults;
    }
}
