<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="LeadFeeMasterMaker.aspx.cs" Inherits="HF48Workflow.LeadFeeMasterMaker" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Lead Fee Masters - Maker</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="LeadFeeMaster.css" rel="stylesheet" type="text/css" />
</head>
<body>
<form id="form1" runat="server" enctype="multipart/form-data">
    <header class="header"><h1>Lead Fee Master Maintenance</h1><h2>Maker submissions require checker approval | <a href="LeadFeeMasterChecker.aspx">Open checker</a></h2></header>
    <main class="container">
        <div class="who-bar">Acting as <strong><asp:Label ID="lblCurrentUser" runat="server" /></strong>
            <asp:TextBox ID="txtCurrentUser" runat="server" MaxLength="100" />
            <asp:Button ID="btnSetUser" runat="server" Text="Switch User" CssClass="btn btn-secondary" OnClick="SetUser_Click" CausesValidation="false" />
        </div>
        <asp:Label ID="lblMessage" runat="server" Visible="false" />
        <section class="panel">
            <div class="panel-header">Filter master records</div>
            <div class="panel-body">
                <div class="filter-grid">
                    <div class="field"><label for="<%= ddlMasterType.ClientID %>">Master</label>
                        <asp:DropDownList ID="ddlMasterType" runat="server" AutoPostBack="true" OnSelectedIndexChanged="MasterType_Changed">
                            <asp:ListItem Text="Promotion master" Value="P" /><asp:ListItem Text="Arrangement fee master" Value="F" />
                        </asp:DropDownList>
                    </div>
                    <div class="field"><label for="<%= txtSearch.ClientID %>">Promotion / product type or subtype</label><asp:TextBox ID="txtSearch" runat="server" MaxLength="200" /></div>
                    <div class="field"><label for="<%= ddlFilterStatus.ClientID %>">Status</label>
                        <asp:DropDownList ID="ddlFilterStatus" runat="server"><asp:ListItem Text="All" Value="" /><asp:ListItem Text="Active" Value="A" /><asp:ListItem Text="Inactive" Value="I" /></asp:DropDownList>
                    </div>
                    <div class="field"><label for="<%= txtFilterResidency.ClientID %>">Residency type (fee master)</label><asp:TextBox ID="txtFilterResidency" runat="server" MaxLength="100" /></div>
                    <div class="field"><label for="<%= ddlFilterStaff.ClientID %>">Staff (fee master)</label>
                        <asp:DropDownList ID="ddlFilterStaff" runat="server"><asp:ListItem Text="All" Value="" /><asp:ListItem Text="Yes" Value="Yes" /><asp:ListItem Text="No" Value="No" /></asp:DropDownList>
                    </div>
                    <div class="field"><label for="<%= txtFromDate.ClientID %>">Promotion start from</label><asp:TextBox ID="txtFromDate" runat="server" /></div>
                    <div class="field"><label for="<%= txtToDate.ClientID %>">Promotion start to</label><asp:TextBox ID="txtToDate" runat="server" /></div>
                </div>
                <div class="filter-actions">
                    <asp:Button ID="btnFilter" runat="server" Text="Apply filters" CssClass="btn" OnClick="Filter_Click" CausesValidation="false" />
                    <asp:Button ID="btnClearFilters" runat="server" Text="Clear" CssClass="btn btn-secondary" OnClick="ClearFilters_Click" CausesValidation="false" />
                    <asp:Button ID="btnExport" runat="server" Text="Export to Excel (CSV)" CssClass="btn btn-secondary" OnClick="Export_Click" CausesValidation="false" />
                </div>
                <div class="table-wrap"><asp:GridView ID="gvMasterRows" runat="server" CssClass="gridview" AutoGenerateColumns="true"
                    AllowPaging="true" PageSize="25" OnSelectedIndexChanged="MasterSelected"
                    OnPageIndexChanging="MasterPage" EmptyDataText="No master rows match these filters.">
                    <Columns><asp:ButtonField ButtonType="Link" CommandName="Select" Text="Edit" /></Columns>
                </asp:GridView></div>
            </div>
        </section>
        <section class="panel">
            <div class="panel-header">Edit or add a master row</div>
            <div class="panel-body">
                <p class="section-note"><asp:Label ID="lblEditorMode" runat="server" Text="Read only. Click Edit on a row or add a new row to make changes." /></p>
                <asp:HiddenField ID="hfTargetSrno" runat="server" Value="0" />
                <asp:HiddenField ID="hfOldProductType" runat="server" />
                <asp:HiddenField ID="hfOldProductSubType" runat="server" />
                <asp:HiddenField ID="hfOldResidencyType" runat="server" />
                <asp:HiddenField ID="hfOldStaff" runat="server" />
                <asp:Panel ID="pnlFields" runat="server" Enabled="false">
                <asp:Panel ID="pnlPromotion" runat="server">
                    <div class="form-grid">
                        <div class="field"><label for="<%= txtPromotionName.ClientID %>">Promotion name <span class="required">*</span></label><asp:TextBox ID="txtPromotionName" runat="server" MaxLength="200" /></div>
                        <div class="field"><label for="<%= txtDiscountPerc.ClientID %>">Discount percent <span class="required">*</span></label><asp:TextBox ID="txtDiscountPerc" runat="server" MaxLength="20" /></div>
                        <div class="field"><label for="<%= txtPromotionStart.ClientID %>">Start date</label><asp:TextBox ID="txtPromotionStart" runat="server" /></div>
                        <div class="field"><label for="<%= txtPromotionEnd.ClientID %>">End date</label><asp:TextBox ID="txtPromotionEnd" runat="server" /></div>
                        <div class="field"><label for="<%= ddlPromotionStatus.ClientID %>">Status</label>
                            <asp:DropDownList ID="ddlPromotionStatus" runat="server"><asp:ListItem Text="Active" Value="A" /><asp:ListItem Text="Inactive" Value="I" /></asp:DropDownList>
                        </div>
                    </div>
                </asp:Panel>
                <asp:Panel ID="pnlFee" runat="server" Visible="false">
                    <div class="form-grid">
                        <div class="field"><label for="<%= txtProductType.ClientID %>">Product type <span class="required">*</span></label><asp:TextBox ID="txtProductType" runat="server" MaxLength="150" /></div>
                        <div class="field"><label for="<%= txtProductSubType.ClientID %>">Product subtype <span class="required">*</span></label><asp:TextBox ID="txtProductSubType" runat="server" MaxLength="150" /></div>
                        <div class="field"><label for="<%= txtResidencyType.ClientID %>">Residency type <span class="required">*</span></label><asp:TextBox ID="txtResidencyType" runat="server" MaxLength="100" /></div>
                        <div class="field"><label for="<%= ddlStaff.ClientID %>">Staff <span class="required">*</span></label>
                            <asp:DropDownList ID="ddlStaff" runat="server"><asp:ListItem Text="No" Value="No" /><asp:ListItem Text="Yes" Value="Yes" /></asp:DropDownList>
                        </div>
                        <div class="field"><label for="<%= txtFeeFv.ClientID %>">FEE_FV (%)</label><asp:TextBox ID="txtFeeFv" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtFeeOpv.ClientID %>">FEE_OPV (%)</label><asp:TextBox ID="txtFeeOpv" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtFeeApv.ClientID %>">FEE_APV (%)</label><asp:TextBox ID="txtFeeApv" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtFeeBuyout.ClientID %>">FEE_Buyout (%)</label><asp:TextBox ID="txtFeeBuyout" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtFeeTopup.ClientID %>">FEE_Topup (%)</label><asp:TextBox ID="txtFeeTopup" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtFeeEquity.ClientID %>">FEE_Equity (%)</label><asp:TextBox ID="txtFeeEquity" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtFeeCashout.ClientID %>">FEE_Cashout (%)</label><asp:TextBox ID="txtFeeCashout" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtFeeMbre.ClientID %>">FEE_MBRE (%)</label><asp:TextBox ID="txtFeeMbre" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtFeeApp.ClientID %>">FEE_APP (%)</label><asp:TextBox ID="txtFeeApp" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtFeeAcc.ClientID %>">FEE_ACC (%)</label><asp:TextBox ID="txtFeeAcc" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtMinFee.ClientID %>">MIN_FEE</label><asp:TextBox ID="txtMinFee" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= txtMaxFee.ClientID %>">MAX_FEE</label><asp:TextBox ID="txtMaxFee" runat="server" MaxLength="30" /></div>
                        <div class="field"><label for="<%= ddlFeeStatus.ClientID %>">Status</label>
                            <asp:DropDownList ID="ddlFeeStatus" runat="server"><asp:ListItem Text="Active" Value="A" /><asp:ListItem Text="Inactive" Value="I" /></asp:DropDownList>
                        </div>
                        <div class="field"><label for="<%= ddlVatApplicable.ClientID %>">Is VAT applicable</label>
                            <asp:DropDownList ID="ddlVatApplicable" runat="server"><asp:ListItem Text="No" Value="0" /><asp:ListItem Text="Yes" Value="1" /></asp:DropDownList>
                        </div>
                    </div>
                </asp:Panel>
                <div class="form-grid" style="margin-top:14px;">
                    <div class="field"><label for="<%= txtMakerRemarks.ClientID %>">Maker remarks <span class="required">*</span></label><asp:TextBox ID="txtMakerRemarks" runat="server" MaxLength="1000" /></div>
                    <div class="field"><label for="<%= fuAttachment.ClientID %>">Supporting attachment (optional, max 5 MB)</label><asp:FileUpload ID="fuAttachment" runat="server" /></div>
                </div>
                </asp:Panel>
                <div class="form-actions">
                    <asp:Button ID="btnSubmit" runat="server" Text="Submit for checker approval" CssClass="btn btn-success" OnClick="Submit_Click" />
                    <asp:Button ID="btnAdd" runat="server" Text="Add new row" CssClass="btn" OnClick="Add_Click" CausesValidation="false" />
                    <asp:Button ID="btnNew" runat="server" Text="Cancel / clear" CssClass="btn btn-secondary" OnClick="New_Click" CausesValidation="false" />
                </div>
            </div>
        </section>
        <section class="panel">
            <div class="panel-header">My submissions</div>
            <div class="panel-body"><div class="table-wrap"><asp:GridView ID="gvMyRequests" runat="server" CssClass="gridview" AutoGenerateColumns="true" AllowPaging="true" PageSize="20" OnPageIndexChanging="MyRequestsPage" EmptyDataText="No submissions yet." /></div></div>
        </section>
    </main>
</form>
</body>
</html>