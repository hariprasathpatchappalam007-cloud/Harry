using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;
using System.Data.SqlTypes;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class LeadFeeMasterChecker : Page
    {
        private bool _isFileDownload;

        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                if (Session["UserID"] != null) return Convert.ToString(Session["UserID"], CultureInfo.InvariantCulture);
                return Context.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            txtFromDate.Attributes["type"] = "date";
            txtToDate.Attributes["type"] = "date";
            if (!IsPostBack)
            {
                txtCurrentUser.Text = CurrentUser;
                lblCurrentUser.Text = CurrentUser;
                LoadRequests();
            }
            else lblCurrentUser.Text = CurrentUser;
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (!_isFileDownload) base.Render(writer);
        }

        private DataTable GetRows(string procedure, Action<SqlCommand> addParameters)
        {
            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(ConnStr))
            using (SqlCommand command = new SqlCommand(procedure, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.CommandType = CommandType.StoredProcedure;
                if (addParameters != null) addParameters(command);
                connection.Open();
                adapter.Fill(table);
            }
            return table;
        }

        private DateTime? ReadDate(TextBox textBox, string name)
        {
            if (String.IsNullOrWhiteSpace(textBox.Text)) return null;
            DateTime date;
            if (!DateTime.TryParseExact(textBox.Text.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                throw new ArgumentException(name + " must be a valid date.");
            return date.Date;
        }

        private void LoadRequests()
        {
            try
            {
                DateTime? from = ReadDate(txtFromDate, "Submitted from");
                DateTime? to = ReadDate(txtToDate, "Submitted to");
                if (from.HasValue && to.HasValue && from.Value > to.Value)
                    throw new ArgumentException("Submitted from must be on or before Submitted to.");
                DataTable data = GetRows("dbo.Proc_LeadFeeMaster_GetRequests", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = String.IsNullOrEmpty(ddlMasterType.SelectedValue) ? (object)DBNull.Value : ddlMasterType.SelectedValue;
                    command.Parameters.Add("@Status", SqlDbType.Char, 1).Value = String.IsNullOrEmpty(ddlStatus.SelectedValue) ? (object)DBNull.Value : ddlStatus.SelectedValue;
                    command.Parameters.Add("@MakerLoginId", SqlDbType.NVarChar, 100).Value = String.IsNullOrWhiteSpace(txtMakerFilter.Text) ? (object)DBNull.Value : txtMakerFilter.Text.Trim();
                    command.Parameters.Add("@FromDate", SqlDbType.Date).Value = from.HasValue ? (object)from.Value : DBNull.Value;
                    command.Parameters.Add("@ToDate", SqlDbType.Date).Value = to.HasValue ? (object)to.Value : DBNull.Value;
                });
                gvRequests.DataSource = data;
                gvRequests.DataBind();
            }
            catch (Exception ex) { ShowMessage(ex.Message, false); }
        }

        private void ShowMessage(string message, bool success)
        {
            lblMessage.Visible = true;
            lblMessage.Text = HttpUtility.HtmlEncode(message);
            lblMessage.CssClass = success ? "message success" : "message error";
        }

        protected void Filter_Click(object sender, EventArgs e) { LoadRequests(); }

        protected void ClearFilters_Click(object sender, EventArgs e)
        {
            ddlMasterType.SelectedIndex = 0;
            ddlStatus.SelectedValue = "P";
            txtMakerFilter.Text = String.Empty;
            txtFromDate.Text = String.Empty;
            txtToDate.Text = String.Empty;
            gvRequests.PageIndex = 0;
            LoadRequests();
        }

        protected void RequestsPage(object sender, GridViewPageEventArgs e)
        {
            gvRequests.PageIndex = e.NewPageIndex;
            LoadRequests();
        }

        protected void RequestSelected(object sender, EventArgs e)
        {
            if (gvRequests.SelectedDataKey == null) return;
            LoadRequest(Convert.ToInt64(gvRequests.SelectedDataKey.Value, CultureInfo.InvariantCulture));
        }

        private DataRow LoadRequest(long requestId)
        {
            DataTable request = GetRows("dbo.Proc_LeadFeeMaster_GetRequest", delegate(SqlCommand command)
            {
                command.Parameters.Add("@RequestId", SqlDbType.BigInt).Value = requestId;
            });
            if (request.Rows.Count == 0) throw new ArgumentException("The selected request was not found.");
            DataRow row = request.Rows[0];
            hfRequestId.Value = requestId.ToString(CultureInfo.InvariantCulture);
            lblRequestSummary.Text = HttpUtility.HtmlEncode(Convert.ToString(row["MasterName"], CultureInfo.InvariantCulture)
                + " / " + Convert.ToString(row["Operation"], CultureInfo.InvariantCulture) + " / "
                + Convert.ToString(row["StatusCode"], CultureInfo.InvariantCulture) + " / "
                + Convert.ToString(row["MasterKey"], CultureInfo.InvariantCulture));
            lblMaker.Text = HttpUtility.HtmlEncode(Convert.ToString(row["MakerLoginId"], CultureInfo.InvariantCulture)
                + " / " + Convert.ToDateTime(row["SubmittedOn"], CultureInfo.InvariantCulture).ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture));
            lblMakerRemarks.Text = HttpUtility.HtmlEncode(Convert.ToString(row["MakerRemarks"], CultureInfo.InvariantCulture));
            BindComparison(XmlText(row["OldValues"]), XmlText(row["NewValues"]));
            DataTable audit = GetRows("dbo.Proc_LeadFeeMaster_GetAudit", delegate(SqlCommand command)
            {
                command.Parameters.Add("@RequestId", SqlDbType.BigInt).Value = requestId;
            });
            gvAudit.DataSource = audit;
            gvAudit.DataBind();
            bool pending = Convert.ToString(row["StatusCode"], CultureInfo.InvariantCulture) == "P";
            bool differentUser = !String.Equals(Convert.ToString(row["MakerLoginId"], CultureInfo.InvariantCulture), CurrentUser, StringComparison.OrdinalIgnoreCase);
            btnApprove.Enabled = btnReject.Enabled = pending && differentUser;
            btnAttachment.Enabled = row["AttachmentData"] != DBNull.Value;
            pnlReview.Visible = true;
            txtCheckerRemarks.Text = String.Empty;
            return row;
        }

        private static string XmlText(object value)
        {
            if (value == null || value == DBNull.Value) return null;
            SqlXml sqlXml = value as SqlXml;
            return sqlXml == null ? Convert.ToString(value, CultureInfo.InvariantCulture) : sqlXml.Value;
        }

        private void BindComparison(string oldXml, string newXml)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Field", typeof(string));
            table.Columns.Add("OldValue", typeof(string));
            table.Columns.Add("NewValue", typeof(string));
            table.Columns.Add("Changed", typeof(bool));
            System.Collections.Generic.Dictionary<string, string> oldValues = ReadFields(oldXml);
            System.Collections.Generic.Dictionary<string, string> newValues = ReadFields(newXml);
            foreach (string field in newValues.Keys)
            {
                string oldValue;
                oldValues.TryGetValue(field, out oldValue);
                string newValue = newValues[field];
                table.Rows.Add(field, oldValue ?? String.Empty, newValue, !String.Equals(oldValue ?? String.Empty, newValue ?? String.Empty, StringComparison.Ordinal));
            }
            gvComparison.DataSource = table;
            gvComparison.DataBind();
        }

        private static System.Collections.Generic.Dictionary<string, string> ReadFields(string xml)
        {
            System.Collections.Generic.Dictionary<string, string> values = new System.Collections.Generic.Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (String.IsNullOrWhiteSpace(xml)) return values;
            XmlDocument document = new XmlDocument();
            document.XmlResolver = null;
            document.LoadXml(xml);
            foreach (XmlNode child in document.DocumentElement.ChildNodes)
                if (child.NodeType == XmlNodeType.Element) values[child.LocalName] = child.InnerText;
            return values;
        }

        protected void Comparison_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            DataRowView row = e.Row.DataItem as DataRowView;
            if (row == null || !Convert.ToBoolean(row["Changed"], CultureInfo.InvariantCulture)) return;
            e.Row.Cells[1].CssClass = "old-value";
            e.Row.Cells[2].CssClass = "new-value";
        }

        private void Decide(string decision)
        {
            try
            {
                long requestId;
                if (!Int64.TryParse(hfRequestId.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out requestId) || requestId <= 0)
                    throw new ArgumentException("Select a request to review.");
                string remarks = (txtCheckerRemarks.Text ?? String.Empty).Trim();
                if (remarks.Length == 0 || remarks.Length > 1000) throw new ArgumentException("Enter checker remarks of up to 1000 characters.");
                using (SqlConnection connection = new SqlConnection(ConnStr))
                using (SqlCommand command = new SqlCommand("dbo.Proc_LeadFeeMaster_Check", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@RequestId", SqlDbType.BigInt).Value = requestId;
                    command.Parameters.Add("@CheckerLoginId", SqlDbType.NVarChar, 100).Value = CurrentUser;
                    command.Parameters.Add("@Decision", SqlDbType.Char, 1).Value = decision;
                    command.Parameters.Add("@Remarks", SqlDbType.NVarChar, 1000).Value = remarks;
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                ShowMessage(decision == "A" ? "Request approved and applied to the live master." : "Request rejected. The live master was not changed.", true);
                LoadRequest(requestId);
                LoadRequests();
            }
            catch (Exception ex) { ShowMessage(ex.Message, false); }
        }

        protected void Approve_Click(object sender, EventArgs e) { Decide("A"); }
        protected void Reject_Click(object sender, EventArgs e) { Decide("R"); }

        protected void Attachment_Click(object sender, EventArgs e)
        {
            try
            {
                long requestId;
                if (!Int64.TryParse(hfRequestId.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out requestId) || requestId <= 0)
                    throw new ArgumentException("Select a request before downloading its attachment.");
                DataTable data = GetRows("dbo.Proc_LeadFeeMaster_GetRequest", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@RequestId", SqlDbType.BigInt).Value = requestId;
                });
                if (data.Rows.Count == 0 || data.Rows[0]["AttachmentData"] == DBNull.Value)
                    throw new ArgumentException("This request has no attachment.");
                DataRow row = data.Rows[0];
                string name = Path.GetFileName(Convert.ToString(row["AttachmentName"], CultureInfo.InvariantCulture));
                byte[] bytes = (byte[])row["AttachmentData"];
                _isFileDownload = true;
                Response.Clear();
                Response.ContentType = "application/octet-stream";
                Response.AddHeader("X-Content-Type-Options", "nosniff");
                Response.AddHeader("Content-Disposition", "attachment; filename*=UTF-8''" + Uri.EscapeDataString(name));
                Response.BinaryWrite(bytes);
                Response.Flush();
                Context.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex) { ShowMessage(ex.Message, false); }
        }

        protected void SetUser_Click(object sender, EventArgs e)
        {
            string login = (txtCurrentUser.Text ?? String.Empty).Trim();
            if (login.Length == 0 || login.Length > 100) { ShowMessage("Enter a user ID of up to 100 characters.", false); return; }
            Session["UserID"] = login;
            lblCurrentUser.Text = login;
            if (!String.IsNullOrEmpty(hfRequestId.Value))
            {
                long requestId;
                if (Int64.TryParse(hfRequestId.Value, out requestId) && requestId > 0) LoadRequest(requestId);
            }
            ShowMessage("Acting user changed to " + login + ".", true);
        }

        protected void Export_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime? from = ReadDate(txtFromDate, "Submitted from");
                DateTime? to = ReadDate(txtToDate, "Submitted to");
                if (from.HasValue && to.HasValue && from.Value > to.Value)
                    throw new ArgumentException("Submitted from must be on or before Submitted to.");
                DataTable data = GetRows("dbo.Proc_LeadFeeMaster_GetRequests", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = String.IsNullOrEmpty(ddlMasterType.SelectedValue) ? (object)DBNull.Value : ddlMasterType.SelectedValue;
                    command.Parameters.Add("@Status", SqlDbType.Char, 1).Value = String.IsNullOrEmpty(ddlStatus.SelectedValue) ? (object)DBNull.Value : ddlStatus.SelectedValue;
                    command.Parameters.Add("@MakerLoginId", SqlDbType.NVarChar, 100).Value = String.IsNullOrWhiteSpace(txtMakerFilter.Text) ? (object)DBNull.Value : txtMakerFilter.Text.Trim();
                    command.Parameters.Add("@FromDate", SqlDbType.Date).Value = from.HasValue ? (object)from.Value : DBNull.Value;
                    command.Parameters.Add("@ToDate", SqlDbType.Date).Value = to.HasValue ? (object)to.Value : DBNull.Value;
                });
                if (data.Rows.Count == 0) throw new ArgumentException("No requests match the current filters.");
                StringBuilder csv = new StringBuilder();
                for (int column = 0; column < data.Columns.Count; column++) { if (column > 0) csv.Append(','); csv.Append(CsvCell(data.Columns[column].ColumnName)); }
                csv.AppendLine();
                foreach (DataRow row in data.Rows)
                {
                    for (int column = 0; column < data.Columns.Count; column++)
                    {
                        if (column > 0) csv.Append(',');
                        csv.Append(CsvCell(row[column] == DBNull.Value ? String.Empty : Convert.ToString(row[column], CultureInfo.InvariantCulture)));
                    }
                    csv.AppendLine();
                }
                _isFileDownload = true;
                Response.Clear();
                Response.ContentType = "text/csv";
                Response.ContentEncoding = Encoding.UTF8;
                Response.AddHeader("Content-Disposition", "attachment; filename=LeadFeeRequests_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".csv");
                Response.BinaryWrite(new UTF8Encoding(true).GetBytes(csv.ToString()));
                Response.Flush();
                Context.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex) { ShowMessage(ex.Message, false); }
        }

        private static string CsvCell(string value)
        {
            string text = value ?? String.Empty;
            if (text.Length > 0 && (text[0] == '=' || text[0] == '+' || text[0] == '-' || text[0] == '@' || text[0] == '\t')) text = "'" + text;
            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }
    }
}