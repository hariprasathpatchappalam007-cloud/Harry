<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="SOACalllogCustQuery.aspx.cs" Inherits="HF48Workflow.SOACalllogCustQuery" ValidateRequest="false" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>SOA Customer Query Call Log</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style type="text/css">
        body { margin: 0; background: #edf1f3; color: #23313a; font-family: Segoe UI, Arial, sans-serif; }
        .header { padding: 18px 28px; background: #174b52; color: #fff; }
        .header h1 { margin: 0; font-size: 21px; }
        .container { max-width: 1080px; margin: 0 auto; padding: 24px 20px; }
        .form-section { margin-bottom: 20px; padding-bottom: 18px; border-bottom: 1px solid #d5dddf; }
        .form-section h2 { margin: 0 0 14px; color: #174b52; font-size: 16px; }
        .fields { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
        .field { min-width: 0; }
        .field-wide { grid-column: 1 / -1; }
        .field label { display: block; margin-bottom: 5px; font-size: 13px; font-weight: 600; }
        .field input, .field textarea { box-sizing: border-box; width: 100%; padding: 9px 10px; border: 1px solid #aebdc0; border-radius: 3px; background: #fff; color: #23313a; font: 13px Consolas, monospace; }
        .field input { font-family: Segoe UI, Arial, sans-serif; }
        .field textarea { min-height: 250px; resize: vertical; white-space: pre; overflow: auto; }
        .actions { display: flex; align-items: center; gap: 14px; }
        .save-button { padding: 10px 18px; border: 0; border-radius: 3px; background: #174b52; color: #fff; cursor: pointer; font-size: 14px; font-weight: 600; }
        .save-button:hover { background: #21636b; }
        .message { display: block; font-size: 13px; }
        .success { color: #17613c; }
        .error { color: #a42e31; }
        .required { color: #a42e31; }
        @media (max-width: 650px) {
            .header { padding: 15px 18px; }
            .container { padding: 18px 14px; }
            .fields { grid-template-columns: minmax(0, 1fr); }
            .field-wide { grid-column: auto; }
            .field textarea { min-height: 210px; }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
    <header class="header"><h1>SOA Customer Query Call Log</h1></header>
    <main class="container">
        <section class="form-section">
            <h2>Call details</h2>
            <div class="fields">
                <div class="field">
                    <label for="<%= txtLeadNo.ClientID %>">Lead number <span class="required">*</span></label>
                    <asp:TextBox ID="txtLeadNo" runat="server" MaxLength="100" />
                </div>
                <div class="field">
                    <label for="<%= txtXref.ClientID %>">Xref <span class="required">*</span></label>
                    <asp:TextBox ID="txtXref" runat="server" MaxLength="200" />
                </div>
                <div class="field field-wide">
                    <label for="<%= txtCreatedBy.ClientID %>">Created by <span class="required">*</span></label>
                    <asp:TextBox ID="txtCreatedBy" runat="server" MaxLength="256" />
                </div>
            </div>
        </section>
        <section class="form-section">
            <h2>Request and response XML</h2>
            <div class="fields">
                <div class="field field-wide">
                    <label for="<%= txtRequestXml.ClientID %>">Sample Request XML <span class="required">*</span></label>
                    <asp:TextBox ID="txtRequestXml" runat="server" TextMode="MultiLine" Rows="14" />
                </div>
                <div class="field field-wide">
                    <label for="<%= txtResponseXml.ClientID %>">Response XML <span class="required">*</span></label>
                    <asp:TextBox ID="txtResponseXml" runat="server" TextMode="MultiLine" Rows="14" />
                </div>
            </div>
        </section>
        <div class="actions">
            <asp:Button ID="btnSave" runat="server" Text="Save call log" CssClass="save-button" OnClick="btnSave_Click" />
            <asp:Label ID="lblMessage" runat="server" CssClass="message" role="status" />
        </div>
    </main>
</form>
</body>
</html>