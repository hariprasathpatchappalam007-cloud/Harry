using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class LeadFeeMasterMaker : Page
    {
        private const int MaxAttachmentBytes = 5242880;
        private bool _isFileDownload;

        [Serializable]
        public sealed class PendingChange
        {
            public string MasterType { get; set; }
            public string MasterName
            {
                get
                {
                    if (MasterType == "P") return "Promotion Setup";
                    if (MasterType == "C") return "Promotion Configuration";
                    return "Arrangement Fee Master";
                }
            }
            public string OperationName { get; set; }
            public string DisplayKey { get; set; }
            public string MasterKey { get; set; }
            public int TargetSRNO { get; set; }
            public string OldProductType { get; set; }
            public string OldProductSubType { get; set; }
            public string OldResidencyType { get; set; }
            public string OldStaff { get; set; }
            public string NewValues { get; set; }
            public string Remarks { get; set; }
            public string AttachmentName { get; set; }
            public string AttachmentType { get; set; }
            public byte[] AttachmentData { get; set; }
        }

        private List<PendingChange> PendingChanges
        {
            get
            {
                List<PendingChange> changes = Session["LeadFeeMasterPendingChanges"] as List<PendingChange>;
                if (changes == null)
                {
                    changes = new List<PendingChange>();
                    Session["LeadFeeMasterPendingChanges"] = changes;
                }
                return changes;
            }
        }

        private List<string> BatchSelection
        {
            get
            {
                List<string> keys = Session["LeadFeeMasterBatchSelection"] as List<string>;
                if (keys == null) { keys = new List<string>(); Session["LeadFeeMasterBatchSelection"] = keys; }
                return keys;
            }
        }

        private string FormMode
        {
            get { return ViewState["LeadFeeMasterFormMode"] as string ?? String.Empty; }
            set { ViewState["LeadFeeMasterFormMode"] = value; }
        }

        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                if (Session["UserID"] != null) return Convert.ToString(Session["UserID"], CultureInfo.InvariantCulture);
                return Context.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            txtFromDate.Attributes["type"] = "date";
            txtToDate.Attributes["type"] = "date";
            txtPromotionStart.Attributes["type"] = "date";
            txtPromotionEnd.Attributes["type"] = "date";
            ApplyEditorMode();
            if (!IsPostBack)
            {
                txtCurrentUser.Text = CurrentUser;
                lblCurrentUser.Text = CurrentUser;
                PopulateFilterOptions();
                SetMasterPanels();
                LoadMasterRows();
                BindBatch();
                LoadMyRequests();
            }
            else lblCurrentUser.Text = CurrentUser;
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (!_isFileDownload) base.Render(writer);
        }

        private void SetMasterPanels()
        {
            bool promotion = ddlMasterType.SelectedValue == "P";
            bool configuration = ddlMasterType.SelectedValue == "C";
            pnlPromotion.Visible = promotion;
            pnlPromotionConfig.Visible = promotion || configuration;
            pnlFee.Visible = !promotion && !configuration;
            pnlPromotionFilters.Visible = promotion;
            pnlConfigFilters.Visible = configuration;
            pnlFeeFilters.Visible = !promotion && !configuration;
            lnkPromotionTab.CssClass = promotion ? "tab tab-active" : "tab";
            lnkFeeTab.CssClass = !promotion && !configuration ? "tab tab-active" : "tab";
            btnAdd.Visible = !promotion && !configuration;
            btnAdd.Text = "Add new fee row";
        }

        private void PopulateFilterOptions()
        {
            if (ddlMasterType.SelectedValue == "C") return;
            DataSet options = new DataSet();
            using (SqlConnection connection = new SqlConnection(ConnStr))
            using (SqlCommand command = new SqlCommand("dbo.Proc_LeadFeeMaster_GetFilterOptions", connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = ddlMasterType.SelectedValue;
                connection.Open();
                adapter.Fill(options);
            }
            if (ddlMasterType.SelectedValue == "P")
                BindOptions(ddlFilterPromotionName, options.Tables[0], "PromotionName", "PromotionKey", "All promotions");
            else if (options.Tables.Count >= 3)
            {
                BindOptions(ddlFilterProductType, options.Tables[0], "PRODUCT_TYPE", "All product types");
                BindOptions(ddlFilterProductSubType, options.Tables[1], "Product_SubTYPE", "All subtypes");
                BindOptions(ddlFilterResidency, options.Tables[2], "Residency_Type", "All residency types");
                BindOptions(ddlProductType, options.Tables[0], "PRODUCT_TYPE", "Select product type");
                BindOptions(ddlProductSubType, options.Tables[1], "Product_SubTYPE", "Select product subtype");
                BindOptions(ddlResidencyType, options.Tables[2], "Residency_Type", "Select residency type");
            }
        }

        private static void BindOptions(DropDownList list, DataTable data, string column, string allText)
        {
            BindOptions(list, data, column, column, allText);
        }

        private static void BindOptions(DropDownList list, DataTable data, string textColumn, string valueColumn, string allText)
        {
            list.Items.Clear();
            list.Items.Add(new ListItem(allText, String.Empty));
            foreach (DataRow row in data.Rows)
            {
                string text = row[textColumn] == DBNull.Value ? String.Empty : Convert.ToString(row[textColumn], CultureInfo.InvariantCulture);
                string value = row[valueColumn] == DBNull.Value ? String.Empty : Convert.ToString(row[valueColumn], CultureInfo.InvariantCulture);
                if (text.Length > 0 && value.Length > 0) list.Items.Add(new ListItem(text, value));
            }
        }

        protected void FeeTab_Click(object sender, EventArgs e) { SwitchMaster("F"); }
        protected void PromotionTab_Click(object sender, EventArgs e) { SwitchMaster("P"); }

        private void SwitchMaster(string masterType)
        {
            ddlMasterType.SelectedValue = masterType;
            ClearForm();
            PopulateFilterOptions();
            SetMasterPanels();
            gvMasterRows.PageIndex = 0;
            LoadMasterRows();
            LoadMyRequests();
        }

        private void ApplyEditorMode()
        {
            bool editable = FormMode == "ADD" || FormMode == "EDIT";
            pnlFields.Enabled = editable;
            btnQueueChange.Enabled = editable;
            pnlEditorModal.Visible = editable;
            lblEditorMode.Text = !editable
                ? "Read only. Click Edit on a row or add a new row to make changes."
                : FormMode == "ADD" ? "Adding a new row. Changes are staged for checker approval." : "Editing a selected row. Changes are staged for checker approval.";
        }

        private DateTime? ReadFilterDate(TextBox textBox, string title)
        {
            if (String.IsNullOrWhiteSpace(textBox.Text)) return null;
            DateTime date;
            if (!DateTime.TryParseExact(textBox.Text.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture,
                DateTimeStyles.None, out date))
                throw new ArgumentException(title + " must be a valid date.");
            return date.Date;
        }

        private DataTable GetMasterRows()
        {
            DateTime? from = ReadFilterDate(txtFromDate, "Start date from");
            DateTime? to = ReadFilterDate(txtToDate, "Start date to");
            if (from.HasValue && to.HasValue && from.Value > to.Value)
                throw new ArgumentException("Start date from must be on or before Start date to.");

            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(ConnStr))
            using (SqlCommand command = new SqlCommand("dbo.Proc_LeadFeeMaster_GetRows", connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = ddlMasterType.SelectedValue;
                command.Parameters.Add("@Search", SqlDbType.NVarChar, 200).Value = DBNull.Value;
                command.Parameters.Add("@PromotionName", SqlDbType.NVarChar, 200).Value = ddlMasterType.SelectedValue == "P" ? OptionalText(ddlFilterPromotionName.SelectedValue, 200) : (object)DBNull.Value;
                command.Parameters.Add("@ProductType", SqlDbType.NVarChar, 300).Value = ddlMasterType.SelectedValue == "F" ? OptionalText(ddlFilterProductType.SelectedValue, 300) : (object)DBNull.Value;
                command.Parameters.Add("@ProductSubType", SqlDbType.NVarChar, 300).Value = ddlMasterType.SelectedValue == "F" ? OptionalText(ddlFilterProductSubType.SelectedValue, 300) : (object)DBNull.Value;
                string status = ddlMasterType.SelectedValue == "P" ? ddlFilterStatus.SelectedValue
                    : ddlMasterType.SelectedValue == "C" ? ddlFilterConfigStatus.SelectedValue : ddlFilterStatusFee.SelectedValue;
                command.Parameters.Add("@Status", SqlDbType.NVarChar, 10).Value = OptionalText(status, 10);
                command.Parameters.Add("@ResidencyType", SqlDbType.NVarChar, 200).Value = ddlMasterType.SelectedValue == "F" ? OptionalText(ddlFilterResidency.SelectedValue, 200) : (object)DBNull.Value;
                command.Parameters.Add("@Staff", SqlDbType.NVarChar, 100).Value = OptionalText(ddlFilterStaff.SelectedValue, 100);
                command.Parameters.Add("@FromDate", SqlDbType.Date).Value = from.HasValue ? (object)from.Value : DBNull.Value;
                command.Parameters.Add("@ToDate", SqlDbType.Date).Value = to.HasValue ? (object)to.Value : DBNull.Value;
                connection.Open();
                adapter.Fill(table);
            }
            return table;
        }

        private DataTable GetRows(string procedure, Action<SqlCommand> addParameters)
        {
            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(ConnStr))
            using (SqlCommand command = new SqlCommand(procedure, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.CommandType = CommandType.StoredProcedure;
                if (addParameters != null) addParameters(command);
                connection.Open();
                adapter.Fill(table);
            }
            return table;
        }

        private void LoadPromotionRules(string promotionKey)
        {
            DataTable rules = GetRows("dbo.Proc_LeadFeeMaster_GetPromotionRules", delegate(SqlCommand command)
            {
                command.Parameters.Add("@PromotionKey", SqlDbType.NVarChar, 200).Value = promotionKey;
            });
            gvPromotionRules.DataSource = rules;
            gvPromotionRules.DataBind();
            pnlPromotionRules.Visible = true;
        }

        private static object OptionalText(string value, int maximumLength)
        {
            string text = (value ?? String.Empty).Trim();
            if (text.Length == 0) return DBNull.Value;
            if (text.Length > maximumLength) throw new ArgumentException("A filter exceeds its maximum length.");
            return text;
        }

        private void LoadMasterRows()
        {
            try
            {
                DataTable data = GetMasterRows();
                DataTable ordered = data.Clone();
                foreach (DataRow row in data.Rows)
                    if (IsStaged(MasterKey(row))) ordered.ImportRow(row);
                foreach (DataRow row in data.Rows)
                    if (!IsStaged(MasterKey(row))) ordered.ImportRow(row);
                gvMasterRows.PageIndex = Math.Min(gvMasterRows.PageIndex, Math.Max(0, (int)Math.Ceiling((double)data.Rows.Count / gvMasterRows.PageSize) - 1));
                gvMasterRows.DataKeyNames = ddlMasterType.SelectedValue == "P"
                    ? new string[] { "PromotionKey" }
                    : ddlMasterType.SelectedValue == "C"
                        ? new string[] { "PromotionKey" }
                        : new string[] { "PRODUCT_TYPE", "Product_SubTYPE", "Residency_Type", "Staff" };
                gvMasterRows.CssClass = ddlMasterType.SelectedValue == "F" ? "gridview grid-fee" : "gridview";
                gvMasterRows.DataSource = ordered;
                gvMasterRows.DataBind();
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, false);
            }
        }

        private bool IsStaged(string masterKey)
        {
            foreach (PendingChange change in PendingChanges)
                if (String.Equals(change.MasterKey, masterKey, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        private string MasterKey(DataRow row)
        {
            if (ddlMasterType.SelectedValue == "P")
                return "P|" + Convert.ToString(row["PromotionKey"], CultureInfo.InvariantCulture);
            if (ddlMasterType.SelectedValue == "C")
                return "C|" + Convert.ToString(row["PromotionKey"], CultureInfo.InvariantCulture);
            return "F|" + Convert.ToString(row["PRODUCT_TYPE"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(row["Product_SubTYPE"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(row["Residency_Type"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(row["Staff"], CultureInfo.InvariantCulture);
        }

        private string MasterKey(DataKey key)
        {
            if (ddlMasterType.SelectedValue == "P") return "P|" + Convert.ToString(key.Values["PromotionKey"], CultureInfo.InvariantCulture);
            if (ddlMasterType.SelectedValue == "C") return "C|" + Convert.ToString(key.Values["PromotionKey"], CultureInfo.InvariantCulture);
            return "F|" + Convert.ToString(key.Values["PRODUCT_TYPE"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(key.Values["Product_SubTYPE"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(key.Values["Residency_Type"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(key.Values["Staff"], CultureInfo.InvariantCulture);
        }

        protected void MasterRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                HideMasterColumns(e.Row, null);
                return;
            }
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            HideMasterColumns(e.Row, gvMasterRows.HeaderRow);
            if (e.Row.RowIndex < gvMasterRows.DataKeys.Count && IsStaged(MasterKey(gvMasterRows.DataKeys[e.Row.RowIndex])))
            {
                e.Row.CssClass = "staged-row";
                CheckBox checkBox = e.Row.FindControl("chkBatchRow") as CheckBox;
                if (checkBox != null) { checkBox.Checked = true; checkBox.Enabled = false; }
            }
            if (e.Row.Cells.Count > 0 && e.Row.Cells[0].Controls.Count > 0)
            {
                WebControl edit = e.Row.Cells[0].Controls[0] as WebControl;
                if (edit != null) edit.CssClass = "btn-edit";
            }
        }

        private void HideMasterColumns(GridViewRow row, GridViewRow header)
        {
            if (ddlMasterType.SelectedValue != "P" && ddlMasterType.SelectedValue != "C") return;
            string[] hiddenColumns = ddlMasterType.SelectedValue == "P"
                ? new string[] { "SRNO", "PromotionKey", "SourcePromotionValue", "MasterPromotionName", "MasterStatus", "MasterCreatedBy",
                    "MasterCreatedOn", "MasterUpdatedBy", "MasterUpdatedOn", "IsEnabled", "ConfigUpdatedBy",
                    "ConfigUpdatedOn", "SourceStatus" }
                : new string[] { "PromotionKey" };
            for (int index = 0; index < row.Cells.Count; index++)
            {
                string headerText = header != null && index < header.Cells.Count ? header.Cells[index].Text : row.Cells[index].Text;
                foreach (string column in hiddenColumns)
                    if (String.Equals(headerText, column, StringComparison.OrdinalIgnoreCase))
                        row.Cells[index].Visible = false;
            }
        }

        private void LoadMyRequests()
        {
            DataTable data = GetRows("dbo.Proc_LeadFeeMaster_GetRequests", delegate(SqlCommand command)
            {
                command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = ddlMasterType.SelectedValue;
                command.Parameters.Add("@Status", SqlDbType.Char, 1).Value = DBNull.Value;
                command.Parameters.Add("@MakerLoginId", SqlDbType.NVarChar, 100).Value = CurrentUser;
                command.Parameters.Add("@FromDate", SqlDbType.Date).Value = DBNull.Value;
                command.Parameters.Add("@ToDate", SqlDbType.Date).Value = DBNull.Value;
            });
            gvMyRequests.DataSource = data;
            gvMyRequests.DataBind();
        }

        private void ShowMessage(string message, bool success)
        {
            lblMessage.Visible = true;
            lblMessage.Text = HttpUtility.HtmlEncode(message);
            lblMessage.CssClass = success ? "message success" : "message error";
        }

        protected void MasterType_Changed(object sender, EventArgs e)
        {
            SetMasterPanels();
            PopulateFilterOptions();
            ClearForm();
            LoadMasterRows();
            LoadMyRequests();
        }

        protected void Filter_Click(object sender, EventArgs e)
        {
            LoadMasterRows();
        }

        protected void ClearFilters_Click(object sender, EventArgs e)
        {
            ddlFilterPromotionName.SelectedIndex = 0;
            ddlFilterProductType.SelectedIndex = 0;
            ddlFilterProductSubType.SelectedIndex = 0;
            ddlFilterResidency.SelectedIndex = 0;
            ddlFilterStatus.SelectedIndex = 0;
            ddlFilterStatusFee.SelectedIndex = 0;
            ddlFilterConfigStatus.SelectedIndex = 0;
            ddlFilterStaff.SelectedIndex = 0;
            txtFromDate.Text = String.Empty;
            txtToDate.Text = String.Empty;
            gvMasterRows.PageIndex = 0;
            LoadMasterRows();
        }

        protected void MasterPage(object sender, GridViewPageEventArgs e)
        {
            gvMasterRows.PageIndex = e.NewPageIndex;
            LoadMasterRows();
        }

        protected void MyRequestsPage(object sender, GridViewPageEventArgs e)
        {
            gvMyRequests.PageIndex = e.NewPageIndex;
            LoadMyRequests();
        }

        protected void MasterSelected(object sender, EventArgs e)
        {
            if (gvMasterRows.SelectedDataKey == null) return;
            DataRow row;
            if (ddlMasterType.SelectedValue == "P")
            {
                string promotionKey = Convert.ToString(gvMasterRows.SelectedDataKey.Values["PromotionKey"], CultureInfo.InvariantCulture);
                hfConfigPromotionName.Value = promotionKey;
                DataTable record = GetRows("dbo.Proc_LeadFeeMaster_GetRecord", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = "P";
                    command.Parameters.Add("@SRNO", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@ProductType", SqlDbType.NVarChar, 300).Value = DBNull.Value;
                    command.Parameters.Add("@ProductSubType", SqlDbType.NVarChar, 300).Value = DBNull.Value;
                    command.Parameters.Add("@ResidencyType", SqlDbType.NVarChar, 200).Value = DBNull.Value;
                    command.Parameters.Add("@Staff", SqlDbType.NVarChar, 200).Value = DBNull.Value;
                    command.Parameters.Add("@ConfigPromotionName", SqlDbType.NVarChar, 200).Value = promotionKey;
                });
                if (record.Rows.Count == 0) throw new ArgumentException("The selected promotion no longer exists.");
                row = record.Rows[0];
                hfTargetSrno.Value = row["SRNO"] == DBNull.Value ? "0"
                    : Convert.ToString(row["SRNO"], CultureInfo.InvariantCulture);
                txtPromotionName.Text = Value(row, "PromotionName");
                hfConfigPromotionDisplayName.Value = txtPromotionName.Text;
                hfConfigPromotionName.Value = Value(row, "PromotionKey");
                lblConfigPromotionName.Text = HttpUtility.HtmlEncode(txtPromotionName.Text);
                txtDiscountPerc.Text = DecimalValue(row, "DiscountPerc", "0.00");
                txtPromotionStart.Text = DateValue(row, "StartDate");
                txtPromotionEnd.Text = DateValue(row, "EndDate");
                ddlPromotionStatus.SelectedValue = Value(row, "MasterStatus") == "I" ? "I" : "A";
                ddlConfigPromotionStatus.SelectedValue = Value(row, "IsEnabled") == "False" || Value(row, "IsEnabled") == "0" ? "0" : "1";
                ddlUseMasterDiscount.SelectedValue = Value(row, "UseMasterDiscount") == "False" || Value(row, "UseMasterDiscount") == "0" ? "0" : "1";
                ddlSkipMinFee.SelectedValue = Value(row, "SkipMinFee") == "True" || Value(row, "SkipMinFee") == "1" ? "1" : "0";
                ddlSkipMaxFee.SelectedValue = Value(row, "SkipMaxFee") == "True" || Value(row, "SkipMaxFee") == "1" ? "1" : "0";
                txtLookupProductType.Text = Value(row, "LookupProductType");
                txtLookupProductSubType.Text = Value(row, "LookupProductSubType");
                LoadPromotionRules(promotionKey);
            }
            else if (ddlMasterType.SelectedValue == "C")
            {
                string promotionKey = Convert.ToString(gvMasterRows.SelectedDataKey.Values["PromotionKey"], CultureInfo.InvariantCulture);
                hfConfigPromotionName.Value = promotionKey;
                hfOldProductType.Value = promotionKey;
                DataTable record = GetRows("dbo.Proc_LeadFeeMaster_GetRecord", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = "C";
                    command.Parameters.Add("@SRNO", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@ProductType", SqlDbType.NVarChar, 300).Value = DBNull.Value;
                    command.Parameters.Add("@ProductSubType", SqlDbType.NVarChar, 300).Value = DBNull.Value;
                    command.Parameters.Add("@ResidencyType", SqlDbType.NVarChar, 200).Value = DBNull.Value;
                    command.Parameters.Add("@Staff", SqlDbType.NVarChar, 200).Value = DBNull.Value;
                    command.Parameters.Add("@ConfigPromotionName", SqlDbType.NVarChar, 200).Value = promotionKey;
                });
                if (record.Rows.Count == 0) throw new ArgumentException("The selected promotion configuration no longer exists.");
                row = record.Rows[0];
                hfConfigPromotionDisplayName.Value = Value(row, "PromotionName");
                lblConfigPromotionName.Text = HttpUtility.HtmlEncode(hfConfigPromotionDisplayName.Value);
                ddlConfigPromotionStatus.SelectedValue = Value(row, "IsEnabled") == "False" || Value(row, "IsEnabled") == "0" ? "0" : "1";
            }
            else
            {
                string productType = Convert.ToString(gvMasterRows.SelectedDataKey.Values["PRODUCT_TYPE"], CultureInfo.InvariantCulture);
                string productSubType = Convert.ToString(gvMasterRows.SelectedDataKey.Values["Product_SubTYPE"], CultureInfo.InvariantCulture);
                string residencyType = Convert.ToString(gvMasterRows.SelectedDataKey.Values["Residency_Type"], CultureInfo.InvariantCulture);
                string staff = Convert.ToString(gvMasterRows.SelectedDataKey.Values["Staff"], CultureInfo.InvariantCulture);
                hfOldProductType.Value = productType;
                hfOldProductSubType.Value = productSubType;
                hfOldResidencyType.Value = residencyType;
                hfOldStaff.Value = staff;
                DataTable record = GetRows("dbo.Proc_LeadFeeMaster_GetRecord", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = "F";
                    command.Parameters.Add("@SRNO", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@ProductType", SqlDbType.NVarChar, 300).Value = productType;
                    command.Parameters.Add("@ProductSubType", SqlDbType.NVarChar, 300).Value = productSubType;
                    command.Parameters.Add("@ResidencyType", SqlDbType.NVarChar, 200).Value = residencyType;
                    command.Parameters.Add("@Staff", SqlDbType.NVarChar, 200).Value = staff;
                });
                if (record.Rows.Count == 0) throw new ArgumentException("The selected arrangement fee row no longer exists.");
                row = record.Rows[0];
                SelectOption(ddlProductType, Value(row, "PRODUCT_TYPE"));
                SelectOption(ddlProductSubType, Value(row, "Product_SubTYPE"));
                SelectOption(ddlResidencyType, Value(row, "Residency_Type"));
                ddlStaff.SelectedValue = Value(row, "Staff");
                txtFeeFv.Text = DecimalValue(row, "FEE_FV", "0.0000");
                txtFeeOpv.Text = DecimalValue(row, "FEE_OPV", "0.0000");
                txtFeeApv.Text = DecimalValue(row, "FEE_APV", "0.0000");
                txtFeeBuyout.Text = DecimalValue(row, "FEE_Buyout", "0.0000");
                txtFeeTopup.Text = DecimalValue(row, "FEE_Topup", "0.0000");
                txtFeeEquity.Text = DecimalValue(row, "FEE_Equity", "0.0000");
                txtFeeCashout.Text = DecimalValue(row, "FEE_Cashout", "0.0000");
                txtFeeMbre.Text = DecimalValue(row, "FEE_MBRE", "0.0000");
                txtFeeApp.Text = DecimalValue(row, "FEE_APP", "0.00");
                txtFeeAcc.Text = DecimalValue(row, "FEE_ACC", "0.00");
                txtMinFee.Text = DecimalValue(row, "MIN_FEE", "0.00");
                txtMaxFee.Text = DecimalValue(row, "MAX_FEE", "0.00");
                ddlFeeStatus.SelectedValue = Value(row, "Status") == "I" ? "I" : "A";
                ddlVatApplicable.SelectedValue = Value(row, "Is_VAT_Applicable") == "True" || Value(row, "Is_VAT_Applicable") == "1" ? "1" : "0";
            }
            txtMakerRemarks.Text = String.Empty;
            FormMode = "EDIT";
            lblEditorTitle.Text = "Edit " + (ddlMasterType.SelectedValue == "P" ? "promotion package"
                : ddlMasterType.SelectedValue == "C" ? "promotion activation" : "arrangement fee row");
            ApplyEditorMode();
        }

        private static void SelectOption(DropDownList list, string value)
        {
            if (list.Items.FindByValue(value) == null)
                list.Items.Add(new ListItem(value, value));
            list.ClearSelection();
            ListItem item = list.Items.FindByValue(value);
            if (item != null) item.Selected = true;
        }

        private static string Value(DataRow row, string column)
        {
            return row[column] == DBNull.Value ? String.Empty : Convert.ToString(row[column], CultureInfo.InvariantCulture);
        }

        private static string DecimalValue(DataRow row, string column, string format)
        {
            return row[column] == DBNull.Value ? String.Empty : Convert.ToDecimal(row[column], CultureInfo.InvariantCulture).ToString(format, CultureInfo.InvariantCulture);
        }

        private static string DateValue(DataRow row, string column)
        {
            return row[column] == DBNull.Value ? String.Empty : Convert.ToDateTime(row[column], CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            SyncBatchSelection();
            List<PendingChange> allChanges = PendingChanges;
            List<string> selectedKeys = BatchSelection;
            List<PendingChange> selected = allChanges.FindAll(delegate(PendingChange change) { return selectedKeys.Contains(change.MasterKey); });
            if (selected.Count == 0) { ShowMessage("Select at least one queued change to submit.", false); return; }
            try
            {
                if (String.IsNullOrWhiteSpace(CurrentUser) || CurrentUser.Length > 100) throw new ArgumentException("A valid maker user ID is required.");
                string requestIds = String.Empty;
                using (SqlConnection connection = new SqlConnection(ConnStr))
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            foreach (PendingChange change in selected)
                            {
                                long requestId = SubmitChange(connection, transaction, change);
                                if (requestIds.Length > 0) requestIds += ", ";
                                requestIds += requestId.ToString(CultureInfo.InvariantCulture);
                            }
                            transaction.Commit();
                        }
                        catch
                        {
                            try { if (transaction.Connection != null) transaction.Rollback(); }
                            catch { }
                            throw;
                        }
                    }
                }
                foreach (PendingChange change in selected) allChanges.Remove(change);
                foreach (PendingChange change in selected) selectedKeys.Remove(change.MasterKey);
                Session["LeadFeeMasterPendingChanges"] = allChanges;
                Session["LeadFeeMasterBatchSelection"] = selectedKeys;
                BindBatch();
                ClearForm();
                ShowMessage(selected.Count.ToString(CultureInfo.InvariantCulture) + " changes submitted in one batch for checker approval. Request IDs: " + requestIds, true);
                LoadMasterRows();
                LoadMyRequests();
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, false);
            }
        }

        private long SubmitChange(SqlConnection connection, SqlTransaction transaction, PendingChange change)
        {
            using (SqlCommand command = new SqlCommand("dbo.Proc_LeadFeeMaster_Submit", connection, transaction))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = change.MasterType;
                command.Parameters.Add("@TargetSRNO", SqlDbType.Int).Value = change.TargetSRNO > 0 ? (object)change.TargetSRNO : DBNull.Value;
                command.Parameters.Add("@OldProductType", SqlDbType.NVarChar, 300).Value = OptionalText(change.OldProductType, 300);
                command.Parameters.Add("@OldProductSubType", SqlDbType.NVarChar, 300).Value = OptionalText(change.OldProductSubType, 300);
                command.Parameters.Add("@OldResidencyType", SqlDbType.NVarChar, 200).Value = OptionalText(change.OldResidencyType, 200);
                command.Parameters.Add("@OldStaff", SqlDbType.NVarChar, 200).Value = OptionalText(change.OldStaff, 200);
                command.Parameters.Add("@NewValues", SqlDbType.Xml).Value = change.NewValues;
                command.Parameters.Add("@MakerLoginId", SqlDbType.NVarChar, 100).Value = CurrentUser;
                command.Parameters.Add("@MakerRemarks", SqlDbType.NVarChar, 1000).Value = change.Remarks;
                command.Parameters.Add("@AttachmentName", SqlDbType.NVarChar, 260).Value = change.AttachmentName == null ? (object)DBNull.Value : change.AttachmentName;
                command.Parameters.Add("@AttachmentType", SqlDbType.NVarChar, 150).Value = change.AttachmentType == null ? (object)DBNull.Value : change.AttachmentType;
                command.Parameters.Add("@AttachmentData", SqlDbType.VarBinary, -1).Value = change.AttachmentData == null ? (object)DBNull.Value : change.AttachmentData;
                SqlParameter requestId = command.Parameters.Add("@RequestId", SqlDbType.BigInt);
                requestId.Direction = ParameterDirection.Output;
                command.ExecuteNonQuery();
                return Convert.ToInt64(requestId.Value, CultureInfo.InvariantCulture);
            }
        }

        protected void QueueChange_Click(object sender, EventArgs e)
        {
            try
            {
                if (FormMode != "ADD" && FormMode != "EDIT") throw new ArgumentException("Open Add or Edit before queueing a change.");
                if (fuAttachment.HasFile && fuAttachment.PostedFile.ContentLength > MaxAttachmentBytes)
                    throw new ArgumentException("The supporting attachment must not exceed 5 MB.");
                string remarks = (txtMakerRemarks.Text ?? String.Empty).Trim();
                if (remarks.Length > 1000) throw new ArgumentException("Maker remarks must not exceed 1000 characters.");
                PendingChange change = new PendingChange();
                change.MasterType = ddlMasterType.SelectedValue;
                change.TargetSRNO = 0;
                int targetSrno;
                Int32.TryParse(hfTargetSrno.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out targetSrno);
                change.TargetSRNO = targetSrno;
                change.OperationName = change.MasterType == "P" ? "Update promotion package"
                    : FormMode == "ADD" ? "Insert" : "Update";
                change.OldProductType = EmptyToNull(hfOldProductType.Value);
                change.OldProductSubType = EmptyToNull(hfOldProductSubType.Value);
                change.OldResidencyType = EmptyToNull(hfOldResidencyType.Value);
                change.OldStaff = EmptyToNull(hfOldStaff.Value);
                change.NewValues = change.MasterType == "P" ? BuildPromotionXml()
                    : change.MasterType == "C" ? BuildPromotionConfigXml() : BuildFeeXml();
                change.Remarks = remarks;
                change.DisplayKey = change.MasterType == "P" ? (txtPromotionName.Text ?? String.Empty).Trim()
                    : change.MasterType == "C" ? hfConfigPromotionDisplayName.Value
                    : (ddlProductType.SelectedValue + " / " + ddlProductSubType.SelectedValue + " / " + ddlResidencyType.SelectedValue + " / " + ddlStaff.SelectedValue);
                change.MasterKey = change.MasterType == "P"
                    ? "P|" + RequiredText(hfConfigPromotionName.Value, "Promotion", 200)
                    : change.MasterType == "C" ? "C|" + hfConfigPromotionName.Value
                    : (change.OperationName == "Update" ? "F|" + change.OldProductType + "|" + change.OldProductSubType + "|" + change.OldResidencyType + "|" + change.OldStaff
                        : "F|N|" + ddlProductType.SelectedValue + "|" + ddlProductSubType.SelectedValue + "|" + ddlResidencyType.SelectedValue + "|" + ddlStaff.SelectedValue);
                if (fuAttachment.HasFile)
                {
                    change.AttachmentName = Path.GetFileName(fuAttachment.FileName);
                    change.AttachmentType = fuAttachment.PostedFile.ContentType ?? "application/octet-stream";
                    change.AttachmentData = ReadAttachment();
                }
                List<PendingChange> changes = PendingChanges;
                for (int index = changes.Count - 1; index >= 0; index--)
                    if (String.Equals(changes[index].MasterKey, change.MasterKey, StringComparison.OrdinalIgnoreCase)) changes.RemoveAt(index);
                changes.Add(change);
                List<string> selectedKeys = BatchSelection;
                if (!selectedKeys.Contains(change.MasterKey)) selectedKeys.Add(change.MasterKey);
                Session["LeadFeeMasterPendingChanges"] = changes;
                Session["LeadFeeMasterBatchSelection"] = selectedKeys;
                BindBatch();
                ClearForm();
                LoadMasterRows();
                ShowMessage("Change added to the batch. Continue editing rows, then submit the selected changes together.", true);
            }
            catch (Exception ex) { ShowMessage(ex.Message, false); }
        }

        private static string EmptyToNull(string value) { return String.IsNullOrEmpty(value) ? null : value; }

        private void BindBatch()
        {
            List<PendingChange> changes = PendingChanges;
            gvChangeBatch.PageIndex = Math.Min(gvChangeBatch.PageIndex, Math.Max(0, (int)Math.Ceiling((double)changes.Count / gvChangeBatch.PageSize) - 1));
            gvChangeBatch.DataSource = changes;
            gvChangeBatch.DataBind();
            lblBatchStatus.Text = changes.Count == 0 ? "No changes queued." : changes.Count.ToString(CultureInfo.InvariantCulture) + " change(s) queued. Select the changes to submit.";
        }

        protected void BatchPage(object sender, GridViewPageEventArgs e)
        {
            SyncBatchSelection();
            gvChangeBatch.PageIndex = e.NewPageIndex;
            BindBatch();
        }

        protected void BatchRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            PendingChange change = e.Row.DataItem as PendingChange;
            CheckBox checkBox = e.Row.FindControl("chkQueueSelected") as CheckBox;
            if (change != null && checkBox != null) checkBox.Checked = BatchSelection.Contains(change.MasterKey);
        }

        private void SyncBatchSelection()
        {
            List<PendingChange> changes = PendingChanges;
            List<string> selectedKeys = BatchSelection;
            for (int index = 0; index < gvChangeBatch.Rows.Count; index++)
            {
                int changeIndex = gvChangeBatch.PageIndex * gvChangeBatch.PageSize + index;
                if (changeIndex >= changes.Count) break;
                CheckBox checkBox = gvChangeBatch.Rows[index].FindControl("chkQueueSelected") as CheckBox;
                string key = changes[changeIndex].MasterKey;
                if (checkBox != null && checkBox.Checked)
                {
                    if (!selectedKeys.Contains(key)) selectedKeys.Add(key);
                }
                else selectedKeys.Remove(key);
            }
            Session["LeadFeeMasterBatchSelection"] = selectedKeys;
        }

        protected void ClearBatch_Click(object sender, EventArgs e)
        {
            Session.Remove("LeadFeeMasterPendingChanges");
            Session.Remove("LeadFeeMasterBatchSelection");
            gvChangeBatch.PageIndex = 0;
            BindBatch();
            LoadMasterRows();
        }

        private string BuildPromotionXml()
        {
            string key = RequiredText(hfConfigPromotionName.Value, "Promotion", 200);
            string name = RequiredText(txtPromotionName.Text, "Promotion name", 200);
            string discountText = (txtDiscountPerc.Text ?? String.Empty).Trim();
            decimal? discount = null;
            if (discountText.Length > 0)
            {
                decimal parsedDiscount = ReadDecimal(discountText, "Master discount percent", false);
                if (parsedDiscount > 100) throw new ArgumentException("Master discount percent must be between 0 and 100.");
                discount = parsedDiscount;
            }
            int targetSrno;
            Int32.TryParse(hfTargetSrno.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out targetSrno);
            if (!discount.HasValue && (targetSrno > 0 || ddlUseMasterDiscount.SelectedValue == "1"))
                throw new ArgumentException("Enter a master discount when the master discount is enabled or a master record exists.");
            DateTime? start = ReadDate(txtPromotionStart.Text, "Promotion start date");
            DateTime? end = ReadDate(txtPromotionEnd.Text, "Promotion end date");
            if (start.HasValue && end.HasValue && start.Value > end.Value) throw new ArgumentException("Promotion end date must be on or after the start date.");
            if (!discount.HasValue && (start.HasValue || end.HasValue || ddlPromotionStatus.SelectedValue != "A"))
                throw new ArgumentException("Master dates and status require a master discount.");
            string lookupProductType = (txtLookupProductType.Text ?? String.Empty).Trim();
            string lookupProductSubType = (txtLookupProductSubType.Text ?? String.Empty).Trim();
            if (lookupProductType.Length > 300 || lookupProductSubType.Length > 300)
                throw new ArgumentException("Lookup product values must be at most 300 characters.");
            if ((lookupProductType.Length == 0) != (lookupProductSubType.Length == 0))
                throw new ArgumentException("Enter both lookup product type and subtype, or leave both blank.");
            return MakeXml(delegate(XmlWriter writer)
            {
                writer.WriteElementString("PromotionKey", key);
                writer.WriteElementString("PromotionName", name);
                writer.WriteElementString("DiscountPerc", discount.HasValue ? discount.Value.ToString("0.00", CultureInfo.InvariantCulture) : String.Empty);
                writer.WriteElementString("StartDate", start.HasValue ? start.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : String.Empty);
                writer.WriteElementString("EndDate", end.HasValue ? end.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : String.Empty);
                writer.WriteElementString("MasterStatus", ddlPromotionStatus.SelectedValue);
                writer.WriteElementString("IsEnabled", ddlConfigPromotionStatus.SelectedValue);
                writer.WriteElementString("UseMasterDiscount", ddlUseMasterDiscount.SelectedValue);
                writer.WriteElementString("SkipMinFee", ddlSkipMinFee.SelectedValue);
                writer.WriteElementString("SkipMaxFee", ddlSkipMaxFee.SelectedValue);
                writer.WriteElementString("LookupProductType", lookupProductType);
                writer.WriteElementString("LookupProductSubType", lookupProductSubType);
            });
        }

        private string BuildPromotionConfigXml()
        {
            string name = RequiredText(hfConfigPromotionName.Value, "Promotion", 200);
            return MakeXml(delegate(XmlWriter writer)
            {
                writer.WriteElementString("PromotionName", name);
                writer.WriteElementString("IsEnabled", ddlConfigPromotionStatus.SelectedValue);
            });
        }

        private string BuildFeeXml()
        {
            string product = RequiredText(ddlProductType.SelectedValue, "Product type", 300);
            string subtype = RequiredText(ddlProductSubType.SelectedValue, "Product subtype", 300);
            string residency = RequiredText(ddlResidencyType.SelectedValue, "Residency type", 200);
            decimal feeFv = ReadDecimal(txtFeeFv.Text, "FEE_FV", false);
            decimal feeOpv = ReadDecimal(txtFeeOpv.Text, "FEE_OPV", false);
            decimal feeApv = ReadDecimal(txtFeeApv.Text, "FEE_APV", false);
            decimal feeBuyout = ReadDecimal(txtFeeBuyout.Text, "FEE_Buyout", false);
            decimal feeTopup = ReadDecimal(txtFeeTopup.Text, "FEE_Topup", false);
            decimal feeEquity = ReadDecimal(txtFeeEquity.Text, "FEE_Equity", false);
            decimal feeCashout = ReadDecimal(txtFeeCashout.Text, "FEE_Cashout", false);
            decimal feeMbre = ReadDecimal(txtFeeMbre.Text, "FEE_MBRE", false);
            decimal feeApp = ReadDecimal(txtFeeApp.Text, "FEE_APP", false);
            decimal feeAcc = ReadDecimal(txtFeeAcc.Text, "FEE_ACC", false);
            decimal minFee = ReadDecimal(txtMinFee.Text, "MIN_FEE", false);
            decimal maxFee = ReadDecimal(txtMaxFee.Text, "MAX_FEE", false);
            if (maxFee < minFee) throw new ArgumentException("MAX_FEE must be greater than or equal to MIN_FEE.");
            return MakeXml(delegate(XmlWriter writer)
            {
                writer.WriteElementString("PRODUCT_TYPE", product);
                writer.WriteElementString("Product_SubTYPE", subtype);
                writer.WriteElementString("Residency_Type", residency);
                writer.WriteElementString("Staff", ddlStaff.SelectedValue);
                writer.WriteElementString("FEE_FV", feeFv.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_OPV", feeOpv.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_APV", feeApv.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_Buyout", feeBuyout.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_Topup", feeTopup.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_Equity", feeEquity.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_Cashout", feeCashout.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_MBRE", feeMbre.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_APP", feeApp.ToString("0.00", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_ACC", feeAcc.ToString("0.00", CultureInfo.InvariantCulture));
                writer.WriteElementString("MIN_FEE", minFee.ToString("0.00", CultureInfo.InvariantCulture));
                writer.WriteElementString("MAX_FEE", maxFee.ToString("0.00", CultureInfo.InvariantCulture));
                writer.WriteElementString("Status", ddlFeeStatus.SelectedValue);
                writer.WriteElementString("Is_VAT_Applicable", ddlVatApplicable.SelectedValue);
            });
        }

        private static string MakeXml(Action<XmlWriter> writeRecord)
        {
            StringBuilder output = new StringBuilder();
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            using (XmlWriter writer = XmlWriter.Create(output, settings))
            {
                writer.WriteStartElement("Record");
                writeRecord(writer);
                writer.WriteEndElement();
            }
            return output.ToString();
        }

        private static string RequiredText(string value, string name, int maximumLength)
        {
            string text = (value ?? String.Empty).Trim();
            if (text.Length == 0 || text.Length > maximumLength) throw new ArgumentException(name + " is required and must be at most " + maximumLength.ToString(CultureInfo.InvariantCulture) + " characters.");
            return text;
        }

        private static decimal ReadDecimal(string value, string name, bool allowNegative)
        {
            decimal result;
            if (!Decimal.TryParse((value ?? String.Empty).Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out result)
                || (!allowNegative && result < 0))
                throw new ArgumentException(name + " must be a valid non-negative number.");
            return result;
        }

        private static DateTime? ReadDate(string value, string name)
        {
            if (String.IsNullOrWhiteSpace(value)) return null;
            DateTime date;
            if (!DateTime.TryParseExact(value.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                throw new ArgumentException(name + " must be a valid date.");
            return date.Date;
        }

        private byte[] ReadAttachment()
        {
            using (MemoryStream memory = new MemoryStream())
            {
                fuAttachment.PostedFile.InputStream.CopyTo(memory);
                return memory.ToArray();
            }
        }

        protected void New_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        protected void Add_Click(object sender, EventArgs e)
        {
            if (ddlMasterType.SelectedValue == "P")
            {
                ShowMessage("Promotion records are sourced from FRM_gnarr. Select an existing promotion to edit its package.", false);
                return;
            }
            if (ddlMasterType.SelectedValue == "C")
            {
                ShowMessage("Promotion activation is changed by editing an existing promotion.", false);
                return;
            }
            ClearForm();
            FormMode = "ADD";
            lblEditorTitle.Text = "Add arrangement fee row";
            ApplyEditorMode();
        }

        private void ClearForm()
        {
            hfTargetSrno.Value = "0";
            hfOldProductType.Value = String.Empty;
            hfOldProductSubType.Value = String.Empty;
            hfOldResidencyType.Value = String.Empty;
            hfOldStaff.Value = String.Empty;
            hfConfigPromotionName.Value = String.Empty;
            hfConfigPromotionDisplayName.Value = String.Empty;
            lblConfigPromotionName.Text = String.Empty;
            txtPromotionName.Text = String.Empty;
            txtDiscountPerc.Text = String.Empty;
            txtPromotionStart.Text = String.Empty;
            txtPromotionEnd.Text = String.Empty;
            ddlPromotionStatus.SelectedValue = "A";
            ddlConfigPromotionStatus.SelectedValue = "1";
            ddlUseMasterDiscount.SelectedValue = "1";
            ddlSkipMinFee.SelectedValue = "0";
            ddlSkipMaxFee.SelectedValue = "0";
            txtLookupProductType.Text = String.Empty;
            txtLookupProductSubType.Text = String.Empty;
            if (ddlProductType.Items.Count > 0) ddlProductType.SelectedIndex = 0;
            if (ddlProductSubType.Items.Count > 0) ddlProductSubType.SelectedIndex = 0;
            if (ddlResidencyType.Items.Count > 0) ddlResidencyType.SelectedIndex = 0;
            ddlStaff.SelectedValue = "No";
            txtFeeFv.Text = txtFeeOpv.Text = txtFeeApv.Text = txtFeeBuyout.Text = String.Empty;
            txtFeeTopup.Text = txtFeeEquity.Text = txtFeeCashout.Text = txtFeeMbre.Text = String.Empty;
            txtFeeApp.Text = txtFeeAcc.Text = txtMinFee.Text = txtMaxFee.Text = String.Empty;
            ddlFeeStatus.SelectedValue = "A";
            ddlVatApplicable.SelectedValue = "0";
            gvPromotionRules.DataSource = null;
            gvPromotionRules.DataBind();
            pnlPromotionRules.Visible = false;
            txtMakerRemarks.Text = String.Empty;
            FormMode = String.Empty;
            ApplyEditorMode();
        }

        protected void SetUser_Click(object sender, EventArgs e)
        {
            string login = (txtCurrentUser.Text ?? String.Empty).Trim();
            if (login.Length == 0 || login.Length > 100) { ShowMessage("Enter a user ID of up to 100 characters.", false); return; }
            Session["UserID"] = login;
            lblCurrentUser.Text = login;
            LoadMyRequests();
            ShowMessage("Acting user changed to " + login + ".", true);
        }

        protected void DownloadPromotionComparison_Click(object sender, EventArgs e)
        {
            try
            {
                const string fileName = "Promotion_Discount_Source_Comparison.xlsx";
                string[] candidatePaths =
                {
                    Path.Combine(Server.MapPath("~/Requirement"), fileName),
                    Path.Combine(Server.MapPath("~/bin/Requirement"), fileName),
                    Path.Combine(Server.MapPath("~"), "..", "Requirement", fileName)
                };
                string filePath = null;
                foreach (string candidatePath in candidatePaths)
                {
                    string resolvedPath = Path.GetFullPath(candidatePath);
                    if (File.Exists(resolvedPath))
                    {
                        filePath = resolvedPath;
                        break;
                    }
                }
                if (filePath == null)
                    throw new FileNotFoundException("The promotion comparison workbook is not available.", candidatePaths[0]);

                _isFileDownload = true;
                Response.Clear();
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("X-Content-Type-Options", "nosniff");
                Response.AddHeader("Content-Disposition", "attachment; filename=\"Promotion_Discount_Source_Comparison.xlsx\"");
                Response.TransmitFile(filePath);
                Response.Flush();
                Context.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex) { ShowMessage(ex.Message, false); }
        }

        protected void Export_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable data = GetMasterRows();
                if (data.Rows.Count == 0) throw new ArgumentException("No master rows match the current filters.");
                StringBuilder csv = new StringBuilder();
                for (int column = 0; column < data.Columns.Count; column++)
                {
                    if (column > 0) csv.Append(',');
                    csv.Append(CsvCell(data.Columns[column].ColumnName));
                }
                csv.AppendLine();
                foreach (DataRow row in data.Rows)
                {
                    for (int column = 0; column < data.Columns.Count; column++)
                    {
                        if (column > 0) csv.Append(',');
                        csv.Append(CsvCell(row[column] == DBNull.Value ? String.Empty : Convert.ToString(row[column], CultureInfo.InvariantCulture)));
                    }
                    csv.AppendLine();
                }
                _isFileDownload = true;
                Response.Clear();
                Response.ContentType = "text/csv";
                Response.ContentEncoding = Encoding.UTF8;
                Response.AddHeader("Content-Disposition", "attachment; filename=LeadFeeMaster_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".csv");
                Response.BinaryWrite(new UTF8Encoding(true).GetBytes(csv.ToString()));
                Response.Flush();
                Context.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex) { ShowMessage(ex.Message, false); }
        }

        private static string CsvCell(string value)
        {
            string text = value ?? String.Empty;
            if (text.Length > 0 && (text[0] == '=' || text[0] == '+' || text[0] == '-' || text[0] == '@' || text[0] == '\t'))
                text = "'" + text;
            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }
    }
}