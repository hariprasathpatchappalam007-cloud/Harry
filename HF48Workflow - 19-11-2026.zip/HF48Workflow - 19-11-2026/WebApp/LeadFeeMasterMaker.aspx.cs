using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class LeadFeeMasterMaker : Page
    {
        private const int MaxAttachmentBytes = 5242880;
        private bool _isFileDownload;

        [Serializable]
        public sealed class PendingChange
        {
            public string MasterType { get; set; }
            public string MasterName
            {
                get { return MasterType == "P" ? "Promotion Master" : "Arrangement Fee Master"; }
            }
            public string OperationName { get; set; }
            public string DisplayKey { get; set; }
            public string MasterKey { get; set; }
            public int TargetSRNO { get; set; }
            public string OldProductType { get; set; }
            public string OldProductSubType { get; set; }
            public string OldResidencyType { get; set; }
            public string OldStaff { get; set; }
            public string NewValues { get; set; }
            public string Remarks { get; set; }
            public string AttachmentName { get; set; }
            public string AttachmentType { get; set; }
            public byte[] AttachmentData { get; set; }
        }

        private List<PendingChange> PendingChanges
        {
            get
            {
                List<PendingChange> changes = Session["LeadFeeMasterPendingChanges"] as List<PendingChange>;
                if (changes == null)
                {
                    changes = new List<PendingChange>();
                    Session["LeadFeeMasterPendingChanges"] = changes;
                }
                return changes;
            }
        }

        private List<string> BatchSelection
        {
            get
            {
                List<string> keys = Session["LeadFeeMasterBatchSelection"] as List<string>;
                if (keys == null) { keys = new List<string>(); Session["LeadFeeMasterBatchSelection"] = keys; }
                return keys;
            }
        }

        private string FormMode
        {
            get { return ViewState["LeadFeeMasterFormMode"] as string ?? String.Empty; }
            set { ViewState["LeadFeeMasterFormMode"] = value; }
        }

        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                if (Session["UserID"] != null) return Convert.ToString(Session["UserID"], CultureInfo.InvariantCulture);
                return Context.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            txtFromDate.Attributes["type"] = "date";
            txtToDate.Attributes["type"] = "date";
            txtPromotionStart.Attributes["type"] = "date";
            txtPromotionEnd.Attributes["type"] = "date";
            ApplyEditorMode();
            if (!IsPostBack)
            {
                txtCurrentUser.Text = CurrentUser;
                lblCurrentUser.Text = CurrentUser;
                PopulateFilterOptions();
                SetMasterPanels();
                LoadMasterRows();
                BindBatch();
                LoadMyRequests();
            }
            else lblCurrentUser.Text = CurrentUser;
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (!_isFileDownload) base.Render(writer);
        }

        private void SetMasterPanels()
        {
            bool promotion = ddlMasterType.SelectedValue == "P";
            pnlPromotion.Visible = promotion;
            pnlFee.Visible = !promotion;
            pnlPromotionFilters.Visible = promotion;
            pnlFeeFilters.Visible = !promotion;
            lnkPromotionTab.CssClass = promotion ? "tab tab-active" : "tab";
            lnkFeeTab.CssClass = promotion ? "tab" : "tab tab-active";
            btnAdd.Text = promotion ? "Add promotion" : "Add new fee row";
        }

        private void PopulateFilterOptions()
        {
            DataSet options = new DataSet();
            using (SqlConnection connection = new SqlConnection(ConnStr))
            using (SqlCommand command = new SqlCommand("dbo.Proc_LeadFeeMaster_GetFilterOptions", connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = ddlMasterType.SelectedValue;
                connection.Open();
                adapter.Fill(options);
            }
            if (ddlMasterType.SelectedValue == "P")
                BindOptions(ddlFilterPromotionName, options.Tables[0], "PromotionName", "All promotions");
            else if (options.Tables.Count >= 3)
            {
                BindOptions(ddlFilterProductType, options.Tables[0], "PRODUCT_TYPE", "All product types");
                BindOptions(ddlFilterProductSubType, options.Tables[1], "Product_SubTYPE", "All subtypes");
                BindOptions(ddlFilterResidency, options.Tables[2], "Residency_Type", "All residency types");
            }
        }

        private static void BindOptions(DropDownList list, DataTable data, string column, string allText)
        {
            list.Items.Clear();
            list.Items.Add(new ListItem(allText, String.Empty));
            foreach (DataRow row in data.Rows)
            {
                string value = row[column] == DBNull.Value ? String.Empty : Convert.ToString(row[column], CultureInfo.InvariantCulture);
                if (value.Length > 0) list.Items.Add(new ListItem(value, value));
            }
        }

        protected void FeeTab_Click(object sender, EventArgs e) { SwitchMaster("F"); }
        protected void PromotionTab_Click(object sender, EventArgs e) { SwitchMaster("P"); }

        private void SwitchMaster(string masterType)
        {
            ddlMasterType.SelectedValue = masterType;
            PopulateFilterOptions();
            SetMasterPanels();
            gvMasterRows.PageIndex = 0;
            LoadMasterRows();
            LoadMyRequests();
        }

        private void ApplyEditorMode()
        {
            bool editable = FormMode == "ADD" || FormMode == "EDIT";
            pnlFields.Enabled = editable;
            btnQueueChange.Enabled = editable;
            pnlEditorModal.Visible = editable;
            lblEditorMode.Text = !editable
                ? "Read only. Click Edit on a row or add a new row to make changes."
                : FormMode == "ADD" ? "Adding a new row. Changes are staged for checker approval." : "Editing a selected row. Changes are staged for checker approval.";
        }

        private DateTime? ReadFilterDate(TextBox textBox, string title)
        {
            if (String.IsNullOrWhiteSpace(textBox.Text)) return null;
            DateTime date;
            if (!DateTime.TryParseExact(textBox.Text.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture,
                DateTimeStyles.None, out date))
                throw new ArgumentException(title + " must be a valid date.");
            return date.Date;
        }

        private DataTable GetMasterRows()
        {
            DateTime? from = ReadFilterDate(txtFromDate, "Start date from");
            DateTime? to = ReadFilterDate(txtToDate, "Start date to");
            if (from.HasValue && to.HasValue && from.Value > to.Value)
                throw new ArgumentException("Start date from must be on or before Start date to.");

            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(ConnStr))
            using (SqlCommand command = new SqlCommand("dbo.Proc_LeadFeeMaster_GetRows", connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = ddlMasterType.SelectedValue;
                command.Parameters.Add("@Search", SqlDbType.NVarChar, 200).Value = DBNull.Value;
                command.Parameters.Add("@PromotionName", SqlDbType.NVarChar, 200).Value = ddlMasterType.SelectedValue == "P" ? OptionalText(ddlFilterPromotionName.SelectedValue, 200) : (object)DBNull.Value;
                command.Parameters.Add("@ProductType", SqlDbType.NVarChar, 300).Value = ddlMasterType.SelectedValue == "F" ? OptionalText(ddlFilterProductType.SelectedValue, 300) : (object)DBNull.Value;
                command.Parameters.Add("@ProductSubType", SqlDbType.NVarChar, 300).Value = ddlMasterType.SelectedValue == "F" ? OptionalText(ddlFilterProductSubType.SelectedValue, 300) : (object)DBNull.Value;
                string status = ddlMasterType.SelectedValue == "P" ? ddlFilterStatus.SelectedValue : ddlFilterStatusFee.SelectedValue;
                command.Parameters.Add("@Status", SqlDbType.NVarChar, 10).Value = OptionalText(status, 10);
                command.Parameters.Add("@ResidencyType", SqlDbType.NVarChar, 200).Value = ddlMasterType.SelectedValue == "F" ? OptionalText(ddlFilterResidency.SelectedValue, 200) : (object)DBNull.Value;
                command.Parameters.Add("@Staff", SqlDbType.NVarChar, 100).Value = OptionalText(ddlFilterStaff.SelectedValue, 100);
                command.Parameters.Add("@FromDate", SqlDbType.Date).Value = from.HasValue ? (object)from.Value : DBNull.Value;
                command.Parameters.Add("@ToDate", SqlDbType.Date).Value = to.HasValue ? (object)to.Value : DBNull.Value;
                connection.Open();
                adapter.Fill(table);
            }
            return table;
        }

        private DataTable GetRows(string procedure, Action<SqlCommand> addParameters)
        {
            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(ConnStr))
            using (SqlCommand command = new SqlCommand(procedure, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.CommandType = CommandType.StoredProcedure;
                if (addParameters != null) addParameters(command);
                connection.Open();
                adapter.Fill(table);
            }
            return table;
        }

        private static object OptionalText(string value, int maximumLength)
        {
            string text = (value ?? String.Empty).Trim();
            if (text.Length == 0) return DBNull.Value;
            if (text.Length > maximumLength) throw new ArgumentException("A filter exceeds its maximum length.");
            return text;
        }

        private void LoadMasterRows()
        {
            try
            {
                DataTable data = GetMasterRows();
                DataTable ordered = data.Clone();
                foreach (DataRow row in data.Rows)
                    if (IsStaged(MasterKey(row))) ordered.ImportRow(row);
                foreach (DataRow row in data.Rows)
                    if (!IsStaged(MasterKey(row))) ordered.ImportRow(row);
                gvMasterRows.PageIndex = Math.Min(gvMasterRows.PageIndex, Math.Max(0, (int)Math.Ceiling((double)data.Rows.Count / gvMasterRows.PageSize) - 1));
                gvMasterRows.DataKeyNames = ddlMasterType.SelectedValue == "P"
                    ? new string[] { "SRNO" }
                    : new string[] { "PRODUCT_TYPE", "Product_SubTYPE", "Residency_Type", "Staff" };
                gvMasterRows.CssClass = ddlMasterType.SelectedValue == "F" ? "gridview grid-fee" : "gridview";
                gvMasterRows.DataSource = ordered;
                gvMasterRows.DataBind();
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, false);
            }
        }

        private bool IsStaged(string masterKey)
        {
            foreach (PendingChange change in PendingChanges)
                if (String.Equals(change.MasterKey, masterKey, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        private string MasterKey(DataRow row)
        {
            if (ddlMasterType.SelectedValue == "P")
                return "P|" + Convert.ToString(row["SRNO"], CultureInfo.InvariantCulture);
            return "F|" + Convert.ToString(row["PRODUCT_TYPE"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(row["Product_SubTYPE"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(row["Residency_Type"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(row["Staff"], CultureInfo.InvariantCulture);
        }

        private string MasterKey(DataKey key)
        {
            if (ddlMasterType.SelectedValue == "P") return "P|" + Convert.ToString(key.Values["SRNO"], CultureInfo.InvariantCulture);
            return "F|" + Convert.ToString(key.Values["PRODUCT_TYPE"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(key.Values["Product_SubTYPE"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(key.Values["Residency_Type"], CultureInfo.InvariantCulture) + "|"
                + Convert.ToString(key.Values["Staff"], CultureInfo.InvariantCulture);
        }

        protected void MasterRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            if (e.Row.RowIndex < gvMasterRows.DataKeys.Count && IsStaged(MasterKey(gvMasterRows.DataKeys[e.Row.RowIndex])))
            {
                e.Row.CssClass = "staged-row";
                CheckBox checkBox = e.Row.FindControl("chkBatchRow") as CheckBox;
                if (checkBox != null) { checkBox.Checked = true; checkBox.Enabled = false; }
            }
            if (e.Row.Cells.Count > 0 && e.Row.Cells[0].Controls.Count > 0)
            {
                WebControl edit = e.Row.Cells[0].Controls[0] as WebControl;
                if (edit != null) edit.CssClass = "btn-edit";
            }
        }

        private void LoadMyRequests()
        {
            DataTable data = GetRows("dbo.Proc_LeadFeeMaster_GetRequests", delegate(SqlCommand command)
            {
                command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = ddlMasterType.SelectedValue;
                command.Parameters.Add("@Status", SqlDbType.Char, 1).Value = DBNull.Value;
                command.Parameters.Add("@MakerLoginId", SqlDbType.NVarChar, 100).Value = CurrentUser;
                command.Parameters.Add("@FromDate", SqlDbType.Date).Value = DBNull.Value;
                command.Parameters.Add("@ToDate", SqlDbType.Date).Value = DBNull.Value;
            });
            gvMyRequests.DataSource = data;
            gvMyRequests.DataBind();
        }

        private void ShowMessage(string message, bool success)
        {
            lblMessage.Visible = true;
            lblMessage.Text = HttpUtility.HtmlEncode(message);
            lblMessage.CssClass = success ? "message success" : "message error";
        }

        protected void MasterType_Changed(object sender, EventArgs e)
        {
            SetMasterPanels();
            PopulateFilterOptions();
            ClearForm();
            LoadMasterRows();
            LoadMyRequests();
        }

        protected void Filter_Click(object sender, EventArgs e)
        {
            LoadMasterRows();
        }

        protected void ClearFilters_Click(object sender, EventArgs e)
        {
            ddlFilterPromotionName.SelectedIndex = 0;
            ddlFilterProductType.SelectedIndex = 0;
            ddlFilterProductSubType.SelectedIndex = 0;
            ddlFilterResidency.SelectedIndex = 0;
            ddlFilterStatus.SelectedIndex = 0;
            ddlFilterStatusFee.SelectedIndex = 0;
            ddlFilterStaff.SelectedIndex = 0;
            txtFromDate.Text = String.Empty;
            txtToDate.Text = String.Empty;
            gvMasterRows.PageIndex = 0;
            LoadMasterRows();
        }

        protected void MasterPage(object sender, GridViewPageEventArgs e)
        {
            gvMasterRows.PageIndex = e.NewPageIndex;
            LoadMasterRows();
        }

        protected void MyRequestsPage(object sender, GridViewPageEventArgs e)
        {
            gvMyRequests.PageIndex = e.NewPageIndex;
            LoadMyRequests();
        }

        protected void MasterSelected(object sender, EventArgs e)
        {
            if (gvMasterRows.SelectedDataKey == null) return;
            DataRow row;
            if (ddlMasterType.SelectedValue == "P")
            {
                int srno = Convert.ToInt32(gvMasterRows.SelectedDataKey.Values["SRNO"], CultureInfo.InvariantCulture);
                hfTargetSrno.Value = srno.ToString(CultureInfo.InvariantCulture);
                DataTable record = GetRows("dbo.Proc_LeadFeeMaster_GetRecord", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = "P";
                    command.Parameters.Add("@SRNO", SqlDbType.Int).Value = srno;
                    command.Parameters.Add("@ProductType", SqlDbType.NVarChar, 300).Value = DBNull.Value;
                    command.Parameters.Add("@ProductSubType", SqlDbType.NVarChar, 300).Value = DBNull.Value;
                    command.Parameters.Add("@ResidencyType", SqlDbType.NVarChar, 200).Value = DBNull.Value;
                    command.Parameters.Add("@Staff", SqlDbType.NVarChar, 200).Value = DBNull.Value;
                });
                if (record.Rows.Count == 0) throw new ArgumentException("The selected promotion no longer exists.");
                row = record.Rows[0];
                txtPromotionName.Text = Value(row, "PromotionName");
                txtDiscountPerc.Text = DecimalValue(row, "DiscountPerc", "0.00");
                txtPromotionStart.Text = DateValue(row, "StartDate");
                txtPromotionEnd.Text = DateValue(row, "EndDate");
                ddlPromotionStatus.SelectedValue = Value(row, "Status") == "I" ? "I" : "A";
            }
            else
            {
                string productType = Convert.ToString(gvMasterRows.SelectedDataKey.Values["PRODUCT_TYPE"], CultureInfo.InvariantCulture);
                string productSubType = Convert.ToString(gvMasterRows.SelectedDataKey.Values["Product_SubTYPE"], CultureInfo.InvariantCulture);
                string residencyType = Convert.ToString(gvMasterRows.SelectedDataKey.Values["Residency_Type"], CultureInfo.InvariantCulture);
                string staff = Convert.ToString(gvMasterRows.SelectedDataKey.Values["Staff"], CultureInfo.InvariantCulture);
                hfOldProductType.Value = productType;
                hfOldProductSubType.Value = productSubType;
                hfOldResidencyType.Value = residencyType;
                hfOldStaff.Value = staff;
                DataTable record = GetRows("dbo.Proc_LeadFeeMaster_GetRecord", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = "F";
                    command.Parameters.Add("@SRNO", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@ProductType", SqlDbType.NVarChar, 300).Value = productType;
                    command.Parameters.Add("@ProductSubType", SqlDbType.NVarChar, 300).Value = productSubType;
                    command.Parameters.Add("@ResidencyType", SqlDbType.NVarChar, 200).Value = residencyType;
                    command.Parameters.Add("@Staff", SqlDbType.NVarChar, 200).Value = staff;
                });
                if (record.Rows.Count == 0) throw new ArgumentException("The selected arrangement fee row no longer exists.");
                row = record.Rows[0];
                txtProductType.Text = Value(row, "PRODUCT_TYPE");
                txtProductSubType.Text = Value(row, "Product_SubTYPE");
                txtResidencyType.Text = Value(row, "Residency_Type");
                ddlStaff.SelectedValue = Value(row, "Staff");
                txtFeeFv.Text = DecimalValue(row, "FEE_FV", "0.0000");
                txtFeeOpv.Text = DecimalValue(row, "FEE_OPV", "0.0000");
                txtFeeApv.Text = DecimalValue(row, "FEE_APV", "0.0000");
                txtFeeBuyout.Text = DecimalValue(row, "FEE_Buyout", "0.0000");
                txtFeeTopup.Text = DecimalValue(row, "FEE_Topup", "0.0000");
                txtFeeEquity.Text = DecimalValue(row, "FEE_Equity", "0.0000");
                txtFeeCashout.Text = DecimalValue(row, "FEE_Cashout", "0.0000");
                txtFeeMbre.Text = DecimalValue(row, "FEE_MBRE", "0.0000");
                txtFeeApp.Text = DecimalValue(row, "FEE_APP", "0.00");
                txtFeeAcc.Text = DecimalValue(row, "FEE_ACC", "0.00");
                txtMinFee.Text = DecimalValue(row, "MIN_FEE", "0.00");
                txtMaxFee.Text = DecimalValue(row, "MAX_FEE", "0.00");
                ddlFeeStatus.SelectedValue = Value(row, "Status") == "I" ? "I" : "A";
                ddlVatApplicable.SelectedValue = Value(row, "Is_VAT_Applicable") == "True" || Value(row, "Is_VAT_Applicable") == "1" ? "1" : "0";
            }
            txtMakerRemarks.Text = String.Empty;
            FormMode = "EDIT";
            lblEditorTitle.Text = "Edit " + (ddlMasterType.SelectedValue == "P" ? "promotion" : "arrangement fee row");
            ApplyEditorMode();
        }

        private static string Value(DataRow row, string column)
        {
            return row[column] == DBNull.Value ? String.Empty : Convert.ToString(row[column], CultureInfo.InvariantCulture);
        }

        private static string DecimalValue(DataRow row, string column, string format)
        {
            return row[column] == DBNull.Value ? String.Empty : Convert.ToDecimal(row[column], CultureInfo.InvariantCulture).ToString(format, CultureInfo.InvariantCulture);
        }

        private static string DateValue(DataRow row, string column)
        {
            return row[column] == DBNull.Value ? String.Empty : Convert.ToDateTime(row[column], CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            SyncBatchSelection();
            List<PendingChange> allChanges = PendingChanges;
            List<string> selectedKeys = BatchSelection;
            List<PendingChange> selected = allChanges.FindAll(delegate(PendingChange change) { return selectedKeys.Contains(change.MasterKey); });
            if (selected.Count == 0) { ShowMessage("Select at least one queued change to submit.", false); return; }
            try
            {
                if (String.IsNullOrWhiteSpace(CurrentUser) || CurrentUser.Length > 100) throw new ArgumentException("A valid maker user ID is required.");
                string requestIds = String.Empty;
                using (SqlConnection connection = new SqlConnection(ConnStr))
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            foreach (PendingChange change in selected)
                            {
                                long requestId = SubmitChange(connection, transaction, change);
                                if (requestIds.Length > 0) requestIds += ", ";
                                requestIds += requestId.ToString(CultureInfo.InvariantCulture);
                            }
                            transaction.Commit();
                        }
                        catch
                        {
                            try { if (transaction.Connection != null) transaction.Rollback(); }
                            catch { }
                            throw;
                        }
                    }
                }
                foreach (PendingChange change in selected) allChanges.Remove(change);
                foreach (PendingChange change in selected) selectedKeys.Remove(change.MasterKey);
                Session["LeadFeeMasterPendingChanges"] = allChanges;
                Session["LeadFeeMasterBatchSelection"] = selectedKeys;
                BindBatch();
                ClearForm();
                ShowMessage(selected.Count.ToString(CultureInfo.InvariantCulture) + " changes submitted in one batch for checker approval. Request IDs: " + requestIds, true);
                LoadMasterRows();
                LoadMyRequests();
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, false);
            }
        }

        private long SubmitChange(SqlConnection connection, SqlTransaction transaction, PendingChange change)
        {
            using (SqlCommand command = new SqlCommand("dbo.Proc_LeadFeeMaster_Submit", connection, transaction))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@MasterType", SqlDbType.Char, 1).Value = change.MasterType;
                command.Parameters.Add("@TargetSRNO", SqlDbType.Int).Value = change.TargetSRNO > 0 ? (object)change.TargetSRNO : DBNull.Value;
                command.Parameters.Add("@OldProductType", SqlDbType.NVarChar, 300).Value = OptionalText(change.OldProductType, 300);
                command.Parameters.Add("@OldProductSubType", SqlDbType.NVarChar, 300).Value = OptionalText(change.OldProductSubType, 300);
                command.Parameters.Add("@OldResidencyType", SqlDbType.NVarChar, 200).Value = OptionalText(change.OldResidencyType, 200);
                command.Parameters.Add("@OldStaff", SqlDbType.NVarChar, 200).Value = OptionalText(change.OldStaff, 200);
                command.Parameters.Add("@NewValues", SqlDbType.Xml).Value = change.NewValues;
                command.Parameters.Add("@MakerLoginId", SqlDbType.NVarChar, 100).Value = CurrentUser;
                command.Parameters.Add("@MakerRemarks", SqlDbType.NVarChar, 1000).Value = change.Remarks;
                command.Parameters.Add("@AttachmentName", SqlDbType.NVarChar, 260).Value = change.AttachmentName == null ? (object)DBNull.Value : change.AttachmentName;
                command.Parameters.Add("@AttachmentType", SqlDbType.NVarChar, 150).Value = change.AttachmentType == null ? (object)DBNull.Value : change.AttachmentType;
                command.Parameters.Add("@AttachmentData", SqlDbType.VarBinary, -1).Value = change.AttachmentData == null ? (object)DBNull.Value : change.AttachmentData;
                SqlParameter requestId = command.Parameters.Add("@RequestId", SqlDbType.BigInt);
                requestId.Direction = ParameterDirection.Output;
                command.ExecuteNonQuery();
                return Convert.ToInt64(requestId.Value, CultureInfo.InvariantCulture);
            }
        }

        protected void QueueChange_Click(object sender, EventArgs e)
        {
            try
            {
                if (FormMode != "ADD" && FormMode != "EDIT") throw new ArgumentException("Open Add or Edit before queueing a change.");
                if (fuAttachment.HasFile && fuAttachment.PostedFile.ContentLength > MaxAttachmentBytes)
                    throw new ArgumentException("The supporting attachment must not exceed 5 MB.");
                string remarks = (txtMakerRemarks.Text ?? String.Empty).Trim();
                if (remarks.Length == 0 || remarks.Length > 1000) throw new ArgumentException("Enter maker remarks of up to 1000 characters.");
                PendingChange change = new PendingChange();
                change.MasterType = ddlMasterType.SelectedValue;
                change.TargetSRNO = 0;
                int targetSrno;
                Int32.TryParse(hfTargetSrno.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out targetSrno);
                change.TargetSRNO = targetSrno;
                change.OperationName = FormMode == "ADD" ? "Insert" : "Update";
                change.OldProductType = EmptyToNull(hfOldProductType.Value);
                change.OldProductSubType = EmptyToNull(hfOldProductSubType.Value);
                change.OldResidencyType = EmptyToNull(hfOldResidencyType.Value);
                change.OldStaff = EmptyToNull(hfOldStaff.Value);
                change.NewValues = change.MasterType == "P" ? BuildPromotionXml() : BuildFeeXml();
                change.Remarks = remarks;
                change.DisplayKey = change.MasterType == "P" ? (txtPromotionName.Text ?? String.Empty).Trim()
                    : (txtProductType.Text + " / " + txtProductSubType.Text + " / " + txtResidencyType.Text + " / " + ddlStaff.SelectedValue);
                change.MasterKey = change.MasterType == "P"
                    ? (change.TargetSRNO > 0 ? "P|" + change.TargetSRNO.ToString(CultureInfo.InvariantCulture) : "P|N|" + change.DisplayKey)
                    : (change.OperationName == "Update" ? "F|" + change.OldProductType + "|" + change.OldProductSubType + "|" + change.OldResidencyType + "|" + change.OldStaff
                        : "F|N|" + txtProductType.Text + "|" + txtProductSubType.Text + "|" + txtResidencyType.Text + "|" + ddlStaff.SelectedValue);
                if (fuAttachment.HasFile)
                {
                    change.AttachmentName = Path.GetFileName(fuAttachment.FileName);
                    change.AttachmentType = fuAttachment.PostedFile.ContentType ?? "application/octet-stream";
                    change.AttachmentData = ReadAttachment();
                }
                List<PendingChange> changes = PendingChanges;
                for (int index = changes.Count - 1; index >= 0; index--)
                    if (String.Equals(changes[index].MasterKey, change.MasterKey, StringComparison.OrdinalIgnoreCase)) changes.RemoveAt(index);
                changes.Add(change);
                List<string> selectedKeys = BatchSelection;
                if (!selectedKeys.Contains(change.MasterKey)) selectedKeys.Add(change.MasterKey);
                Session["LeadFeeMasterPendingChanges"] = changes;
                Session["LeadFeeMasterBatchSelection"] = selectedKeys;
                BindBatch();
                ClearForm();
                LoadMasterRows();
                ShowMessage("Change added to the batch. Continue editing rows, then submit the selected changes together.", true);
            }
            catch (Exception ex) { ShowMessage(ex.Message, false); }
        }

        private static string EmptyToNull(string value) { return String.IsNullOrEmpty(value) ? null : value; }

        private void BindBatch()
        {
            List<PendingChange> changes = PendingChanges;
            gvChangeBatch.PageIndex = Math.Min(gvChangeBatch.PageIndex, Math.Max(0, (int)Math.Ceiling((double)changes.Count / gvChangeBatch.PageSize) - 1));
            gvChangeBatch.DataSource = changes;
            gvChangeBatch.DataBind();
            lblBatchStatus.Text = changes.Count == 0 ? "No changes queued." : changes.Count.ToString(CultureInfo.InvariantCulture) + " change(s) queued. Select the changes to submit.";
        }

        protected void BatchPage(object sender, GridViewPageEventArgs e)
        {
            SyncBatchSelection();
            gvChangeBatch.PageIndex = e.NewPageIndex;
            BindBatch();
        }

        protected void BatchRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            PendingChange change = e.Row.DataItem as PendingChange;
            CheckBox checkBox = e.Row.FindControl("chkQueueSelected") as CheckBox;
            if (change != null && checkBox != null) checkBox.Checked = BatchSelection.Contains(change.MasterKey);
        }

        private void SyncBatchSelection()
        {
            List<PendingChange> changes = PendingChanges;
            List<string> selectedKeys = BatchSelection;
            for (int index = 0; index < gvChangeBatch.Rows.Count; index++)
            {
                int changeIndex = gvChangeBatch.PageIndex * gvChangeBatch.PageSize + index;
                if (changeIndex >= changes.Count) break;
                CheckBox checkBox = gvChangeBatch.Rows[index].FindControl("chkQueueSelected") as CheckBox;
                string key = changes[changeIndex].MasterKey;
                if (checkBox != null && checkBox.Checked)
                {
                    if (!selectedKeys.Contains(key)) selectedKeys.Add(key);
                }
                else selectedKeys.Remove(key);
            }
            Session["LeadFeeMasterBatchSelection"] = selectedKeys;
        }

        protected void ClearBatch_Click(object sender, EventArgs e)
        {
            Session.Remove("LeadFeeMasterPendingChanges");
            Session.Remove("LeadFeeMasterBatchSelection");
            gvChangeBatch.PageIndex = 0;
            BindBatch();
            LoadMasterRows();
        }

        private string BuildPromotionXml()
        {
            string name = (txtPromotionName.Text ?? String.Empty).Trim();
            if (name.Length == 0 || name.Length > 200) throw new ArgumentException("Promotion name is required and must be at most 200 characters.");
            decimal discount = ReadDecimal(txtDiscountPerc.Text, "Discount percent", false);
            if (discount > 100) throw new ArgumentException("Discount percent must be between 0 and 100.");
            DateTime? start = ReadDate(txtPromotionStart.Text, "Promotion start date");
            DateTime? end = ReadDate(txtPromotionEnd.Text, "Promotion end date");
            if (start.HasValue && end.HasValue && start.Value > end.Value) throw new ArgumentException("Promotion end date must be on or after the start date.");
            return MakeXml(delegate(XmlWriter writer)
            {
                writer.WriteElementString("PromotionName", name);
                writer.WriteElementString("DiscountPerc", discount.ToString("0.00", CultureInfo.InvariantCulture));
                writer.WriteElementString("StartDate", start.HasValue ? start.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : String.Empty);
                writer.WriteElementString("EndDate", end.HasValue ? end.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : String.Empty);
                writer.WriteElementString("Status", ddlPromotionStatus.SelectedValue);
            });
        }

        private string BuildFeeXml()
        {
            string product = RequiredText(txtProductType.Text, "Product type", 300);
            string subtype = RequiredText(txtProductSubType.Text, "Product subtype", 300);
            string residency = RequiredText(txtResidencyType.Text, "Residency type", 200);
            decimal feeFv = ReadDecimal(txtFeeFv.Text, "FEE_FV", false);
            decimal feeOpv = ReadDecimal(txtFeeOpv.Text, "FEE_OPV", false);
            decimal feeApv = ReadDecimal(txtFeeApv.Text, "FEE_APV", false);
            decimal feeBuyout = ReadDecimal(txtFeeBuyout.Text, "FEE_Buyout", false);
            decimal feeTopup = ReadDecimal(txtFeeTopup.Text, "FEE_Topup", false);
            decimal feeEquity = ReadDecimal(txtFeeEquity.Text, "FEE_Equity", false);
            decimal feeCashout = ReadDecimal(txtFeeCashout.Text, "FEE_Cashout", false);
            decimal feeMbre = ReadDecimal(txtFeeMbre.Text, "FEE_MBRE", false);
            decimal feeApp = ReadDecimal(txtFeeApp.Text, "FEE_APP", false);
            decimal feeAcc = ReadDecimal(txtFeeAcc.Text, "FEE_ACC", false);
            decimal minFee = ReadDecimal(txtMinFee.Text, "MIN_FEE", false);
            decimal maxFee = ReadDecimal(txtMaxFee.Text, "MAX_FEE", false);
            if (maxFee < minFee) throw new ArgumentException("MAX_FEE must be greater than or equal to MIN_FEE.");
            return MakeXml(delegate(XmlWriter writer)
            {
                writer.WriteElementString("PRODUCT_TYPE", product);
                writer.WriteElementString("Product_SubTYPE", subtype);
                writer.WriteElementString("Residency_Type", residency);
                writer.WriteElementString("Staff", ddlStaff.SelectedValue);
                writer.WriteElementString("FEE_FV", feeFv.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_OPV", feeOpv.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_APV", feeApv.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_Buyout", feeBuyout.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_Topup", feeTopup.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_Equity", feeEquity.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_Cashout", feeCashout.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_MBRE", feeMbre.ToString("0.0000", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_APP", feeApp.ToString("0.00", CultureInfo.InvariantCulture));
                writer.WriteElementString("FEE_ACC", feeAcc.ToString("0.00", CultureInfo.InvariantCulture));
                writer.WriteElementString("MIN_FEE", minFee.ToString("0.00", CultureInfo.InvariantCulture));
                writer.WriteElementString("MAX_FEE", maxFee.ToString("0.00", CultureInfo.InvariantCulture));
                writer.WriteElementString("Status", ddlFeeStatus.SelectedValue);
                writer.WriteElementString("Is_VAT_Applicable", ddlVatApplicable.SelectedValue);
            });
        }

        private static string MakeXml(Action<XmlWriter> writeRecord)
        {
            StringBuilder output = new StringBuilder();
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            using (XmlWriter writer = XmlWriter.Create(output, settings))
            {
                writer.WriteStartElement("Record");
                writeRecord(writer);
                writer.WriteEndElement();
            }
            return output.ToString();
        }

        private static string RequiredText(string value, string name, int maximumLength)
        {
            string text = (value ?? String.Empty).Trim();
            if (text.Length == 0 || text.Length > maximumLength) throw new ArgumentException(name + " is required and must be at most " + maximumLength.ToString(CultureInfo.InvariantCulture) + " characters.");
            return text;
        }

        private static decimal ReadDecimal(string value, string name, bool allowNegative)
        {
            decimal result;
            if (!Decimal.TryParse((value ?? String.Empty).Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out result)
                || (!allowNegative && result < 0))
                throw new ArgumentException(name + " must be a valid non-negative number.");
            return result;
        }

        private static DateTime? ReadDate(string value, string name)
        {
            if (String.IsNullOrWhiteSpace(value)) return null;
            DateTime date;
            if (!DateTime.TryParseExact(value.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                throw new ArgumentException(name + " must be a valid date.");
            return date.Date;
        }

        private byte[] ReadAttachment()
        {
            using (MemoryStream memory = new MemoryStream())
            {
                fuAttachment.PostedFile.InputStream.CopyTo(memory);
                return memory.ToArray();
            }
        }

        protected void New_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        protected void Add_Click(object sender, EventArgs e)
        {
            ClearForm();
            FormMode = "ADD";
            lblEditorTitle.Text = "Add " + (ddlMasterType.SelectedValue == "P" ? "promotion" : "arrangement fee row");
            ApplyEditorMode();
        }

        private void ClearForm()
        {
            hfTargetSrno.Value = "0";
            hfOldProductType.Value = String.Empty;
            hfOldProductSubType.Value = String.Empty;
            hfOldResidencyType.Value = String.Empty;
            hfOldStaff.Value = String.Empty;
            txtPromotionName.Text = String.Empty;
            txtDiscountPerc.Text = String.Empty;
            txtPromotionStart.Text = String.Empty;
            txtPromotionEnd.Text = String.Empty;
            ddlPromotionStatus.SelectedValue = "A";
            txtProductType.Text = String.Empty;
            txtProductSubType.Text = String.Empty;
            txtResidencyType.Text = String.Empty;
            ddlStaff.SelectedValue = "No";
            txtFeeFv.Text = txtFeeOpv.Text = txtFeeApv.Text = txtFeeBuyout.Text = String.Empty;
            txtFeeTopup.Text = txtFeeEquity.Text = txtFeeCashout.Text = txtFeeMbre.Text = String.Empty;
            txtFeeApp.Text = txtFeeAcc.Text = txtMinFee.Text = txtMaxFee.Text = String.Empty;
            ddlFeeStatus.SelectedValue = "A";
            ddlVatApplicable.SelectedValue = "0";
            txtMakerRemarks.Text = String.Empty;
            FormMode = String.Empty;
            ApplyEditorMode();
        }

        protected void SetUser_Click(object sender, EventArgs e)
        {
            string login = (txtCurrentUser.Text ?? String.Empty).Trim();
            if (login.Length == 0 || login.Length > 100) { ShowMessage("Enter a user ID of up to 100 characters.", false); return; }
            Session["UserID"] = login;
            lblCurrentUser.Text = login;
            LoadMyRequests();
            ShowMessage("Acting user changed to " + login + ".", true);
        }

        protected void Export_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable data = GetMasterRows();
                if (data.Rows.Count == 0) throw new ArgumentException("No master rows match the current filters.");
                StringBuilder csv = new StringBuilder();
                for (int column = 0; column < data.Columns.Count; column++)
                {
                    if (column > 0) csv.Append(',');
                    csv.Append(CsvCell(data.Columns[column].ColumnName));
                }
                csv.AppendLine();
                foreach (DataRow row in data.Rows)
                {
                    for (int column = 0; column < data.Columns.Count; column++)
                    {
                        if (column > 0) csv.Append(',');
                        csv.Append(CsvCell(row[column] == DBNull.Value ? String.Empty : Convert.ToString(row[column], CultureInfo.InvariantCulture)));
                    }
                    csv.AppendLine();
                }
                _isFileDownload = true;
                Response.Clear();
                Response.ContentType = "text/csv";
                Response.ContentEncoding = Encoding.UTF8;
                Response.AddHeader("Content-Disposition", "attachment; filename=LeadFeeMaster_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".csv");
                Response.BinaryWrite(new UTF8Encoding(true).GetBytes(csv.ToString()));
                Response.Flush();
                Context.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex) { ShowMessage(ex.Message, false); }
        }

        private static string CsvCell(string value)
        {
            string text = value ?? String.Empty;
            if (text.Length > 0 && (text[0] == '=' || text[0] == '+' || text[0] == '-' || text[0] == '@' || text[0] == '\t'))
                text = "'" + text;
            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }
    }
}