namespace HF48Workflow
{
    public partial class LeadFeeMasterChecker
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.Label lblCurrentUser;
        protected global::System.Web.UI.WebControls.TextBox txtCurrentUser;
        protected global::System.Web.UI.WebControls.Button btnSetUser;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.DropDownList ddlMasterType;
        protected global::System.Web.UI.WebControls.DropDownList ddlStatus;
        protected global::System.Web.UI.WebControls.TextBox txtMakerFilter;
        protected global::System.Web.UI.WebControls.TextBox txtFromDate;
        protected global::System.Web.UI.WebControls.TextBox txtToDate;
        protected global::System.Web.UI.WebControls.Button btnFilter;
        protected global::System.Web.UI.WebControls.Button btnClearFilters;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.GridView gvRequests;
        protected global::System.Web.UI.WebControls.Panel pnlReview;
        protected global::System.Web.UI.WebControls.HiddenField hfRequestId;
        protected global::System.Web.UI.WebControls.Label lblRequestSummary;
        protected global::System.Web.UI.WebControls.Label lblMaker;
        protected global::System.Web.UI.WebControls.Label lblMakerRemarks;
        protected global::System.Web.UI.WebControls.GridView gvComparison;
        protected global::System.Web.UI.WebControls.Button btnAttachment;
        protected global::System.Web.UI.WebControls.GridView gvAudit;
        protected global::System.Web.UI.WebControls.TextBox txtCheckerRemarks;
        protected global::System.Web.UI.WebControls.Button btnApprove;
        protected global::System.Web.UI.WebControls.Button btnReject;
    }
}