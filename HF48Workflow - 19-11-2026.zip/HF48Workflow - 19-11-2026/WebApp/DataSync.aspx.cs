using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Xml;
using System.Web.Script.Services;
using System.Web;
using System.Web.UI;
using System.Web.Services;

namespace HF48Workflow
{
    public partial class DataSync : Page
    {
        private const string PreviewSessionKey = "DataSyncPreviewApplicationId";
        private const string PreviewLeadApplicationIdSessionKey = "DataSyncPreviewLeadApplicationId";
        private static readonly FieldDefinition[] FieldDefinitions = CreateFieldDefinitions();

        [WebMethod(EnableSession = true)]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static ComparisonResponse LoadApplicationData(
            string applicationId, string selectedCoreApplicationId)
        {
            ComparisonResponse response = new ComparisonResponse();
            applicationId = (applicationId ?? String.Empty).Trim();
            selectedCoreApplicationId = (selectedCoreApplicationId ?? String.Empty).Trim();
            if (HttpContext.Current != null && HttpContext.Current.Session != null)
            {
                HttpContext.Current.Session.Remove(PreviewSessionKey);
                HttpContext.Current.Session.Remove(PreviewLeadApplicationIdSessionKey);
            }
            if (applicationId.Length == 0 || applicationId.Length > 200)
            {
                response.Message = "Enter an application ID of 1 to 200 characters.";
                return response;
            }
            response.SearchApplicationId = applicationId;

            try
            {
                ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
                if (settings == null || String.IsNullOrEmpty(settings.ConnectionString))
                {
                    response.Message = "The database connection is not configured. Contact IT support.";
                    return response;
                }

                using (SqlConnection connection = new SqlConnection(settings.ConnectionString))
                {
                    connection.Open();
                    response.Candidates = LoadApplicationCandidates(connection, applicationId);
                    if (response.Candidates.Count == 0)
                    {
                        response.Message = "No matching lead or Core application was found.";
                        return response;
                    }

                    ApplicationCandidate selectedCandidate = null;
                    if (selectedCoreApplicationId.Length == 0)
                    {
                        if (response.Candidates.Count > 1)
                        {
                            response.NeedsCandidateSelection = true;
                            response.Success = true;
                            response.Message = "Several Core application IDs match. Select the exact record to review.";
                            return response;
                        }
                        selectedCandidate = response.Candidates[0];
                    }
                    else
                    {
                        foreach (ApplicationCandidate candidate in response.Candidates)
                        {
                            if (String.Equals(candidate.ApplicationId, selectedCoreApplicationId,
                                StringComparison.OrdinalIgnoreCase))
                            {
                                selectedCandidate = candidate;
                                break;
                            }
                        }
                        if (selectedCandidate == null)
                        {
                            response.Message = "The selected Core application ID is not a candidate for this search. Search again.";
                            return response;
                        }
                    }

                    using (DataSet data = new DataSet())
                    {
                        SqlParameter matched;
                        using (SqlCommand command = new SqlCommand("dbo.Proc_HFLMS_AfterSales_DataSync_ByApplicationId", connection))
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            command.CommandType = CommandType.StoredProcedure;
                            command.CommandTimeout = 60;
                            command.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value =
                                selectedCandidate.ApplicationId;
                            command.Parameters.Add("@LeadApplicationId", SqlDbType.NVarChar, 200).Value =
                                String.IsNullOrEmpty(selectedCandidate.LeadApplicationId)
                                    ? (object)DBNull.Value
                                    : selectedCandidate.LeadApplicationId;
                            command.Parameters.Add("@PreviewOnly", SqlDbType.Bit).Value = true;
                            matched = command.Parameters.Add("@CustomerRowsMatched", SqlDbType.Int);
                            matched.Direction = ParameterDirection.Output;
                            adapter.Fill(data);
                        }

                        if (data.Tables.Count != 5)
                            throw new InvalidOperationException("The data sync procedure did not return all comparison records.");
                        response.MatchedCustomerCount = matched.Value == DBNull.Value
                            ? 0
                            : Convert.ToInt32(matched.Value, CultureInfo.InvariantCulture);

                        DataTable lead = data.Tables[0];
                        DataTable master = data.Tables[1];
                        DataTable customerDetails = data.Tables[2];
                        DataTable coreApplicationDetails = data.Tables[3];
                        DataTable repaymentDetails = data.Tables[4];
                        DataRow leadRow = lead.Rows.Count == 0 ? null : lead.Rows[0];
                        DataRow masterRow = master.Rows.Count == 0 ? null : master.Rows[0];
                        if (leadRow == null && masterRow == null)
                        {
                            response.Message = "No lead, Core, or master data was found for this ID.";
                            return response;
                        }

                        Dictionary<int, DataRow> customerRows = IndexCustomers(customerDetails);
                        response.ApplicationId = selectedCandidate.ApplicationId;
                        response.SourceType = selectedCandidate.SourceType;
                        response.MasterFound = masterRow != null;
                        response.Operation = response.MasterFound ? "Update existing master record" : "Insert new master record";
                        response.Rows = BuildComparisonRows(leadRow, masterRow, customerRows,
                            coreApplicationDetails.Rows.Count == 0 ? null : coreApplicationDetails.Rows[0],
                            repaymentDetails.Rows.Count == 0 ? null : repaymentDetails.Rows[0]);
                        if (HttpContext.Current != null && HttpContext.Current.Session != null)
                        {
                            HttpContext.Current.Session[PreviewSessionKey] = selectedCandidate.ApplicationId;
                            HttpContext.Current.Session[PreviewLeadApplicationIdSessionKey] =
                                selectedCandidate.LeadApplicationId ?? String.Empty;
                        }
                        response.Success = true;
                        return response;
                    }
                }
            }
            catch (SqlException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync comparison failed: {0}", ex);
                response.Message = ex.Number == 50000
                    ? ex.Message
                    : ex.Number == -2
                        ? "The comparison timed out after 60 seconds. Ask IT to check the database query plan and indexes."
                        : "The comparison failed because of a database error. Contact IT support.";
                return response;
            }
            catch (ConfigurationErrorsException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync configuration failed: {0}", ex);
                response.Message = "The database connection is not configured. Contact IT support.";
                return response;
            }
            catch (InvalidOperationException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync returned an unexpected result: {0}", ex);
                response.Message = "The database returned an incomplete comparison. Contact IT support.";
                return response;
            }
        }

        private static List<ApplicationCandidate> LoadApplicationCandidates(
            SqlConnection connection, string searchApplicationId)
        {
            List<ApplicationCandidate> candidates = new List<ApplicationCandidate>();
            using (SqlCommand command = new SqlCommand("dbo.Proc_HFLMS_AfterSales_DataSync_GetApplicationCandidates", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 30;
                command.Parameters.Add("@SearchApplicationId", SqlDbType.NVarChar, 200).Value = searchApplicationId;
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        candidates.Add(new ApplicationCandidate
                        {
                            ApplicationId = Convert.ToString(reader["ApplicationId"], CultureInfo.InvariantCulture),
                            LeadApplicationId = reader["LeadApplicationId"] == DBNull.Value
                                ? null
                                : Convert.ToString(reader["LeadApplicationId"], CultureInfo.InvariantCulture),
                            SourceType = Convert.ToString(reader["SourceType"], CultureInfo.InvariantCulture),
                            IsExactMatch = Convert.ToBoolean(reader["IsExactMatch"], CultureInfo.InvariantCulture)
                        });
                    }
                }
            }
            return candidates;
        }

        [WebMethod(EnableSession = true)]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static SyncResponse SynchronizeApplicationData(
            string applicationId, string[] selectedFields, string synchronizedBy)
        {
            SyncResponse response = new SyncResponse();
            applicationId = (applicationId ?? String.Empty).Trim();
            synchronizedBy = (synchronizedBy ?? String.Empty).Trim();
            if (applicationId.Length == 0 || applicationId.Length > 200)
            {
                response.Message = "Enter an application ID of 1 to 200 characters.";
                return response;
            }
            if (synchronizedBy.Length == 0 || synchronizedBy.Length > 256)
            {
                response.Message = "Enter and apply a current user name of 1 to 256 characters.";
                return response;
            }
            HttpContext context = HttpContext.Current;
            string previewApplicationId = context == null || context.Session == null
                ? null
                : context.Session[PreviewSessionKey] as string;
            string previewLeadApplicationId = context == null || context.Session == null
                ? null
                : context.Session[PreviewLeadApplicationIdSessionKey] as string;
            if (!String.Equals(applicationId, previewApplicationId, StringComparison.Ordinal))
            {
                response.Message = "Search and review this application before synchronizing.";
                return response;
            }
            if (selectedFields == null || selectedFields.Length == 0)
            {
                response.Message = "Select at least one field to synchronize.";
                return response;
            }

            Dictionary<string, bool> allowedFields = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
            foreach (FieldDefinition field in FieldDefinitions)
                allowedFields[field.MasterColumn] = true;
            List<string> validatedFields = new List<string>();
            Dictionary<string, bool> seenFields = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
            foreach (string fieldName in selectedFields)
            {
                if (String.IsNullOrWhiteSpace(fieldName) || !allowedFields.ContainsKey(fieldName))
                {
                    response.Message = "The selected field list is invalid. Search the application again.";
                    return response;
                }
                if (!seenFields.ContainsKey(fieldName))
                {
                    validatedFields.Add(fieldName);
                    seenFields.Add(fieldName, true);
                }
            }

            try
            {
                ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
                if (settings == null || String.IsNullOrEmpty(settings.ConnectionString))
                {
                    response.Message = "The database connection is not configured. Contact IT support.";
                    return response;
                }

                using (SqlConnection connection = new SqlConnection(settings.ConnectionString))
                using (SqlCommand command = new SqlCommand("dbo.Proc_HFLMS_AfterSales_DataSync_ByApplicationId", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 60;
                    command.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value = applicationId;
                    command.Parameters.Add("@LeadApplicationId", SqlDbType.NVarChar, 200).Value =
                        String.IsNullOrEmpty(previewLeadApplicationId)
                            ? (object)DBNull.Value
                            : previewLeadApplicationId;
                    command.Parameters.Add("@PreviewOnly", SqlDbType.Bit).Value = false;
                    command.Parameters.Add("@SelectedFields", SqlDbType.Xml).Value = BuildSelectedFieldsXml(validatedFields);
                    command.Parameters.Add("@SynchronizedBy", SqlDbType.NVarChar, 256).Value = synchronizedBy;
                    SqlParameter inserted = command.Parameters.Add("@InsertedRows", SqlDbType.Int);
                    inserted.Direction = ParameterDirection.Output;
                    SqlParameter updated = command.Parameters.Add("@UpdatedRows", SqlDbType.Int);
                    updated.Direction = ParameterDirection.Output;
                    SqlParameter matched = command.Parameters.Add("@CustomerRowsMatched", SqlDbType.Int);
                    matched.Direction = ParameterDirection.Output;
                    SqlParameter changed = command.Parameters.Add("@ChangedFields", SqlDbType.Int);
                    changed.Direction = ParameterDirection.Output;
                    connection.Open();
                    command.ExecuteNonQuery();

                    response.InsertedRows = Convert.ToInt32(inserted.Value, CultureInfo.InvariantCulture);
                    response.UpdatedRows = Convert.ToInt32(updated.Value, CultureInfo.InvariantCulture);
                    response.MatchedCustomerCount = Convert.ToInt32(matched.Value, CultureInfo.InvariantCulture);
                    response.ChangedFields = Convert.ToInt32(changed.Value, CultureInfo.InvariantCulture);
                    response.Success = true;
                    response.Message = "Synchronization completed.";
                    return response;
                }
            }
            catch (SqlException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data synchronization failed: {0}", ex);
                response.Message = ex.Number == 50000
                    ? ex.Message
                    : "Synchronization failed. The database transaction was rolled back; contact IT support.";
                return response;
            }
            catch (ConfigurationErrorsException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync configuration failed: {0}", ex);
                response.Message = "The database connection is not configured. Contact IT support.";
                return response;
            }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static AuditHistoryResponse LoadAuditHistory(string applicationId)
        {
                AuditHistoryResponse response = new AuditHistoryResponse();
                applicationId = (applicationId ?? String.Empty).Trim();
                if (applicationId.Length > 200)
                {
                    response.Message = "Application ID must be 200 characters or fewer.";
                    return response;
                }

                try
                {
                    ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
                    if (settings == null || String.IsNullOrEmpty(settings.ConnectionString))
                    {
                        response.Message = "The database connection is not configured. Contact IT support.";
                        return response;
                    }

                    using (SqlConnection connection = new SqlConnection(settings.ConnectionString))
                    using (SqlCommand command = new SqlCommand("dbo.Proc_HFLMS_AfterSales_DataSync_GetAuditHistory", connection))
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    using (DataTable history = new DataTable())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandTimeout = 60;
                        command.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value =
                            applicationId.Length == 0 ? (object)DBNull.Value : applicationId;
                        adapter.Fill(history);
                        foreach (DataRow row in history.Rows)
                        {
                            response.Rows.Add(new AuditHistoryRow
                            {
                                RunId = ReadValue(row, "RunId"),
                                ApplicationId = ReadValue(row, "ApplicationId"),
                                SynchronizedBy = ReadValue(row, "SynchronizedBy"),
                                SynchronizedOn = ReadTimestamp(row, "SynchronizedOn"),
                                Operation = ReadValue(row, "Operation"),
                                SelectedFieldCount = ReadInt(row, "SelectedFieldCount"),
                                ChangedFieldCount = ReadInt(row, "ChangedFieldCount"),
                                FieldName = ReadValue(row, "FieldName"),
                                OldValue = ReadValue(row, "OldValue"),
                                NewValue = ReadValue(row, "NewValue")
                            });
                        }
                    }

                    response.Success = true;
                    return response;
                }
                catch (SqlException ex)
                {
                    System.Diagnostics.Trace.TraceError("Application data sync audit history failed: {0}", ex);
                    response.Message = "Audit history could not be loaded. Contact IT support.";
                    return response;
                }
                catch (ConfigurationErrorsException ex)
                {
                    System.Diagnostics.Trace.TraceError("Application data sync audit configuration failed: {0}", ex);
                    response.Message = "The database connection is not configured. Contact IT support.";
                    return response;
                }
        }

        private static string BuildSelectedFieldsXml(List<string> fields)
        {
                StringBuilder xml = new StringBuilder();
                using (XmlWriter writer = XmlWriter.Create(xml, new XmlWriterSettings { OmitXmlDeclaration = true }))
                {
                    writer.WriteStartElement("fields");
                    foreach (string field in fields)
                        writer.WriteElementString("field", field);
                    writer.WriteEndElement();
                }
                return xml.ToString();
        }

        private static int ReadInt(DataRow row, string columnName)
        {
                return row.Table.Columns.Contains(columnName) && row[columnName] != DBNull.Value
                    ? Convert.ToInt32(row[columnName], CultureInfo.InvariantCulture)
                    : 0;
        }

        private static string ReadTimestamp(DataRow row, string columnName)
        {
            if (!row.Table.Columns.Contains(columnName) || row[columnName] == DBNull.Value)
                return String.Empty;
            DateTime timestamp;
            return DateTime.TryParse(Convert.ToString(row[columnName], CultureInfo.InvariantCulture),
                CultureInfo.InvariantCulture, DateTimeStyles.None, out timestamp)
                ? timestamp.ToString("dd MMM yyyy HH:mm:ss", CultureInfo.InvariantCulture)
                : Convert.ToString(row[columnName], CultureInfo.InvariantCulture);
        }

        private static Dictionary<int, DataRow> IndexCustomers(DataTable details)
        {
            Dictionary<int, DataRow> customers = new Dictionary<int, DataRow>();
            foreach (DataRow row in details.Rows)
            {
                int slot;
                if (Int32.TryParse(Convert.ToString(row["CustomerSlot"], CultureInfo.InvariantCulture), out slot)
                    && !customers.ContainsKey(slot))
                    customers.Add(slot, row);
            }
            return customers;
        }

        private static List<ComparisonRow> BuildComparisonRows(
            DataRow lead,
            DataRow master,
            Dictionary<int, DataRow> customers,
            DataRow coreApplication,
            DataRow repayment)
        {
            List<ComparisonRow> rows = new List<ComparisonRow>(FieldDefinitions.Length);
            foreach (FieldDefinition field in FieldDefinitions)
            {
                DataRow customer = null;
                if (field.CustomerSlot > 0)
                    customers.TryGetValue(field.CustomerSlot, out customer);

                string leadValue = ReadValue(lead, field.LeadColumn);
                string masterValue = ReadValue(master, field.MasterColumn);
                if (field.MasterColumn == "INSTALLMENTAMOUNT" && masterValue.Length == 0)
                    masterValue = ReadValue(master, "EMI_AMOUNT");
                DataRow coreSource = field.CoreSource == "Application" ? coreApplication
                    : field.CoreSource == "Repayment" ? repayment : customer;
                string customerValue = ReadValue(coreSource, field.CustomerColumn);
                bool hasCustomerValue = HasNonNullValue(coreSource, field.CustomerColumn);
                if (!hasCustomerValue && coreSource != null)
                {
                    customerValue = ReadValue(coreSource, field.CustomerFallbackColumn);
                    hasCustomerValue = HasNonNullValue(coreSource, field.CustomerFallbackColumn);
                }
                bool hasLeadValue = HasNonNullValue(lead, field.LeadColumn);
                bool coreOnly = master != null
                    && (lead == null
                        || !lead.Table.Columns.Contains("LEAD_NO")
                        || lead["LEAD_NO"] == DBNull.Value
                        || String.IsNullOrWhiteSpace(Convert.ToString(lead["LEAD_NO"], CultureInfo.InvariantCulture)));

                string proposedValue = hasCustomerValue
                    ? customerValue
                    : leadValue;
                if (!hasCustomerValue && !hasLeadValue
                    && (field.PreserveMasterWhenMissing || (coreOnly && master != null)))
                    proposedValue = masterValue;

                string action;
                string actionClass;
                if (master == null)
                {
                    action = "Insert";
                    actionClass = "insert";
                }
                else if (String.Equals(Normalize(masterValue), Normalize(proposedValue), StringComparison.OrdinalIgnoreCase))
                {
                    action = "No change";
                    actionClass = "no-change";
                }
                else
                {
                    action = "Update";
                    actionClass = "update";
                }

                rows.Add(new ComparisonRow
                {
                    Section = field.Section,
                    FriendlyName = field.FriendlyName,
                    FieldKey = field.MasterColumn,
                    LeadValue = leadValue,
                    MasterValue = masterValue,
                    CustomerValue = customerValue,
                    ProposedValue = proposedValue,
                    Action = action,
                    ActionClass = actionClass
                });
            }
            return rows;
        }

        private static string ReadValue(DataRow row, string columnName)
        {
            if (row == null || String.IsNullOrEmpty(columnName) || !row.Table.Columns.Contains(columnName))
                return String.Empty;

            object value = row[columnName];
            if (value == null || value == DBNull.Value)
                return String.Empty;
            if (value is DateTime)
                return ((DateTime)value).ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
            return Convert.ToString(value, CultureInfo.InvariantCulture);
        }

        private static bool HasNonNullValue(DataRow row, string columnName)
        {
            return row != null
                && !String.IsNullOrEmpty(columnName)
                && row.Table.Columns.Contains(columnName)
                && row[columnName] != null
                && row[columnName] != DBNull.Value;
        }

        private static string Normalize(string value)
        {
            return (value ?? String.Empty).Trim();
        }

        private static FieldDefinition[] CreateFieldDefinitions()
        {
            List<FieldDefinition> fields = new List<FieldDefinition>();
            AddCustomerFields(fields, 1, String.Empty);
            AddCustomerFields(fields, 2, "2");
            AddCustomerFields(fields, 3, "3");
            AddCustomerFields(fields, 4, "4");
            fields.Add(new FieldDefinition("ID Documents", "Residency type", "RESIDENCYTYPE", "RESIDENCYTYPE", null, 0));
            fields.Add(new FieldDefinition("ID Documents", "Branch code", "BRANCH_CODE", "BRANCH_CODE", "BRANCH_CODE", 1));

            fields.Add(new FieldDefinition("Property Details", "Developer", "DEVELOPER", "DEVELOPER", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Project / property name", "PROPERTYNAME", "PROPERTYNAME", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Property description", "PROPERTYDETAILS", "PROPERTYDETAILS", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Property type", "PROPERTYTYPE", "PROPERTYTYPE", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Built-up area", "BUILTUPAREA", "BUILTUPAREA", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Property / project ID", "PROPERTYID", "PROPERTYID", null, 0));

            fields.Add(new FieldDefinition("Employment Details", "Employment type", "EMPLOYMENTTYPE", "EMPLOYMENTTYPE", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Current employer", "CURRENTEMPLOYER1", "CURRENTEMPLOYER1", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Designation", "DESIGNATION1", "DESIGNATION1", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Applicant 1 income", "INCOME1", "INCOME1", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Applicant 2 income", "INCOME2", "INCOME2", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Applicant 3 income", "INCOME3", "INCOME3", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Applicant 4 income", "INCOME4", "INCOME4", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Customer category", null, "CORPORATECATEGORY", "CUSTOMER_CATEGORY", 1, true));
            fields.Add(new FieldDefinition("Employment Details", "Staff indicator", null, "STAFF_YN", "STAFF_YN", 1, true));

            fields.Add(new FieldDefinition("Finance Details", "Application status", "CURRENTSTATUS", "CURRENTSTATUS", "CURRENTSTATUS", 1));
            fields.Add(new FieldDefinition("Finance Details", "Pre-approval number", "PREAPPROVALNO", "PREAPPROVALNO", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Original property value", "ORIGINALPROPERTYVALUE", "ORIGINALPROPERTYVALUE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Appraised property value", "APPRAISEDPROPERTYVALUE", "APPRAISEDPROPERTYVALUE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Finance amount", "FINANCEVALUE", "FINANCEVALUE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Down payment", "DOWNPAYMENT", "DOWNPAYMENT", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Debt service ratio (DSR)", "DSR", "DSR", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Finance-to-value (FTV)", "FTV", "FTV", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Installment / EMI amount", "INSTALLMENTAMOUNT",
                "INSTALLMENTAMOUNT", "EMI_AMOUNT", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Istisna tenor", "ISTISNATENOR", "ISTISNATENOR", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Ijara tenor", "IJARATENOR", "IJARATENOR", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Final rate", "FINALRATE", "FINALRATE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Istisna product", "ISTISNAPRODUCT", "ISTISNAPRODUCT", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Ijara product", "IJARAPRODUCT", "IJARAPRODUCT", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Purchase type", "PURCHASETYPE", "PURCHASETYPE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Offer letter acceptance date", "OL_ACCEPTANCE_DATE", "OL_ACCEPTANCE_DATE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Offer letter generation date", "OL_GENERATION_DATE", "OL_GENERATION_DATE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Lead last updated", "LASTUPDATED", "LASTUPDATED", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Core application ID", null, "APPLICATION_ID", "APPLICATION_ID", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Application start date", null, "APP_START_DATE", "APP_START_DATE", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Contract status", null, "CONT_STAT", "CONT_STAT", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Current account balance", null, "CURR_ACC_BAL", "CURR_ACC_BAL", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Current rate", null, "CURR_RATE", "CURR_RATE", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "EMI date", null, "EMI_DATE", "EMI_DATE", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "EMI frequency", null, "EMI_FREQUENCY", "EMI_FREQUENCY", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Ijara booked status", null, "IJARA_BOOKED", "IJARA_BOOKED", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Ijara booked date", null, "IJARA_BOOKED_DATE", "IJARA_BOOKED_DATE", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Installment number (core)", null, "INSTALL_NO", "INSTALL_NO", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Maturity date", null, "MATURITY_DATE", "MATURITY_DATE", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "PDC amount", null, "PDC_AMOUNT", "PDC_AMOUNT", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "PDC number", null, "PDC_NO", "PDC_NO", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Principal outstanding", null, "PRIN_OS", "PRIN_OS", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Remaining current tenor", null, "REM_TENOR_CURR", "REM_TENOR_CURR", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Repayment tenor", null, "REPAY_TENOR", "REPAY_TENOR", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Return value", null, "RETURN_VALUE", "RETURN_VALUE", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "TBR current", null, "TBR_CURR", "TBR_CURR", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Total installment number", null, "TOT_INST_NO", "TOT_INST_NO", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Total bounce count", null, "TOTAL_BOUNCE", "TOTAL_BOUNCE", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Delinquency type", null, "DQ_TYPE", "DQ_TYPE", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Core value date", null, "VALUE_DATE", "VALUE_DATE", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Installment number", null, "INSTALLMENT_NO", "INSTALLMENT_NO", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Contract reference number", null, "contract_ref_no", "contract_ref_no", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Core CIF", null, "CIF", "CIF", 0, "Application", true));
            fields.Add(new FieldDefinition("Finance Details", "Repayment type", null, "REPAYMENT_TYPE", "RepaymentType", 0, "Repayment", true));
            fields.Add(new FieldDefinition("Finance Details", "Repayment start date", null, "REPAYMENT_START_DATE", "StartDate", 0, "Repayment", true));
            fields.Add(new FieldDefinition("Finance Details", "Repayment bank", null, "REPAYMENT_BANK_NAME", "BankName", 0, "Repayment", true));
            fields.Add(new FieldDefinition("Finance Details", "Repayment account type", null, "REPAYMENT_ACCOUNT_TYPE", "AccountType", 0, "Repayment", true));
            fields.Add(new FieldDefinition("Finance Details", "Repayment IBAN", null, "REPAYMENT_IBAN", "IBAN", 0, "Repayment", true));

            fields.Add(new FieldDefinition("Address Details", "Mobile country code", "MOBILECODE", "MOBILECODE", "MOBILECODE", 1));
            fields.Add(new FieldDefinition("Address Details", "Mobile number", "MOBILENUMBER", "MOBILENUMBER", "MOBILENUMBER", 1));
            fields.Add(new FieldDefinition("Address Details", "Personal email", "PERSONAL_EMAIL", "PERSONAL_EMAIL", "PERSONAL_EMAIL", 1));
            fields.Add(new FieldDefinition("Address Details", "Office email", "OFFICE_EMAIL", "OFFICE_EMAIL", "OFFICE_EMAIL", 1));
            fields.Add(new FieldDefinition("Address Details", "Mailing PO box", "MAILING_POBOX", "MAILING_POBOX", "MAILING_POBOX", 1));
            fields.Add(new FieldDefinition("Address Details", "Mailing city", "MAILING_CITY", "MAILING_CITY", null, 0));
            fields.Add(new FieldDefinition("Address Details", "Mailing country", "MAILING_COUNTRY", "MAILING_COUNTRY", "MAILING_COUNTRY", 1));
            fields.Add(new FieldDefinition("Address Details", "Residential telephone code", "RESI_TEL_CODE", "RESI_TEL_CODE", "RESI_TEL_CODE", 1));
            fields.Add(new FieldDefinition("Address Details", "Residential telephone number", "RESI_TEL_NUM", "RESI_TEL_NUM", "RESI_TEL_NUM", 1, true));
            fields.Add(new FieldDefinition("Address Details", "Office telephone code", "OFFICE_TEL_CODE", "OFFICE_TEL_CODE", null, 0));
            fields.Add(new FieldDefinition("Address Details", "Office telephone number", "OFFICE_TEL_NUM", "OFFICE_TEL_NUM", null, 0, true));
            fields.Add(new FieldDefinition("Address Details", "Residential address line 1", "RESI_ADDRESS1", "RESI_ADDRESS1", "RESI_ADDRESS1", 1, true));
            fields.Add(new FieldDefinition("Address Details", "Residential address line 2", "RESI_ADDRESS2", "RESI_ADDRESS2", "RESI_ADDRESS2", 1, true));
            fields.Add(new FieldDefinition("Address Details", "Residential address line 3", "RESI_ADDRESS3", "RESI_ADDRESS3", "RESI_ADDRESS3", 1, true));
            fields.Add(new FieldDefinition("Address Details", "Home country address line 1", "HOMECOUNTRY_ADD1", "HOMECOUNTRY_ADD1", null, 0));
            fields.Add(new FieldDefinition("Address Details", "Home country address line 2", "HOMECOUNTRY_ADD2", "HOMECOUNTRY_ADD2", null, 0));
            fields.Add(new FieldDefinition("Address Details", "Home country address line 3", "HOMECOUNTRY_ADD3", "HOMECOUNTRY_ADD3", null, 0));
            return fields.ToArray();
        }

        private static void AddCustomerFields(List<FieldDefinition> fields, int slot, string suffix)
        {
            string customerSlot = "CUSTOMERID" + suffix;
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " customer ID",
                customerSlot, customerSlot, "CUSTOMERID", slot));
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " full name",
                "CUSTOMERNAME" + slot, "CUSTOMERNAME" + slot, "CUSTOMERNAME1", slot));
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " nationality",
                "NATIONALITY" + slot, "NATIONALITY" + slot, "NATIONALITY1", slot));
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " passport number",
                slot == 1 ? "PASSPORTNUMBER" : "PASSPORTNUMBER" + slot,
                slot == 1 ? "PASSPORTNUMBER" : "PASSPORTNUMBER" + slot,
                "CUSTOMER_PASSPORTNO", slot, "PASSPORTNUMBER"));
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " date of birth",
                "DATEOFBIRTH" + slot, "DATEOFBIRTH" + slot, "DATEOFBIRTH1", slot));
        }

        private sealed class FieldDefinition
        {
            public FieldDefinition(string section, string friendlyName, string leadColumn,
                string masterColumn, string customerColumn, int customerSlot)
                : this(section, friendlyName, leadColumn, masterColumn, customerColumn, customerSlot,
                    null, false, "Customer", false)
            {
            }

            public FieldDefinition(string section, string friendlyName, string leadColumn,
                string masterColumn, string customerColumn, int customerSlot, bool preserveMasterWhenMissing)
                : this(section, friendlyName, leadColumn, masterColumn, customerColumn, customerSlot,
                    null, preserveMasterWhenMissing, "Customer", false)
            {
            }

            public FieldDefinition(string section, string friendlyName, string leadColumn,
                string masterColumn, string customerColumn, int customerSlot, string coreSource, bool preserveMasterWhenMissing)
                : this(section, friendlyName, leadColumn, masterColumn, customerColumn, customerSlot,
                    null, preserveMasterWhenMissing, coreSource, false)
            {
            }

            public FieldDefinition(string section, string friendlyName, string leadColumn,
                string masterColumn, string customerColumn, int customerSlot, string customerFallbackColumn)
                : this(section, friendlyName, leadColumn, masterColumn, customerColumn, customerSlot,
                    customerFallbackColumn, false, "Customer", false)
            {
            }

            private FieldDefinition(string section, string friendlyName, string leadColumn,
                string masterColumn, string customerColumn, int customerSlot,
                string customerFallbackColumn, bool preserveMasterWhenMissing, string coreSource, bool useCoreSource)
            {
                Section = section;
                FriendlyName = friendlyName;
                LeadColumn = leadColumn;
                MasterColumn = masterColumn;
                CustomerColumn = customerColumn;
                CustomerSlot = customerSlot;
                CustomerFallbackColumn = customerFallbackColumn;
                PreserveMasterWhenMissing = preserveMasterWhenMissing;
                CoreSource = coreSource;
            }

            public string Section { get; private set; }
            public string FriendlyName { get; private set; }
            public string LeadColumn { get; private set; }
            public string MasterColumn { get; private set; }
            public string CustomerColumn { get; private set; }
            public string CustomerFallbackColumn { get; private set; }
            public int CustomerSlot { get; private set; }
            public bool PreserveMasterWhenMissing { get; private set; }
            public string CoreSource { get; private set; }
        }

        public sealed class ComparisonResponse
        {
            public bool Success { get; set; }
            public string Message { get; set; }
            public string SearchApplicationId { get; set; }
            public string ApplicationId { get; set; }
            public string SourceType { get; set; }
            public string Operation { get; set; }
            public bool MasterFound { get; set; }
            public int MatchedCustomerCount { get; set; }
            public bool NeedsCandidateSelection { get; set; }
            public List<ApplicationCandidate> Candidates { get; set; }
            public List<ComparisonRow> Rows { get; set; }

            public ComparisonResponse()
            {
                Candidates = new List<ApplicationCandidate>();
                Rows = new List<ComparisonRow>();
            }
        }

        public sealed class ApplicationCandidate
        {
            public string ApplicationId { get; set; }
            public string LeadApplicationId { get; set; }
            public string SourceType { get; set; }
            public bool IsExactMatch { get; set; }
        }

        public sealed class ComparisonRow
        {
            public string Section { get; set; }
            public string FriendlyName { get; set; }
            public string FieldKey { get; set; }
            public string LeadValue { get; set; }
            public string MasterValue { get; set; }
            public string CustomerValue { get; set; }
            public string ProposedValue { get; set; }
            public string Action { get; set; }
            public string ActionClass { get; set; }
        }

        public sealed class SyncResponse
        {
            public bool Success { get; set; }
            public string Message { get; set; }
            public int InsertedRows { get; set; }
            public int UpdatedRows { get; set; }
            public int MatchedCustomerCount { get; set; }
            public int ChangedFields { get; set; }
        }

        public sealed class AuditHistoryResponse
        {
            public bool Success { get; set; }
            public string Message { get; set; }
            public List<AuditHistoryRow> Rows { get; set; }

            public AuditHistoryResponse()
            {
                Rows = new List<AuditHistoryRow>();
            }
        }

        public sealed class AuditHistoryRow
        {
            public string RunId { get; set; }
            public string ApplicationId { get; set; }
            public string SynchronizedBy { get; set; }
            public string SynchronizedOn { get; set; }
            public string Operation { get; set; }
            public int SelectedFieldCount { get; set; }
            public int ChangedFieldCount { get; set; }
            public string FieldName { get; set; }
            public string OldValue { get; set; }
            public string NewValue { get; set; }
        }
    }
}
