using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Xml;
using System.Web.UI;

namespace HF48Workflow
{
    public partial class SOACalllogCustQuery : Page
    {
        protected void btnSave_Click(object sender, EventArgs e)
        {
            lblMessage.Text = String.Empty;
            lblMessage.CssClass = "message";

            string leadNo = (txtLeadNo.Text ?? String.Empty).Trim();
            string xref = (txtXref.Text ?? String.Empty).Trim();
            string createdBy = (txtCreatedBy.Text ?? String.Empty).Trim();
            string requestXml = txtRequestXml.Text ?? String.Empty;
            string responseXml = txtResponseXml.Text ?? String.Empty;

            if (leadNo.Length == 0 || leadNo.Length > 100 ||
                xref.Length == 0 || xref.Length > 200 ||
                createdBy.Length == 0 || createdBy.Length > 256 ||
                requestXml.Trim().Length == 0 || responseXml.Trim().Length == 0)
            {
                ShowError("Enter Lead number, Xref, Created by, Request XML, and Response XML. Check the maximum lengths for the text fields.");
                return;
            }

            string xmlError;
            if (!IsValidXml(requestXml, out xmlError))
            {
                ShowError("Request XML is invalid: " + xmlError);
                return;
            }
            if (!IsValidXml(responseXml, out xmlError))
            {
                ShowError("Response XML is invalid: " + xmlError);
                return;
            }

            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
            if (settings == null || String.IsNullOrEmpty(settings.ConnectionString))
            {
                ShowError("The LMS_DEV database connection is not configured.");
                return;
            }

            try
            {
                int srNo;
                using (SqlConnection connection = new SqlConnection(settings.ConnectionString))
                using (SqlCommand command = new SqlCommand(
                    "INSERT INTO dbo.SOA_Calllog_CustQuery " +
                    "(Lead_no, Xref, RequestXML, REsponse, Createdby_user, Createdon_date) " +
                    "VALUES (@Lead_no, @Xref, @RequestXML, @REsponse, @Createdby_user, GETDATE()); " +
                    "SELECT CAST(SCOPE_IDENTITY() AS int);", connection))
                {
                    command.Parameters.Add("@Lead_no", SqlDbType.NVarChar, 100).Value = leadNo;
                    command.Parameters.Add("@Xref", SqlDbType.NVarChar, 200).Value = xref;
                    command.Parameters.Add("@RequestXML", SqlDbType.Xml).Value = requestXml;
                    command.Parameters.Add("@REsponse", SqlDbType.Xml).Value = responseXml;
                    command.Parameters.Add("@Createdby_user", SqlDbType.NVarChar, 256).Value = createdBy;
                    connection.Open();
                    srNo = Convert.ToInt32(command.ExecuteScalar());
                }

                lblMessage.CssClass = "message success";
                lblMessage.Text = "Saved successfully. SRNo: " + srNo.ToString();
            }
            catch (SqlException ex)
            {
                System.Diagnostics.Trace.TraceError("SOA customer query call-log insert failed: {0}", ex);
                if (ex.Number == 2601 || ex.Number == 2627)
                    ShowError("This Xref already exists. Enter a unique Xref.");
                else
                    ShowError("The call log could not be saved. Check that the SOA_Calllog_CustQuery table exists and contact IT if the issue continues.");
            }
            catch (ConfigurationErrorsException ex)
            {
                System.Diagnostics.Trace.TraceError("SOA customer query call-log configuration failed: {0}", ex);
                ShowError("The database connection could not be read from configuration.");
            }
        }

        private static bool IsValidXml(string value, out string error)
        {
            try
            {
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.DtdProcessing = DtdProcessing.Prohibit;
                settings.XmlResolver = null;
                using (StringReader textReader = new StringReader(value))
                using (XmlReader reader = XmlReader.Create(textReader, settings))
                {
                    XmlDocument document = new XmlDocument();
                    document.XmlResolver = null;
                    document.Load(reader);
                }
                error = String.Empty;
                return true;
            }
            catch (XmlException ex)
            {
                error = ex.Message;
                return false;
            }
        }

        private void ShowError(string message)
        {
            lblMessage.CssClass = "message error";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}