<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="LeadFeeMasterChecker.aspx.cs" Inherits="HF48Workflow.LeadFeeMasterChecker" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Lead Fee Masters - Checker</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="LeadFeeMaster.css" rel="stylesheet" type="text/css" />
</head>
<body>
<form id="form1" runat="server">
    <header class="header"><h1>Lead Fee Master Review</h1><h2>Review maker changes before they update the live master | <a href="LeadFeeMasterMaker.aspx">Open maker</a></h2></header>
    <main class="container">
        <div class="who-bar">Acting as <strong><asp:Label ID="lblCurrentUser" runat="server" /></strong>
            <asp:TextBox ID="txtCurrentUser" runat="server" MaxLength="100" />
            <asp:Button ID="btnSetUser" runat="server" Text="Switch User" CssClass="btn btn-secondary" OnClick="SetUser_Click" CausesValidation="false" />
        </div>
        <asp:Label ID="lblMessage" runat="server" Visible="false" />
        <section class="panel">
            <div class="panel-header">Filter maker requests</div>
            <div class="panel-body">
                <div class="filter-grid">
                    <div class="field"><label for="<%= ddlMasterType.ClientID %>">Master</label>
                        <asp:DropDownList ID="ddlMasterType" runat="server"><asp:ListItem Text="All masters" Value="" /><asp:ListItem Text="Promotion master" Value="P" /><asp:ListItem Text="Arrangement fee master" Value="F" /></asp:DropDownList>
                    </div>
                    <div class="field"><label for="<%= ddlStatus.ClientID %>">Request status</label>
                        <asp:DropDownList ID="ddlStatus" runat="server"><asp:ListItem Text="Pending" Value="P" /><asp:ListItem Text="All statuses" Value="" /><asp:ListItem Text="Approved" Value="A" /><asp:ListItem Text="Rejected" Value="R" /></asp:DropDownList>
                    </div>
                    <div class="field"><label for="<%= txtMakerFilter.ClientID %>">Maker user</label><asp:TextBox ID="txtMakerFilter" runat="server" MaxLength="100" /></div>
                    <div class="field"><label for="<%= txtFromDate.ClientID %>">Submitted from</label><asp:TextBox ID="txtFromDate" runat="server" /></div>
                    <div class="field"><label for="<%= txtToDate.ClientID %>">Submitted to</label><asp:TextBox ID="txtToDate" runat="server" /></div>
                </div>
                <div class="filter-actions">
                    <asp:Button ID="btnFilter" runat="server" Text="Apply filters" CssClass="btn" OnClick="Filter_Click" CausesValidation="false" />
                    <asp:Button ID="btnClearFilters" runat="server" Text="Clear" CssClass="btn btn-secondary" OnClick="ClearFilters_Click" CausesValidation="false" />
                    <asp:Button ID="btnExport" runat="server" Text="Export to Excel (CSV)" CssClass="btn btn-secondary" OnClick="Export_Click" CausesValidation="false" />
                </div>
                <div class="table-wrap"><asp:GridView ID="gvRequests" runat="server" CssClass="gridview" AutoGenerateColumns="true"
                    AutoGenerateSelectButton="true" DataKeyNames="RequestId" AllowPaging="true" PageSize="25"
                    OnSelectedIndexChanged="RequestSelected" OnPageIndexChanging="RequestsPage" EmptyDataText="No requests match these filters." /></div>
            </div>
        </section>
        <asp:Panel ID="pnlReview" runat="server" Visible="false">
            <section class="panel">
                <div class="panel-header">Request details</div>
                <div class="panel-body">
                    <asp:HiddenField ID="hfRequestId" runat="server" Value="0" />
                    <div class="form-grid">
                        <div class="field"><label>Request</label><asp:Label ID="lblRequestSummary" runat="server" /></div>
                        <div class="field"><label>Maker / submitted</label><asp:Label ID="lblMaker" runat="server" /></div>
                        <div class="field"><label>Maker remarks</label><asp:Label ID="lblMakerRemarks" runat="server" /></div>
                    </div>
                    <p class="section-note">Red shows the old value; green shows the proposed value. System audit fields are not editable. New promotion SRNO values are assigned during approval.</p>
                    <div class="table-wrap"><asp:GridView ID="gvComparison" runat="server" CssClass="gridview" AutoGenerateColumns="false" OnRowDataBound="Comparison_RowDataBound">
                        <Columns>
                            <asp:BoundField DataField="Field" HeaderText="Field" />
                            <asp:BoundField DataField="OldValue" HeaderText="Old value" HtmlEncode="true" />
                            <asp:BoundField DataField="NewValue" HeaderText="New value" HtmlEncode="true" />
                        </Columns>
                    </asp:GridView></div>
                    <div class="form-actions">
                        <asp:Button ID="btnAttachment" runat="server" Text="Download attachment" CssClass="btn btn-secondary" OnClick="Attachment_Click" CausesValidation="false" />
                    </div>
                </div>
            </section>
            <section class="panel">
                <div class="panel-header">Audit history</div>
                <div class="panel-body"><div class="table-wrap"><asp:GridView ID="gvAudit" runat="server" CssClass="gridview" AutoGenerateColumns="false" EmptyDataText="No audit entries.">
                    <Columns>
                        <asp:BoundField DataField="ActionName" HeaderText="Action" />
                        <asp:BoundField DataField="ActionBy" HeaderText="User" />
                        <asp:BoundField DataField="ActionOn" HeaderText="Date" DataFormatString="{0:yyyy-MM-dd HH:mm:ss}" />
                        <asp:BoundField DataField="Remarks" HeaderText="Remarks" />
                    </Columns>
                </asp:GridView></div></div>
            </section>
            <section class="panel">
                <div class="panel-header">Checker decision</div>
                <div class="panel-body">
                    <div class="field"><label for="<%= txtCheckerRemarks.ClientID %>">Checker remarks <span class="required">*</span></label><asp:TextBox ID="txtCheckerRemarks" runat="server" MaxLength="1000" /></div>
                    <div class="form-actions">
                        <asp:Button ID="btnApprove" runat="server" Text="Approve" CssClass="btn btn-success" OnClick="Approve_Click" OnClientClick="return confirm('Approve and apply this master change?');" />
                        <asp:Button ID="btnReject" runat="server" Text="Reject" CssClass="btn btn-danger" OnClick="Reject_Click" OnClientClick="return confirm('Reject this master change?');" />
                    </div>
                </div>
            </section>
        </asp:Panel>
    </main>
</form>
</body>
</html>