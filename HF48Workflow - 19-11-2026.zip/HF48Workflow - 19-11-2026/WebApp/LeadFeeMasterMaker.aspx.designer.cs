namespace HF48Workflow
{
    public partial class LeadFeeMasterMaker
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.Label lblCurrentUser;
        protected global::System.Web.UI.WebControls.TextBox txtCurrentUser;
        protected global::System.Web.UI.WebControls.Button btnSetUser;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.DropDownList ddlMasterType;
        protected global::System.Web.UI.WebControls.TextBox txtSearch;
        protected global::System.Web.UI.WebControls.DropDownList ddlFilterStatus;
        protected global::System.Web.UI.WebControls.TextBox txtFilterResidency;
        protected global::System.Web.UI.WebControls.DropDownList ddlFilterStaff;
        protected global::System.Web.UI.WebControls.TextBox txtFromDate;
        protected global::System.Web.UI.WebControls.TextBox txtToDate;
        protected global::System.Web.UI.WebControls.Button btnFilter;
        protected global::System.Web.UI.WebControls.Button btnClearFilters;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.GridView gvMasterRows;
        protected global::System.Web.UI.WebControls.Label lblEditorMode;
        protected global::System.Web.UI.WebControls.HiddenField hfTargetSrno;
        protected global::System.Web.UI.WebControls.HiddenField hfOldProductType;
        protected global::System.Web.UI.WebControls.HiddenField hfOldProductSubType;
        protected global::System.Web.UI.WebControls.HiddenField hfOldResidencyType;
        protected global::System.Web.UI.WebControls.HiddenField hfOldStaff;
        protected global::System.Web.UI.WebControls.Panel pnlFields;
        protected global::System.Web.UI.WebControls.Panel pnlPromotion;
        protected global::System.Web.UI.WebControls.TextBox txtPromotionName;
        protected global::System.Web.UI.WebControls.TextBox txtDiscountPerc;
        protected global::System.Web.UI.WebControls.TextBox txtPromotionStart;
        protected global::System.Web.UI.WebControls.TextBox txtPromotionEnd;
        protected global::System.Web.UI.WebControls.DropDownList ddlPromotionStatus;
        protected global::System.Web.UI.WebControls.Panel pnlFee;
        protected global::System.Web.UI.WebControls.TextBox txtProductType;
        protected global::System.Web.UI.WebControls.TextBox txtProductSubType;
        protected global::System.Web.UI.WebControls.TextBox txtResidencyType;
        protected global::System.Web.UI.WebControls.DropDownList ddlStaff;
        protected global::System.Web.UI.WebControls.TextBox txtFeeFv;
        protected global::System.Web.UI.WebControls.TextBox txtFeeOpv;
        protected global::System.Web.UI.WebControls.TextBox txtFeeApv;
        protected global::System.Web.UI.WebControls.TextBox txtFeeBuyout;
        protected global::System.Web.UI.WebControls.TextBox txtFeeTopup;
        protected global::System.Web.UI.WebControls.TextBox txtFeeEquity;
        protected global::System.Web.UI.WebControls.TextBox txtFeeCashout;
        protected global::System.Web.UI.WebControls.TextBox txtFeeMbre;
        protected global::System.Web.UI.WebControls.TextBox txtFeeApp;
        protected global::System.Web.UI.WebControls.TextBox txtFeeAcc;
        protected global::System.Web.UI.WebControls.TextBox txtMinFee;
        protected global::System.Web.UI.WebControls.TextBox txtMaxFee;
        protected global::System.Web.UI.WebControls.DropDownList ddlFeeStatus;
        protected global::System.Web.UI.WebControls.DropDownList ddlVatApplicable;
        protected global::System.Web.UI.WebControls.TextBox txtMakerRemarks;
        protected global::System.Web.UI.WebControls.FileUpload fuAttachment;
        protected global::System.Web.UI.WebControls.Button btnSubmit;
        protected global::System.Web.UI.WebControls.Button btnAdd;
        protected global::System.Web.UI.WebControls.Button btnNew;
        protected global::System.Web.UI.WebControls.GridView gvMyRequests;
    }
}