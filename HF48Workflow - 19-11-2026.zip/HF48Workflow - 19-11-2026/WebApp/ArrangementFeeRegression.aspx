<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ArrangementFeeRegression.aspx.cs" Inherits="HF48Workflow.ArrangementFeeRegression" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Arrangement Fee Regression</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        :root { --ink: #19363b; --muted: #52686b; --paper: #f4f6f3; --white: #fff; --line: #d3ddda; --teal: #087c78; --teal-dark: #075957; --coral: #b95740; --red: #9c2f25; }
        * { box-sizing: border-box; }
        body { margin: 0; background: var(--paper); color: var(--ink); font: 14px/1.5 "Aptos", "Avenir Next", "Trebuchet MS", sans-serif; }
        header { padding: 22px max(18px, calc((100vw - 1200px) / 2)); color: var(--white); background: linear-gradient(120deg, #123d43, #087c78); }
        header p { margin: 0; color: #d9eae7; }
        h1, h2 { margin: 0 0 10px; font-family: Georgia, "Times New Roman", serif; font-weight: 500; }
        h1 { font-size: 30px; }
        h2 { font-size: 22px; }
        main { width: 99%; max-width: none; margin: 0 auto; padding: 22px 18px 36px; }
        .panel { margin-bottom: 20px; border: 1px solid var(--line); background: var(--white); }
        .panel-title { padding: 12px 15px; border-bottom: 1px solid var(--line); font-weight: 700; }
        .panel-body { padding: 14px 15px; }
        .hint { margin: 0 0 10px; color: var(--muted); font-size: 12px; }
        .fixture-row { display: flex; flex-wrap: wrap; align-items: end; gap: 8px; margin: 12px 0 4px; }
        .fixture-row label { display: block; width: 100%; color: var(--muted); font-size: 12px; }
        .fixture-row input { width: 220px; max-width: 100%; min-height: 36px; padding: 7px 9px; border: 1px solid #aebdba; }
        .lead-input { width: 100%; min-height: 220px; padding: 10px; border: 1px solid #aebdba; color: var(--ink); font: 13px/1.45 Consolas, monospace; resize: vertical; }
        .actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
        .btn { min-height: 36px; padding: 8px 13px; border: 1px solid var(--teal-dark); background: var(--teal); color: var(--white); font: inherit; font-weight: 700; cursor: pointer; }
        .btn-secondary { background: var(--white); color: var(--teal-dark); }
        .btn:disabled { opacity: .55; cursor: not-allowed; }
        .message { display: block; margin-top: 10px; padding: 9px 11px; }
        .message.success { border-left: 4px solid var(--teal); background: #e2f1ed; }
        .message.error { border-left: 4px solid var(--red); background: #fbe9e6; color: var(--red); }
        .table-wrap { width: 100%; overflow: auto; }
        .gridview { width: 100%; min-width: 2200px; border-collapse: collapse; }
        .gridview th, .gridview td { max-width: 280px; padding: 8px 9px; border-bottom: 1px solid var(--line); text-align: left; vertical-align: top; overflow-wrap: anywhere; }
        .gridview th { position: sticky; top: 0; background: #e9f1ee; color: #29484d; font-size: 10px; text-transform: uppercase; }
        .gridview td { font-size: 12px; }
        .gridview tr:nth-child(even) td { background: #fafcfb; }
        .pager { padding: 10px; text-align: center; white-space: nowrap; }
        .pager a, .pager span { display: inline-block; min-width: 34px; min-height: 32px; margin: 2px; padding: 5px 8px; border: 1px solid var(--line); background: var(--white); color: var(--teal-dark); text-decoration: none; }
        .pager span { border-color: var(--teal); background: var(--teal); color: var(--white); }
        @media (max-width: 640px) { header { padding: 19px 16px; } main { width: 99%; padding: 16px 5px 24px; } h1 { font-size: 26px; } .panel-body { padding: 11px; } }
        @media print { body { background: #fff; } .actions, .lead-input { display: none; } header { padding: 16px 0; background: #fff; color: #111; border-bottom: 2px solid var(--teal); } header p { color: #333; } main { padding: 12px 0; } }
    </style>
</head>
<body>
<form id="form1" runat="server">
    <header>
        <h1>Arrangement Fee Regression</h1>
        <p>Runs PROC_Lead_Arrangement_FEE for selected leads or generated cases and displays the returned scenario, fee, and VAT breakdown.</p>
    </header>
    <main>
        <section class="panel">
            <div class="panel-title">Regression cases</div>
            <div class="panel-body">
                <p class="hint">One lead number per line. Optionally add a scenario label after a pipe, for example LD-00126593|NSTL non-Equity Release. Maximum 70 cases. This mode calls the procedure without modifying lead data.</p>
                <asp:TextBox ID="txtLeadCases" runat="server" TextMode="MultiLine" Rows="12" CssClass="lead-input" />
                <div class="fixture-row">
                    <label for="<%= txtFixtureLead.ClientID %>">Regression fixture lead for generated matrix cases</label>
                    <asp:TextBox ID="txtFixtureLead" runat="server" MaxLength="100" />
                    <asp:Button ID="btnRunMatrix" runat="server" Text="Run full master/promotion matrix" CssClass="btn btn-secondary" OnClick="RunMatrix_Click" CausesValidation="false" />
                </div>
                <p class="hint">Full matrix runs at most 100 unique scenarios: every active product/subtype, each active promotion, selected pre-approval promotion paths, STL/NSTL, staff, residency, cap boundaries, Equity Release, GHP, and MB/NB/TW conversion prefixes. Enter a dedicated test lead; every temporary change is rolled back.</p>
                <div class="actions">
                    <asp:Button ID="btnRun" runat="server" Text="Run regression" CssClass="btn" OnClick="Run_Click" />
                    <asp:Button ID="btnExport" runat="server" Text="Export results to CSV" CssClass="btn btn-secondary" OnClick="Export_Click" CausesValidation="false" />
                </div>
                <asp:Label ID="lblMessage" runat="server" Visible="false" />
            </div>
        </section>
        <section class="panel">
            <div class="panel-title">Procedure results</div>
            <div class="panel-body table-wrap">
                <asp:GridView ID="gvResults" runat="server" CssClass="gridview" AutoGenerateColumns="true" AllowPaging="true" PageSize="10" OnPageIndexChanging="ResultsPage" EmptyDataText="Run the procedure to see regression results.">
                    <PagerStyle CssClass="pager" HorizontalAlign="Center" />
                    <PagerSettings Mode="NumericFirstLast" PageButtonCount="10" FirstPageText="&amp;laquo;" LastPageText="&amp;raquo;" />
                </asp:GridView>
            </div>
        </section>
    </main>
</form>
</body>
</html>
