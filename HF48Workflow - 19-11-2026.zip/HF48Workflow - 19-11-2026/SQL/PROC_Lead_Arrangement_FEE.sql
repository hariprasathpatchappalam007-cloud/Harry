IF OBJECT_ID(N'dbo.PROC_Lead_Arrangement_FEE', N'P') IS NOT NULL
	DROP PROCEDURE dbo.PROC_Lead_Arrangement_FEE;
GO
CREATE PROCEDURE [dbo].[PROC_Lead_Arrangement_FEE]
@REFNO nvarchar(100)=null,
@Scenario nvarchar(200)=null
as
BEGIN
	set quoted_identifier off
	create table #List
	(
	Lead_No nvarchar(100), PRODUCT_TYPE nvarchar(150), Product_SubTYPE nvarchar(150), Residency_Type nvarchar(100), StaffYN nvarchar(100),
	promotiontype nvarchar(100), Scenario nvarchar(200), FEE_FV numeric(20,4), FEE_OPV numeric(20,4), FEE_APV numeric(20,4),
	FEE_Buyout numeric(20,4), FEE_Topup numeric(20,4), FEE_Equity numeric(20,4), FEE_Cashout numeric(20,4),
	FEE_MBRE numeric(20,4), AMT_FV numeric(20,4), AMT_OPV numeric(20,4), AMT_APV numeric(20,4),
	AMT_Buyout numeric(20,4), AMT_Topup numeric(20,4), AMT_Equity numeric(20,4), AMT_Cashout numeric(20,4),
	AMT_MBRE numeric(20,4), FEE_APP numeric(20,2), FEE_ACC numeric(20,2), MIN_FEE numeric(20,2),
	MAX_FEE numeric(20,2), ARRANGEMENT_FEE_APP numeric(20,2), ARRANGEMENT_FEE_ACC numeric(20,2),
	ARRANGEMENT_FEE numeric(20,2), RECCOUNT int,
	Remarks nvarchar(100), ErrorMsg nvarchar(200)
	)

	declare @found int
	declare @Source_Submission nvarchar(100)
	declare @Employment_Type nvarchar(100)
	declare @Relationship_with_bank nvarchar(100)
	declare @LeadConversionProduct nvarchar(300)
	declare @PRODUCT_TYPE nvarchar(100)
	declare @Product_SubTYPE nvarchar(100)
	declare @CUSTOMER_RES_TYPE nvarchar(100)
	declare @FEE_FV numeric(20,4)
	declare @FEE_OPV numeric(20,4)
	declare @FEE_APV numeric(20,4)
	declare @FEE_Buyout numeric(20,4)
	declare @FEE_Topup numeric(20,4)
	declare @FEE_Equity numeric(20,4)
	declare @FEE_Cashout numeric(20,4)
	declare @FEE_MBRE numeric(20,4)
	declare @FEE_APP numeric(20,2)
	declare @FEE_ACC numeric(20,2)
	declare @MIN_FEE numeric(20,2)
	declare @MAX_FEE numeric(20,2)

	declare @AMT_FV numeric(20,4)
	declare @AMT_OPV numeric(20,4)
	declare @AMT_APV numeric(20,4)
	declare @AMT_Buyout numeric(20,4)
	declare @AMT_Topup numeric(20,4)
	declare @AMT_Equity numeric(20,4)
	declare @AMT_Cashout numeric(20,4)
	declare @AMT_MBRE numeric(20,4)

	declare @CAL_AMT_FV numeric(20,4)
	declare @CAL_AMT_OPV numeric(20,4)
	declare @CAL_AMT_APV numeric(20,4)
	declare @CAL_AMT_Buyout numeric(20,4)
	declare @CAL_AMT_Topup numeric(20,4)
	declare @CAL_AMT_Equity numeric(20,4)
	declare @CAL_AMT_Cashout numeric(20,4)
	declare @CAL_AMT_MBRE numeric(20,4)
	declare @ARRANGEMENT_FEE_APP numeric(20,2)
	declare @ARRANGEMENT_FEE_ACC numeric(20,2)
	declare @ARRANGEMENT_FEE numeric(20,2)
	declare @promotiontype nvarchar(100)
	declare @Is_VAT_Applicable Bit
	declare @Actual_PRODUCT_TYPE nvarchar(100)
	declare @Actual_Product_SubTYPE nvarchar(100)
	declare @PromotionEnabled bit = 1
	declare @UseMasterDiscount bit = 1
	declare @SkipMinFee bit = 0
	declare @SkipMaxFee bit = 0
	declare @LookupProductType nvarchar(300)
	declare @LookupProductSubType nvarchar(300)
	declare @STLFeeRate numeric(20,4) = 0.75
	declare @IsSTL bit = 0
	declare @IsAggregator bit = 0
	declare @IsGHP bit = 0
	declare @IsAggregatorEquityRelease bit = 0
	declare @IsAbuDhabiFinalPayment bit = 0
	declare @ApplyMasterDiscount bit = 1
	declare @RuleId int
	declare @RuleType varchar(32)
	declare @RuleTargetField varchar(32)
	declare @RuleValue numeric(20,4)
	declare @RuleAmountBasis varchar(16)
	declare @RuleMinimumFee numeric(20,2)
	declare @RuleSplitMode varchar(20)
	declare @RuleFloorSplitMode varchar(20)
	declare @RuleVATApplicable bit
	declare @RuleAmount numeric(20,4)
	declare @PromotionRules table
	(
		RuleId int NOT NULL,
		RuleSequence int NOT NULL,
		RuleStage varchar(24) NOT NULL,
		RuleType varchar(32) NOT NULL,
		TargetField varchar(32) NULL,
		AmountBasis varchar(16) NULL,
		RuleValue numeric(20,4) NULL,
		MinimumFee numeric(20,2) NULL,
		SplitMode varchar(20) NULL,
		FloorSplitMode varchar(20) NULL,
		VATApplicable bit NULL
	)

	select
		@PRODUCT_TYPE = lead_product,
		@Product_SubTYPE = LEAD_FIN_REFINANCETYPE,
		@AMT_FV=isnull(finance_amount,0),
		@AMT_OPV = isnull(lead_prop_org_value,0),
		@AMT_APV = isnull(lead_prop_appr_value,0),
		@AMT_Buyout=isnull(lead_fin_buyout_repay_amt,0),
		@AMT_Topup=isnull(lead_fin_topup_amt,0),
		@AMT_Equity=isnull(lead_fin_Equity_amt,0),
		@AMT_Cashout=isnull(lead_fin_cashout_amt,0),
		@AMT_MBRE = isnull(MBRE_AMOUNT,0),
		@LeadConversionProduct = Lead_Conversion_Product,
		@promotiontype = lead_fin_promotiontype
	from lead_details_finance where lead_no = @REFNO

	select @PromotionEnabled=IsEnabled,@UseMasterDiscount=UseMasterDiscount,
		@SkipMinFee=SkipMinFee,@SkipMaxFee=SkipMaxFee,
		@LookupProductType=LookupProductType,@LookupProductSubType=LookupProductSubType
	from dbo.LEAD_ARR_FEE_PROMOTION_CONFIG
	where PromotionName=@promotiontype

	if @PromotionEnabled=1 AND @LookupProductType IS NOT NULL AND @LookupProductSubType IS NOT NULL
	begin
		SET @Actual_PRODUCT_TYPE = @PRODUCT_TYPE
		SET @Actual_Product_SubTYPE = @Product_SubTYPE
		SET @PRODUCT_TYPE = @LookupProductType
		SET @Product_SubTYPE = @LookupProductSubType
	end

	declare @StaffYN nvarchar(100)
	declare @ProjectID nvarchar(100)
	select @StaffYN=staffyn,@Relationship_with_bank=Relationship_with_bank
	from lead_details_others where lead_no=@REFNO
	select @ProjectID = property_projectid from lead_details_property where lead_no=@REFNO
	select @CUSTOMER_RES_TYPE=CUSTOMER_RES_TYPE,@Source_Submission=Lead_Source_OF_Submission
	from lead_details where lead_no=@REFNO

	SET @IsSTL = CASE WHEN UPPER(LTRIM(RTRIM(ISNULL(@Relationship_with_bank,N''))))=N'STL' THEN 1 ELSE 0 END;
	SET @IsAggregator = CASE WHEN UPPER(LTRIM(RTRIM(ISNULL(@Source_Submission,N''))))=N'AGGREGATOR' THEN 1 ELSE 0 END;
	SET @IsGHP = CASE WHEN ISNULL(@AMT_MBRE,0)>0 THEN 1 ELSE 0 END;
	SET @IsAggregatorEquityRelease = CASE WHEN @IsAggregator=1 AND @PRODUCT_TYPE=N'Equity Release' AND ISNULL(@AMT_Equity,0)>0 THEN 1 ELSE 0 END;
	SET @IsAbuDhabiFinalPayment = CASE WHEN @promotiontype=N'Abu Dhabi Promotion' AND @Product_SubTYPE=N'Final Payment' AND @IsAggregatorEquityRelease=0 THEN 1 ELSE 0 END;

	if isnull(@StaffYN,'') = '' set @StaffYN = 'No'
	if isnull(@StaffYN,'') = '0' set @StaffYN = 'No'

	IF UPPER(LTRIM(RTRIM(ISNULL(@Relationship_with_bank,N''))))=N'NSTL'
	BEGIN
		SELECT @STLFeeRate=FeeRate
		FROM dbo.LEAD_STL_NSTL_FEE_CONFIG
		WHERE RelationshipType='NSTL' AND IsApplicable=1;
	END;

	select @Is_VAT_Applicable = isnull(Is_VAT_Applicable,0) from LEAD_ARR_FEE_MASTER
	Where
		PRODUCT_TYPE=@PRODUCT_TYPE and Product_SubTYPE = @Product_SubTYPE and
		Residency_Type = @CUSTOMER_RES_TYPE and Staff = @StaffYN and
		ISNULL(Status,'A')='A'

	select @found=count(1) from LEAD_ARR_FEE_MASTER where PRODUCT_TYPE = @PRODUCT_TYPE
		and Product_SubTYPE = @Product_SubTYPE and Residency_Type = @CUSTOMER_RES_TYPE and Staff = @StaffYN
	--Madesh Made changes on 11/7/2021 for UAT fix for product type and product sub type-->added msg

	print 'test1'
	--select @PRODUCT_TYPE, @Product_SubTYPE, @CUSTOMER_RES_TYPE, @StaffYN, @found
	declare @TextError nvarchar(1000)
	if(@Product_SubTYPE='None' or @Product_SubTYPE='0' or @Product_SubTYPE='' or @PRODUCT_TYPE='None' or @PRODUCT_TYPE='' or @PRODUCT_TYPE='0' )
	BEGIN
		set @TextError='Please Update the Product Type and Product Sub Type and process the application'
	END
	else if @found = 0
	begin
		/*
		EXEC sp_addmessage
		@msgnum = 60000,
		@severity = 16,
		@msgtext = 'Arrangement fee not defined, Please contact Product Team',
		@lang = 'us_english',
		@replace= 'replace'
		*/
		declare @Text nvarchar(1000)
		set @text = 'Arrangement fee not defined for product - ' + @PRODUCT_TYPE + ',' + @Product_SubTYPE + '. Please raise this to product team.'
		---changed by rajesh kumar 04/02/2026 -> to fix error message
		RAISERROR (@text,16,1)
		return
	end
	print 'test2'
	select
		@FEE_FV=FEE_FV,
		@FEE_OPV=FEE_OPV,
		@FEE_APV=FEE_APV,
		@FEE_Buyout=FEE_Buyout,
		@FEE_Topup=FEE_Topup,
		@FEE_Equity=FEE_Equity,
		@FEE_Cashout=FEE_Cashout,
		@FEE_MBRE=FEE_MBRE,
		@FEE_APP=FEE_APP,
		@FEE_ACC=FEE_ACC,
		@MIN_FEE=MIN_FEE,
		@MAX_FEE=MAX_FEE
	from LEAD_ARR_FEE_MASTER where PRODUCT_TYPE = @PRODUCT_TYPE and Product_SubTYPE = @Product_SubTYPE and Residency_Type = @CUSTOMER_RES_TYPE and Staff = @StaffYN
	print 'test3'

	IF @IsAggregatorEquityRelease=1
	BEGIN
		SET @FEE_FV = CASE WHEN @IsSTL=1 THEN 0 ELSE ISNULL(@STLFeeRate,0.75) END;
		SET @FEE_OPV=0; SET @FEE_APV=0; SET @FEE_Buyout=0; SET @FEE_Topup=0;
		SET @FEE_Equity=0;
		SET @FEE_Cashout=0; SET @FEE_MBRE=0;
		SET @MIN_FEE=5250; SET @MAX_FEE=999999999;
		SET @SkipMinFee=1;
	END
	ELSE IF @IsAbuDhabiFinalPayment=1 OR @IsGHP=1 OR @IsSTL=1
	BEGIN
		SET @FEE_FV=0; SET @FEE_OPV=0; SET @FEE_APV=0; SET @FEE_Buyout=0;
		SET @FEE_Topup=0; SET @FEE_Equity=0; SET @FEE_Cashout=0; SET @FEE_MBRE=0;
		SET @MIN_FEE=0; SET @MAX_FEE=999999999;
		SET @SkipMinFee=1; SET @SkipMaxFee=1;
	END
	ELSE IF @PRODUCT_TYPE=N'Equity Release' AND ISNULL(@AMT_Equity,0)>0
	BEGIN
		SET @FEE_FV=0; SET @FEE_OPV=0; SET @FEE_APV=0; SET @FEE_Buyout=0;
		SET @FEE_Topup=0; SET @FEE_Equity=1.25; SET @FEE_Cashout=0; SET @FEE_MBRE=0;
		SET @MIN_FEE=5250; SET @MAX_FEE=999999999;
	END
	ELSE
	BEGIN
		SET @FEE_FV=ISNULL(@STLFeeRate,0.75);
		SET @FEE_OPV=0; SET @FEE_APV=0; SET @FEE_Buyout=0; SET @FEE_Topup=0;
		SET @FEE_Equity=0; SET @FEE_Cashout=0; SET @FEE_MBRE=0;
		SET @MIN_FEE=5250;
		SET @MAX_FEE=CASE WHEN @CUSTOMER_RES_TYPE LIKE N'Non-Resident%' THEN 999999999 ELSE 105000 END;
	END;

	INSERT @PromotionRules
		(RuleId,RuleSequence,RuleStage,RuleType,TargetField,AmountBasis,RuleValue,MinimumFee,SplitMode,FloorSplitMode,VATApplicable)
	SELECT PromotionRule.RuleId,PromotionRule.RuleSequence,PromotionRule.RuleStage,PromotionRule.RuleType,
		PromotionRule.TargetField,PromotionRule.AmountBasis,PromotionRule.RuleValue,PromotionRule.MinimumFee,
		PromotionRule.SplitMode,PromotionRule.FloorSplitMode,PromotionRule.VATApplicable
	FROM dbo.LEAD_ARR_FEE_PROMOTION_RULE PromotionRule
	WHERE PromotionRule.PromotionName=@promotiontype AND PromotionRule.IsEnabled=1 AND @PromotionEnabled=1
	  AND NOT EXISTS
	  (
		SELECT 1 FROM dbo.LEAD_ARR_FEE_PROMOTION_RULE_FILTER RuleFilter
		WHERE RuleFilter.RuleId=PromotionRule.RuleId
		  AND NOT
		  (
			(RuleFilter.FieldName='PRODUCT_TYPE' AND
				((RuleFilter.ComparisonOperator='EQ' AND ISNULL(@PRODUCT_TYPE,N'')=RuleFilter.FilterValue)
				 OR (RuleFilter.ComparisonOperator='NE' AND ISNULL(@PRODUCT_TYPE,N'')<>RuleFilter.FilterValue)))
			OR (RuleFilter.FieldName='PRODUCT_SUBTYPE' AND
				((RuleFilter.ComparisonOperator='EQ' AND ISNULL(@Product_SubTYPE,N'')=RuleFilter.FilterValue)
				 OR (RuleFilter.ComparisonOperator='NE' AND ISNULL(@Product_SubTYPE,N'')<>RuleFilter.FilterValue)))
			OR (RuleFilter.FieldName='RESIDENCY_TYPE' AND
				((RuleFilter.ComparisonOperator='EQ' AND ISNULL(@CUSTOMER_RES_TYPE,N'')=RuleFilter.FilterValue)
				 OR (RuleFilter.ComparisonOperator='NE' AND ISNULL(@CUSTOMER_RES_TYPE,N'')<>RuleFilter.FilterValue)))
			OR (RuleFilter.FieldName='STAFF' AND
				((RuleFilter.ComparisonOperator='EQ' AND ISNULL(@StaffYN,N'')=RuleFilter.FilterValue)
				 OR (RuleFilter.ComparisonOperator='NE' AND ISNULL(@StaffYN,N'')<>RuleFilter.FilterValue)))
			OR (RuleFilter.FieldName='SOURCE_SUBMISSION' AND
				((RuleFilter.ComparisonOperator='EQ' AND ISNULL(@Source_Submission,N'')=RuleFilter.FilterValue)
				 OR (RuleFilter.ComparisonOperator='NE' AND ISNULL(@Source_Submission,N'')<>RuleFilter.FilterValue)))
			OR (RuleFilter.FieldName='PROJECT_ID' AND
				((RuleFilter.ComparisonOperator='EQ' AND ISNULL(@ProjectID,N'')=RuleFilter.FilterValue)
				 OR (RuleFilter.ComparisonOperator='NE' AND ISNULL(@ProjectID,N'')<>RuleFilter.FilterValue)))
			OR (RuleFilter.FieldName='CONVERSION_PRODUCT' AND
				((RuleFilter.ComparisonOperator='EQ' AND ISNULL(@LeadConversionProduct,N'')=RuleFilter.FilterValue)
				 OR (RuleFilter.ComparisonOperator='NE' AND ISNULL(@LeadConversionProduct,N'')<>RuleFilter.FilterValue)
				 OR (RuleFilter.ComparisonOperator='PREFIX' AND LEFT(ISNULL(@LeadConversionProduct,N''),LEN(RuleFilter.FilterValue))=RuleFilter.FilterValue)
				 OR (RuleFilter.ComparisonOperator='NOT_PREFIX' AND LEFT(ISNULL(@LeadConversionProduct,N''),LEN(RuleFilter.FilterValue))<>RuleFilter.FilterValue)))
		  )
	  );

	DECLARE PreCalculationRules CURSOR LOCAL FAST_FORWARD FOR
		SELECT RuleType,TargetField,RuleValue FROM @PromotionRules
		WHERE RuleStage='PRE_CALC' ORDER BY RuleSequence,RuleId;
	OPEN PreCalculationRules;
	FETCH NEXT FROM PreCalculationRules INTO @RuleType,@RuleTargetField,@RuleValue;
	WHILE @@FETCH_STATUS=0
	BEGIN
		IF @RuleType IN ('RATE_SET','RATE_SUBTRACT_POSITIVE') AND @RuleValue IS NOT NULL
		BEGIN
			IF @RuleTargetField='FEE_FV'
				IF @RuleType='RATE_SET' SET @FEE_FV=@RuleValue ELSE IF ISNULL(@FEE_FV,0)>0 SET @FEE_FV=@FEE_FV-@RuleValue;
			IF @RuleTargetField='FEE_OPV'
				IF @RuleType='RATE_SET' SET @FEE_OPV=@RuleValue ELSE IF ISNULL(@FEE_OPV,0)>0 SET @FEE_OPV=@FEE_OPV-@RuleValue;
			IF @RuleTargetField='FEE_APV'
				IF @RuleType='RATE_SET' SET @FEE_APV=@RuleValue ELSE IF ISNULL(@FEE_APV,0)>0 SET @FEE_APV=@FEE_APV-@RuleValue;
			IF @RuleTargetField='FEE_Buyout'
				IF @RuleType='RATE_SET' SET @FEE_Buyout=@RuleValue ELSE IF ISNULL(@FEE_Buyout,0)>0 SET @FEE_Buyout=@FEE_Buyout-@RuleValue;
			IF @RuleTargetField='FEE_Topup'
				IF @RuleType='RATE_SET' SET @FEE_Topup=@RuleValue ELSE IF ISNULL(@FEE_Topup,0)>0 SET @FEE_Topup=@FEE_Topup-@RuleValue;
			IF @RuleTargetField='FEE_Equity'
				IF @RuleType='RATE_SET' SET @FEE_Equity=@RuleValue ELSE IF ISNULL(@FEE_Equity,0)>0 SET @FEE_Equity=@FEE_Equity-@RuleValue;
			IF @RuleTargetField='FEE_Cashout'
				IF @RuleType='RATE_SET' SET @FEE_Cashout=@RuleValue ELSE IF ISNULL(@FEE_Cashout,0)>0 SET @FEE_Cashout=@FEE_Cashout-@RuleValue;
			IF @RuleTargetField='FEE_MBRE'
				IF @RuleType='RATE_SET' SET @FEE_MBRE=@RuleValue ELSE IF ISNULL(@FEE_MBRE,0)>0 SET @FEE_MBRE=@FEE_MBRE-@RuleValue;
		END;
		FETCH NEXT FROM PreCalculationRules INTO @RuleType,@RuleTargetField,@RuleValue;
	END;
	CLOSE PreCalculationRules;
	DEALLOCATE PreCalculationRules;

	if isnull(@StaffYN,'') = 'Yes' or isnull(@StaffYN,'') = ' Y'
	begin
		set @ARRANGEMENT_FEE = 3500
		set @ARRANGEMENT_FEE_APP = 0
		set @ARRANGEMENT_FEE_ACC = 3500
	end
	else
	begin
		set @CAL_AMT_FV = (@FEE_FV/100) * @AMT_FV
		set @CAL_AMT_OPV = (@FEE_OPV/100) * @AMT_OPV
		set @CAL_AMT_APV = (@FEE_APV/100) * @AMT_APV
		set @CAL_AMT_Buyout = (@FEE_Buyout/100) * @AMT_Buyout
		set @CAL_AMT_Topup = (@FEE_Topup/100) * @AMT_Topup
		set @CAL_AMT_Equity = (@FEE_Equity/100) * @AMT_Equity
		set @CAL_AMT_Cashout = (@FEE_Cashout/100) * @AMT_Cashout
		set @CAL_AMT_MBRE = (@FEE_MBRE/100) * @AMT_MBRE

		set @ARRANGEMENT_FEE = @CAL_AMT_FV + @CAL_AMT_OPV + @CAL_AMT_APV + @CAL_AMT_Buyout + @CAL_AMT_Topup + @CAL_AMT_Equity + @CAL_AMT_Cashout + @CAL_AMT_MBRE

		if @PRODUCT_TYPE = 'Standard Ijara' and @Product_SubTYPE = 'Standard'
		begin
			if @AMT_FV > 7000000 and @AMT_FV < 15000000
				set @MAX_FEE = 60000 --50000 , fixed prod bug, it should be 60K

			if @AMT_FV >= 15000000
				set @MAX_FEE = 100000
		end
		else
		begin
			--Below cap is applicable to all products except Subvention
			--03-01-2019 Raheel > Revised RFC to add FI-OPF Subvention sub product
			If @Product_SubTYPE <> 'Subvention' AND @Product_SubTYPE <> 'OPF Subvention'
			Begin
				if @MAX_FEE <> 999999999
				begin
					if @AMT_FV >= 15000000
						set @MAX_FEE = 100000
				end
			End
		end

		/*
		24-10-2018 Raheel Ahmed > RFC-New Sub-Product 'subvention'
		Product Type SubProduct Residency Type Staff Processing Fee Min Fee Max Fee
		Standard Ijara Subvention Non-Resident - Company No 0.50% +VAT 5000 +VAT No Cap
		Standard Ijara Subvention Resident - Company No 0.50% +VAT 5000 +VAT Same as Standard Ijara - Standard
		Standard Ijara Subvention Resident No 0.50% +VAT 5000 +VAT Same as Standard Ijara - Standard
		Standard Ijara Subvention Resident Yes 3500 + VAT 3500 +VAT 3500 + VAT
		Standard Ijara Subvention Non-Resident No 0.50% +VAT 5000 +VAT No Cap
		*/
		--03-01-2019 Raheel > Revised RFC to add FI-OPF Subvention sub product
		if (@PRODUCT_TYPE = 'Standard Ijara' and @Product_SubTYPE = 'Subvention') OR (@PRODUCT_TYPE = 'Forward Ijara' and @Product_SubTYPE = 'OPF Subvention')
		begin
			IF (@CUSTOMER_RES_TYPE = 'Resident' OR @CUSTOMER_RES_TYPE = 'Resident - Company') and (@StaffYN = 'No')
			Begin
				if @AMT_FV > 7000000 and @AMT_FV < 15000000
					set @MAX_FEE = 60000 --50000 , fixed prod bug, it should be 60K

				if @AMT_FV >= 15000000
					set @MAX_FEE = 100000
			End
		end

		----------------------------------------------------------------------
		--By Raheel Ahmed ON 13-05-2015 CR 'SD2015-223593'
		--Start
		if @PRODUCT_TYPE = 'Commercial' OR @PRODUCT_TYPE = 'Equity Release' OR @PRODUCT_TYPE = 'Standard Ijara'
		if @Product_SubTYPE = 'Buyout' OR @Product_SubTYPE = 'Topup' OR @Product_SubTYPE = 'Buyout - Bulk Residential'
		If @CUSTOMER_RES_TYPE = 'Resident' OR @CUSTOMER_RES_TYPE = 'Company Resident'
		begin
			if @AMT_FV > 15000000
				set @MAX_FEE = 250000
			else
				set @MAX_FEE = 60000
				--set @ARRANGEMENT_FEE = 250000
		end
		--End
		----------------------------------------------------------------------

		if (@ARRANGEMENT_FEE < @MIN_FEE) and @SkipMinFee=0
			set @ARRANGEMENT_FEE = @MIN_FEE

		if (@ARRANGEMENT_FEE > @MAX_FEE) and @SkipMaxFee=0
			set @ARRANGEMENT_FEE = @MAX_FEE

		IF @IsAggregatorEquityRelease=1 OR (@PRODUCT_TYPE=N'Equity Release' AND ISNULL(@AMT_Equity,0)>0)
		BEGIN
			SET @MIN_FEE=5250;
			SET @MAX_FEE=999999999;
		END
		ELSE IF @IsAbuDhabiFinalPayment=1 OR @IsGHP=1 OR @IsSTL=1
		BEGIN
			SET @ARRANGEMENT_FEE=0;
			SET @MIN_FEE=0;
			SET @MAX_FEE=999999999;
			SET @SkipMinFee=1;
			SET @SkipMaxFee=1;
		END
		ELSE
		BEGIN
			SET @MIN_FEE=5250;
			SET @MAX_FEE=CASE WHEN @CUSTOMER_RES_TYPE LIKE N'Non-Resident%' THEN 999999999 ELSE 105000 END;
		END;

		if (@ARRANGEMENT_FEE < @MIN_FEE) and @SkipMinFee=0
			set @ARRANGEMENT_FEE = @MIN_FEE

		if (@ARRANGEMENT_FEE > @MAX_FEE) and @SkipMaxFee=0
			set @ARRANGEMENT_FEE = @MAX_FEE

		set @ARRANGEMENT_FEE_APP = @ARRANGEMENT_FEE * (@FEE_APP /100)
		set @ARRANGEMENT_FEE_ACC = @ARRANGEMENT_FEE * (@FEE_ACC /100)
	end

	DECLARE PostBaseRules CURSOR LOCAL FAST_FORWARD FOR
		SELECT RuleType,AmountBasis,RuleValue,MinimumFee,SplitMode,FloorSplitMode
		FROM @PromotionRules WHERE RuleStage='POST_BASE' ORDER BY RuleSequence,RuleId;
	OPEN PostBaseRules;
	FETCH NEXT FROM PostBaseRules INTO @RuleType,@RuleAmountBasis,@RuleValue,@RuleMinimumFee,@RuleSplitMode,@RuleFloorSplitMode;
	WHILE @@FETCH_STATUS=0
	BEGIN
		IF @RuleType='FEE_PERCENT_DISCOUNT' AND ISNULL(@ARRANGEMENT_FEE,0)>0
			SET @ARRANGEMENT_FEE=@ARRANGEMENT_FEE-(@ARRANGEMENT_FEE*@RuleValue/100);
		ELSE IF @RuleType='FEE_FROM_AMOUNT'
		BEGIN
			SET @RuleAmount=CASE @RuleAmountBasis WHEN 'FINANCE' THEN @AMT_FV WHEN 'TOPUP' THEN @AMT_Topup WHEN 'EQUITY' THEN @AMT_Equity ELSE 0 END;
			SET @ARRANGEMENT_FEE=(@RuleAmount*@RuleValue)/100;
		END;

		IF @RuleType IN ('FEE_PERCENT_DISCOUNT','FEE_FROM_AMOUNT')
		BEGIN
			IF @RuleSplitMode='RECALCULATE'
			BEGIN
				SET @ARRANGEMENT_FEE_APP=@ARRANGEMENT_FEE*(@FEE_APP/100);
				SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE*(@FEE_ACC/100);
			END
			ELSE IF @RuleSplitMode='APP_ZERO'
			BEGIN
				SET @ARRANGEMENT_FEE_APP=0;
				SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE;
			END
			ELSE IF @RuleSplitMode='ACC_RESIDUAL'
				SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE-@ARRANGEMENT_FEE_APP;

			IF @RuleMinimumFee IS NOT NULL AND @ARRANGEMENT_FEE<@RuleMinimumFee
			BEGIN
				SET @ARRANGEMENT_FEE=@RuleMinimumFee;
				IF @RuleFloorSplitMode='RECALCULATE'
				BEGIN
					SET @ARRANGEMENT_FEE_APP=@ARRANGEMENT_FEE*(@FEE_APP/100);
					SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE*(@FEE_ACC/100);
				END
				ELSE IF @RuleFloorSplitMode='APP_ZERO'
				BEGIN
					SET @ARRANGEMENT_FEE_APP=0;
					SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE;
				END
				ELSE IF @RuleFloorSplitMode='ACC_RESIDUAL'
					SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE-@ARRANGEMENT_FEE_APP;
			END;
		END;
		FETCH NEXT FROM PostBaseRules INTO @RuleType,@RuleAmountBasis,@RuleValue,@RuleMinimumFee,@RuleSplitMode,@RuleFloorSplitMode;
	END;
	CLOSE PostBaseRules;
	DEALLOCATE PostBaseRules;

	IF @IsAbuDhabiFinalPayment=1 OR (@IsGHP=1 AND @IsAggregatorEquityRelease=0) OR (@IsSTL=1 AND @IsAggregatorEquityRelease=0)
	BEGIN
		SET @ARRANGEMENT_FEE=0;
		SET @ARRANGEMENT_FEE_APP=0;
		SET @ARRANGEMENT_FEE_ACC=0;
	END;

	if @ProjectID = 'PRE_APPROVAL'
	begin
		if @ARRANGEMENT_FEE_ACC <> 0
		begin
			set @ARRANGEMENT_FEE = 1500
			set @ARRANGEMENT_FEE_APP = 0
			set @ARRANGEMENT_FEE_ACC = 1500
			set @StaffYN = 'No'
		end
		else
		begin
			set @ARRANGEMENT_FEE = 0
			set @ARRANGEMENT_FEE_APP = 0
			set @ARRANGEMENT_FEE_ACC = 0
			set @StaffYN = 'No'
		end
	end

	declare @DiscountPerc numeric(20,2) = 0
	declare @Temp_ARRANGEMENT_FEE numeric(20,2)
	set @ApplyMasterDiscount=@UseMasterDiscount

	DECLARE PreMasterDiscountRules CURSOR LOCAL FAST_FORWARD FOR
		SELECT RuleType FROM @PromotionRules
		WHERE RuleStage='PRE_MASTER_DISCOUNT' ORDER BY RuleSequence,RuleId;
	OPEN PreMasterDiscountRules;
	FETCH NEXT FROM PreMasterDiscountRules INTO @RuleType;
	WHILE @@FETCH_STATUS=0
	BEGIN
		IF @RuleType='SKIP_MASTER_DISCOUNT' SET @ApplyMasterDiscount=0;
		FETCH NEXT FROM PreMasterDiscountRules INTO @RuleType;
	END;
	CLOSE PreMasterDiscountRules;
	DEALLOCATE PreMasterDiscountRules;

	if @PromotionEnabled=1 AND @ApplyMasterDiscount=1 AND isnull(@promotiontype,'') <> ''
	begin
		select @DiscountPerc=isnull(DiscountPerc,0) from Lead_Promotion_master
		where PromotionName=@promotiontype and status='A'
		and isnull(startdate,getdate()) >= getdate() and isnull(enddate,getdate()) <= getdate()

		set @DiscountPerc=isnull(@DiscountPerc,0)
		set @Temp_ARRANGEMENT_FEE=@ARRANGEMENT_FEE-(@ARRANGEMENT_FEE*@DiscountPerc/100)
		set @ARRANGEMENT_FEE=@Temp_ARRANGEMENT_FEE
		set @ARRANGEMENT_FEE_ACC=@Temp_ARRANGEMENT_FEE-@ARRANGEMENT_FEE_APP
	end

	--select @DiscountPerc
	--exec PROC_Lead_Arrangement_FEE 'LD-00091535' --26250.00 --13125.00

	--END > 06-05-2020 RFC-Arrangement fee to be zero for "Procesing Fee Promotion"

	----Processing Fee Promotion--START
	--16-02-2026 Arun Rajan

	DECLARE PostMasterDiscountRules CURSOR LOCAL FAST_FORWARD FOR
		SELECT RuleType,RuleValue,VATApplicable,MinimumFee FROM @PromotionRules
		WHERE RuleStage='POST_MASTER_DISCOUNT' ORDER BY RuleSequence,RuleId;
	OPEN PostMasterDiscountRules;
	FETCH NEXT FROM PostMasterDiscountRules INTO @RuleType,@RuleValue,@RuleVATApplicable,@RuleMinimumFee;
	WHILE @@FETCH_STATUS=0
	BEGIN
		IF @RuleType='EQUITY_RATE_TO_ACC' AND @IsAggregatorEquityRelease=0
		BEGIN
			IF @IsAggregatorEquityRelease=1
				SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE_ACC+(@AMT_Equity*@RuleValue/100);
			ELSE
				SET @ARRANGEMENT_FEE_ACC=@AMT_Equity*@RuleValue/100;
			SET @ARRANGEMENT_FEE=@ARRANGEMENT_FEE_ACC+@ARRANGEMENT_FEE_APP;
			IF @RuleMinimumFee IS NOT NULL AND @ARRANGEMENT_FEE<@RuleMinimumFee
			BEGIN
				SET @ARRANGEMENT_FEE=@RuleMinimumFee;
				SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE-@ARRANGEMENT_FEE_APP;
			END;
			IF @RuleVATApplicable IS NOT NULL SET @Is_VAT_Applicable=@RuleVATApplicable;
		END;
		FETCH NEXT FROM PostMasterDiscountRules INTO @RuleType,@RuleValue,@RuleVATApplicable,@RuleMinimumFee;
	END;
	CLOSE PostMasterDiscountRules;
	DEALLOCATE PostMasterDiscountRules;

	IF @IsAggregatorEquityRelease=1
	BEGIN
		SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE_ACC+(@AMT_Equity*1.25/100);
		SET @ARRANGEMENT_FEE=@ARRANGEMENT_FEE_APP+@ARRANGEMENT_FEE_ACC;
		IF @ARRANGEMENT_FEE<5250
		BEGIN
			SET @ARRANGEMENT_FEE=5250;
			SET @ARRANGEMENT_FEE_ACC=@ARRANGEMENT_FEE-@ARRANGEMENT_FEE_APP;
		END;
		SET @Is_VAT_Applicable=1;
	END;
	print 'Processing Fee Promotion--END'
	----Processing Fee Promotion--END

	--START ---------------------------------------------------------------------------

	--10-12-2017 Raheel Ahmed > VAT Implementation

	if @Is_VAT_Applicable = 1
	Begin
		Declare @VAT_Percentage numeric(20,5)
		select @VAT_Percentage = displayvalue from frm_gnarr where code = 'LEAD_CONSTANT' and [Value] = 'VAT_PERCENTAGE'

		print 'BEFORE VAT'
		print @ARRANGEMENT_FEE
		print @ARRANGEMENT_FEE_APP
		print @ARRANGEMENT_FEE_ACC

		--Check Is_VAT_Applicable for product and sub product
		set @ARRANGEMENT_FEE = @ARRANGEMENT_FEE + (@ARRANGEMENT_FEE * (@VAT_Percentage/100.0))
		set @ARRANGEMENT_FEE_APP = @ARRANGEMENT_FEE_APP + (@ARRANGEMENT_FEE_APP * (@VAT_Percentage/100.0))
		set @ARRANGEMENT_FEE_ACC = @ARRANGEMENT_FEE_ACC + (@ARRANGEMENT_FEE_ACC * (@VAT_Percentage/100.0))

		print 'AFTER VAT'
		print @VAT_Percentage
		print @ARRANGEMENT_FEE
		print @ARRANGEMENT_FEE_APP
		print @ARRANGEMENT_FEE_ACC
	End

	--END -----------------------------------------------------------------------------

	--now restore actual product and sub-product
	if @PromotionEnabled=1 AND @LookupProductType IS NOT NULL AND @LookupProductSubType IS NOT NULL
	Begin
		SET @PRODUCT_TYPE = @Actual_PRODUCT_TYPE
		SET @Product_SubTYPE = @Actual_Product_SubTYPE
	End

	insert into #List(
		Lead_No,
		PRODUCT_TYPE,
		Product_SubTYPE,
		Residency_Type,
		StaffYN,
		promotiontype,
		Scenario,

		FEE_FV,
		FEE_OPV,
		FEE_APV,
		FEE_Buyout,
		FEE_Topup,
		FEE_Equity,
		FEE_Cashout,
		FEE_MBRE,

		AMT_FV,
		AMT_OPV,
		AMT_APV,
		AMT_Buyout,
		AMT_Topup,
		AMT_Equity,
		AMT_Cashout,
		AMT_MBRE,

		FEE_APP,
		FEE_ACC,
		MIN_FEE,
		MAX_FEE,
		ARRANGEMENT_FEE_APP,
		ARRANGEMENT_FEE_ACC,
		ARRANGEMENT_FEE,
		RECCOUNT,
		Remarks,
		--Madesh Made changes on 11/7/2021 for UAT fix for product type and product sub type-->added msg
		ErrorMsg
	)
	values(
		@REFNO,
		@PRODUCT_TYPE,
		@Product_SubTYPE,
		@CUSTOMER_RES_TYPE,
		@StaffYN,
		@promotiontype,
		COALESCE(NULLIF(@Scenario,N''),
			CASE
				WHEN @IsAbuDhabiFinalPayment=1 THEN N'Abu Dhabi Promotion - Final Payment'
				WHEN @IsAggregatorEquityRelease=1 AND @IsSTL=1 THEN N'Aggregator Equity Release - STL'
				WHEN @IsAggregatorEquityRelease=1 AND @IsGHP=1 THEN N'Aggregator Equity Release - GHP'
				WHEN @IsAggregatorEquityRelease=1 THEN N'Aggregator Equity Release - Non-STL'
				WHEN @IsGHP=1 THEN N'GHP - Nil Fee'
				WHEN @IsSTL=1 THEN N'STL - Nil Fee'
				WHEN @PRODUCT_TYPE=N'Equity Release' AND ISNULL(@AMT_Equity,0)>0 THEN N'Non-STL Equity Release'
				WHEN @ProjectID='PRE_APPROVAL' THEN N'Pre-approval'
				ELSE N'Non-STL other than Equity Release'
			END),

		@FEE_FV,
		@FEE_OPV,
		@FEE_APV,
		@FEE_Buyout,
		@FEE_Topup,
		@FEE_Equity,
		@FEE_Cashout,
		@FEE_MBRE,

		@AMT_FV,
		@AMT_OPV,
		@AMT_APV,
		@AMT_Buyout,
		@AMT_Topup,
		@AMT_Equity,
		@AMT_Cashout,
		@AMT_MBRE,

		@FEE_APP,
		@FEE_ACC,
		@MIN_FEE,
		@MAX_FEE,
		isnull(@ARRANGEMENT_FEE_APP,0),
		isnull(@ARRANGEMENT_FEE_ACC,0),
		isnull(@ARRANGEMENT_FEE,0),
		null,
		null,
		--Madesh Made changes on 11/7/2021 for UAT fix for product type and product sub type-->added msg
		@TextError
	)

	select * from #list
	Drop table #list

END
