IF OBJECT_ID('dbo.SOA_Calllog_CustQuery', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.SOA_Calllog_CustQuery
    (
        SRNo INT IDENTITY(1,1) NOT NULL,
        Lead_no NVARCHAR(100) NOT NULL,
        Xref NVARCHAR(200) NOT NULL,
        RequestXML XML NOT NULL,
        REsponse XML NOT NULL,
        Createdby_user NVARCHAR(256) NOT NULL,
        Createdon_date DATETIME NOT NULL
            CONSTRAINT DF_SOA_Calllog_CustQuery_Createdon_date DEFAULT (GETDATE()),
        CONSTRAINT PK_SOA_Calllog_CustQuery PRIMARY KEY CLUSTERED (SRNo ASC),
        CONSTRAINT UQ_SOA_Calllog_CustQuery_Xref UNIQUE (Xref)
    );
END
GO