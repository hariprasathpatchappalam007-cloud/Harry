USE [LMS_DEV]
GO

IF OBJECT_ID(N'dbo.FRM_GNARR',N'U') IS NULL
    THROW 51900, 'dbo.FRM_GNARR must exist before seeding promotion values.', 1;

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'Aggregator-STL-Equity Release',N'Aggregator-STL-Equity Release',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'Aggregator-STL-Equity Release');

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'Aggregator-NSTL-Equity Release',N'Aggregator-NSTL-Equity Release',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'Aggregator-NSTL-Equity Release');

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'Aggregator-GHP-Equity Release',N'Aggregator-GHP-Equity Release',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'Aggregator-GHP-Equity Release');

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'STL-100% Processing Fee Discount',N'STL-100% Processing Fee Discount',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'STL-100% Processing Fee Discount');

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'NSTL-0.75% Processing Fee',N'NSTL-0.75% Processing Fee',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'NSTL-0.75% Processing Fee');

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'Direct Customer-NSTL-Equity Release',N'Direct Customer-NSTL-Equity Release',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'Direct Customer-NSTL-Equity Release');

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'GHP-STL-100% Processing Fee Discount',N'GHP-STL-100% Processing Fee Discount',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'GHP-STL-100% Processing Fee Discount');

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'GHP-NSTL-100% Processing Fee Discount',N'GHP-NSTL-100% Processing Fee Discount',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'GHP-NSTL-100% Processing Fee Discount');

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'Abu Dhabi Developers-Final Payment-100% Processing Fee Discount',N'Abu Dhabi Developers-Final Payment-100% Processing Fee Discount',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'Abu Dhabi Developers-Final Payment-100% Processing Fee Discount');

INSERT dbo.FRM_GNARR
    (Code,[Value],DisplayValue,[Status],[createdby_User],[createdon_date],[PassValue],[DISPLAYVALUE_AR])
SELECT N'LEAD_PROMOTION',N'Nest & Wajaha-50% Processing Fee Discount',N'Nest & Wajaha-50% Processing Fee Discount',N'A',N'SYSTEM',GETDATE(),NULL,NULL
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR WHERE Code=N'LEAD_PROMOTION' AND [Value]=N'Nest & Wajaha-50% Processing Fee Discount');

SELECT *
FROM dbo.FRM_GNARR
WHERE Code=N'LEAD_PROMOTION'
ORDER BY [Value];
GO
