<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="HF48Workflow.Login" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>DIB UAT Sign In</title>
</head>
<body>
    <form id="form1" runat="server">
        <h1>DIB UAT Sign In</h1>
        <asp:Label ID="lblStatus" runat="server" />
    </form>
</body>
</html>
