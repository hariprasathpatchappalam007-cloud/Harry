<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DdaBulkMaker.aspx.cs" Inherits="HF48Workflow.DdaBulkMaker" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>DDA Bulk Update - Maker</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; background-color: #ccccff; color: #222; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: inline-block; width: 180px; font-weight: bold; font-size: 13px; vertical-align: top; padding-top: 4px; }
        input, select, textarea { padding: 5px 8px; border: 1px solid #aaa; border-radius: 3px; font-size: 13px; }
        .btn { padding: 7px 16px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-primary { background-color: #003366; color: white; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-info { background-color: #17a2b8; color: white; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; background: white; }
        .gridview th { background-color: #507CD1; color: white; padding: 8px; text-align: left; white-space: nowrap; }
        .gridview td { padding: 6px 8px; border-bottom: 1px solid #ddd; vertical-align: top; }
        .who-bar { background: #fff8d8; border: 1px dashed #d8b400; padding: 8px 14px; margin-bottom: 15px; font-size: 12px; border-radius: 3px; }
        .hint { margin: 5px 0 12px 184px; color: #555; font-size: 12px; }
        .old-value { color: #7a3434; text-decoration: line-through; }
        .new-value { color: #176b2c; font-weight: bold; background-color: #e4f5e8; }
        .match-warning { color: #9b1c1c; font-weight: bold; }
        .tabs { margin: 0 0 15px 0; border-bottom: 2px solid #6c7ae0; padding-bottom: 8px; }
        .tab { display: inline-block; padding: 8px 14px; margin-right: 5px; background: #d7d7e8; color: #003366; font-weight: bold; text-decoration: none; border-radius: 3px; }
        .tab-active { background: #003366; color: white; }
    </style>
</head>
<body>
    <form id="form1" runat="server" enctype="multipart/form-data">
        <div class="header">
            <h1>DDA Bulk Update Maker</h1>
            <h2>Upload a CSV, review matched records, and submit the update for checker approval</h2>
        </div>
        <div class="container">
            <div class="who-bar">
                <strong>Acting As:</strong>
                <asp:TextBox ID="txtCurrentUser" runat="server" Width="180px" />
                <asp:Button ID="btnSetUser" runat="server" Text="Switch User" CssClass="btn btn-info" OnClick="btnSetUser_Click" />
            </div>
            <asp:Panel ID="pnlMessage" runat="server" Visible="false"><asp:Label ID="lblMessage" runat="server" /></asp:Panel>
            <asp:HiddenField ID="hfPreviewToken" runat="server" />
            <asp:HiddenField ID="hfActiveTab" runat="server" Value="BULK" />

            <div class="tabs">
                <asp:LinkButton ID="lnkBulkTab" runat="server" Text="Bulk Status Update" CssClass="tab" OnClick="lnkBulkTab_Click" CausesValidation="false" />
                <asp:LinkButton ID="lnkStandardDataTab" runat="server" Text="Standard DDA Data" CssClass="tab" OnClick="lnkStandardDataTab_Click" CausesValidation="false" />
            </div>

            <asp:Panel ID="pnlBulkWorkflow" runat="server">
            <div class="panel">
                <div class="panel-header">Create DDA Bulk Request</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>Operation</label>
                        <asp:DropDownList ID="ddlOperation" runat="server" Width="300px" AutoPostBack="true" OnSelectedIndexChanged="ddlOperation_SelectedIndexChanged" />
                    </div>
                    <div class="form-group">
                        <label>CSV list</label>
                        <asp:FileUpload ID="fuCsv" runat="server" />
                        <asp:Button ID="btnPreview" runat="server" Text="Preview CSV" CssClass="btn btn-primary" OnClick="btnPreview_Click" />
                    </div>
                    <div class="form-group">
                        <label>Supporting attachment</label>
                        <asp:FileUpload ID="fuAttachment" runat="server" />
                    </div>
                    <div class="hint">Optional. Maximum attachment size: 5 MB. Select it after previewing the CSV.</div>
                    <div class="form-group">
                        <label>Checker</label>
                        <asp:DropDownList ID="ddlChecker" runat="server" Width="300px" />
                    </div>
                    <div class="form-group">
                        <label>Maker remarks</label>
                        <asp:TextBox ID="txtMakerRemarks" runat="server" Width="520px" TextMode="MultiLine" Rows="3" />
                    </div>
                    <div class="form-group">
                        <label>Sample CSV templates</label>
                        <asp:Button ID="btnCancelTemplate" runat="server" Text="Cancellation" CssClass="btn btn-info" OnClick="btnCancelTemplate_Click" CausesValidation="false" />
                        <asp:Button ID="btnRegisterTemplate" runat="server" Text="Registration" CssClass="btn btn-info" OnClick="btnRegisterTemplate_Click" CausesValidation="false" />
                        <asp:Button ID="btnDeclineTemplate" runat="server" Text="Decline" CssClass="btn btn-info" OnClick="btnDeclineTemplate_Click" CausesValidation="false" />
                        <asp:Button ID="btnExportPreviewExcel" runat="server" Text="Export Preview to Excel (CSV)" CssClass="btn btn-info" OnClick="btnExportPreviewExcel_Click" CausesValidation="false" />
                    </div>
                    <div class="hint">Every CSV row must include REF_NBR, DDS_INTERNAL_REF, or both, and a target status. Cancellation matches the cancellation table by these keys; a DDA_REF_NO is read from that matched record for any cancellation cascade.</div>
                    <asp:Button ID="btnSubmit" runat="server" Text="Submit To Checker" CssClass="btn btn-success" OnClick="btnSubmit_Click" />
                </div>
            </div>

            <div class="panel">
                <div class="panel-header">CSV Preview</div>
                <div class="panel-body">
                    <asp:GridView ID="gvPreview" runat="server" CssClass="gridview" AutoGenerateColumns="false" DataKeyNames="InputRowNo,TargetTable,MatchStatus" OnRowDataBound="gvPreview_RowDataBound">
                        <Columns>
                            <asp:TemplateField HeaderText="Include">
                                <ItemTemplate><asp:CheckBox ID="chkInclude" runat="server" /></ItemTemplate>
                            </asp:TemplateField>
                            <asp:BoundField DataField="InputRowNo" HeaderText="CSV Row" />
                            <asp:BoundField DataField="TargetTable" HeaderText="Target Table" />
                            <asp:BoundField DataField="ApplicationId" HeaderText="Application ID" />
                            <asp:BoundField DataField="RefNbr" HeaderText="REF_NBR" />
                            <asp:BoundField DataField="InternalRef" HeaderText="DDS_INTERNAL_REF" />
                            <asp:BoundField DataField="DdaRefNo" HeaderText="Current DDA_REF_NO" ItemStyle-CssClass="old-value" />
                            <asp:BoundField DataField="ProposedDdaRefNo" HeaderText="DDA_REF_NO after approval" ItemStyle-CssClass="new-value" />
                            <asp:BoundField DataField="CurrentStatus" HeaderText="Current Status" ItemStyle-CssClass="old-value" />
                            <asp:BoundField DataField="ProposedStatus" HeaderText="Status to set" ItemStyle-CssClass="new-value" />
                            <asp:BoundField DataField="MatchBy" HeaderText="Matched By" />
                            <asp:BoundField DataField="MatchStatus" HeaderText="Match Result" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
            <div class="panel">
                <div class="panel-header">My DDA Bulk Requests</div>
                <div class="panel-body">
                    <asp:GridView ID="gvMyRequests" runat="server" CssClass="gridview" AutoGenerateColumns="true" />
                </div>
            </div>
            </asp:Panel>

            <asp:Panel ID="pnlStandardData" runat="server" Visible="false">
                <div class="panel">
                    <div class="panel-header">Standard DDA Table Data</div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label>Data set</label>
                            <asp:DropDownList ID="ddlStandardTable" runat="server" Width="300px" />
                        </div>
                        <div class="form-group">
                            <label>From date</label>
                            <asp:TextBox ID="txtStandardFromDate" runat="server" placeholder="yyyy-mm-dd" />
                            <label style="width:60px;">To date</label>
                            <asp:TextBox ID="txtStandardToDate" runat="server" placeholder="yyyy-mm-dd" />
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <asp:TextBox ID="txtStandardStatus" runat="server" Width="220px" />
                            <span class="hint" style="margin-left:8px;">Exact status; leave blank for all statuses.</span>
                        </div>
                        <div class="form-group">
                            <label>Application ID</label>
                            <asp:TextBox ID="txtStandardApplicationId" runat="server" Width="220px" />
                        </div>
                        <div class="form-group">
                            <label></label>
                            <asp:Button ID="btnPreviewStandard" runat="server" Text="Preview Data" CssClass="btn btn-primary" OnClick="btnPreviewStandard_Click" />
                            <asp:Button ID="btnExportStandardCsv" runat="server" Text="Export to CSV" CssClass="btn btn-info" OnClick="btnExportStandardCsv_Click" CausesValidation="false" />
                        </div>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-header"><asp:Label ID="lblStandardDataTitle" runat="server" Text="Preview" /></div>
                    <div class="panel-body">
                        <asp:GridView ID="gvStandardData" runat="server" CssClass="gridview" AutoGenerateColumns="true" />
                    </div>
                </div>
            </asp:Panel>
        </div>
    </form>
</body>
</html>
