namespace HF48Workflow
{
    public partial class Login
    {
        protected global::System.Web.UI.WebControls.Label lblStatus;
    }
}
