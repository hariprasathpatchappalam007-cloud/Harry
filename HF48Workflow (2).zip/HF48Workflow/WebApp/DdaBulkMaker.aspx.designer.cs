namespace HF48Workflow
{
    public partial class DdaBulkMaker
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.TextBox txtCurrentUser;
        protected global::System.Web.UI.WebControls.Button btnSetUser;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hfPreviewToken;
        protected global::System.Web.UI.WebControls.HiddenField hfActiveTab;
        protected global::System.Web.UI.WebControls.LinkButton lnkBulkTab;
        protected global::System.Web.UI.WebControls.LinkButton lnkStandardDataTab;
        protected global::System.Web.UI.WebControls.Panel pnlBulkWorkflow;
        protected global::System.Web.UI.WebControls.DropDownList ddlOperation;
        protected global::System.Web.UI.WebControls.FileUpload fuCsv;
        protected global::System.Web.UI.WebControls.Button btnPreview;
        protected global::System.Web.UI.WebControls.FileUpload fuAttachment;
        protected global::System.Web.UI.WebControls.DropDownList ddlChecker;
        protected global::System.Web.UI.WebControls.TextBox txtMakerRemarks;
        protected global::System.Web.UI.WebControls.Button btnCancelTemplate;
        protected global::System.Web.UI.WebControls.Button btnRegisterTemplate;
        protected global::System.Web.UI.WebControls.Button btnDeclineTemplate;
        protected global::System.Web.UI.WebControls.Button btnExportPreviewExcel;
        protected global::System.Web.UI.WebControls.Button btnSubmit;
        protected global::System.Web.UI.WebControls.GridView gvPreview;
        protected global::System.Web.UI.WebControls.GridView gvMyRequests;
        protected global::System.Web.UI.WebControls.Panel pnlStandardData;
        protected global::System.Web.UI.WebControls.DropDownList ddlStandardTable;
        protected global::System.Web.UI.HtmlControls.HtmlInputText txtStandardFromDate;
        protected global::System.Web.UI.HtmlControls.HtmlInputText txtStandardToDate;
        protected global::System.Web.UI.WebControls.TextBox txtStandardStatus;
        protected global::System.Web.UI.WebControls.TextBox txtStandardApplicationId;
        protected global::System.Web.UI.WebControls.Button btnPreviewStandard;
        protected global::System.Web.UI.WebControls.Button btnExportStandardCsv;
        protected global::System.Web.UI.WebControls.Label lblStandardDataTitle;
        protected global::System.Web.UI.WebControls.GridView gvStandardData;
    }
}
