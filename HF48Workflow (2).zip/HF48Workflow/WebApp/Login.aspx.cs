using System;
using System.Web;
using System.Web.UI;

namespace HF48Workflow
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Context.User != null
                && Context.User.Identity != null
                && Context.User.Identity.IsAuthenticated)
            {
                lblStatus.Text = "Signed in as "
                    + HttpUtility.HtmlEncode(Context.User.Identity.Name) + ".";
                return;
            }

            lblStatus.Text = "Windows Authentication is required to sign in.";
        }
    }
}
