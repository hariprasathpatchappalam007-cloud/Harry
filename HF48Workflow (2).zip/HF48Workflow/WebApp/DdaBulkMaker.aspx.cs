using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace HF48Workflow
{
    public partial class DdaBulkMaker : Page
    {
        private const int MaxCsvBytes = 2097152;
        private const int MaxAttachmentBytes = 5242880;
        private bool _isFileDownload;

        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                string fromTextbox = (txtCurrentUser.Text ?? "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                if (Context.User != null && Context.User.Identity != null && !string.IsNullOrEmpty(Context.User.Identity.Name))
                    return Context.User.Identity.Name;
                return "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null) txtCurrentUser.Text = Session["UserID"].ToString();
                hfPreviewToken.Value = Guid.NewGuid().ToString("N");
                ddlOperation.Items.Add(new ListItem("DDA Cancellation", "CANCEL"));
                ddlOperation.Items.Add(new ListItem("DDA Registration Status", "REGISTER"));
                ddlOperation.Items.Add(new ListItem("DDA Decline / Rejection", "DECLINE"));
                LoadCheckers();
                LoadMyRequests();
            }
        }

        private void LoadCheckers()
        {
            DataTable dt = ExecuteDataTable("Proc_DDA_BulkGetUsers", null);
            ddlChecker.DataSource = dt;
            ddlChecker.DataTextField = "LoginId";
            ddlChecker.DataValueField = "LoginId";
            ddlChecker.DataBind();
            ddlChecker.Items.Insert(0, new ListItem("-- Select Checker --", ""));
        }

        private void LoadMyRequests()
        {
            gvMyRequests.DataSource = ExecuteDataTable("Proc_DDA_BulkGetRequests", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@Mode", "MAKER");
            });
            gvMyRequests.DataBind();
        }

        protected void ddlOperation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(hfPreviewToken.Value))
                Session.Remove(PreviewSessionKey(hfPreviewToken.Value));
            hfPreviewToken.Value = Guid.NewGuid().ToString("N");
            gvPreview.DataSource = null;
            gvPreview.DataBind();
            ShowMessage("Select a CSV template for the chosen operation and preview the file.", true);
        }

        protected void btnPreview_Click(object sender, EventArgs e)
        {
            if (!fuCsv.HasFile)
            {
                ShowMessage("Choose a CSV file to preview.", false);
                return;
            }
            if (fuCsv.PostedFile.ContentLength <= 0 || fuCsv.PostedFile.ContentLength > MaxCsvBytes)
            {
                ShowMessage("The CSV must be non-empty and no larger than 2 MB.", false);
                return;
            }
            if (!string.Equals(Path.GetExtension(fuCsv.FileName), ".csv", StringComparison.OrdinalIgnoreCase))
            {
                ShowMessage("Upload a .csv file.", false);
                return;
            }

            try
            {
                byte[] csvBytes = ReadPostedFile(fuCsv.PostedFile);
                string csv;
                using (StreamReader reader = new StreamReader(new MemoryStream(csvBytes), Encoding.UTF8, true))
                    csv = reader.ReadToEnd();

                string inputXml = BuildInputXml(csv, ddlOperation.SelectedValue);
                DataTable preview = Preview(inputXml, ddlOperation.SelectedValue);
                gvPreview.DataSource = preview;
                gvPreview.DataBind();

                if (!string.IsNullOrEmpty(hfPreviewToken.Value))
                    Session.Remove(PreviewSessionKey(hfPreviewToken.Value));
                string token = Guid.NewGuid().ToString("N");
                hfPreviewToken.Value = token;
                Session[PreviewSessionKey(token)] = new string[]
                {
                    ddlOperation.SelectedValue,
                    DdaBulkCsv.SafeFileName(fuCsv.FileName),
                    Convert.ToBase64String(csvBytes),
                    inputXml
                };

                string validationMessage;
                bool valid = ValidatePreview(preview, ddlOperation.SelectedValue, out validationMessage);
                ShowMessage(valid
                    ? string.Format("Preview successful: {0} target record(s). Optionally attach a supporting document and submit.", preview.Rows.Count)
                    : validationMessage, valid);
            }
            catch (InvalidDataException ex)
            {
                ShowMessage(ex.Message, false);
            }
            catch (FormatException ex)
            {
                ShowMessage(ex.Message, false);
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(hfPreviewToken.Value))
            {
                ShowMessage("Preview a CSV before submitting.", false);
                return;
            }
            if (fuAttachment.HasFile && fuAttachment.PostedFile.ContentLength > MaxAttachmentBytes)
            {
                ShowMessage("The supporting attachment must not exceed 5 MB.", false);
                return;
            }
            if (string.IsNullOrEmpty(ddlChecker.SelectedValue))
            {
                ShowMessage("Select a checker.", false);
                return;
            }

            string[] previewData = Session[PreviewSessionKey(hfPreviewToken.Value)] as string[];
            if (previewData == null || previewData.Length != 4 || previewData[0] != ddlOperation.SelectedValue)
            {
                ShowMessage("The CSV preview has expired or no longer matches the selected operation. Preview the CSV again.", false);
                return;
            }

            try
            {
                DataTable preview = GetSelectedPreviewRows(previewData);
                if (preview.Rows.Count == 0)
                {
                    ShowMessage("Select at least one preview row to submit.", false);
                    return;
                }
                string validationMessage;
                if (!ValidatePreview(preview, previewData[0], out validationMessage))
                {
                    ShowMessage(validationMessage + " Preview the CSV again after correcting the source data.", false);
                    return;
                }

                string detailsXml = BuildDetailsXml(preview);
                byte[] csvBytes = Convert.FromBase64String(previewData[2]);
                byte[] attachmentBytes = fuAttachment.HasFile ? ReadPostedFile(fuAttachment.PostedFile) : null;

                using (SqlConnection conn = new SqlConnection(ConnStr))
                using (SqlCommand cmd = new SqlCommand("Proc_DDA_BulkSubmit", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@OperationCode", previewData[0]);
                    cmd.Parameters.AddWithValue("@MakerLoginId", CurrentUser);
                    cmd.Parameters.AddWithValue("@CheckerLoginId", ddlChecker.SelectedValue);
                    cmd.Parameters.AddWithValue("@MakerRemarks", string.IsNullOrWhiteSpace(txtMakerRemarks.Text) ? (object)DBNull.Value : txtMakerRemarks.Text.Trim());
                    cmd.Parameters.AddWithValue("@SourceFileName", previewData[1]);
                    cmd.Parameters.Add("@SourceFileData", SqlDbType.VarBinary, -1).Value = csvBytes;
                    cmd.Parameters.AddWithValue("@AttachmentFileName", fuAttachment.HasFile ? (object)DdaBulkCsv.SafeFileName(fuAttachment.FileName) : DBNull.Value);
                    cmd.Parameters.AddWithValue("@AttachmentContentType", fuAttachment.HasFile ? (object)(fuAttachment.PostedFile.ContentType ?? "application/octet-stream") : DBNull.Value);
                    cmd.Parameters.Add("@AttachmentData", SqlDbType.VarBinary, -1).Value = attachmentBytes == null ? (object)DBNull.Value : attachmentBytes;
                    cmd.Parameters.Add("@DetailsXml", SqlDbType.Xml).Value = detailsXml;
                    SqlParameter requestId = new SqlParameter("@RequestId", SqlDbType.Int) { Direction = ParameterDirection.Output };
                    SqlParameter status = new SqlParameter("@Status", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
                    SqlParameter message = new SqlParameter("@Message", SqlDbType.NVarChar, 500) { Direction = ParameterDirection.Output };
                    cmd.Parameters.Add(requestId);
                    cmd.Parameters.Add(status);
                    cmd.Parameters.Add(message);
                    conn.Open();
                    cmd.ExecuteNonQuery();

                    bool success = Convert.ToString(status.Value) == "SUCCESS";
                    ShowMessage(Convert.ToString(message.Value), success);
                    if (success)
                    {
                        Session.Remove(PreviewSessionKey(hfPreviewToken.Value));
                        hfPreviewToken.Value = Guid.NewGuid().ToString("N");
                        gvPreview.DataSource = null;
                        gvPreview.DataBind();
                        txtMakerRemarks.Text = "";
                        ddlChecker.SelectedIndex = 0;
                    }
                }
                LoadMyRequests();
            }
            catch (FormatException ex)
            {
                ShowMessage("The stored CSV preview is invalid. Preview the file again. " + ex.Message, false);
            }
        }

        private string BuildInputXml(string csv, string operation)
        {
            List<string[]> rows = DdaBulkCsv.Parse(csv);
            if (rows.Count < 2) throw new InvalidDataException("The CSV must include a header and at least one data row.");
            if (rows.Count > 5001) throw new InvalidDataException("The CSV cannot contain more than 5,000 data rows.");

            if (operation != "CANCEL" && operation != "REGISTER" && operation != "DECLINE")
                throw new InvalidDataException("Select a supported DDA operation.");
            string[] expected = new string[] { "REF_NBR", "DDS_INTERNAL_REF", "STATUS", "DDA_REF_NO" };

            string[] headers = rows[0];
            if (headers.Length != expected.Length) throw new InvalidDataException("The CSV columns do not match the selected operation's template.");
            for (int i = 0; i < expected.Length; i++)
                if (!string.Equals(headers[i].Trim(), expected[i], StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Expected CSV header: " + string.Join(",", expected) + ".");

            XmlDocument document = new XmlDocument();
            XmlElement root = document.CreateElement("Rows");
            document.AppendChild(root);
            HashSet<string> uniqueRows = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 1; i < rows.Count; i++)
            {
                if (rows[i].Length != expected.Length) throw new InvalidDataException("CSV data row " + i + " has an incorrect number of columns.");
                string[] values = new string[expected.Length];
                for (int j = 0; j < values.Length; j++) values[j] = DdaBulkCsv.ReadExcelTextCell(rows[i][j].Trim());
                if ((values[0].Length == 0) == (values[1].Length == 0))
                    throw new InvalidDataException("CSV data row " + i + " must include exactly one of REF_NBR or DDS_INTERNAL_REF.");
                if (values[2].Length == 0)
                    throw new InvalidDataException("CSV data row " + i + " must include a target status.");
                for (int j = 0; j < values.Length; j++)
                    if (values[j].Length > 200) throw new InvalidDataException("CSV data row " + i + " contains a value longer than 200 characters.");

                values[2] = NormalizeTargetStatus(values[2], operation, i);
                if (operation == "REGISTER" && values[2] == "Active" && values[3].Length == 0)
                    throw new InvalidDataException("CSV data row " + i + " requires DDA_REF_NO when registration status is Active.");
                if (operation != "REGISTER" && values[3].Length > 0)
                    throw new InvalidDataException("DDA_REF_NO must be left blank for cancellation or decline rows.");

                string uniqueKey = operation + "|" + string.Join("|", values);
                if (!uniqueRows.Add(uniqueKey)) throw new InvalidDataException("The CSV contains a duplicate data row: " + i + ".");

                XmlElement row = document.CreateElement("Row");
                row.SetAttribute("RowNo", i.ToString());
                row.SetAttribute("REFERENCE_NO", values[0].Length > 0 ? values[0] : values[1]);
                row.SetAttribute("STATUS", values[2]);
                row.SetAttribute("DDA_REF_NO", values[3]);
                root.AppendChild(row);
            }
            return document.OuterXml;
        }

        private string NormalizeTargetStatus(string status, string operation, int rowNumber)
        {
            string[] allowed;
            if (operation == "CANCEL")
                allowed = new string[] { "Cancelled" };
            else if (operation == "REGISTER")
                allowed = new string[] { "Active", "Declined by CB", "Rejected" };
            else
                allowed = new string[] { "Declined by CB", "Rejected" };

            foreach (string value in allowed)
                if (string.Equals(status, value, StringComparison.OrdinalIgnoreCase))
                    return value;
            throw new InvalidDataException("CSV data row " + rowNumber + " has an invalid status for the selected operation. Allowed status: " + string.Join(", ", allowed) + ".");
        }

        private DataTable GetSelectedPreviewRows(string[] previewData)
        {
            HashSet<string> selectedKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (GridViewRow row in gvPreview.Rows)
            {
                CheckBox include = row.FindControl("chkInclude") as CheckBox;
                if (include == null || !include.Checked) continue;
                DataKey key = gvPreview.DataKeys[row.RowIndex];
                selectedKeys.Add(Convert.ToString(key.Values["InputRowNo"]) + "|" + Convert.ToString(key.Values["TargetTable"]));
            }

            DataTable allRows = Preview(previewData[3], previewData[0]);
            DataTable selectedRows = allRows.Clone();
            foreach (DataRow row in allRows.Rows)
                if (selectedKeys.Contains(Convert.ToString(row["InputRowNo"]) + "|" + Convert.ToString(row["TargetTable"])))
                    selectedRows.ImportRow(row);
            return selectedRows;
        }

        private DataTable Preview(string inputXml, string operation)
        {
            return ExecuteDataTable("Proc_DDA_BulkPreview", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@OperationCode", operation);
                cmd.Parameters.Add("@RowsXml", SqlDbType.Xml).Value = inputXml;
            });
        }

        private bool ValidatePreview(DataTable preview, string operation, out string message)
        {
            if (preview.Rows.Count == 0)
            {
                message = "No matching DDA records were found.";
                return false;
            }
            foreach (DataRow row in preview.Rows)
            {
                if (!string.Equals(Convert.ToString(row["MatchStatus"]), "Ready", StringComparison.OrdinalIgnoreCase))
                {
                    message = "The preview contains missing or ambiguous matches. Resolve all rows marked Not found or Ambiguous before submitting.";
                    return false;
                }
            }

            if (operation == "REGISTER" || operation == "CANCEL")
            {
                Dictionary<string, int> counts = new Dictionary<string, int>();
                foreach (DataRow row in preview.Rows)
                {
                    string targetTable = Convert.ToString(row["TargetTable"]);
                    if ((operation == "REGISTER" && targetTable != "CORE_DDA_REGISTRATION_DETAILS") ||
                        (operation == "CANCEL" && targetTable != "CORE_DDA_CANCELLATION_DETAILS"))
                        continue;
                    string key = Convert.ToString(row["InputRowNo"]);
                    if (!counts.ContainsKey(key)) counts[key] = 0;
                    counts[key]++;
                }
                foreach (int count in counts.Values)
                {
                    if (count != 1)
                    {
                        message = operation == "CANCEL"
                            ? "Each cancellation row must match exactly one CORE_DDA_CANCELLATION_DETAILS record."
                            : "Each registration row must match exactly one CORE_DDA_REGISTRATION_DETAILS record by DDS_INTERNAL_REF or REF_NBR.";
                        return false;
                    }
                }
                foreach (DataRow row in preview.Rows)
                {
                    if (!counts.ContainsKey(Convert.ToString(row["InputRowNo"])))
                    {
                        message = operation == "CANCEL"
                            ? "Each cancellation row must match exactly one CORE_DDA_CANCELLATION_DETAILS record."
                            : "Each registration row must match exactly one CORE_DDA_REGISTRATION_DETAILS record.";
                        return false;
                    }
                }
            }

            message = "";
            return true;
        }

        private string BuildDetailsXml(DataTable preview)
        {
            XmlDocument document = new XmlDocument();
            XmlElement root = document.CreateElement("Details");
            document.AppendChild(root);
            foreach (DataRow item in preview.Rows)
            {
                XmlElement detail = document.CreateElement("Detail");
                detail.SetAttribute("InputRowNo", Convert.ToString(item["InputRowNo"]));
                detail.SetAttribute("TargetTable", Convert.ToString(item["TargetTable"]));
                detail.SetAttribute("MatchBy", Convert.ToString(item["MatchBy"]));
                SetAttribute(detail, "ApplicationId", item["ApplicationId"]);
                SetAttribute(detail, "RefNbr", item["RefNbr"]);
                SetAttribute(detail, "DdaRefNo", item["DdaRefNo"]);
                SetAttribute(detail, "InternalRef", item["InternalRef"]);
                SetAttribute(detail, "CurrentStatus", item["CurrentStatus"]);
                SetAttribute(detail, "ProposedStatus", item["ProposedStatus"]);
                SetAttribute(detail, "ProposedDdaRefNo", item["ProposedDdaRefNo"]);
                root.AppendChild(detail);
            }
            return document.OuterXml;
        }

        private void SetAttribute(XmlElement element, string name, object value)
        {
            string text = value == null || value == DBNull.Value ? "" : Convert.ToString(value);
            element.SetAttribute(name, text);
        }

        private void DownloadTemplate(string fileName, string content)
        {
            _isFileDownload = true;
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.ContentEncoding = Encoding.UTF8;
            Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
            Response.BinaryWrite(new UTF8Encoding(true).GetBytes(content));
            Response.Flush();
            Context.ApplicationInstance.CompleteRequest();
        }

        protected void btnCancelTemplate_Click(object sender, EventArgs e)
        {
            DownloadTemplate("DDA_Cancellation_Template.csv", "REF_NBR,DDS_INTERNAL_REF,STATUS,DDA_REF_NO\r\n" +
                DdaBulkCsv.Escape(DdaBulkCsv.ExcelTextCell("7893434343343763746734673643")) + ",,Cancelled,\r\n");
        }

        protected void btnRegisterTemplate_Click(object sender, EventArgs e)
        {
            DownloadTemplate("DDA_Registration_Template.csv", "REF_NBR,DDS_INTERNAL_REF,STATUS,DDA_REF_NO\r\n" +
                "," + DdaBulkCsv.Escape(DdaBulkCsv.ExcelTextCell("7893434343343763746734673643")) + ",Active," +
                DdaBulkCsv.Escape(DdaBulkCsv.ExcelTextCell("71200001972024000043606")) + "\r\n");
        }

        protected void btnDeclineTemplate_Click(object sender, EventArgs e)
        {
            DownloadTemplate("DDA_Decline_Template.csv", "REF_NBR,DDS_INTERNAL_REF,STATUS,DDA_REF_NO\r\n" +
                DdaBulkCsv.Escape(DdaBulkCsv.ExcelTextCell("7893434343343763746734673643")) + ",,Declined by CB,\r\n");
        }

        protected void gvPreview_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            CheckBox include = e.Row.FindControl("chkInclude") as CheckBox;
            if (include != null) include.Checked = true;
            DataRowView data = e.Row.DataItem as DataRowView;
            if (data != null && Convert.ToString(data["MatchStatus"]) != "Ready")
                e.Row.CssClass = "match-warning";
            if (data != null && string.Equals(Convert.ToString(data["DdaRefNo"]), Convert.ToString(data["ProposedDdaRefNo"]), StringComparison.Ordinal))
            {
                e.Row.Cells[6].CssClass = "";
                e.Row.Cells[7].CssClass = "";
                e.Row.Cells[7].Text = "Unchanged";
            }
        }

        protected void btnExportPreviewExcel_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(hfPreviewToken.Value))
            {
                ShowMessage("Preview a CSV before exporting.", false);
                return;
            }
            string[] previewData = Session[PreviewSessionKey(hfPreviewToken.Value)] as string[];
            if (previewData == null || previewData.Length != 4)
            {
                ShowMessage("The CSV preview has expired. Preview the CSV again before exporting.", false);
                return;
            }
            DataTable selected = GetSelectedPreviewRows(previewData);
            if (selected.Rows.Count == 0)
            {
                ShowMessage("Select at least one preview row to export.", false);
                return;
            }

            StringBuilder csv = new StringBuilder();
            for (int columnIndex = 0; columnIndex < selected.Columns.Count; columnIndex++)
            {
                if (columnIndex > 0) csv.Append(',');
                csv.Append(DdaBulkCsv.Escape(selected.Columns[columnIndex].ColumnName));
            }
            csv.Append("\r\n");
            foreach (DataRow row in selected.Rows)
            {
                for (int columnIndex = 0; columnIndex < selected.Columns.Count; columnIndex++)
                {
                    if (columnIndex > 0) csv.Append(',');
                    string value = row[columnIndex] == DBNull.Value ? "" : Convert.ToString(row[columnIndex]);
                    csv.Append(DdaBulkCsv.Escape(DdaBulkCsv.ExcelTextCell(value)));
                }
                csv.Append("\r\n");
            }
            DownloadTemplate("DDA_Bulk_Preview.csv", csv.ToString());
        }

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Session["UserID"] = (txtCurrentUser.Text ?? "").Trim();
            LoadMyRequests();
            ShowMessage("Acting user set to: " + CurrentUser, true);
        }

        private DataTable ExecuteDataTable(string procedureName, Action<SqlCommand> addParameters)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (addParameters != null) addParameters(cmd);
                DataTable dt = new DataTable();
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    conn.Open();
                    adapter.Fill(dt);
                }
                return dt;
            }
        }

        private string PreviewSessionKey(string token)
        {
            return "DdaBulkPreview_" + token;
        }

        private byte[] ReadPostedFile(HttpPostedFile postedFile)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = postedFile.InputStream.Read(buffer, 0, buffer.Length)) > 0)
                    memory.Write(buffer, 0, bytesRead);
                return memory.ToArray();
            }
        }

        private void ShowMessage(string message, bool success)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = success ? "msg-success" : "msg-error";
            lblMessage.Text = HttpUtility.HtmlEncode(message);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (!_isFileDownload) base.Render(writer);
        }
    }
}
