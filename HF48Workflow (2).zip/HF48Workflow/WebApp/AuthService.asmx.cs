using System.Web;
using System.Web.Services;

namespace HF48Workflow
{
    [WebService(Namespace = "https://dib.ae/HF48Workflow/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class AuthService : WebService
    {
        [WebMethod]
        public bool IsAuthenticated()
        {
            HttpContext context = HttpContext.Current;
            return context != null
                && context.User != null
                && context.User.Identity != null
                && context.User.Identity.IsAuthenticated;
        }
    }
}
