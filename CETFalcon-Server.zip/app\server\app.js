import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import {createAuthentication} from './auth.js';
import {asyncRoute, handleError, notFound} from './errors.js';
import {createHelperRouter} from './helper-routes.js';
import {createPortfolioRouter} from './portfolio.js';

export function createApp({database, config}) {
  const app = express();
  const router = express.Router();
  const authentication = createAuthentication({
    database,
    sessionCookieName: config.sessionCookieName,
    developmentIdentity: config.developmentIdentity
  });
  const expectedOrigin = new URL(config.publicUrl).origin;

  app.disable('x-powered-by');
  if (config.basePath) {
    app.use((request, response, next) => {
      const normalized = request.path.toLowerCase().replace(/\/$/, '');
      if (['GET', 'HEAD'].includes(request.method) && normalized === config.basePath.toLowerCase() && request.path !== `${config.basePath}/`) {
        const query = request.originalUrl.includes('?') ? request.originalUrl.slice(request.originalUrl.indexOf('?')) : '';
        return response.redirect(302, `${config.basePath}/${query}`);
      }
      next();
    });
  }
  app.use((request, response, next) => {
    response.set({
      'Cache-Control': 'no-store',
      'Content-Security-Policy': `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' http://127.0.0.1:${config.helperPort}; frame-ancestors 'none'; base-uri 'self'; form-action 'self'`,
      'Referrer-Policy': 'no-referrer',
      'X-Content-Type-Options': 'nosniff'
    });
    next();
  });
  app.use((request, response, next) => {
    const unsafe = !['GET', 'HEAD', 'OPTIONS'].includes(request.method);
    if (unsafe && request.get('origin') && request.get('origin') !== expectedOrigin) {
      return response.status(403).json({message: 'Invalid request origin.'});
    }
    next();
  });
  app.use(express.json({limit: '1mb'}));

  router.get('/api/auth/me', authentication.authenticate, asyncRoute(async (request, response) => {
    response.json({
      userId: request.user.userId,
      email: request.user.email,
      displayName: request.user.displayName,
      directoryAccount: request.user.directoryAccount,
      roles: request.user.roles,
      authentication: request.user.authentication
    });
  }));
  router.use('/api', createHelperRouter({database, authentication, config}));
  router.use('/api/portfolio', createPortfolioRouter({
    database,
    authentication,
    attachmentRoot: config.attachmentRoot
  }));
  router.use('/api', notFound);
  router.get('/downloads/DFM-Helper-Setup.exe', (request, response) => {
    const installerPath = path.join(config.downloadRoot, 'DFM-Helper-Setup.exe');
    if (!fs.existsSync(installerPath)) return response.status(404).type('text/plain').send('DFM Helper has not been published yet.');
    response.download(installerPath, 'DFM-Helper-Setup.exe');
  });
  router.use(express.static(config.staticRoot, {index: false, dotfiles: 'deny'}));
  router.get('/{*path}', (request, response) => {
    if (request.path.startsWith('/api/') || request.path.startsWith('/Controllers/') || request.path.startsWith('/Infrastructure/') || /\.(?:config|cs|csproj)$/i.test(request.path)) {
      return response.status(404).type('text/plain').send('Not found.');
    }
    response.sendFile(path.join(config.staticRoot, 'index.html'));
  });

  app.use(config.basePath || '/', router);
  app.use(handleError);
  return app;
}