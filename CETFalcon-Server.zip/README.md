# CETFalcon Deployment

For a complete, non-technical, printable walkthrough, open [CETFalcon-Deployment-Guide.html](CETFalcon-Deployment-Guide.html) in a browser.

## Packages

Build on the development Windows machine: `npm ci`, `npm run helper:build`, then `npm run release:build` in DFM.Node. Only send the resulting server ZIP to DXB01-VWU-HFNA2. No npm, compiler, source tree, tests, or build cache is needed on the server. Compact production dependency bundles are included; server Node, ARR and URL Rewrite are prerequisites, not bundled payloads. The helper is a native Windows application rather than an Electron/Chromium distribution.

The release builder enforces a maximum of **5,000,000 uncompressed bytes per folder** for server `app\downloads` and `app\node_modules` (and workstation dependencies). Runtime bundles include third-party license notices, not npm development tools, source maps or unused browser builds. They preserve SQL Server, CSV, Express and multipart upload support; the workstation bundle also includes LDAPS. Do not run `npm ci` in the extracted release: it would replace these generated bundles with the full development dependency tree. The whole server ZIP also includes client assets and migrations; the folder limits are not a whole-archive size guarantee.

To update an already-built release in place, run `npm run release:build -- --refresh <release-timestamp>` after building the helper. This replaces its dependency folders, copies current runtime files and helper, regenerates manifests and ZIP checksums, and refreshes existing nested/outer distribution ZIPs. Do not deploy while refreshing; validation/build errors must be resolved before distribution. The outer ZIP contains only the two deployable folders, not redundant nested archive copies.

- CETFalcon-Server.zip: IIS configuration/setup, web runtime, migrations, helper installer. No Node executable or ARR/Rewrite installers.
- CETFalcon-WorkstationSync.zip: standalone LDAP/JIRA sync tooling with its own bundled Node for one authorized domain workstation; do not install on UAT. Server prerequisites do not imply Node exists on that workstation.
- CETFalcon-Users.zip: generated on the server after deployment, containing the helper installer, public certificate and fingerprint only. This is the package for normal users.

## Server

1. Back up DFM and existing attachments. Ensure Windows Server installation sources are available for the IIS role. Installing IIS may require a restart and another setup run.
2. Extract CETFalcon-Server.zip completely on DXB01-VWU-HFNA2. Right-click Install-Server.cmd, Run as administrator. Windows administrator approval is mandatory for server provisioning; it cannot be bypassed.
   Before database changes, setup checks the installed Node version (24-26) and registered IIS URL Rewrite/ARR modules, failing explicitly if missing. Node defaults to `C:\Program Files\nodejs\node.exe`. For a custom machine-wide location, run `.\Install-Server.ps1 -NodePath 'D:\Tools\Node\node.exe'` from an elevated PowerShell. The Local Service runtime identity must have read/execute access to that installation and its parent folders; do not use an administrator's private profile installation. Setup saves the absolute path in the restricted installation's `tools\node-path.txt`; startup tasks and readiness checks use it without relying on user PATH. Keep Node at that path when updating it, or rerun setup with the new path. `-ValidateOnly` still checks package integrity only, not server prerequisites.
3. Confirm DEPLOY and enter the SQL password locally. The package contains no passwords. Runtime credentials are machine-DPAPI encrypted and the install folder is restricted to Administrators, SYSTEM and the Local Service runtime identity. Use a dedicated least-privilege application SQL login for production; migration/bootstrap permissions should be temporary DBA-authorized permissions.
4. The installer sets up IIS site CETFalcon, one-year self-signed TLS with a non-exportable private key, three startup/restarting Node tasks under Local Service, and HTTPS firewall access. It reuses a managed unexpired certificate on repeat installs, preserves attachments, and backs up existing app/config files. IIS configuration is backed up with appcmd before changes. An unrelated/conflicting site or port is not deleted or stopped.
5. Check READY results for all three URLs. On failure, review the named task and `C:\ProgramData\CETFalcon\<environment-path>\logs\server.log`. Do not rerun the legacy application concurrently for writes.
6. Send `C:\ProgramData\CETFalcon\CETFalcon-Users.zip` to users, and give them the certificate SHA-256 fingerprint through a separate trusted channel. Private keys and SQL credentials are never in that ZIP.

Portals and local backend ports:

- Production: https://DXB01-VWU-HFNA2/CETFalcon, loopback 5100
- Development: https://DXB01-VWU-HFNA2/CETFalconDev, loopback 5101
- UAT: https://DXB01-VWU-HFNA2/CETFalconUAT, loopback 5102

All three use SQL Server 10.224.3.13, database DFM. **These are three application instances, not three isolated databases. Changes in any environment affect the same data.** Review deployment.json before building if separate databases are needed. Existing databases must already match migration 012; setup applies helper migration 013 only, never blindly replays baseline scripts. Empty databases are initialized without the placeholder-user seed script 011. SQL Server itself must already be installed and the DFM database must exist; setup does not install or reconfigure the remote SQL server.

SQL connections remain encrypted. This release has the explicitly approved temporary setting `sqlTrustServerCertificate: true` for SQL Server `10.224.3.13`, database `DFM`: SQL certificate identity verification is skipped, so no trusted SQL certificate installation is required to proceed. This weakens protection against server impersonation and applies to both server and workstation SQL connections and all three shared-database portals, not just UAT. Setup prints a warning. Passwords are still entered locally, never hard-coded. Have IT configure trusted SQL TLS with a matching hostname, then set this flag back to `false`, rebuild and redeploy both packages (rerun workstation setup to replace its stored connection settings). Website HTTPS, helper, LDAPS and JIRA certificate checks are unchanged.

## Workstation Sync And First Administrator

Extract CETFalcon-WorkstationSync.zip on a restricted authorized workstation that can reach LDAPS, JIRA, and SQL Server 10.224.3.13. Double-click Setup-Workstation.cmd as the normal user. Enter SQL, LDAP and optional JIRA credentials locally; they are protected with Current User DPAPI under LocalAppData\CETFalcon-Sync. The workstation requires .NET Framework 4.5 or later for the existing JIRA collector. No administrator rights or npm installation is required. It must have a trusted LDAPS/JIRA certificate chain; the collector does not bypass TLS validation.

Setup runs sync once, and optionally schedules it at logon and 09:00 while that user is logged in. The workstation must be powered on and connected. Subsequent runs use Run-Sync.cmd. Raw JIRA responses/logs can contain confidential business data; retain this folder only under the authorized user's restricted profile. Nothing schedules LDAP or JIRA on the UAT server.

After LDAP sync, setup offers first-administrator bootstrap. This is a DBA-authorized operation: confirm the synchronized administrator email, explicitly approve the Master role grant, and use the displayed one-time code in that administrator's DFM Helper. Subsequent users request device approval in the helper and the Master approves them in DFM. Never share workstation sync credentials or packages with ordinary users.

## Certificates And Email

The helper offers Import certificate (Current User Trusted Root, no elevation) and Validate URL. It checks SAN hostname, self-signature and expiry before prompting with the SHA-256 fingerprint. Only trust the administrator-supplied public certificate after independent fingerprint confirmation. User-level certificate import may still be prohibited by domain policy; IT must then distribute trust or use an enterprise-issued certificate. Browsers may need restarting and Local Network Access approval for the helper bridge. No blanket certificate-error callback or TLS-verification bypass is installed.

No SMTP server, sender or recipient list was supplied, so setup prepares a distribution ZIP but does not send unsolicited email. To send the public certificate and instructions through an approved SMTP server, run Send-Certificate.ps1 on the server with -SmtpServer, -From and -To. SMTP TLS is required and credentials are entered locally. Send the installer ZIP via your approved file-sharing channel rather than attaching an executable to email.

## Rollback And Verification

Stop CETFalcon-Prod, CETFalcon-Dev and CETFalcon-UAT tasks before restoring app/runtime.bin backups. Restore the named IIS backup with appcmd only after assessing its server-wide effect. Application rollback does not roll back SQL migrations; restore SQL only through the DBA's backup/recovery plan. No automatic destructive rollback is attempted.

Build-time checks cover package manifests, script syntax, Node tests and helper packaging. Run Install-Server.ps1 -ValidateOnly on an extracted package to check hashes without modifying the machine. Actual IIS provisioning, certificate trust, SQL permissions, workstation network access and end-to-end device approval must be accepted on the target infrastructure. A self-signed certificate is a private deployment trust mechanism, not a substitute for enterprise PKI.

The native helper requires the full Windows .NET Framework 4.5+ with Windows Forms instead of shipping Chromium or Node; use patched 4.8/4.8.1 in production. When upgrading from Electron, quit the old helper from its tray menu, disable its old startup entry, and uninstall the Electron version before installing the native helper. Preserve `%APPDATA%\DFM Helper`; existing per-portal enrollment profiles are retained. Native setup installs only for the current user without elevation. Interactive install/update/uninstall, certificate-store changes, browser permissions, and real IIS/AD/SQL enrollment still need target-workstation acceptance testing; local native self-tests do not replace that. Code signing requires your organization's signing certificate; the build does not manufacture a trusted publisher identity.