# CETFalcon Deployment

For a complete, non-technical, printable walkthrough, open [CETFalcon-Deployment-Guide.html](CETFalcon-Deployment-Guide.html) in a browser.

## Packages

Build on the development Windows machine: `npm ci`, `npm run helper:build`, then `npm run release:build` in DFM.Node. Only send the resulting server ZIP to DXB01-VWU-HFNA2.dibuat.ae. No npm, compiler, source tree, tests, or build cache is needed on the server. Compact production dependency bundles are included; server Node, ARR and URL Rewrite are prerequisites, not bundled payloads. The helper is a native Windows application rather than an Electron/Chromium distribution.

The release builder enforces a maximum of **5,000,000 uncompressed bytes per folder** for server `app\downloads` and `app\node_modules` (and workstation dependencies). Runtime bundles include third-party license notices, not npm development tools, source maps or unused browser builds. They preserve SQL Server, CSV, Express and multipart upload support; the workstation bundle also includes LDAPS. Do not run `npm ci` in the extracted release: it would replace these generated bundles with the full development dependency tree. The whole server ZIP also includes client assets and migrations; the folder limits are not a whole-archive size guarantee.

To update an already-built release in place, run `npm run release:build -- --refresh <release-timestamp>` after building the helper. This replaces its dependency folders, copies current runtime files and helper, regenerates manifests and ZIP checksums, and refreshes existing nested/outer distribution ZIPs. Do not deploy while refreshing; validation/build errors must be resolved before distribution. The outer ZIP contains only the two deployable folders, not redundant nested archive copies.

- CETFalcon-Server.zip: IIS configuration/setup, web runtime, migrations, helper installer. No Node executable or ARR/Rewrite installers.
- CETFalcon-WorkstationSync.zip: standalone LDAP/JIRA sync tooling with its own bundled Node for one authorized domain workstation; do not install on UAT. Server prerequisites do not imply Node exists on that workstation.
- CETFalcon-Users.zip: generated on the server after deployment, containing the helper installer, public certificate and fingerprint only. This is the package for normal users.

## Server

1. Back up DFM and existing attachments. Ensure Windows Server installation sources are available for the IIS role. Installing IIS may require a restart and another setup run.
2. Extract CETFalcon-Server.zip completely on DXB01-VWU-HFNA2.dibuat.ae. Right-click Install-Server.cmd, Run as administrator. Windows administrator approval is mandatory for server provisioning; it cannot be bypassed.
   Before database changes, setup checks the installed Node version (24-26) and registered IIS URL Rewrite/ARR modules, failing explicitly if missing. Node defaults to `C:\Program Files\nodejs\node.exe`. For a custom machine-wide location, run `.\Install-Server.ps1 -NodePath 'D:\Tools\Node\node.exe'` from an elevated PowerShell. The Local Service runtime identity must have read/execute access to that installation and its parent folders; do not use an administrator's private profile installation. Setup saves the absolute path in the restricted installation's `tools\node-path.txt`; startup tasks and readiness checks use it without relying on user PATH. Keep Node at that path when updating it, or rerun setup with the new path. `-ValidateOnly` still checks package integrity only, not server prerequisites.
3. Confirm DEPLOY and enter the SQL password locally. The package contains no passwords. Runtime credentials are machine-DPAPI encrypted and the install folder is restricted to Administrators, SYSTEM and the Local Service runtime identity. Use a dedicated least-privilege application SQL login for production; migration/bootstrap permissions should be temporary DBA-authorized permissions.
4. The installer sets up IIS site CETFalcon, HTTPS using a selected CA-issued certificate or the default one-year self-signed certificate, three startup/restarting Node tasks under Local Service, and HTTPS firewall access. It preserves attachments and backs up existing app/config files. IIS configuration is backed up with appcmd before changes. An unrelated/conflicting site or port is not deleted or stopped.
5. Check READY results for all three URLs. On failure, review the named task and `C:\ProgramData\CETFalcon\<environment-path>\logs\server.log`. Do not rerun the legacy application concurrently for writes.
6. Send `C:\ProgramData\CETFalcon\CETFalcon-Users.zip` to users, and give them the certificate SHA-256 fingerprint through a separate trusted channel. Private keys and SQL credentials are never in that ZIP.

Setup grants Local Service inherited Modify access to each environment's `data` and `logs` folders using a separate `icacls` invocation per folder; application code remains read/execute only. If an older package fails with `Invalid parameter "...\\logs"` followed by `Failed to set runtime writable-folder permissions`, extract a rebuilt server package and rerun setup as administrator. Do not edit the old extracted scripts (the integrity manifest will reject them), delete the installation, or broaden permissions on the whole installation root. The rerun preserves attachments and reuses the existing configuration backup/certificate behavior.

Portals and local backend ports:

- Production: https://DXB01-VWU-HFNA2.dibuat.ae/CETFalcon, loopback 5100
- Development: https://DXB01-VWU-HFNA2.dibuat.ae/CETFalconDev, loopback 5101
- UAT: https://DXB01-VWU-HFNA2.dibuat.ae/CETFalconUAT, loopback 5102

The FQDN is the canonical hostname for IIS HTTPS/SNI bindings, certificate SAN, runtime `PUBLIC_URL`, readiness checks and helper profiles. Windows still reports the computer name as `DXB01-VWU-HFNA2`; setup checks that short name separately. When upgrading a short-name deployment, rerun the rebuilt server package. Setup does not reuse the managed short-name-only certificate: it selects a matching unexpired FQDN certificate or issues a new one and exports its public certificate/fingerprint. Distribute the new user package and have IT deploy its verified trust if Current User import is blocked. Update the helper and select Production/Development/UAT again to select the FQDN profile; existing short-name profiles are retained, not automatically transferred to a different portal identity. Request device approval or a fresh first-administrator enrollment code for the new profile as appropriate. No database reset is needed.

All three use SQL Server 10.224.3.13, database DFM. **These are three application instances, not three isolated databases. Changes in any environment affect the same data.** Review deployment.json before building if separate databases are needed. Existing databases must already match migration 012; setup applies helper migration 013 only, never blindly replays baseline scripts. Empty databases are initialized without the placeholder-user seed script 011. SQL Server itself must already be installed and the DFM database must exist; setup does not install or reconfigure the remote SQL server.

SQL connections remain encrypted. This release has the explicitly approved temporary setting `sqlTrustServerCertificate: true` for SQL Server `10.224.3.13`, database `DFM`: SQL certificate identity verification is skipped, so no trusted SQL certificate installation is required to proceed. This weakens protection against server impersonation and applies to both server and workstation SQL connections and all three shared-database portals, not just UAT. Setup prints a warning. Passwords are still entered locally, never hard-coded. Have IT configure trusted SQL TLS with a matching hostname, then set this flag back to `false`, rebuild and redeploy both packages (rerun workstation setup to replace its stored connection settings). Website HTTPS, helper, LDAPS and JIRA certificate checks are unchanged.

### Website HTTPS without workstation certificate imports

Use a CA-issued certificate whose issuer chain is already trusted by user workstations. A new self-signed FQDN certificate, a renamed CER file, or a certificate for a coworker's different hostname does not establish that trust. This workflow never changes workstation trust stores or bypasses certificate validation.

#### Single-command guided setup

On the website server, extract the complete current server ZIP, then right-click **Setup-TrustedHttps.cmd** and choose **Run as administrator**. Keep its supporting PowerShell scripts, configuration and app files together; copying the CMD alone is not a deployment package.

This one entry point checks package integrity, server identity, Node and IIS prerequisites, then reuses the saved CA certificate or lets you select an existing certificate by thumbprint. If requesting a new certificate, it runs CA discovery, prompts for a CA configuration to list templates, prompts for an authorized HTTPS template **name**, and requires you to type `REQUEST`. Windows submits the request using existing LDAP/Active Directory enrollment policy, which chooses an issuing CA; the CA selected for discovery is not a forced routing override. The template controls key policy and must be suitable for this HTTPS server. No enrollment permissions, CA settings or trust stores are changed.

CA and template discovery text is displayed before the corresponding input prompt and is not mixed into the returned certificate object. If an older launcher prints only discovery headings, then asks for a CA host/name without showing the actual details, use the refreshed package: its wrapper captured the native discovery text instead of displaying it. Do not guess the CA configuration. A genuinely empty discovery response now stops with an explicit error; domain connectivity and CA visibility must then be checked.

After immediate issuance, the certificate is validated and the normal installer starts automatically. Its `DEPLOY` confirmation and locally entered SQL password are still required. Enrollment denial, missing PKI tooling, invalid/untrusted certificates and pending approval stop the workflow explicitly; it never substitutes a self-signed certificate or reports a pending request as success.

Optional command-line arguments:

```powershell
.\Setup-TrustedHttps.cmd -CertificateThumbprint 'PASTE_40_HEX_THUMBPRINT_HERE'
.\Setup-TrustedHttps.cmd -Template 'AUTHORIZED_TEMPLATE_NAME'
.\Setup-TrustedHttps.cmd -RequestThumbprint 'PENDING_REQUEST_THUMBPRINT'
```

The last command retrieves an existing request after CA approval and continues setup if issued. New enrollment is blocked when a pending request for the same hostname is found, preventing duplicate submissions on a retry. Template choice and account/CA permission cannot be guessed or bypassed; if no suitable template is available, the authorized CA administrator must provide access or issue the certificate. An already selected certificate that later becomes invalid must be renewed/replaced explicitly, not silently replaced.

#### Manual discovery and enrollment

1. On the website server, from the fully extracted server package, discover enterprise CAs using existing domain permissions:
   ```powershell
   .\Discover-CertificateAuthority.ps1
   ```
   This wraps the read-only `certutil -ADCA` command. Domain connectivity is required. From its output, identify the correct CA host and CA common name, then list its published templates and reported enrollment access:
   ```powershell
   .\Discover-CertificateAuthority.ps1 -CAConfig 'CA-HOST\CA-COMMON-NAME'
   ```
   This wraps `certutil -config ... -CATemplates`. Discovery does not request a certificate, prove enrollment permission, or prove that workstations trust that CA.
2. On the website server, open `certlm.msc` as an authorized server administrator. Under **Personal > Certificates**, choose **All Tasks > Request New Certificate**. Use the existing Active Directory enrollment policy and an authorized template intended for HTTPS servers, with **Server Authentication** EKU. Supply subject CN and DNS SAN `DXB01-VWU-HFNA2.dibuat.ae` if the template permits it. Keep the private key on this server and non-exportable. Complete the normal CA enrollment flow; do not change CA/template permissions or use device/user-authentication certificates. If no appropriate template is available, enrollment is denied, or issuance needs approval, an authorized CA administrator must provide/approve the server certificate. This script cannot grant that permission.
3. Find the enrolled certificate's **Thumbprint** in `Cert:\LocalMachine\My`, not the SHA-256 fingerprint of an exported CER. It must have a private key, cover the FQDN in SAN, be valid for more than 30 days, explicitly allow Server Authentication, and pass Windows chain validation with online revocation checking on the server.
4. Run setup from elevated PowerShell with its 40-character thumbprint:
   ```powershell
   .\Install-Server.ps1 -CertificateThumbprint 'PASTE_40_HEX_THUMBPRINT_HERE'
   ```
   Setup validates it before SQL changes or stopping backends, binds it to the existing FQDN HTTPS site, and **does not import the leaf certificate into Trusted Root**. Selection is saved in the restricted `tools\portal-certificate-thumbprint.txt`; subsequent normal setup runs reuse and revalidate it. Renew by enrolling the replacement and rerunning with its new thumbprint. Invalid, missing, expired or untrusted selected certificates stop setup; there is no silent self-signed fallback. Deploy the refreshed package rather than editing its manifest-covered scripts.
5. On an actual user workstation, open the FQDN portal in Edge/Chrome and choose **Validate portal URL and certificate trust** in the helper. If both pass normal validation, skip the helper's Import certificate action. The public leaf certificate in the user package is informational, not a root to install. Server-side trust alone does not prove workstation trust; a remaining trust/revocation error needs its actual CA-chain/network issue resolved.

### Existing database baseline errors

An error saying the existing database does not match migration 012 occurs **after SQL connected successfully**. It is not a SQL certificate failure, and installing a certificate on SQL Server will not fix that schema check. The installer now lists each failed requirement instead of labelling all failures as migration 012:

- `dbo.Users`, `dbo.AuditLog`, or `dbo.Users.DirectoryAccount`: core schema from 001 is missing or not visible to the setup login. Have the DBA inspect the database and metadata permissions; **do not replay 001 on an existing database**.
- `dbo.JiraIssues.Labels`: ask the DBA to review `database\007_Jira_Additional_Fields.sql`.
- `dbo.sp_SaveBudgetLine` missing or lacking the pending-approval workflow: ask the DBA to review `database\012_Budget_Lines_Before_Approval.sql`. This script creates/alters the procedure; it does not drop tables or delete existing data. The DBA must confirm its referenced tables and columns already exist.
- Procedure definition cannot be inspected: the DBA must check `VIEW DEFINITION` permission or whether the procedure is encrypted before assuming migration 012 is missing.

After the DBA resolves the listed requirements, rerun setup; it applies helper migration 013. Do not run all old scripts or placeholder-user seed 011 to bypass the check.

Run the installer from a fully extracted, freshly built server ZIP, not directly from the source `deployment` folder. The source folder is a template and does not contain the packaged app, database folder or integrity manifest. Rebuild with `npm run release:build`; do not copy edited scripts into an old extracted package because the manifest will reject them.

## Backend remains running during redeployment

Older scheduled tasks run a PowerShell launcher that starts Node. Stopping
the scheduled task can leave the Node child listening on 5100/5101/5102.
The installer now checks each configured listener's executable, command
line and creation time before stopping the corresponding task. If the
verified Node child remains after the graceful wait, it terminates only
that exact PID, rechecks process identity to avoid PID reuse, and confirms
that the port is released before replacing application files.

New runtimes use an absolute environment-specific server entry point.
Legacy relative-entry processes must match their still-live configured
launcher, or (for an existing orphan) the configured loopback `/api/info`
identity and public URL. These checks use loopback HTTP only and do not
disable public HTTPS validation. A foreign executable/entry point,
unverifiable portal identity or replacement listener stops deployment
explicitly. Setup never kills every node.exe process or unrelated ports.
No manual stop command is needed for a successfully verified backend.

## Workstation Sync And First Administrator

Extract CETFalcon-WorkstationSync.zip on a restricted authorized workstation that can reach LDAPS, JIRA, and SQL Server 10.224.3.13. Double-click Setup-Workstation.cmd as the normal user. Enter SQL, LDAP and optional JIRA credentials locally; they are protected with Current User DPAPI under LocalAppData\CETFalcon-Sync. The workstation requires .NET Framework 4.5 or later for the existing JIRA collector. No administrator rights or npm installation is required. It must have a trusted LDAPS/JIRA certificate chain; the collector does not bypass TLS validation.

Setup runs sync once, and optionally schedules it at logon and 09:00 while that user is logged in. The workstation must be powered on and connected. Subsequent runs use Run-Sync.cmd. Raw JIRA responses/logs can contain confidential business data; retain this folder only under the authorized user's restricted profile. Nothing schedules LDAP or JIRA on the UAT server.

After LDAP sync, setup offers first-administrator bootstrap. This is a DBA-authorized operation: confirm the synchronized administrator email, explicitly approve the Master role grant, and use the displayed one-time code in that administrator's DFM Helper. Subsequent users request device approval in the helper and the Master approves them in DFM. Never share workstation sync credentials or packages with ordinary users.

If bootstrap was skipped, run **Bootstrap-Administrator.cmd** from this
freshly extracted workstation package as the **same Windows user who
configured sync**. It reuses that user's protected sync configuration,
does not rerun LDAP/JIRA, prompts for the synchronized initial administrator's
email and explicit `GRANT`, records the role grant in the audit log, and
issues a one-day, single-use enrollment code. The SQL account must already
have DBA-authorized role-management/bootstrap permissions.
The selected administrator opens the helper under their own Windows account,
expands **Portal and enrollment settings > One-time enrollment code**, enters
the code, and chooses **Enroll with code**. They do not request approval
from another administrator. The code is bound to that synchronized user.
Windows local administrator membership, being the first visitor, and
being the first device requester do not grant DFM roles.

For a DBA-run SQL-only bootstrap, open
`Bootstrap-DfmAdministrator.sql` in SSMS against the intended DFM server.
It is preconfigured for `dib\hariprasath.p` and optional computer audit
hint `AN07itl076` (set the hint to `NULL` to omit it). The account must
already exist exactly once from directory sync and be active; the script
does not invent an email, create a user, or reactivate disabled users.
It atomically grants the existing Master application role, replaces this
user's unused enrollment codes, stores only the new code's SHA-256 hash,
and records the SQL operator and account in the audit log. The result
contains the new single-use, 24-hour enrollment code. Keep that result
private and enroll under the matching Windows account, not through
Request administrator approval. Existing roles/devices are retained.
The PC hint is informational; the helper reports the actual PC name.
This is an explicitly run administration script, **not a migration** and
not something server installation automatically executes. It does not
grant SQL Server/Windows administrator rights or establish HTTPS trust.

## Certificates And Email

The helper offers Import certificate (Current User Trusted Root, no elevation) and Validate URL. It checks SAN hostname, self-signature and expiry before prompting with the SHA-256 fingerprint. Only trust the administrator-supplied public certificate after independent fingerprint confirmation. User-level certificate import may still be prohibited by domain policy; IT must then distribute trust or use an enterprise-issued certificate. Browsers may need restarting and Local Network Access approval for the helper bridge. No blanket certificate-error callback or TLS-verification bypass is installed.

For the self-signed deployment, an authorized PC administrator can instead
perform a **one-time machine-wide trust import**:

1. Distribute the complete generated `CETFalcon-Users.zip` through an approved
   channel and fully extract it. It includes `Trust-Certificate.cmd`,
   the helper executable, public `CETFalcon.cer`, and fingerprint details.
2. On **each client PC** (not just the server), right-click
   **Trust-Certificate.cmd > Run as administrator**. Select the public CER,
   compare the displayed SHA-256 fingerprint through a separate trusted
   channel, and explicitly confirm trust for **all users of this PC**.
3. This uses the same certificate format, SAN, self-signature and validity
   checks as the helper, then adds only the selected public certificate
   to `LocalMachine\Root`. It does not import private keys, change store
   permissions, download and automatically trust an unknown certificate,
   or bypass TLS validation.
4. The utility validates the portal's HTTPS `/api/info` response using normal
   Windows trust. A post-import connection failure is explicitly reported:
   the import may have completed, but the handshake is not confirmed.
5. Restart the helper/browser as the **normal Windows user** and validate
   the FQDN portal there. This check is still necessary: per-user policy,
   browser-specific trust and notification settings may differ from the
   elevated administrator's context.

The command defaults to the helper's embedded Production FQDN. An explicit
portal can be supplied as `Trust-Certificate.cmd "https://server/portal"`.
If machine-wide import is also denied, stop and use approved IT trust
distribution; the utility does not override Windows policy. Certificate
renewal requires independently verifying and trusting the replacement.

### When users cannot elevate

Ordinary helper operation never requires elevation. Displaying the current
Windows account does not prove an authenticated session or make a rejected
server certificate trusted. TLS validation must succeed before enrollment,
browser approval or authenticated notifications can reach the portal.
TLS connection failures do not expire or remove an enrolled device.

If Current User certificate import is permitted, an ordinary user can
verify and import the administrator-provided self-signed public certificate.
If that write is denied and users cannot elevate, a device/domain
administrator must distribute approved trust centrally (for example,
Group Policy/MDM) or the website must use a certificate whose issuer is
already trusted. This does not require commands run as administrator by
end users. If neither trust distribution nor changing to an already-trusted
issuer is available, a Windows-trusted self-signed deployment is blocked.
Application code and matching profile names cannot resolve that external
trust restriction. A helper-only exception would not establish trust in
the external browser; no blanket certificate exception is installed.

No SMTP server, sender or recipient list was supplied, so setup prepares a distribution ZIP but does not send unsolicited email. To send the public certificate and instructions through an approved SMTP server, run Send-Certificate.ps1 on the server with -SmtpServer, -From and -To. SMTP TLS is required and credentials are entered locally. Send the installer ZIP via your approved file-sharing channel rather than attaching an executable to email.

## Rollback And Verification

Stop CETFalcon-Prod, CETFalcon-Dev and CETFalcon-UAT tasks before restoring app/runtime.bin backups. Restore the named IIS backup with appcmd only after assessing its server-wide effect. Application rollback does not roll back SQL migrations; restore SQL only through the DBA's backup/recovery plan. No automatic destructive rollback is attempted.

Build-time checks cover package manifests, script syntax, Node tests and helper packaging. Run Install-Server.ps1 -ValidateOnly on an extracted package to check hashes without modifying the machine. Actual IIS provisioning, certificate trust, SQL permissions, workstation network access and end-to-end device approval must be accepted on the target infrastructure. A self-signed certificate is a private deployment trust mechanism, not a substitute for enterprise PKI.

The native helper requires the full Windows .NET Framework 4.5+ with Windows Forms instead of shipping Chromium or Node; use patched 4.8/4.8.1 in production. When upgrading from Electron, quit the old helper from its tray menu, disable its old startup entry, and uninstall the Electron version before installing the native helper. Preserve `%APPDATA%\DFM Helper`; existing per-portal enrollment profiles are retained. Native setup installs only for the current user without elevation. Interactive install/update/uninstall, certificate-store changes, browser permissions, and real IIS/AD/SQL enrollment still need target-workstation acceptance testing; local native self-tests do not replace that. Code signing requires your organization's signing certificate; the build does not manufacture a trusted publisher identity.