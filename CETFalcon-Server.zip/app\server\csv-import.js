import {parse} from 'csv-parse/sync';

function normalize(value) {
  return String(value || '').replace(/[^a-z0-9]/gi, '').toLowerCase();
}

function get(row, name, fallback = '') {
  const value = row[name];
  return value === undefined || value === null || String(value).trim() === '' ? fallback : String(value).trim();
}

function decimal(row, name, fallback = 0) {
  const value = Number(get(row, name).replaceAll(',', ''));
  return Number.isFinite(value) ? value : fallback;
}

function integer(row, name, fallback) {
  const value = Number.parseInt(get(row, name), 10);
  return Number.isInteger(value) ? value : fallback;
}

function requireColumns(columns, ...required) {
  const missing = required.filter(name => !columns.includes(name));
  if (missing.length) {
    const error = new Error(`Missing CSV columns: ${missing.join(', ')}`);
    error.status = 400;
    throw error;
  }
}

function csvRows(text) {
  const records = parse(String(text || ''), {
    bom: true,
    columns: headers => headers.map(normalize),
    skip_empty_lines: true,
    relax_column_count: true,
    trim: true
  });
  if (!records.length) {
    const error = new Error('The CSV has no data rows.');
    error.status = 400;
    throw error;
  }
  return records;
}

async function importPets(database, projectId, rows, columns, userEmail) {
  requireColumns(columns, 'petreference', 'vendor', 'unitprice');
  const pets = new Map();
  let imported = 0;

  for (const row of rows) {
    const reference = get(row, 'petreference');
    if (!reference) throw Object.assign(new Error('PET reference is required for every PET import row.'), {status: 400});
    const units = decimal(row, 'units', 1);
    const unitPrice = decimal(row, 'unitprice');
    const foreignAmount = decimal(row, 'fcyamount', units * unitPrice);
    const aedAmount = decimal(row, 'aedamount', foreignAmount);
    const contingency = decimal(row, 'contingency');
    let petId = pets.get(reference.toLowerCase());

    if (!petId) {
      const existing = await database.query(
        "SELECT PetId FROM dbo.PETRequests WHERE ProjectId=@project AND Code=@code AND Status IN ('Draft','Pending Review','Pending Approval')",
        {project: projectId, code: reference}
      );
      const saved = await database.query(
        'EXEC dbo.sp_SavePet @pet,@project,@code,@amount,@currency,@user',
        {
          pet: existing[0]?.petId ?? null,
          project: projectId,
          code: reference,
          amount: aedAmount * (1 + contingency / 100),
          currency: get(row, 'currency', 'AED'),
          user: userEmail
        }
      );
      petId = saved[0]?.petId;
      if (!petId) throw new Error('The PET import did not return a PET identifier.');
      pets.set(reference.toLowerCase(), petId);
    }

    await database.query(
      'EXEC dbo.sp_SaveSpendItem @id,@pet,@head,@topic,@vendor,@costType,@unitType,@units,@unitPrice,@currency,@foreign,@aed,@contingency,@gl',
      {
        id: null,
        pet: petId,
        head: get(row, 'head') || null,
        topic: get(row, 'topic') || null,
        vendor: get(row, 'vendor'),
        costType: get(row, 'costtype') || null,
        unitType: get(row, 'unittype') || null,
        units,
        unitPrice,
        currency: get(row, 'currency', 'AED'),
        foreign: foreignAmount,
        aed: aedAmount,
        contingency,
        gl: get(row, 'glnumber') || null
      }
    );
    imported++;
  }
  return imported;
}

async function importBudgetLines(database, petId, rows, columns, userEmail) {
  requireColumns(columns, 'vendor', 'cost', 'currency');
  for (const row of rows) {
    await database.query(
      'EXEC dbo.sp_SaveBudgetLine @id,@pet,@vendor,@justification,@cost,@currency,@gl,@petRef,@camId,@camStatus,@camComments,@lpoRequest,@lpoStatus,@lpoComments,@user',
      {
        id: null,
        pet: petId,
        vendor: get(row, 'vendor'),
        justification: get(row, 'justification') || null,
        cost: decimal(row, 'cost'),
        currency: get(row, 'currency', 'AED'),
        gl: get(row, 'gl') || null,
        petRef: get(row, 'petreference') || null,
        camId: get(row, 'camid') || null,
        camStatus: get(row, 'camstatus') || null,
        camComments: get(row, 'camcomments') || null,
        lpoRequest: get(row, 'lporequest') || null,
        lpoStatus: get(row, 'lpostatus') || null,
        lpoComments: get(row, 'lpocomments') || null,
        user: userEmail
      }
    );
  }
  return rows.length;
}

async function importInvoices(database, defaultBudgetLineId, rows, columns, userEmail) {
  requireColumns(columns, 'vendorname', 'invoicenumber', 'invoiceamount');
  for (const row of rows) {
    await database.query(
      'EXEC dbo.sp_SaveInvoice @id,@line,@vendor,@justification,@gl,@number,@amount,@status,@paymentDate,@user',
      {
        id: null,
        line: integer(row, 'budgetlineid', defaultBudgetLineId),
        vendor: get(row, 'vendorname'),
        justification: get(row, 'justification') || null,
        gl: get(row, 'glnumber') || null,
        number: get(row, 'invoicenumber'),
        amount: decimal(row, 'invoiceamount'),
        status: get(row, 'invoicestatus', 'Raised'),
        paymentDate: get(row, 'paymentdate') || null,
        user: userEmail
      }
    );
  }
  return rows.length;
}

export async function importCsv(database, kind, parentId, text, userEmail) {
  const firstLine = String(text || '').replace(/^\uFEFF/, '').split(/\r?\n/, 1)[0];
  const columns = parse(firstLine, {relax_column_count: true})[0]?.map(normalize) || [];
  const rows = csvRows(text);
  if (kind === 'pet') return importPets(database, parentId, rows, columns, userEmail);
  if (kind === 'budget') return importBudgetLines(database, parentId, rows, columns, userEmail);
  if (kind === 'invoice') return importInvoices(database, parentId, rows, columns, userEmail);
  throw Object.assign(new Error('Unknown CSV import kind.'), {status: 400});
}