import sql from 'mssql';

const SESSION_OPTIONS = `
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
`;

function camelCaseKey(key) {
  return key ? key.charAt(0).toLowerCase() + key.slice(1) : key;
}

export function normalizeRow(row) {
  return Object.fromEntries(Object.entries(row).map(([key, value]) => [camelCaseKey(key), value]));
}

function bindParameters(request, parameters) {
  for (const [name, value] of Object.entries(parameters)) {
    request.input(name.replace(/^@/, ''), value ?? null);
  }
}

export function createDatabase(connectionString) {
  if (!connectionString) throw new Error('SQL_CONNECTION_STRING is required.');
  const pool = new sql.ConnectionPool(connectionString);
  let connection;

  async function getPool() {
    connection ||= pool.connect();
    return connection;
  }

  async function run(statement, parameters = {}) {
    const request = (await getPool()).request();
    bindParameters(request, parameters);
    return request.query(SESSION_OPTIONS + statement);
  }

  return {
    async query(statement, parameters) {
      const result = await run(statement, parameters);
      return (result.recordset || []).map(normalizeRow);
    },
    async queryMultiple(statement, parameters) {
      const result = await run(statement, parameters);
      return (result.recordsets || []).map(recordset => recordset.map(normalizeRow));
    },
    async execute(statement, parameters) {
      await run(statement, parameters);
    },
    async close() {
      if (connection) await (await connection).close();
    }
  };
}