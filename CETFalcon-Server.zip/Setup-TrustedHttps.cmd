@echo off
setlocal
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -File "%~dp0Setup-TrustedHttps.ps1" %*
set "result=%errorlevel%"
if not "%result%"=="0" echo Trusted HTTPS setup did not complete. Review the error above before retrying.
pause
exit /b %result%
