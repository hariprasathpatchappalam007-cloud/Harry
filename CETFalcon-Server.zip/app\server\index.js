import fs from 'node:fs';
import {createApp} from './app.js';
import {loadConfig} from './config.js';
import {createDatabase} from './db.js';
import {cleanupHelperAuthentication} from './helper-routes.js';

if (fs.existsSync('.env')) process.loadEnvFile('.env');
const config = loadConfig();
const database = createDatabase(config.sqlConnectionString);
const app = createApp({database, config});
const server = app.listen(config.port, config.host, () => {
  console.log(`DFM Node is listening at ${config.publicUrl}.`);
});
const cleanupTimer = setInterval(() => cleanupHelperAuthentication(database).catch(error => console.error('Helper authentication cleanup failed:', error.message)), 60000);
cleanupTimer.unref();

let stopping = false;
async function shutdown() {
  if (stopping) return;
  stopping = true;
  clearInterval(cleanupTimer);
  const force = setTimeout(() => server.closeAllConnections(), 10000);
  force.unref();
  server.close(async () => {
    clearTimeout(force);
    await database.close();
    process.exit(0);
  });
}

process.once('SIGINT', shutdown);
process.once('SIGTERM', shutdown);