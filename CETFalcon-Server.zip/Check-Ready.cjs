const {setTimeout: delay} = require('node:timers/promises');

async function check() {
  const [base, publicUrl] = process.argv.slice(2);
  for (let attempt = 0; attempt < 20; attempt++) {
    try {
      const response = await fetch(`${base}/api/info`, {signal: AbortSignal.timeout(3000)});
      const info = await response.json();
      if (!response.ok || info.authentication !== 'dfm-helper' || info.publicUrl !== publicUrl || !info.installerAvailable) {
        throw new Error('Unexpected portal configuration or missing helper installer.');
      }
      const auth = await fetch(`${base}/api/auth/me`, {signal: AbortSignal.timeout(3000)});
      if (auth.status !== 401) throw new Error('Anonymous API access was not rejected.');
      return;
    } catch (error) {
      if (attempt === 19) throw error;
      await delay(1000);
    }
  }
}
check().catch(error => { console.error(error.message); process.exitCode = 1; });