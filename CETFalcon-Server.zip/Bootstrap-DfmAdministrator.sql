USE [DFM];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;

DECLARE @WindowsAccount nvarchar(200) = N'dib\hariprasath.p';
DECLARE @ComputerName nvarchar(100) = N'AN07itl076'; -- Optional audit hint only; NULL is allowed.

IF @@TRANCOUNT <> 0
    THROW 50127, 'Run administrator bootstrap outside an existing transaction.', 1;

IF OBJECT_ID(N'dbo.DfmHelperEnrollment', N'U') IS NULL
    THROW 50128, 'Helper authentication schema is missing. Have the DBA review migration 013 first.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @UserId int, @Email nvarchar(254), @IsActive bit, @Matches int, @RoleId int;
    SELECT @Matches = COUNT(*)
    FROM dbo.Users WITH (UPDLOCK, HOLDLOCK)
    WHERE LOWER(LTRIM(RTRIM(DirectoryAccount))) = LOWER(@WindowsAccount);

    IF @Matches <> 1
        THROW 50129, 'Expected exactly one synchronized dib\hariprasath.p account. Run directory sync or resolve duplicate directory accounts first. No user will be invented.', 1;

    SELECT @UserId = UserId, @Email = Email, @IsActive = IsActive
    FROM dbo.Users
    WHERE LOWER(LTRIM(RTRIM(DirectoryAccount))) = LOWER(@WindowsAccount);

    IF @IsActive <> 1
        THROW 50130, 'The synchronized administrator account is disabled. Review its directory/application status first.', 1;

    SELECT @RoleId = RoleId FROM dbo.Roles WHERE Name = N'Master';
    IF @RoleId IS NULL
        THROW 50126, 'The DFM Master role is missing. Have the DBA review the application roles.', 1;

    DECLARE @RandomBytes varbinary(32) = CRYPT_GEN_RANDOM(32);
    DECLARE @EnrollmentCode varchar(43) = REPLACE(REPLACE(REPLACE(
        CAST(N'' AS xml).value('xs:base64Binary(sql:variable("@RandomBytes"))', 'varchar(44)'),
        '+', '-'), '/', '_'), '=', '');
    IF @EnrollmentCode IS NULL OR DATALENGTH(@EnrollmentCode) <> 43
        THROW 50131, 'Enrollment-code generation failed. No administrator change was committed.', 1;

    DECLARE @ExpiresUtc datetime2 = DATEADD(DAY, 1, SYSUTCDATETIME());
    IF NOT EXISTS (
        SELECT 1 FROM dbo.UserRoles WITH (UPDLOCK, HOLDLOCK)
        WHERE UserId = @UserId AND RoleId = @RoleId
    )
        INSERT dbo.UserRoles(UserId, RoleId) VALUES(@UserId, @RoleId);

    UPDATE dbo.DfmHelperEnrollment
    SET Used = 1
    WHERE UserId = @UserId AND Used = 0;

    -- varchar is intentional: ASCII token bytes must match Node's SHA-256 UTF-8 hash.
    INSERT dbo.DfmHelperEnrollment(CodeHash, UserId, ExpiresUtc)
    VALUES(HASHBYTES('SHA2_256', @EnrollmentCode), @UserId, @ExpiresUtc);

    DECLARE @Detail nvarchar(max) = CONCAT(
        N'Operator=', ORIGINAL_LOGIN(), N'; WindowsAccount=', @WindowsAccount,
        N'; ComputerHint=', COALESCE(NULLIF(@ComputerName, N''), N'(not specified)'),
        N'; ExpiresUtc=', CONVERT(nvarchar(33), @ExpiresUtc, 126), N'Z');
    INSERT dbo.AuditLog(EntityType, EntityId, ActionName, UserEmail, Detail)
    VALUES(N'HelperDevice', NULL, N'bootstrap.master.grant', @Email, @Detail),
          (N'HelperDevice', NULL, N'device.bootstrap-enrollment.issue', @Email, @Detail);

    COMMIT TRANSACTION;

    SELECT @UserId AS UserId, @WindowsAccount AS WindowsAccount, @Email AS Email,
           N'Master' AS DfmRole, @ComputerName AS ComputerHint,
           @EnrollmentCode AS OneTimeEnrollmentCode, @ExpiresUtc AS ExpiresUtc;
    PRINT 'Keep the enrollment code private. It expires in 24 hours and works only once for this synchronized Windows account.';
    PRINT 'Run DFM Helper normally as dib\hariprasath.p. Open Portal and enrollment settings > One-time enrollment code, then Enroll with code.';
    PRINT 'No existing administrator approval is needed. The PC hint is not a device restriction; the helper supplies its actual PC name.';
    PRINT 'This grants a DFM application role only. It does not create a SQL/Windows login or resolve HTTPS certificate trust.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
