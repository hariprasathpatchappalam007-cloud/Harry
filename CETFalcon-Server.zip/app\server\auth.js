import {parseWindowsIdentity} from './identity.js';
import {cookieValue, secretHash} from './helper-crypto.js';

const USER_LOOKUP = `
SELECT u.UserId,u.Email,u.DisplayName,u.DirectoryAccount,
 STUFF((SELECT ',' + r.Name FROM dbo.UserRoles ur JOIN dbo.Roles r ON r.RoleId=ur.RoleId WHERE ur.UserId=u.UserId FOR XML PATH('')),1,1,'') Roles
FROM dbo.Users u
WHERE u.IsActive=1 AND (
 LOWER(ISNULL(u.DirectoryAccount,''))=LOWER(@raw)
 OR (@upn<>'' AND LOWER(u.Email)=LOWER(@upn))
 OR LOWER(RIGHT(ISNULL(u.DirectoryAccount,''),LEN(@username)+1))=LOWER(N'\\'+@username)
);`;

export function publicUser(row) {
  return {
    userId: row.userId,
    email: row.email,
    displayName: row.displayName,
    directoryAccount: row.directoryAccount,
    roles: String(row.roles || '').split(',').filter(Boolean)
  };
}

export async function findWindowsUser(database, identityValue) {
  const identity = parseWindowsIdentity(identityValue);
  if (!identity) return null;
  const rows = await database.query(USER_LOOKUP, identity);
  if (!rows.length) return null;

  const raw = identity.raw.toLowerCase();
  const exact = rows.filter(row => String(row.directoryAccount || '').toLowerCase() === raw);
  if (exact.length === 1) return publicUser(exact[0]);

  const upn = rows.filter(row => identity.upn && String(row.email || '').toLowerCase() === identity.upn);
  if (upn.length === 1) return publicUser(upn[0]);

  return rows.length === 1 ? publicUser(rows[0]) : null;
}

export function hasRole(user, requiredRole) {
  const required = String(requiredRole || '').toLowerCase();
  const roles = new Set((user?.roles || []).map(role => String(role).toLowerCase()));
  if (roles.has(required)) return true;
  return (required === 'master' && roles.has('admin')) || (required === 'admin' && roles.has('master'));
}

const SESSION_LOOKUP = `
SELECT u.UserId,u.Email,u.DisplayName,u.DirectoryAccount,d.DeviceId,d.PcName,
 STUFF((SELECT ',' + r.Name FROM dbo.UserRoles ur JOIN dbo.Roles r ON r.RoleId=ur.RoleId WHERE ur.UserId=u.UserId FOR XML PATH('')),1,1,'') Roles
FROM dbo.DfmHelperSessions s
JOIN dbo.DfmHelperDevices d ON d.DeviceId=s.DeviceId AND d.UserId=s.UserId
JOIN dbo.Users u ON u.UserId=s.UserId
WHERE s.SessionHash=@sessionHash AND s.ExpiresUtc>SYSUTCDATETIME() AND d.Revoked=0 AND u.IsActive=1;`;

export function createAuthentication({database, sessionCookieName = 'dfm_session', developmentIdentity = ''}) {
  async function authenticate(request, response, next) {
    try {
      let user;
      if (developmentIdentity) {
        user = await findWindowsUser(database, developmentIdentity);
        if (user) user.authentication = 'development';
      } else {
        const session = cookieValue(request, sessionCookieName);
        const rows = session ? await database.query(SESSION_LOOKUP, {sessionHash: secretHash(session)}) : [];
        if (rows.length === 1) {
          user = {...publicUser(rows[0]), deviceId: rows[0].deviceId, pcName: rows[0].pcName, authentication: 'helper'};
        }
      }
      if (!user) return response.status(401).json({message: 'Connect DFM Helper to continue.', error: 'Connect DFM Helper to continue.'});
      request.user = user;
      next();
    } catch (error) {
      next(error);
    }
  }

  function requireRoles(...roles) {
    return (request, response, next) => {
      if (!roles.some(role => hasRole(request.user, role))) {
        return response.status(403).json({message: 'This role cannot perform the action.'});
      }
      next();
    };
  }

  return {authenticate, requireRoles};
}