export function asyncRoute(handler) {
  return (request, response, next) => Promise.resolve(handler(request, response, next)).catch(next);
}

export function notFound(request, response) {
  response.status(404).json({message: 'API endpoint not found.'});
}

export function handleError(error, request, response, next) {
  if (response.headersSent) return next(error);
  const sqlNumber = Number(error.number || error.originalError?.info?.number);
  const isExpectedSqlError = sqlNumber >= 50000 || sqlNumber === 2601 || sqlNumber === 2627;
  const status = error.status || (error.name === 'MulterError' || isExpectedSqlError ? 400 : 500);
  const message = status < 500 ? error.message : 'The request could not be completed. Contact the DFM administrator.';
  if (status >= 500) console.error(error);
  response.status(status).json({message, error: message});
}