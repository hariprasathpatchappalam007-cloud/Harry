param([Parameter(Mandatory=$true)][string]$ApplicationRoot)
. "$PSScriptRoot\Common.ps1"
$settings = Read-ProtectedJson (Join-Path $ApplicationRoot 'runtime.bin') -Machine
foreach ($property in $settings.PSObject.Properties) {
    [Environment]::SetEnvironmentVariable($property.Name, [string]$property.Value, 'Process')
}
Set-Location (Join-Path $ApplicationRoot 'app')
$nodePath = (Get-Content -LiteralPath "$PSScriptRoot\node-path.txt" -Raw).Trim()
if (!$nodePath) { throw 'Configured server Node path is empty. Rerun Install-Server.ps1.' }
$node = Resolve-ServerNode $nodePath
& $node (Join-Path $ApplicationRoot 'app\server\index.js') *>> (Join-Path $ApplicationRoot 'logs\server.log')
exit $LASTEXITCODE