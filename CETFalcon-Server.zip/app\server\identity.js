const WINDOWS_IDENTITY_PATTERN = /^[^\u0000-\u001f\u007f]{1,256}$/;

export function parseWindowsIdentity(value) {
  const raw = String(value || '').trim();
  if (!WINDOWS_IDENTITY_PATTERN.test(raw)) return null;

  const slash = raw.indexOf('\\');
  const at = raw.lastIndexOf('@');
  let domain = '';
  let username = raw;
  let upn = '';

  if (slash > 0 && slash < raw.length - 1) {
    domain = raw.slice(0, slash);
    username = raw.slice(slash + 1);
  } else if (at > 0 && at < raw.length - 1) {
    username = raw.slice(0, at);
    domain = raw.slice(at + 1);
    upn = raw;
  }

  if (!username || username.includes('\\') || username.includes('@')) return null;
  if (/^(anonymous logon|iusr|iis apppool)$/i.test(username)) return null;

  return {
    raw,
    username: username.toLowerCase(),
    domain: domain.toLowerCase(),
    upn: upn.toLowerCase()
  };
}