import {createHash, randomBytes} from 'node:crypto';

export function token() {
  return randomBytes(32).toString('base64url');
}

export function installationSecret() {
  return randomBytes(32).toString('hex');
}

export function secretHash(value) {
  return createHash('sha256').update(String(value || '')).digest();
}

export function cookieValue(request, name) {
  const source = String(request.headers.cookie || '');
  for (const part of source.split(';')) {
    const separator = part.indexOf('=');
    if (separator < 0 || part.slice(0, separator).trim() !== name) continue;
    try {
      return decodeURIComponent(part.slice(separator + 1).trim());
    } catch {
      return '';
    }
  }
  return '';
}