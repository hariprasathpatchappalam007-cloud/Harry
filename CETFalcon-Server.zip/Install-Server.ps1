param([switch]$ValidateOnly, [string]$NodePath, [string]$CertificateThumbprint)
. "$PSScriptRoot\Common.ps1"
$config = Get-Content "$PSScriptRoot\deployment.json" -Raw | ConvertFrom-Json
Test-PackageManifest $PSScriptRoot
if ($ValidateOnly) { Write-Host 'Package integrity validated. No changes made.'; return }
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Server setup requires administrator rights. Right-click Install-Server.cmd and choose Run as administrator. Workstation certificate import does not require elevation.'
}
Assert-DeploymentServer $env:COMPUTERNAME $config.serverName
if (!(Get-Command Install-WindowsFeature -ErrorAction SilentlyContinue)) { throw 'This installer requires Windows Server with ServerManager.' }
$node = Resolve-ServerNode $NodePath
Import-Module WebAdministration
Test-IisPrerequisites
$certificate = $null
$certificateSelectionPath = Join-Path $config.installRoot 'tools\portal-certificate-thumbprint.txt'
if (!$CertificateThumbprint -and (Test-Path -LiteralPath $certificateSelectionPath)) {
    $CertificateThumbprint = (Get-Content -LiteralPath $certificateSelectionPath -Raw).Trim()
    if (!$CertificateThumbprint) { throw "Saved CA certificate selection is empty: $certificateSelectionPath. Supply -CertificateThumbprint with the enrolled server certificate." }
}
if ($CertificateThumbprint) {
    $certificate = Get-TrustedPortalCertificate $CertificateThumbprint $config.serverName
    Write-Host "Using CA-issued HTTPS certificate: $($certificate.Subject), thumbprint $($certificate.Thumbprint). Verify its CA is also trusted by user workstations."
}
Write-Warning 'Prod, Dev, and UAT share the configured DFM database. Back up SQL and attachments before continuing.'
if ((Read-Host 'Type DEPLOY to install/update all three environments') -cne 'DEPLOY') { throw 'Deployment cancelled.' }
$password = Read-LocalSecret 'SQL password (entered locally, not saved in the package)'
$connectionString = Get-SqlConnectionString $config $password
$password = $null
$connection = New-Object Data.SqlClient.SqlConnection($connectionString)
$sqlConnected = $false
try {
    $connection.Open()
    $sqlConnected = $true
    $tables = Invoke-Sql $connection 'SELECT COUNT(*) FROM sys.tables WHERE is_ms_shipped=0' -Scalar
    if ($tables -eq 0) {
        foreach ($migration in (Get-ChildItem "$PSScriptRoot\database\*.sql" | Sort-Object Name)) {
            if ($migration.Name -like '011_*') { continue }
            foreach ($batch in ([regex]::Split([IO.File]::ReadAllText($migration.FullName), '(?im)^\s*GO\s*\r?$'))) {
                if ($batch.Trim()) { Invoke-Sql $connection $batch }
            }
            Write-Host "Applied $($migration.Name)"
        }
    } else {
        Assert-SqlDeploymentBaseline $connection
        foreach ($batch in ([regex]::Split([IO.File]::ReadAllText("$PSScriptRoot\database\013_Helper_Authentication.sql"), '(?im)^\s*GO\s*\r?$'))) {
            if ($batch.Trim()) { Invoke-Sql $connection $batch }
        }
    }
} catch {
    if ($sqlConnected) { throw "SQL schema preflight/migration failed after a successful connection. $($_.Exception.Message)" }
    throw "SQL connection failed. Verify login permissions, database availability and SQL TLS settings. $($_.Exception.Message)"
}
finally { $connection.Dispose() }

$featureResult = Install-WindowsFeature Web-Server,Web-Mgmt-Tools -IncludeManagementTools
if (!$featureResult.Success -or $featureResult.RestartNeeded -eq 'Yes') { throw 'IIS feature installation requires attention/restart. Restart the server and run setup again.' }
Import-Module WebAdministration
Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter 'system.webServer/proxy' -Name enabled -Value $true
$root = $config.installRoot
$null = New-Item $root -ItemType Directory -Force
& icacls.exe $root /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-19:(OI)(CI)RX' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Failed to restrict installation folder permissions.' }
$null = New-Item "$root\tools","$root\iis","$root\user-distribution" -ItemType Directory -Force
foreach ($environment in $config.environments) {
    $taskName = "CETFalcon-$($environment.name)"
    $existingTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($existingTask) {
        $processes = @(Get-NetTCPConnection -LocalPort $environment.port -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
        Stop-ScheduledTask -TaskName $taskName
        foreach ($processId in $processes) {
            $process = Get-Process -Id $processId -ErrorAction SilentlyContinue
            if ($process) {
                Wait-Process -Id $processId -Timeout 20 -ErrorAction SilentlyContinue
                if (Get-Process -Id $processId -ErrorAction SilentlyContinue) { throw "Backend $taskName has not stopped. Rerun setup after it stops." }
            }
        }
    }
}
$node | Set-Content -LiteralPath "$root\tools\node-path.txt" -Encoding UTF8
Copy-Item "$PSScriptRoot\Common.ps1","$PSScriptRoot\Start-Runtime.ps1" "$root\tools" -Force
$appcmd = "$env:windir\System32\inetsrv\appcmd.exe"
$backupName = "CETFalcon-$(Get-Date -Format yyyyMMdd-HHmmss)"
& $appcmd add backup $backupName
if ($LASTEXITCODE -ne 0) { throw 'IIS configuration backup failed.' }

if (!$certificate) {
    $certificate = Get-ChildItem Cert:\LocalMachine\My | Where-Object {
        Test-ManagedPortalCertificate $_ $config.serverName
    } | Sort-Object NotAfter -Descending | Select-Object -First 1
    if (!$certificate) {
        $certificate = New-SelfSignedCertificate -DnsName $config.serverName -CertStoreLocation Cert:\LocalMachine\My -FriendlyName 'CETFalcon portal TLS' -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -KeyExportPolicy NonExportable -NotAfter (Get-Date).AddYears(1)
    }
}
$cerPath = "$root\user-distribution\CETFalcon.cer"
$null = Export-Certificate -Cert $certificate -FilePath $cerPath
if (!$CertificateThumbprint) {
    $null = Import-Certificate -FilePath $cerPath -CertStoreLocation Cert:\LocalMachine\Root
}
$sha256 = [Security.Cryptography.SHA256]::Create()
try { $fingerprint = [BitConverter]::ToString($sha256.ComputeHash($certificate.RawData)).Replace('-', ':') }
finally { $sha256.Dispose() }
$trustMode = 'Self-signed: user trust must be established through an approved import/distribution process.'
if ($CertificateThumbprint) { $trustMode = 'CA-issued: validate the URL using normal Windows/browser trust. Do not import this leaf into Trusted Root.' }
"Server: $($config.serverName)`r`nSHA-256: $fingerprint`r`nExpires: $($certificate.NotAfter.ToString('o'))`r`nTrust mode: $trustMode`r`nCompare this fingerprint through a trusted channel before trusting." | Set-Content "$root\user-distribution\Certificate-Fingerprint.txt"
Copy-Item "$PSScriptRoot\app\downloads\DFM-Helper-Setup.exe" "$root\user-distribution" -Force
Copy-Item "$PSScriptRoot\USER-INSTRUCTIONS.md" "$root\user-distribution" -Force

$site = $config.siteName
if (!(Test-Path "IIS:\Sites\$site")) {
    $null = New-Website -Name $site -PhysicalPath "$root\iis" -Port 443 -HostHeader $config.serverName -Ssl
    Set-WebBinding -Name $site -BindingInformation "*:443:$($config.serverName)" -PropertyName sslFlags -Value 1
} elseif ((Get-Website -Name $site).PhysicalPath -ne "$root\iis") {
    throw "Existing IIS site $site has a different physical path. Setup will not overwrite it. Review it and move/remove only that conflicting site, then retry. IIS backup: $backupName"
}
if (!(Get-WebBinding -Name $site -Protocol https | Where-Object bindingInformation -eq "*:443:$($config.serverName)")) {
    $null = New-WebBinding -Name $site -Protocol https -Port 443 -HostHeader $config.serverName -SslFlags 1
}
$binding = Get-WebBinding -Name $site -Protocol https | Where-Object bindingInformation -eq "*:443:$($config.serverName)"
$binding.AddSslCertificate($certificate.Thumbprint, 'My')
if ($CertificateThumbprint) { $certificate.Thumbprint | Set-Content -LiteralPath $certificateSelectionPath -Encoding ASCII }
& icacls.exe "$root\iis" /grant '*S-1-5-17:(OI)(CI)RX' '*S-1-5-32-568:(OI)(CI)RX' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Failed to set IIS proxy folder permissions.' }
$completed = @()
foreach ($environment in $config.environments) {
    $appRoot = Join-Path $root $environment.path
    $taskName = "CETFalcon-$($environment.name)"
    $listener = Get-NetTCPConnection -LocalPort $environment.port -State Listen -ErrorAction SilentlyContinue
    if ($listener) { throw "Port $($environment.port) is in use. Setup will not stop an unrelated process." }
    $null = New-Item "$appRoot\app","$appRoot\data\attachments","$appRoot\logs" -ItemType Directory -Force
    if (Test-Path "$appRoot\runtime.bin") {
        $backup = "$root\backups\$($environment.path)-$(Get-Date -Format yyyyMMdd-HHmmss)"
        $null = New-Item $backup -ItemType Directory -Force
        Copy-Item "$appRoot\app","$appRoot\runtime.bin" $backup -Recurse -Force
    }
    Copy-Item "$PSScriptRoot\app\*" "$appRoot\app" -Recurse -Force
    $url = "https://$($config.serverName)/$($environment.path)"
    Save-ProtectedJson "$appRoot\runtime.bin" @{
        NODE_ENV='production'; HOST='127.0.0.1'; PORT=$environment.port; PUBLIC_URL=$url;
        BASE_PATH="/$($environment.path)"; SQL_CONNECTION_STRING=$connectionString;
        ATTACHMENT_ROOT="$appRoot\data\attachments"; STATIC_ROOT='public'; HELPER_PORT=47832
    } -Machine
    foreach ($writableFolder in @("$appRoot\data", "$appRoot\logs")) {
        & icacls.exe $writableFolder /grant '*S-1-5-19:(OI)(CI)M' | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "Failed to set runtime writable-folder permissions on '$writableFolder' (icacls exit code $LASTEXITCODE)." }
    }
    $proxyRoot = Join-Path "$root\iis" $environment.path
    $null = New-Item $proxyRoot -ItemType Directory -Force
    [xml]$proxy = Get-Content "$PSScriptRoot\web.config.subpath.example" -Raw
    $rules = $proxy.configuration.'system.webServer'.rewrite.rules.rule
    $rules[0].conditions.add[0].input = '{UNENCODED_URL}'
    $rules[0].conditions.add[0].pattern = "^/$($environment.path)/?(\?.*)?$"
    $rules[0].conditions.add[1].pattern = "^/$($environment.path)/(\?.*)?$"
    $rules[0].action.url = "/$($environment.path)/"
    $rules[1].action.url = "http://127.0.0.1:$($environment.port)/$($environment.path)/{R:1}"
    $proxy.Save("$proxyRoot\web.config")
    if (!(Get-WebApplication -Site $site -Name $environment.path)) {
        $null = New-WebApplication -Site $site -Name $environment.path -PhysicalPath $proxyRoot
    } elseif ((Get-WebApplication -Site $site -Name $environment.path).PhysicalPath -ne $proxyRoot) {
        throw "Existing application $($environment.path) points elsewhere. Review before retrying."
    }
    & $appcmd set config "$site/$($environment.path)" /section:system.webServer/security/authentication/anonymousAuthentication /enabled:true /commit:apphost | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Unable to enable anonymous proxy access.' }
    if (Get-WebGlobalModule | Where-Object Name -eq 'WindowsAuthenticationModule') {
        & $appcmd set config "$site/$($environment.path)" /section:system.webServer/security/authentication/windowsAuthentication /enabled:false /commit:apphost | Out-Null
        if ($LASTEXITCODE -ne 0) { throw 'Unable to disable IIS Windows Authentication.' }
    }
    $action = New-ScheduledTaskAction -Execute "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$root\tools\Start-Runtime.ps1`" -ApplicationRoot `"$appRoot`"" -WorkingDirectory "$appRoot\app"
    $settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -StartWhenAvailable
    $identity = New-ScheduledTaskPrincipal -UserId 'S-1-5-19' -LogonType ServiceAccount
    $null = Register-ScheduledTask -TaskName $taskName -Action $action -Trigger (New-ScheduledTaskTrigger -AtStartup) -Settings $settings -Principal $identity -Force
    Start-ScheduledTask -TaskName $taskName
    & $node "$PSScriptRoot\Check-Ready.cjs" "http://127.0.0.1:$($environment.port)/$($environment.path)" $url
    if ($LASTEXITCODE -ne 0) { throw "Backend $taskName failed readiness. Check $appRoot\logs\server.log before proceeding." }
    $completed += $url
}
if (!(Get-NetFirewallRule -Name CETFalcon-HTTPS -ErrorAction SilentlyContinue)) {
    $null = New-NetFirewallRule -Name CETFalcon-HTTPS -DisplayName 'CETFalcon HTTPS' -Direction Inbound -Protocol TCP -LocalPort 443 -Action Allow
}
$distributionZip = "$root\CETFalcon-Users.zip"
Compress-Archive -Path "$root\user-distribution\*" -DestinationPath $distributionZip -Force
Write-Host "Public certificate SHA-256: $fingerprint"
Write-Host "Send only $distributionZip to users. It contains NO private key or SQL credentials."
Write-Host 'LDAP/JIRA sync was NOT scheduled on this server. Configure the separate workstation package on a domain workstation.'
Write-Host "IIS backup: $backupName. Application backups: $root\backups"
foreach ($url in $completed) {
    try {
        $info = Invoke-RestMethod "$url/api/info" -TimeoutSec 20
        if ($info.authentication -ne 'dfm-helper' -or $info.publicUrl -ne $url) { throw 'Unexpected portal response.' }
        Write-Host "READY: $url"
    } catch { throw "Deployment installed but readiness failed for $url. Check its logs and task status. $($_.Exception.Message)" }
}