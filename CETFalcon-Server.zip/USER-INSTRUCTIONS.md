# CETFalcon Workstation Access

1. Install DFM-Helper-Setup.exe under your normal Windows account.
   This is the compact native Windows helper; it requires full .NET Framework 4.5+ (patched 4.8/4.8.1 recommended), not Electron or Chromium. When upgrading, first quit the older helper from its tray menu, disable its old startup entry, and uninstall the Electron version. Do not delete `%APPDATA%\DFM Helper`; your existing portal enrollment profiles are retained.
2. In DFM Helper, select Production, Development, or UAT.
3. Choose Import certificate and select CETFalcon.cer. Compare the SHA-256 fingerprint with your administrator through a trusted channel before confirming.
4. Choose Validate URL. Certificate validation remains enabled. If trust is cached, restart the helper and browser. If company policy blocks Current User trust, IT must distribute trust through Group Policy or issue an enterprise certificate.
5. Request administrator approval. Ask the DFM administrator to approve your request reference. The first administrator uses the one-time enrollment code instead.
6. Open DFM from the helper. If the browser requests Local Network Access for the loopback bridge, allow it only for this portal.

Portals:

- Production: https://DXB01-VWU-HFNA2/CETFalcon
- Development: https://DXB01-VWU-HFNA2/CETFalconDev
- UAT: https://DXB01-VWU-HFNA2/CETFalconUAT

The certificate is public and contains no private key or database password. Do not forward server packages or workstation sync credentials to normal users. A self-signed certificate is valid only until its recorded expiry; distribute the replacement public certificate when it is renewed.