# CETFalcon Workstation Access

1. Install DFM-Helper-Setup.exe under your normal Windows account.
   This is the compact native Windows helper; it requires full .NET Framework 4.5+ (patched 4.8/4.8.1 recommended), not Electron or Chromium. When upgrading, first quit the older helper from its tray menu, disable its old startup entry, and uninstall the Electron version. Do not delete `%APPDATA%\DFM Helper`; your existing portal enrollment profiles are retained.
2. In DFM Helper, select Production, Development, or UAT.
3. Choose Validate URL first. If the website uses a CA-issued certificate already trusted by Windows and validation succeeds, **skip certificate import**. Do not import a CA-issued website leaf certificate into Trusted Root.
4. For an approved self-signed deployment only, choose Import certificate and select CETFalcon.cer. Compare the SHA-256 fingerprint with your administrator through a trusted channel before confirming, then choose Validate URL again. Certificate validation remains enabled. If trust is cached, restart the helper and browser. If company policy blocks Current User trust, IT must distribute trust through Group Policy or the server must use a certificate from a CA already trusted by workstations.
   If confirming the fingerprint produces "Access is denied", Windows rejected the certificate-store write; this is not an enrollment rejection or a SQL certificate error. Ask IT to approve/distribute the verified public portal certificate. Do not change store permissions or disable TLS validation. Running the helper as a different administrator does not establish trust for your normal user.
   Certificate details show the full validity period and this computer's clock, explicitly in UTC. An expiry such as `2027-10-17` means 17 October 2027, not 17 October 2026. If a certificate is reported expired or not yet valid, check the workstation clock/time zone and ask IT to compare it with the server; do not change the clock just to bypass validation.
5. Request administrator approval. Ask the DFM administrator to approve your request reference. The first administrator uses the one-time enrollment code instead.
6. Open DFM from the helper. If the browser requests Local Network Access for the loopback bridge, allow it only for this portal.

Portals:

- Production: https://DXB01-VWU-HFNA2.dibuat.ae/CETFalcon
- Development: https://DXB01-VWU-HFNA2.dibuat.ae/CETFalconDev
- UAT: https://DXB01-VWU-HFNA2.dibuat.ae/CETFalconUAT

Use the full hostname including `.dibuat.ae`, not the old short hostname. After upgrading from the short-name helper, select the environment again to switch to the new FQDN profile. Old saved profiles are retained, but approval/enrollment is not automatically transferred between portal identities. Use the newly distributed public certificate whose SAN includes the FQDN; verify its new fingerprint independently. If Windows blocks import, IT must distribute trust through an approved process.

The certificate is public and contains no private key or database password. Do not forward server packages or workstation sync credentials to normal users. A self-signed certificate is valid only until its recorded expiry; distribute the replacement public certificate when it is renewed.