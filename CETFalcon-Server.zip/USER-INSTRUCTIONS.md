# CETFalcon Workstation Access

1. Install DFM-Helper-Setup.exe under your normal Windows account.
   This is the compact native Windows helper; it requires full .NET Framework 4.5+ (patched 4.8/4.8.1 recommended), not Electron or Chromium. When upgrading, first quit the older helper from its tray menu, disable its old startup entry, and uninstall the Electron version. Do not delete `%APPDATA%\DFM Helper`; your existing portal enrollment profiles are retained.
2. In DFM Helper, confirm your Windows account and PC name. Open **Portal and enrollment settings** and select Production, Development, or UAT.
3. Choose **Validate portal URL and certificate trust** first. If Windows already trusts the website certificate and validation succeeds, skip certificate approval/import. Do not import a CA-issued website leaf certificate into Trusted Root.
4. For a self-signed deployment, choose **Approve public certificate for DFM Helper** and select the verified **CETFalcon.cer** from the extracted user package. Compare its SHA-256 fingerprint with the server administrator through a separate trusted channel before approving. The helper checks the exact certificate, hostname, validity, self-signature and server purpose, and validates the HTTPS/API connection before saving approval. **No administrator rights, PowerShell commands or Windows certificate import are needed.** Approval persists only for your Windows user and selected portal; approve independently for Production, Development and UAT as needed.
   Browser trust is separate: helper approval does not remove browser certificate warnings. If Windows/browser trust is also required and permitted, **Optional: import certificate into Windows trust** retains the Current User Trusted Root import. A denied optional import does not prevent helper-only approval. For browser trust where user import is denied, authorized machine/central trust distribution or an already-trusted issuer is still required; do not change store permissions or disable TLS validation.
   If the server certificate changes or expires, the helper will not accept a replacement automatically. Independently verify and approve the replacement. **Remove helper-only certificate approval** returns the selected portal to normal Windows trust without removing enrollment.
   Certificate details show the full validity period and this computer's clock, explicitly in UTC. An expiry such as `2027-10-17` means 17 October 2027, not 17 October 2026. If a certificate is reported expired or not yet valid, check the workstation clock/time zone and ask IT to compare it with the server; do not change the clock just to bypass validation.
5. Ordinary users request administrator approval and give the DFM administrator their request reference. **The first DFM administrator does not request approval**: the authorized sync operator runs Bootstrap-Administrator.cmd from the workstation-sync package, confirms the intended synchronized administrator email and Master-role grant, and provides the generated one-time code securely. That administrator opens **Portal and enrollment settings > One-time enrollment code**, enters the code and chooses **Enroll with code** under their own Windows account. Windows administrator rights alone do not grant DFM administrator privileges.
6. Open DFM from the helper. If the browser requests Local Network Access for the loopback bridge, allow it only for this portal.

## Enrollment duration and user identity

Once a device is enrolled, enrollment has **no time-based expiry**. Keep the
helper's saved Windows-user/portal profile; normal restarts and updates
preserve it. An administrator can revoke the device or deactivate the DFM
account, which blocks further access.

The one-time code's 24-hour validity is only the window to **complete initial
enrollment**, not the duration of the resulting enrollment. Browser sessions
remain temporary (eight hours), and browser connection tickets are short-lived;
reconnecting with an enrolled helper does not require enrolling again.
HTTPS certificate expiry/renewal is also separate from device enrollment.

The portal's **Helper detected** card shows the Windows account and computer
reported by an updated helper, including while approval is pending. After
sign-in, the header shows the authenticated DFM user's name and directory
account. Displaying a detected Windows name does not grant access or roles.

## Notifications

Keep DFM Helper running in the system tray to receive notifications. Closing
its window does not quit it. Every 15 seconds it checks for PETs awaiting
your assigned review/approval, review/approval/rejection decisions on your
own PETs, and pending device-enrollment approval/rejection.

New events appear as Windows desktop notifications and in the helper's
**Notifications** list. Click a desktop notification or choose
**Notifications** from the tray menu to open the list. Select a row for
full details, and use **Mark all notifications read** to clear unread flags.
Windows Do Not Disturb or notification settings can suppress desktop
banners without removing the inbox entries.

Each portal keeps its own latest 200 notifications and read state across
restarts. The first sync can include existing workflow events. This list
is event history, not a live list of outstanding tasks. Both server and
helper must be updated for workflow notifications; normal enrollment and
HTTPS certificate trust are still required.

Portals:

- Production: https://DXB01-VWU-HFNA2.dibuat.ae/CETFalcon
- Development: https://DXB01-VWU-HFNA2.dibuat.ae/CETFalconDev
- UAT: https://DXB01-VWU-HFNA2.dibuat.ae/CETFalconUAT

Use the full hostname including `.dibuat.ae`, not the old short hostname. After upgrading from the short-name helper, select the environment again to switch to the new FQDN profile. Old saved profiles are retained, but approval/enrollment is not automatically transferred between portal identities. Use the newly distributed public certificate whose SAN includes the FQDN; verify its new fingerprint independently. Windows import is not required for helper-only approval; browser trust remains separate.

The certificate is public and contains no private key or database password. Do not forward server packages or workstation sync credentials to normal users. A self-signed certificate is valid only until its recorded expiry; distribute the replacement public certificate when it is renewed.