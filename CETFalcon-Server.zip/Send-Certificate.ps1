param(
    [Parameter(Mandatory=$true)][string]$SmtpServer,
    [Parameter(Mandatory=$true)][string]$From,
    [Parameter(Mandatory=$true)][string[]]$To,
    [string]$DistributionRoot = 'C:\ProgramData\CETFalcon\user-distribution',
    [int]$Port = 587,
    [switch]$UseWindowsCredentials
)
$ErrorActionPreference = 'Stop'
$message = New-Object Net.Mail.MailMessage
$client = New-Object Net.Mail.SmtpClient($SmtpServer, $Port)
try {
    $client.EnableSsl = $true
    if ($UseWindowsCredentials) { $client.UseDefaultCredentials = $true }
    else { $client.Credentials = (Get-Credential -Message 'SMTP credentials (entered locally)').GetNetworkCredential() }
    $message.From = $From
    foreach ($recipient in $To) { $message.To.Add($recipient) }
    $message.Subject = 'CETFalcon public certificate and workstation access'
    $message.Body = [IO.File]::ReadAllText((Join-Path $DistributionRoot 'USER-INSTRUCTIONS.md'))
    foreach ($name in @('CETFalcon.cer','Certificate-Fingerprint.txt')) {
        $message.Attachments.Add((New-Object Net.Mail.Attachment((Join-Path $DistributionRoot $name))))
    }
    $client.Send($message)
    Write-Host 'Public certificate and instructions sent. Communicate the fingerprint through a separate trusted channel.'
} finally { $message.Dispose(); $client.Dispose() }