param(
    [string]$CertificateThumbprint,
    [string]$Template,
    [string]$RequestThumbprint,
    [string]$NodePath
)

. "$PSScriptRoot\Common.ps1"

function Get-SetupCertificate($Config, [string]$PackageRoot, [string]$Thumbprint, [string]$Template, [string]$RequestThumbprint) {
    if ($Thumbprint -and $RequestThumbprint) { throw 'Choose either an issued certificate thumbprint or a pending request thumbprint, not both.' }
    if ($Thumbprint) { return (Get-TrustedPortalCertificate $Thumbprint $Config.serverName) }
    $savedPath = Join-Path $Config.installRoot 'tools\portal-certificate-thumbprint.txt'
    if (!$RequestThumbprint -and (Test-Path -LiteralPath $savedPath)) {
        $saved = (Get-Content -LiteralPath $savedPath -Raw).Trim()
        if (!$saved) { throw "Saved CA certificate selection is empty: $savedPath. Supply -CertificateThumbprint with the issued certificate." }
        return (Get-TrustedPortalCertificate $saved $Config.serverName)
    }
    if (!$RequestThumbprint) {
        Write-Host 'Existing server certificates (select only an approved CA-issued HTTPS certificate for the portal):'
        Get-ChildItem Cert:\LocalMachine\My | Select-Object Subject, Issuer, NotAfter, Thumbprint | Format-List | Out-Host
        $choice = (Read-Host 'Paste an existing certificate thumbprint, or press Enter to discover/request a new certificate').Trim()
        if ($choice) { return (Get-TrustedPortalCertificate $choice $Config.serverName) }
    }
    if (!(Get-Command Get-Certificate -ErrorAction SilentlyContinue)) {
        throw 'The Windows PKI Get-Certificate command is unavailable. Enroll using certlm.msc, then rerun with -CertificateThumbprint. Setup does not install Windows features or bypass enrollment policy to obtain this command.'
    }
    if ($RequestThumbprint) {
        $normalized = [regex]::Replace($RequestThumbprint, '\s', '').ToUpperInvariant()
        if ($normalized -notmatch '^[A-F0-9]{40}$') { throw 'RequestThumbprint must contain 40 hexadecimal characters from the pending request.' }
        $request = Get-Item -LiteralPath "Cert:\LocalMachine\Request\$normalized" -ErrorAction Stop
        if ($request.Subject -ine "CN=$($Config.serverName)" -and
            @($request.DnsNameList | ForEach-Object { $_.Unicode }) -inotcontains $Config.serverName) {
            throw 'The selected pending request is not for the configured portal hostname.'
        }
        $result = Get-Certificate -Request $request -ErrorAction Stop
    } else {
        if (Test-Path -LiteralPath 'Cert:\LocalMachine\Request') {
            $pending = @(Get-ChildItem Cert:\LocalMachine\Request | Where-Object {
                $_.Subject -ieq "CN=$($Config.serverName)" -or
                @($_.DnsNameList | ForEach-Object { $_.Unicode }) -icontains $Config.serverName
            })
            if ($pending.Count) {
                $requests = ($pending | ForEach-Object { $_.Thumbprint }) -join ', '
                throw "A pending request already exists for this portal: $requests. Obtain CA approval, then rerun Setup-TrustedHttps.cmd -RequestThumbprint <request-thumbprint>. No duplicate request was submitted."
            }
        }
        & "$PackageRoot\Discover-CertificateAuthority.ps1" | Out-Host
        $caConfig = (Read-Host 'Enter CA-HOST\CA-NAME from discovery to inspect templates (blank cancels)').Trim()
        if (!$caConfig) { throw 'CA enrollment cancelled. No certificate request was submitted.' }
        & "$PackageRoot\Discover-CertificateAuthority.ps1" -CAConfig $caConfig | Out-Host
        if (!$Template) { $Template = (Read-Host 'Enter the authorized HTTPS template NAME, not its display label (blank cancels)').Trim() }
        if (![string]::IsNullOrWhiteSpace($Template)) { $Template = $Template.Trim() }
        else { throw 'Certificate template is required. No certificate request was submitted.' }
        Write-Warning 'Enrollment uses existing Active Directory policy and permissions. Windows chooses an issuing CA from that policy; the CA above was used to inspect published templates. No template permissions or trust stores will be changed.'
        if ((Read-Host "Type REQUEST to request template '$Template' for $($Config.serverName) in this server's Personal store") -cne 'REQUEST') {
            throw 'CA enrollment cancelled. No certificate request was submitted.'
        }
        $result = Get-Certificate -Template $Template -SubjectName "CN=$($Config.serverName)" -DnsName $Config.serverName -Url 'ldap:' -CertStoreLocation 'Cert:\LocalMachine\My' -ErrorAction Stop
    }
    if (!$result) { throw 'Windows certificate enrollment returned no result. Deployment was not started.' }
    if ([string]$result.Status -eq 'Pending') {
        $pendingThumbprint = '(inspect Cert:\LocalMachine\Request)'
        if ($result.Request) { $pendingThumbprint = $result.Request.Thumbprint }
        throw "The CA requires approval. Pending request: $pendingThumbprint. After approval, rerun Setup-TrustedHttps.cmd -RequestThumbprint <request-thumbprint>. Deployment was not started."
    }
    if ([string]$result.Status -ne 'Issued' -or !$result.Certificate) {
        throw "Certificate enrollment did not issue a certificate (status: $($result.Status)). Deployment was not started."
    }
    return (Get-TrustedPortalCertificate $result.Certificate.Thumbprint $Config.serverName)
}

Test-PackageManifest $PSScriptRoot
$config = Get-Content "$PSScriptRoot\deployment.json" -Raw | ConvertFrom-Json
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Right-click Setup-TrustedHttps.cmd and choose Run as administrator on the website server.'
}
Assert-DeploymentServer $env:COMPUTERNAME $config.serverName
if (!(Get-Command Install-WindowsFeature -ErrorAction SilentlyContinue)) { throw 'This installer requires Windows Server with ServerManager.' }
$node = Resolve-ServerNode $NodePath
Import-Module WebAdministration
Test-IisPrerequisites
$certificate = Get-SetupCertificate -Config $config -PackageRoot $PSScriptRoot -Thumbprint $CertificateThumbprint -Template $Template -RequestThumbprint $RequestThumbprint
$installParameters = @{ CertificateThumbprint = $certificate.Thumbprint; NodePath = $node }
& "$PSScriptRoot\Install-Server.ps1" @installParameters
