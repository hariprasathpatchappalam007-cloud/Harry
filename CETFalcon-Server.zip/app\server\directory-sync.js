function one(value) {
  return Array.isArray(value) ? value[0] : value;
}

export function domainToBaseDn(domain) {
  return String(domain || '').split('.').filter(Boolean).map(part => `DC=${part}`).join(',');
}

export function activeDirectoryGuid(value) {
  const bytes = Buffer.isBuffer(value) ? value : Buffer.from(value || []);
  if (bytes.length !== 16) throw new Error('Active Directory returned an invalid objectGUID.');
  const hex = [...bytes].map(byte => byte.toString(16).padStart(2, '0'));
  const reversed = indexes => indexes.map(index => hex[index]).join('');
  return [
    reversed([3, 2, 1, 0]),
    reversed([5, 4]),
    reversed([7, 6]),
    reversed([8, 9]),
    reversed([10, 11, 12, 13, 14, 15])
  ].join('-');
}

export async function runDirectorySync({database, client, config, log = console.log}) {
  const baseDn = config.baseDn || domainToBaseDn(config.domain);
  if (!config.url || !baseDn || !config.bindDn || !config.password || !config.domain) {
    throw new Error('LDAP_URL, LDAP_BIND_DN, LDAP_PASSWORD, LDAP_DOMAIN, and LDAP_BASE_DN or a derivable domain are required.');
  }

  await client.bind(config.bindDn, config.password);
  let synchronized = 0;
  try {
    const {searchEntries} = await client.search(baseDn, {
      scope: 'sub',
      filter: '(&(objectCategory=person)(objectClass=user)(mail=*)(sAMAccountName=*)(objectGUID=*)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))',
      attributes: ['mail', 'displayName', 'sAMAccountName', 'objectGUID'],
      paged: {pageSize: 1000, pagePause: false}
    });

    for (const entry of searchEntries) {
      const email = String(one(entry.mail) || '').trim().toLowerCase();
      const accountName = String(one(entry.sAMAccountName) || '').trim();
      const objectGuid = one(entry.objectGUID);
      if (!email || !accountName || !objectGuid) continue;
      const displayName = String(one(entry.displayName) || accountName).trim();
      await database.execute('EXEC dbo.sp_SyncDirectoryUser @Email,@DisplayName,@AccountName,@ObjectGuid,@DefaultRole', {
        Email: email,
        DisplayName: displayName,
        AccountName: `${config.domain}\\${accountName}`,
        ObjectGuid: activeDirectoryGuid(objectGuid),
        DefaultRole: config.defaultRole || 'Requestor'
      });
      synchronized++;
    }
  } finally {
    await client.unbind();
  }

  log(`Synchronized ${synchronized} directory users.`);
  return synchronized;
}