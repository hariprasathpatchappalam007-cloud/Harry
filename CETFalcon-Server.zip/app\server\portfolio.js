import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import express from 'express';
import multer from 'multer';
import {asyncRoute} from './errors.js';
import {importCsv} from './csv-import.js';

const ALLOWED_ATTACHMENT_EXTENSIONS = new Set(['.csv', '.doc', '.docx', '.jpeg', '.jpg', '.pdf', '.png', '.txt', '.xls', '.xlsx']);

function first(rows) {
  return rows[0] || null;
}

function positiveId(value, name) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isInteger(parsed) || parsed <= 0) throw Object.assign(new Error(`${name} must be a positive integer.`), {status: 400});
  return parsed;
}

function requireBody(value, field, message) {
  if (!value || !String(value[field] ?? '').trim()) throw Object.assign(new Error(message), {status: 400});
}

export function createPortfolioRouter({database, authentication, attachmentRoot}) {
  const router = express.Router();
  const {authenticate, requireRoles} = authentication;
  fs.mkdirSync(attachmentRoot, {recursive: true});
  const upload = multer({
    storage: multer.diskStorage({
      destination: attachmentRoot,
      filename(request, file, callback) {
        callback(null, randomUUID() + path.extname(file.originalname).toLowerCase());
      }
    }),
    limits: {fileSize: 50 * 1024 * 1024, files: 10},
    fileFilter(request, file, callback) {
      const extension = path.extname(file.originalname).toLowerCase();
      callback(extension && ALLOWED_ATTACHMENT_EXTENSIONS.has(extension) ? null : Object.assign(new Error('This attachment type is not allowed.'), {status: 400}), true);
    }
  });

  router.use(authenticate);

  router.get('/dashboard', asyncRoute(async (request, response) => {
    const projectKey = String(request.query.projectKey || 'DMGT').slice(0, 20);
    const accountableExec = String(request.query.accountableExec || 'Zahoor Ul Islam (IT Dept)').slice(0, 200);
    const [metrics, projects, budgets, jira, budgetUsage] = await Promise.all([
      database.query('SELECT * FROM dbo.vw_ManagementDashboard'),
      database.query('SELECT * FROM dbo.vw_ProjectPortfolio ORDER BY CreatedUtc DESC'),
      database.query('EXEC dbo.sp_GetBudgetSources'),
      database.query('EXEC dbo.sp_GetJiraRegistrationCandidates @projectKey,@exec', {projectKey, exec: accountableExec}),
      database.query('SELECT * FROM dbo.vw_CapexProjectUtilization ORDER BY BudgetSource,ApprovedUtc DESC')
    ]);
    response.json({metrics, projects, budgets, jira, budgetUsage});
  }));

  router.get('/projects/:projectId', asyncRoute(async (request, response) => {
    const projectId = positiveId(request.params.projectId, 'Project id');
    const sets = await database.queryMultiple('EXEC dbo.sp_GetProjectDetail @id', {id: projectId});
    response.json({
      project: first(sets[0] || []),
      pets: sets[1] || [],
      spendItems: sets[2] || [],
      budgetLines: sets[3] || [],
      invoices: sets[4] || [],
      attachments: sets[5] || []
    });
  }));

  router.get('/roles', requireRoles('Master'), asyncRoute(async (request, response) => {
    const users = await database.query(`SELECT u.UserId,u.Email,u.DisplayName,u.IsActive,
      STUFF((SELECT ',' + r.Name FROM dbo.UserRoles ur JOIN dbo.Roles r ON r.RoleId=ur.RoleId WHERE ur.UserId=u.UserId FOR XML PATH('')),1,1,'') Roles
      FROM dbo.Users u ORDER BY u.DisplayName,u.Email`);
    const roleRows = await database.query("SELECT Name FROM dbo.Roles WHERE Name <> 'Requestor' ORDER BY CASE Name WHEN 'Reviewer' THEN 1 WHEN 'Approver' THEN 2 WHEN 'Admin' THEN 3 WHEN 'Master' THEN 4 ELSE 5 END,Name");
    response.json({users, roles: roleRows.map(row => row.name)});
  }));

  router.post('/roles', requireRoles('Master'), asyncRoute(async (request, response) => {
    const userId = positiveId(request.body?.userId, 'User id');
    const roles = [...new Set((request.body?.roles || []).map(role => String(role)))];
    const allowed = new Set(['Reviewer', 'Approver', 'Admin']);
    if (roles.length > 1 || roles.some(role => !allowed.has(role))) {
      throw Object.assign(new Error('Select only one elevated role: Reviewer, Approver, or Admin.'), {status: 400});
    }
    await database.execute(`DELETE ur FROM dbo.UserRoles ur JOIN dbo.Roles r ON r.RoleId=ur.RoleId WHERE ur.UserId=@user AND r.Name IN ('Reviewer','Approver','Admin','Master');
      INSERT dbo.UserRoles(UserId,RoleId) SELECT @user,RoleId FROM dbo.Roles WHERE Name='Requestor' AND NOT EXISTS(SELECT 1 FROM dbo.UserRoles WHERE UserId=@user AND RoleId=dbo.Roles.RoleId);
      INSERT dbo.UserRoles(UserId,RoleId) SELECT @user,RoleId FROM dbo.Roles WHERE Name IN ('Reviewer','Approver','Admin') AND CHARINDEX(',' + Name + ',', @roles) > 0;`,
    {user: userId, roles: `,${roles.join(',')},`});
    response.json({ok: true});
  }));

  router.get('/pets/:petId/history', asyncRoute(async (request, response) => {
    response.json(await database.query('EXEC dbo.sp_GetWorkflowHistory @id', {id: positiveId(request.params.petId, 'PET id')}));
  }));

  router.post('/projects', requireRoles('Requestor', 'Master'), asyncRoute(async (request, response) => {
    const value = request.body;
    requireBody(value, 'projectName', 'Project name is required.');
    const rows = await database.query('EXEC dbo.sp_SaveProject @ProjectId,@IsJira,@JiraKey,@Name,@Type,@Lead,@Executive,@Sme,@Size,@Manager,@BudgetType,@BudgetSource,@RequiresPet,@SkipReview,@User', {
      ProjectId: value.projectId ?? null,
      IsJira: !!value.isJira,
      JiraKey: value.jiraKey || null,
      Name: value.projectName,
      Type: value.projectType || null,
      Lead: value.accountableExecLead || null,
      Executive: value.accountableExec || null,
      Sme: value.smeLead || null,
      Size: value.projectSize || null,
      Manager: value.projectManager || null,
      BudgetType: value.budgetType || null,
      BudgetSource: value.budgetSourceId ?? null,
      RequiresPet: value.requiresPet !== false,
      SkipReview: !!value.skipReview,
      User: request.user.email
    });
    response.json(first(rows));
  }));

  router.delete('/projects/:projectId', requireRoles('Requestor', 'Master'), asyncRoute(async (request, response) => {
    await database.execute('EXEC dbo.sp_DeleteProject @ProjectId,@User', {ProjectId: positiveId(request.params.projectId, 'Project id'), User: request.user.email});
    response.json({ok: true});
  }));

  router.delete('/pets/:petId', requireRoles('Requestor', 'Master'), asyncRoute(async (request, response) => {
    await database.execute('EXEC dbo.sp_DeletePet @PetId,@User', {PetId: positiveId(request.params.petId, 'PET id'), User: request.user.email});
    response.json({ok: true});
  }));

  router.post('/pets', requireRoles('Requestor', 'Master'), asyncRoute(async (request, response) => {
    const value = request.body;
    if (!value || Number(value.requestedAmount) <= 0) throw Object.assign(new Error('A positive PET amount is required.'), {status: 400});
    const rows = await database.query('EXEC dbo.sp_SavePet @PetId,@ProjectId,@Code,@Amount,@Currency,@User', {
      PetId: value.petId ?? null,
      ProjectId: value.projectId,
      Code: value.code,
      Amount: value.requestedAmount,
      Currency: value.currency || 'AED',
      User: request.user.email
    });
    response.json(first(rows));
  }));

  router.post('/spend-items', requireRoles('Requestor', 'Master'), asyncRoute(async (request, response) => {
    const value = request.body;
    requireBody(value, 'vendor', 'Vendor is required.');
    const foreignAmount = Number(value.foreignAmount) || Number(value.units) * Number(value.unitPrice);
    const aedAmount = Number(value.aedAmount) || foreignAmount;
    const rows = await database.query('EXEC dbo.sp_SaveSpendItem @Id,@Pet,@Head,@Topic,@Vendor,@CostType,@UnitType,@Units,@UnitPrice,@Currency,@Foreign,@Aed,@Contingency,@Gl', {
      Id: value.spendItemId ?? null,
      Pet: value.petId,
      Head: value.head || null,
      Topic: value.topic || null,
      Vendor: value.vendor,
      CostType: value.costType || null,
      UnitType: value.unitType || null,
      Units: value.units,
      UnitPrice: value.unitPrice,
      Currency: value.currency || 'AED',
      Foreign: foreignAmount,
      Aed: aedAmount,
      Contingency: value.contingencyPercent || 0,
      Gl: value.glNumber || null
    });
    response.json(first(rows));
  }));

  async function decision(request, response, stage) {
    const petId = positiveId(request.params.petId, 'PET id');
    await database.execute('EXEC dbo.sp_PetDecision @PetId,@Stage,@Approve,@Comments,@User', {
      PetId: petId,
      Stage: stage,
      Approve: !!request.body?.approve,
      Comments: request.body?.comments || null,
      User: request.user.email
    });
    response.json({ok: true});
  }

  router.post('/pets/:petId/review', requireRoles('Reviewer'), asyncRoute((request, response) => decision(request, response, 'Review')));
  router.post('/pets/:petId/approve', requireRoles('Approver'), asyncRoute((request, response) => decision(request, response, 'Approval')));

  router.post('/budget-lines', requireRoles('Requestor', 'Master'), asyncRoute(async (request, response) => {
    const value = request.body || {};
    const rows = await database.query('EXEC dbo.sp_SaveBudgetLine @Id,@Pet,@Vendor,@Justification,@Cost,@Currency,@Gl,@PetRef,@CamId,@CamStatus,@CamComments,@LpoRequest,@LpoStatus,@LpoComments,@User', {
      Id: value.budgetLineId ?? null,
      Pet: value.petId,
      Vendor: value.vendor,
      Justification: value.justification || null,
      Cost: value.cost,
      Currency: value.currency || 'AED',
      Gl: value.glNumber || null,
      PetRef: value.petReference || null,
      CamId: value.camId || null,
      CamStatus: value.camStatus || null,
      CamComments: value.camComments || null,
      LpoRequest: value.lpoRequest || null,
      LpoStatus: value.lpoStatus || null,
      LpoComments: value.lpoComments || null,
      User: request.user.email
    });
    response.json(first(rows));
  }));

  router.post('/invoices', requireRoles('Requestor', 'Master'), asyncRoute(async (request, response) => {
    const value = request.body || {};
    const rows = await database.query('EXEC dbo.sp_SaveInvoice @Id,@Line,@Vendor,@Justification,@Gl,@Number,@Amount,@Status,@PaymentDate,@User', {
      Id: value.invoiceId ?? null,
      Line: value.budgetLineId,
      Vendor: value.vendorName,
      Justification: value.justification || null,
      Gl: value.glNumber || null,
      Number: value.invoiceNumber,
      Amount: value.invoiceAmount,
      Status: value.invoiceStatus || 'Raised',
      PaymentDate: value.paymentDate || null,
      User: request.user.email
    });
    response.json(first(rows));
  }));

  router.put('/budgets/:budgetSourceId', requireRoles('Master'), asyncRoute(async (request, response) => {
    const value = request.body || {};
    await database.execute('EXEC dbo.sp_UpdateBudget @Id,@Description,@Budget,@Utilization,@Available,@User', {
      Id: positiveId(request.params.budgetSourceId, 'Budget source id'),
      Description: value.description || null,
      Budget: value.budget,
      Utilization: value.utilization,
      Available: value.availableBudget,
      User: request.user.email
    });
    response.json({ok: true});
  }));

  router.post('/attachments/:entityType/:entityId', requireRoles('Requestor', 'Master'), upload.any(), asyncRoute(async (request, response) => {
    const entityType = String(request.params.entityType || '').toLowerCase();
    const normalizedType = entityType === 'project' ? 'Project' : entityType === 'pet' ? 'PET' : '';
    if (!normalizedType) throw Object.assign(new Error('Attachment entity type must be Project or PET.'), {status: 400});
    const entityId = positiveId(request.params.entityId, 'Entity id');
    const files = request.files || [];
    if (!files.length) throw Object.assign(new Error('Choose at least one attachment.'), {status: 400});
    try {
      for (const file of files) {
        await database.execute('EXEC dbo.sp_InsertAttachment @type,@id,@original,@stored,@content,@size,@user', {
          type: normalizedType,
          id: entityId,
          original: path.basename(file.originalname).slice(0, 260),
          stored: file.filename,
          content: file.mimetype || 'application/octet-stream',
          size: file.size,
          user: request.user.email
        });
      }
    } catch (error) {
      await Promise.all(files.map(file => fs.promises.rm(file.path, {force: true})));
      throw error;
    }
    response.json({uploaded: files.length});
  }));

  router.post('/bulk/:kind/:parentId', requireRoles('Requestor', 'Master'), express.text({type: ['text/csv', 'text/plain'], limit: '10mb'}), asyncRoute(async (request, response) => {
    const kind = String(request.params.kind || '').toLowerCase();
    if (!['pet', 'budget', 'invoice'].includes(kind)) throw Object.assign(new Error('Unknown template type.'), {status: 400});
    const imported = await importCsv(database, kind, positiveId(request.params.parentId, 'Parent id'), request.body, request.user.email);
    response.json({imported});
  }));

  return router;
}