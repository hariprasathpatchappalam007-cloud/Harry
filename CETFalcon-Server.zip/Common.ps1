Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
Add-Type -AssemblyName System.Data

function Test-NodeVersion([string]$Version) {
    if ($Version -notmatch '^v(24|25|26)\.\d+\.\d+$') {
        throw "Node.js 24-26 is required; found '$Version'. Install a supported machine-wide Node version."
    }
}

function Resolve-ServerNode([string]$NodePath) {
    if (!$NodePath) { $NodePath = Join-Path $env:ProgramFiles 'nodejs\node.exe' }
    if (![IO.Path]::IsPathRooted($NodePath) -or !(Test-Path -LiteralPath $NodePath -PathType Leaf)) {
        throw "Node executable not found: $NodePath. Install Node.js 24-26 machine-wide or pass -NodePath with its absolute node.exe path."
    }
    $resolved = (Get-Item -LiteralPath $NodePath).FullName
    $version = & $resolved --version
    if ($LASTEXITCODE -ne 0) { throw "Unable to run Node executable: $resolved" }
    Test-NodeVersion ([string]$version)
    return $resolved
}

function Get-DeploymentListeners([int]$Port) {
    try {
        Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop
    } catch {
        if ($_.FullyQualifiedErrorId -notlike 'CmdletizationQuery_NotFound*') { throw }
    }
}

function Test-DeploymentProcessOwner($Process, [string[]]$NodePaths, [string]$ApplicationRoot, [string]$RuntimeTools, [string]$ProbeUrl, [string]$PublicUrl) {
    if (!$Process -or !$Process.ExecutablePath -or !$Process.CommandLine -or !$Process.CreationDate -or
        $Process.ProcessId -le 4 -or $NodePaths -inotcontains $Process.ExecutablePath) { return $false }
    $prefix = '^\s*(?:"' + [regex]::Escape($Process.ExecutablePath) + '"|' + [regex]::Escape($Process.ExecutablePath) + ')\s+'
    $entry = [regex]::Escape((Join-Path $ApplicationRoot 'app\server\index.js'))
    if ($Process.CommandLine -imatch ($prefix + '(?:"' + $entry + '"|' + $entry + ')\s*$')) { return $true }
    if ($Process.CommandLine -inotmatch ($prefix + '(?:"server\\index\.js"|server\\index\.js)\s*$')) { return $false }

    # Older runtimes used a relative entry point; prove their environment through the still-live launcher.
    $parent = Get-CimInstance Win32_Process -Filter "ProcessId = $($Process.ParentProcessId)" -ErrorAction Stop
    $launcher = [regex]::Escape((Join-Path $RuntimeTools 'Start-Runtime.ps1'))
    $application = [regex]::Escape($ApplicationRoot)
    if ($parent -and $parent.CreationDate -and $parent.CreationDate -le $Process.CreationDate -and
        $parent.ExecutablePath -ieq "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -and
        $parent.CommandLine -imatch ('(?:^|\s)-File\s+(?:"' + $launcher + '"|' + $launcher + ')(?=\s|$)') -and
        $parent.CommandLine -imatch ('(?:^|\s)-ApplicationRoot\s+(?:"' + $application + '"|' + $application + ')(?=\s|$)')) { return $true }

    # An already orphaned legacy process has no launcher; require the configured local portal identity as well.
    if (!$ProbeUrl -or !$PublicUrl) { return $false }
    $probe = [Uri]$ProbeUrl
    if ($probe.Scheme -ne 'http' -or $probe.Host -ne '127.0.0.1') { throw 'Backend ownership probes must use HTTP IPv4 loopback only.' }
    try { $info = Invoke-RestMethod -Uri $ProbeUrl -TimeoutSec 5 -MaximumRedirection 0 -ErrorAction Stop }
    catch { throw "Cannot verify legacy backend PID $($Process.ProcessId) using $ProbeUrl. No process was terminated. $($_.Exception.Message)" }
    if (!$info -or !$info.PSObject.Properties['authentication'] -or !$info.PSObject.Properties['publicUrl'] -or
        !$info.PSObject.Properties['helperPort']) { return $false }
    return ($info.authentication -ceq 'dfm-helper' -and $info.publicUrl -ceq $PublicUrl -and $info.helperPort -eq 47832)
}

function Stop-DeploymentBackend($Config, $Environment, [string]$NodePath, [int]$GraceSeconds = 20) {
    $taskName = "CETFalcon-$($Environment.name)"
    $applicationRoot = Join-Path $Config.installRoot $Environment.path
    $runtimeTools = Join-Path $Config.installRoot 'tools'
    $nodePaths = @($NodePath)
    $savedNode = Join-Path $runtimeTools 'node-path.txt'
    if (Test-Path -LiteralPath $savedNode -PathType Leaf) {
        $previousNode = (Get-Content -LiteralPath $savedNode -Raw).Trim()
        if (![IO.Path]::IsPathRooted($previousNode)) { throw "Invalid saved runtime Node path in $savedNode. Review it before deployment." }
        $nodePaths += $previousNode
    }
    $owned = @()
    $probeUrl = "http://127.0.0.1:$($Environment.port)/$($Environment.path)/api/info"
    $publicUrl = "https://$($Config.serverName)/$($Environment.path)"
    $listeners = @(Get-DeploymentListeners $Environment.port | Select-Object -ExpandProperty OwningProcess -Unique)
    foreach ($processId in $listeners) {
        $process = Get-CimInstance Win32_Process -Filter "ProcessId = $processId" -ErrorAction Stop
        if (!$process) { continue }
        if (!(Test-DeploymentProcessOwner $process $nodePaths $applicationRoot $runtimeTools $probeUrl $publicUrl)) {
            throw "Port $($Environment.port) is owned by PID $processId, but ownership by $taskName cannot be verified from its executable, command line, launcher or local portal identity. No process was terminated. Review that PID and the configured environment before retrying."
        }
        $owned += $process
    }
    $task = $null
    try { $task = Get-ScheduledTask -TaskName $taskName -TaskPath '\' -ErrorAction Stop }
    catch {
        if ($_.FullyQualifiedErrorId -notlike 'CmdletizationQuery_NotFound*') { throw }
    }
    if ($task) {
        Stop-ScheduledTask -TaskName $taskName -TaskPath '\' -ErrorAction Stop
    }
    foreach ($process in $owned) {
        $processId = $process.ProcessId
        try { Wait-Process -Id $processId -Timeout $GraceSeconds -ErrorAction Stop }
        catch {
            if ($_.FullyQualifiedErrorId -notmatch '^(ProcessNotTerminated|NoProcessFoundForGivenId),') { throw }
        }
        $remaining = Get-CimInstance Win32_Process -Filter "ProcessId = $processId" -ErrorAction Stop
        if (!$remaining) { continue }
        if ($remaining.CreationDate -ne $process.CreationDate -or
            $remaining.ExecutablePath -ine $process.ExecutablePath -or $remaining.CommandLine -cne $process.CommandLine) {
            throw "PID $processId changed identity while stopping $taskName. No replacement process was terminated."
        }
        Write-Warning "Task $taskName left its verified Node backend running. Stopping only PID $processId on port $($Environment.port)."
        Stop-Process -Id $processId -Force -ErrorAction Stop
        try { Wait-Process -Id $processId -Timeout 10 -ErrorAction Stop }
        catch {
            if ($_.FullyQualifiedErrorId -notmatch '^NoProcessFoundForGivenId,') { throw }
        }
    }
    $remainingListeners = @(Get-DeploymentListeners $Environment.port)
    if ($remainingListeners.Count) {
        $owners = ($remainingListeners | Select-Object -ExpandProperty OwningProcess -Unique) -join ', '
        throw "Backend $taskName did not release port $($Environment.port); listener PID(s): $owners. No application files have been replaced. Review task restart/trigger behavior and process ownership."
    }
}

function Test-IisPrerequisites {
    $modules = @(Get-WebGlobalModule | Select-Object -ExpandProperty Name)
    foreach ($name in @('RewriteModule', 'ApplicationRequestRouting')) {
        if ($name -notin $modules) {
            throw "Required IIS module is missing: $name. Ask the server administrator to install URL Rewrite and ARR, then rerun setup. This package contains no prerequisite installers."
        }
    }
}

function Assert-DeploymentServer([string]$ComputerName, [string]$ServerName) {
    $expectedComputer = $ServerName.Split('.')[0]
    if ($ComputerName -ine $expectedComputer) { throw "Run this installer on $ServerName ($expectedComputer), not $ComputerName." }
}

function Test-ManagedPortalCertificate($Certificate, [string]$ServerName, [datetime]$Now = (Get-Date)) {
    $dnsNames = @($Certificate.DnsNameList | ForEach-Object { $_.Unicode })
    return ($Certificate.FriendlyName -eq 'CETFalcon portal TLS' -and
        $Certificate.HasPrivateKey -and $Certificate.NotBefore -le $Now -and
        $Certificate.NotAfter -gt $Now.AddDays(30) -and $dnsNames -contains $ServerName)
}

function Assert-PortalCertificateIdentity($Certificate, [string]$ServerName, [datetime]$Now = (Get-Date)) {
    if (!$Certificate.HasPrivateKey) { throw 'The selected HTTPS certificate has no private key on this server. Enroll a server certificate using certlm.msc.' }
    if ($Certificate.NotBefore -gt $Now -or $Certificate.NotAfter -le $Now.AddDays(30)) {
        throw 'The selected HTTPS certificate is not yet valid, expired, or expires within 30 days. Renew it and verify the server clock.'
    }
    $san = @($Certificate.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.17' })
    if (!$san.Count) { throw "The selected HTTPS certificate has no SAN extension covering $ServerName." }
    $matchesHost = $false
    foreach ($name in $Certificate.DnsNameList) {
        $dnsName = $name.Unicode
        if ($dnsName -ieq $ServerName -or
            ($dnsName.StartsWith('*.') -and $ServerName.EndsWith($dnsName.Substring(1), [StringComparison]::OrdinalIgnoreCase) -and
             $ServerName.Split('.').Length -eq $dnsName.Split('.').Length)) { $matchesHost = $true }
    }
    if (!$matchesHost) { throw "The selected HTTPS certificate SAN does not cover $ServerName." }
    if ($Certificate.Subject -eq $Certificate.Issuer) {
        throw 'The selected HTTPS certificate is self-issued. This option requires a CA-issued server certificate, not another self-signed certificate.'
    }
    $serverAuthentication = @($Certificate.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.37' } |
        ForEach-Object { $_.EnhancedKeyUsages } | Where-Object { $_.Value -eq '1.3.6.1.5.5.7.3.1' })
    if (!$serverAuthentication.Count) { throw 'The selected HTTPS certificate must explicitly include the Server Authentication extended key usage.' }
}

function Get-TrustedPortalCertificate([string]$Thumbprint, [string]$ServerName) {
    $normalized = [regex]::Replace($Thumbprint, '\s', '').ToUpperInvariant()
    if ($normalized -notmatch '^[A-F0-9]{40}$') { throw 'CertificateThumbprint must be the 40 hexadecimal characters from the certificate Thumbprint property, not its SHA-256 fingerprint.' }
    $certificate = Get-Item -LiteralPath "Cert:\LocalMachine\My\$normalized" -ErrorAction Stop
    Assert-PortalCertificateIdentity $certificate $ServerName
    $chain = New-Object Security.Cryptography.X509Certificates.X509Chain
    try {
        $chain.ChainPolicy.RevocationMode = [Security.Cryptography.X509Certificates.X509RevocationMode]::Online
        $chain.ChainPolicy.VerificationFlags = [Security.Cryptography.X509Certificates.X509VerificationFlags]::NoFlag
        $chain.ChainPolicy.UrlRetrievalTimeout = [TimeSpan]::FromSeconds(10)
        $null = $chain.ChainPolicy.ApplicationPolicy.Add((New-Object Security.Cryptography.Oid('1.3.6.1.5.5.7.3.1')))
        if (!$chain.Build($certificate)) {
            $problems = ($chain.ChainStatus | ForEach-Object { "$($_.Status): $($_.StatusInformation.Trim())" }) -join '; '
            throw "The selected HTTPS certificate failed Windows chain/revocation validation on this server: $problems. Resolve the CA chain or revocation access before retrying; setup will not fall back to a self-signed certificate."
        }
    } finally { $chain.Dispose() }
    return $certificate
}

function Save-ProtectedJson($Path, $Value, [switch]$Machine) {
    $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
    if ($Machine) { $scope = [Security.Cryptography.DataProtectionScope]::LocalMachine }
    $bytes = [Text.Encoding]::UTF8.GetBytes(($Value | ConvertTo-Json -Depth 12 -Compress))
    try {
        $protected = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, $scope)
        [IO.File]::WriteAllBytes($Path, $protected)
    } finally { [Array]::Clear($bytes, 0, $bytes.Length) }
}

function Read-ProtectedJson($Path, [switch]$Machine) {
    $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
    if ($Machine) { $scope = [Security.Cryptography.DataProtectionScope]::LocalMachine }
    $bytes = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($Path), $null, $scope)
    try { return [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json }
    finally { [Array]::Clear($bytes, 0, $bytes.Length) }
}

function Read-LocalSecret($Prompt) {
    $secure = Read-Host $Prompt -AsSecureString
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}

function Get-SqlConnectionString($Config, $Password) {
    if ($Config.sqlTrustServerCertificate) {
        Write-Warning 'Temporary SQL trust exception: encryption is enabled, but SQL server certificate identity is NOT verified. Applies to every environment using this configuration. Restore certificate verification after IT configures trusted SQL TLS.'
    }
    $builder = New-Object Data.SqlClient.SqlConnectionStringBuilder
    $builder['Data Source'] = $Config.sqlServer
    $builder['Initial Catalog'] = $Config.database
    $builder['User ID'] = $Config.sqlUsername
    $builder['Password'] = $Password
    $builder['Encrypt'] = $true
    $builder['TrustServerCertificate'] = [bool]$Config.sqlTrustServerCertificate
    $builder['Connect Timeout'] = 15
    return $builder.ConnectionString
}

function Invoke-Sql($Connection, $Statement, $Parameters = @{}, [switch]$Scalar) {
    $command = $Connection.CreateCommand()
    try {
        $command.CommandText = $Statement
        $command.CommandTimeout = 180
        foreach ($key in $Parameters.Keys) { $null = $command.Parameters.AddWithValue("@$key", $Parameters[$key]) }
        if ($Scalar) { return $command.ExecuteScalar() }
        $null = $command.ExecuteNonQuery()
    } finally { $command.Dispose() }
}

function Assert-SqlDeploymentBaseline($Connection) {
    $statement = @'
SELECT
 CASE WHEN OBJECT_ID(N'dbo.Users', N'U') IS NULL
      THEN N'dbo.Users is missing or not visible (001_DFM_Schema.sql). ' ELSE N'' END +
 CASE WHEN OBJECT_ID(N'dbo.AuditLog', N'U') IS NULL
      THEN N'dbo.AuditLog is missing or not visible (001_DFM_Schema.sql). ' ELSE N'' END +
 CASE WHEN COL_LENGTH(N'dbo.Users', N'DirectoryAccount') IS NULL
      THEN N'dbo.Users.DirectoryAccount is missing or not visible (001_DFM_Schema.sql). ' ELSE N'' END +
 CASE WHEN COL_LENGTH(N'dbo.JiraIssues', N'Labels') IS NULL
      THEN N'dbo.JiraIssues.Labels is missing or not visible (007_Jira_Additional_Fields.sql). ' ELSE N'' END +
 CASE WHEN OBJECT_ID(N'dbo.sp_SaveBudgetLine', N'P') IS NULL
      THEN N'dbo.sp_SaveBudgetLine is missing or not visible (012_Budget_Lines_Before_Approval.sql). '
      WHEN OBJECT_DEFINITION(OBJECT_ID(N'dbo.sp_SaveBudgetLine', N'P')) IS NULL
      THEN N'dbo.sp_SaveBudgetLine definition cannot be inspected; ask the DBA to check VIEW DEFINITION permission or an encrypted procedure. '
      WHEN OBJECT_DEFINITION(OBJECT_ID(N'dbo.sp_SaveBudgetLine', N'P')) NOT LIKE N'%Pending Approval%'
      THEN N'dbo.sp_SaveBudgetLine does not include the migration 012 budget-line workflow (012_Budget_Lines_Before_Approval.sql). '
      ELSE N'' END;
'@
    $problems = Invoke-Sql $Connection $statement -Scalar
    if ($problems) {
        throw "Existing database baseline check failed: $problems SQL connected successfully; this is not a SQL TLS certificate error. Have the DBA review the listed objects, metadata permissions and migrations in the package's database folder. Do not replay 001 against an existing database or run seed script 011. Setup will not replay destructive scripts."
    }
}

function Test-PackageManifest($Root) {
    $manifest = Join-Path $Root 'manifest.json'
    if (!(Test-Path $manifest)) { throw 'Package manifest is missing. Extract the entire deployment ZIP.' }
    foreach ($entry in (Get-Content $manifest -Raw | ConvertFrom-Json).files) {
        $file = [IO.Path]::GetFullPath((Join-Path $Root $entry.path))
        if (!$file.StartsWith([IO.Path]::GetFullPath($Root).TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Invalid package path.'
        }
        if (!(Test-Path $file) -or (Get-FileHash $file -Algorithm SHA256).Hash -ne $entry.sha256) {
            throw "Package file missing or changed: $($entry.path). Extract a fresh package."
        }
    }
}