Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
Add-Type -AssemblyName System.Data

function Test-NodeVersion([string]$Version) {
    if ($Version -notmatch '^v(24|25|26)\.\d+\.\d+$') {
        throw "Node.js 24-26 is required; found '$Version'. Install a supported machine-wide Node version."
    }
}

function Resolve-ServerNode([string]$NodePath) {
    if (!$NodePath) { $NodePath = Join-Path $env:ProgramFiles 'nodejs\node.exe' }
    if (![IO.Path]::IsPathRooted($NodePath) -or !(Test-Path -LiteralPath $NodePath -PathType Leaf)) {
        throw "Node executable not found: $NodePath. Install Node.js 24-26 machine-wide or pass -NodePath with its absolute node.exe path."
    }
    $resolved = (Get-Item -LiteralPath $NodePath).FullName
    $version = & $resolved --version
    if ($LASTEXITCODE -ne 0) { throw "Unable to run Node executable: $resolved" }
    Test-NodeVersion ([string]$version)
    return $resolved
}

function Test-IisPrerequisites {
    $modules = @(Get-WebGlobalModule | Select-Object -ExpandProperty Name)
    foreach ($name in @('RewriteModule', 'ApplicationRequestRouting')) {
        if ($name -notin $modules) {
            throw "Required IIS module is missing: $name. Ask the server administrator to install URL Rewrite and ARR, then rerun setup. This package contains no prerequisite installers."
        }
    }
}

function Assert-DeploymentServer([string]$ComputerName, [string]$ServerName) {
    $expectedComputer = $ServerName.Split('.')[0]
    if ($ComputerName -ine $expectedComputer) { throw "Run this installer on $ServerName ($expectedComputer), not $ComputerName." }
}

function Test-ManagedPortalCertificate($Certificate, [string]$ServerName, [datetime]$Now = (Get-Date)) {
    $dnsNames = @($Certificate.DnsNameList | ForEach-Object { $_.Unicode })
    return ($Certificate.FriendlyName -eq 'CETFalcon portal TLS' -and
        $Certificate.HasPrivateKey -and $Certificate.NotBefore -le $Now -and
        $Certificate.NotAfter -gt $Now.AddDays(30) -and $dnsNames -contains $ServerName)
}

function Save-ProtectedJson($Path, $Value, [switch]$Machine) {
    $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
    if ($Machine) { $scope = [Security.Cryptography.DataProtectionScope]::LocalMachine }
    $bytes = [Text.Encoding]::UTF8.GetBytes(($Value | ConvertTo-Json -Depth 12 -Compress))
    try {
        $protected = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, $scope)
        [IO.File]::WriteAllBytes($Path, $protected)
    } finally { [Array]::Clear($bytes, 0, $bytes.Length) }
}

function Read-ProtectedJson($Path, [switch]$Machine) {
    $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
    if ($Machine) { $scope = [Security.Cryptography.DataProtectionScope]::LocalMachine }
    $bytes = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($Path), $null, $scope)
    try { return [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json }
    finally { [Array]::Clear($bytes, 0, $bytes.Length) }
}

function Read-LocalSecret($Prompt) {
    $secure = Read-Host $Prompt -AsSecureString
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}

function Get-SqlConnectionString($Config, $Password) {
    if ($Config.sqlTrustServerCertificate) {
        Write-Warning 'Temporary SQL trust exception: encryption is enabled, but SQL server certificate identity is NOT verified. Applies to every environment using this configuration. Restore certificate verification after IT configures trusted SQL TLS.'
    }
    $builder = New-Object Data.SqlClient.SqlConnectionStringBuilder
    $builder['Data Source'] = $Config.sqlServer
    $builder['Initial Catalog'] = $Config.database
    $builder['User ID'] = $Config.sqlUsername
    $builder['Password'] = $Password
    $builder['Encrypt'] = $true
    $builder['TrustServerCertificate'] = [bool]$Config.sqlTrustServerCertificate
    $builder['Connect Timeout'] = 15
    return $builder.ConnectionString
}

function Invoke-Sql($Connection, $Statement, $Parameters = @{}, [switch]$Scalar) {
    $command = $Connection.CreateCommand()
    try {
        $command.CommandText = $Statement
        $command.CommandTimeout = 180
        foreach ($key in $Parameters.Keys) { $null = $command.Parameters.AddWithValue("@$key", $Parameters[$key]) }
        if ($Scalar) { return $command.ExecuteScalar() }
        $null = $command.ExecuteNonQuery()
    } finally { $command.Dispose() }
}

function Assert-SqlDeploymentBaseline($Connection) {
    $statement = @'
SELECT
 CASE WHEN OBJECT_ID(N'dbo.Users', N'U') IS NULL
      THEN N'dbo.Users is missing or not visible (001_DFM_Schema.sql). ' ELSE N'' END +
 CASE WHEN OBJECT_ID(N'dbo.AuditLog', N'U') IS NULL
      THEN N'dbo.AuditLog is missing or not visible (001_DFM_Schema.sql). ' ELSE N'' END +
 CASE WHEN COL_LENGTH(N'dbo.Users', N'DirectoryAccount') IS NULL
      THEN N'dbo.Users.DirectoryAccount is missing or not visible (001_DFM_Schema.sql). ' ELSE N'' END +
 CASE WHEN COL_LENGTH(N'dbo.JiraIssues', N'Labels') IS NULL
      THEN N'dbo.JiraIssues.Labels is missing or not visible (007_Jira_Additional_Fields.sql). ' ELSE N'' END +
 CASE WHEN OBJECT_ID(N'dbo.sp_SaveBudgetLine', N'P') IS NULL
      THEN N'dbo.sp_SaveBudgetLine is missing or not visible (012_Budget_Lines_Before_Approval.sql). '
      WHEN OBJECT_DEFINITION(OBJECT_ID(N'dbo.sp_SaveBudgetLine', N'P')) IS NULL
      THEN N'dbo.sp_SaveBudgetLine definition cannot be inspected; ask the DBA to check VIEW DEFINITION permission or an encrypted procedure. '
      WHEN OBJECT_DEFINITION(OBJECT_ID(N'dbo.sp_SaveBudgetLine', N'P')) NOT LIKE N'%Pending Approval%'
      THEN N'dbo.sp_SaveBudgetLine does not include the migration 012 budget-line workflow (012_Budget_Lines_Before_Approval.sql). '
      ELSE N'' END;
'@
    $problems = Invoke-Sql $Connection $statement -Scalar
    if ($problems) {
        throw "Existing database baseline check failed: $problems SQL connected successfully; this is not a SQL TLS certificate error. Have the DBA review the listed objects, metadata permissions and migrations in the package's database folder. Do not replay 001 against an existing database or run seed script 011. Setup will not replay destructive scripts."
    }
}

function Test-PackageManifest($Root) {
    $manifest = Join-Path $Root 'manifest.json'
    if (!(Test-Path $manifest)) { throw 'Package manifest is missing. Extract the entire deployment ZIP.' }
    foreach ($entry in (Get-Content $manifest -Raw | ConvertFrom-Json).files) {
        $file = [IO.Path]::GetFullPath((Join-Path $Root $entry.path))
        if (!$file.StartsWith([IO.Path]::GetFullPath($Root).TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Invalid package path.'
        }
        if (!(Test-Path $file) -or (Get-FileHash $file -Algorithm SHA256).Hash -ne $entry.sha256) {
            throw "Package file missing or changed: $($entry.path). Extract a fresh package."
        }
    }
}