@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Server.ps1"
if errorlevel 1 echo Deployment did not complete. Review the error above before retrying.
pause