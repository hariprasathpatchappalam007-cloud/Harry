USE DFM;
GO
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'dbo.DfmHelperDevices', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.DfmHelperDevices(
  DeviceId varchar(43) NOT NULL PRIMARY KEY,
  UserId int NOT NULL REFERENCES dbo.Users(UserId),
  SecretHash varbinary(32) NOT NULL UNIQUE,
  PcName nvarchar(100) NOT NULL,
  CreatedUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),
  Revoked bit NOT NULL DEFAULT 0
 );
 CREATE INDEX IX_DfmHelperDevices_User ON dbo.DfmHelperDevices(UserId,Revoked);
END;
GO

IF OBJECT_ID(N'dbo.DfmHelperDeviceRequests', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.DfmHelperDeviceRequests(
  RequestId varchar(43) NOT NULL PRIMARY KEY,
  UserId int NOT NULL REFERENCES dbo.Users(UserId),
  SecretHash varbinary(32) NOT NULL UNIQUE,
  PcName nvarchar(100) NOT NULL,
  Reference varchar(8) NOT NULL UNIQUE,
  CreatedUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),
  ExpiresUtc datetime2 NOT NULL,
  Status nvarchar(20) NOT NULL,
  DeviceId varchar(43) NULL REFERENCES dbo.DfmHelperDevices(DeviceId),
  DecidedBy nvarchar(254) NULL,
  CONSTRAINT CK_DfmHelperDeviceRequests_Status CHECK(Status IN (N'pending',N'approved',N'rejected',N'expired'))
 );
 CREATE INDEX IX_DfmHelperDeviceRequests_UserCreated ON dbo.DfmHelperDeviceRequests(UserId,CreatedUtc DESC);
 CREATE INDEX IX_DfmHelperDeviceRequests_Status ON dbo.DfmHelperDeviceRequests(Status,CreatedUtc DESC);
END;
GO

IF OBJECT_ID(N'dbo.DfmHelperTickets', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.DfmHelperTickets(
  TicketId varchar(43) NOT NULL PRIMARY KEY,
  SecretHash varbinary(32) NOT NULL,
  ExpiresUtc datetime2 NOT NULL,
  UserId int NULL REFERENCES dbo.Users(UserId),
  DeviceId varchar(43) NULL REFERENCES dbo.DfmHelperDevices(DeviceId)
 );
 CREATE INDEX IX_DfmHelperTickets_Expires ON dbo.DfmHelperTickets(ExpiresUtc);
END;
GO

IF OBJECT_ID(N'dbo.DfmHelperSessions', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.DfmHelperSessions(
  SessionHash varbinary(32) NOT NULL PRIMARY KEY,
  UserId int NOT NULL REFERENCES dbo.Users(UserId),
  DeviceId varchar(43) NOT NULL REFERENCES dbo.DfmHelperDevices(DeviceId),
  ExpiresUtc datetime2 NOT NULL,
  CreatedUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME()
 );
 CREATE INDEX IX_DfmHelperSessions_Expires ON dbo.DfmHelperSessions(ExpiresUtc);
 CREATE INDEX IX_DfmHelperSessions_User ON dbo.DfmHelperSessions(UserId,ExpiresUtc);
END;
GO

IF OBJECT_ID(N'dbo.DfmHelperEnrollment', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.DfmHelperEnrollment(
  CodeHash varbinary(32) NOT NULL PRIMARY KEY,
  UserId int NOT NULL REFERENCES dbo.Users(UserId),
  ExpiresUtc datetime2 NOT NULL,
  Used bit NOT NULL DEFAULT 0,
  CreatedUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME()
 );
 CREATE INDEX IX_DfmHelperEnrollment_Expires ON dbo.DfmHelperEnrollment(ExpiresUtc);
END;
GO