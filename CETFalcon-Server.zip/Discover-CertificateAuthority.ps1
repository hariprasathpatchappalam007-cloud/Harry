param([string]$CAConfig)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$certutil = Join-Path $env:SystemRoot 'System32\certutil.exe'
if (!(Test-Path -LiteralPath $certutil -PathType Leaf)) { throw "Windows certificate utility not found: $certutil" }

Write-Host 'Read-only certificate authority discovery. No certificates will be requested or imported.'
if ($CAConfig) {
    Write-Host "Published templates and reported enrollment access for $CAConfig"
    $details = @(& $certutil -config $CAConfig -CATemplates)
} else {
    Write-Host 'Enterprise certification authorities visible in Active Directory:'
    $details = @(& $certutil -ADCA)
}
$details | Write-Output
if ($LASTEXITCODE -ne 0) {
    throw "Certificate authority discovery failed (certutil exit code $LASTEXITCODE). Review the error above and verify domain connectivity and your existing account permissions."
}
if (![string]::Join([Environment]::NewLine, $details).Trim()) {
    throw 'Certificate authority discovery returned no details. Verify domain connectivity and existing CA visibility; no CA host/name or template can be inferred from an empty response.'
}
Write-Host 'Discovery does not grant enrollment permission or prove that a user workstation trusts a CA.'
Write-Host 'Use certlm.msc on the website server to inspect available Computer/Personal certificate enrollment templates.'
