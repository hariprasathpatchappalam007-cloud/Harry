param([string]$CAConfig)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$certutil = Join-Path $env:SystemRoot 'System32\certutil.exe'
if (!(Test-Path -LiteralPath $certutil -PathType Leaf)) { throw "Windows certificate utility not found: $certutil" }

Write-Host 'Read-only certificate authority discovery. No certificates will be requested or imported.'
if ($CAConfig) {
    Write-Host "Published templates and reported enrollment access for $CAConfig"
    & $certutil -config $CAConfig -CATemplates
} else {
    Write-Host 'Enterprise certification authorities visible in Active Directory:'
    & $certutil -ADCA
}
if ($LASTEXITCODE -ne 0) {
    throw "Certificate authority discovery failed (certutil exit code $LASTEXITCODE). Review the error above and verify domain connectivity and your existing account permissions."
}
Write-Host 'Discovery does not grant enrollment permission or prove that a user workstation trusts a CA.'
Write-Host 'Use certlm.msc on the website server to inspect available Computer/Personal certificate enrollment templates.'
