import {secretHash, token} from './helper-crypto.js';

const ADMIN_LOOKUP = `
SELECT u.UserId,u.Email
FROM dbo.Users u
WHERE LOWER(u.Email)=LOWER(@email) AND u.IsActive=1
 AND EXISTS(
  SELECT 1 FROM dbo.UserRoles ur JOIN dbo.Roles r ON r.RoleId=ur.RoleId
  WHERE ur.UserId=u.UserId AND r.Name IN(N'Admin',N'Master')
 );`;

export async function issueHelperEnrollment({database, email, now = new Date(), createCode = token}) {
  const normalizedEmail = String(email || '').trim();
  if (!normalizedEmail) throw new Error('An administrator email is required.');

  const users = await database.query(ADMIN_LOOKUP, {email: normalizedEmail});
  if (users.length !== 1) throw new Error('The email must match one active Admin or Master account.');

  const code = createCode();
  const expires = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  await database.execute(`SET XACT_ABORT ON; BEGIN TRAN;
IF NOT EXISTS(SELECT 1 FROM dbo.Users u JOIN dbo.UserRoles ur ON ur.UserId=u.UserId JOIN dbo.Roles r ON r.RoleId=ur.RoleId
 WHERE u.UserId=@userId AND u.IsActive=1 AND r.Name IN(N'Admin',N'Master'))
 THROW 50124,'The administrator account is no longer active.',1;
INSERT dbo.DfmHelperEnrollment(CodeHash,UserId,ExpiresUtc) VALUES(@codeHash,@userId,@expires);
INSERT dbo.AuditLog(EntityType,EntityId,ActionName,UserEmail,Detail)
 VALUES(N'HelperDevice',NULL,N'device.bootstrap-enrollment.issue',@email,@detail);
COMMIT;`, {
    userId: users[0].userId,
    codeHash: secretHash(code),
    expires,
    email: users[0].email,
    detail: JSON.stringify({expiresUtc: expires.toISOString()})
  });

  return {code, email: users[0].email, expires};
}