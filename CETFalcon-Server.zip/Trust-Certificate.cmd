@echo off
setlocal
cd /d "%~dp0"
echo One-time certificate trust for ALL USERS of this PC.
echo Right-click this command and choose Run as administrator.
echo Keep DFM-Helper-Setup.exe beside this command. Select the public CETFalcon.cer when prompted.
if not exist "%~dp0DFM-Helper-Setup.exe" (
    echo DFM-Helper-Setup.exe is missing. Extract or copy the complete user-distribution folder.
    pause
    exit /b 1
)
"%~dp0DFM-Helper-Setup.exe" --trust-machine %*
set "result=%errorlevel%"
if not "%result%"=="0" echo Certificate trust or portal validation did not complete. Review the error dialog.
pause
exit /b %result%
