import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import {findWindowsUser, publicUser} from './auth.js';
import {asyncRoute} from './errors.js';
import {cookieValue, secretHash, token} from './helper-crypto.js';

const DEVICE_LOOKUP = `
SELECT d.DeviceId,d.UserId,d.PcName,u.Email,u.DisplayName,u.DirectoryAccount,
 STUFF((SELECT ',' + r.Name FROM dbo.UserRoles ur JOIN dbo.Roles r ON r.RoleId=ur.RoleId WHERE ur.UserId=u.UserId FOR XML PATH('')),1,1,'') Roles
FROM dbo.DfmHelperDevices d
JOIN dbo.Users u ON u.UserId=d.UserId
WHERE d.SecretHash=@secretHash AND d.Revoked=0 AND u.IsActive=1;`;

function httpError(status, message) {
  return Object.assign(new Error(message), {status});
}

function bearer(request) {
  return String(request.get('authorization') || '').replace(/^Bearer\s+/i, '');
}

async function helperDevice(database, secret) {
  if (!/^[a-f0-9]{64}$/i.test(secret) && !/^[A-Za-z0-9_-]{43}$/.test(secret)) return null;
  const rows = await database.query(DEVICE_LOOKUP, {secretHash: secretHash(secret)});
  if (rows.length !== 1) return null;
  return {...publicUser(rows[0]), deviceId: rows[0].deviceId, pcName: rows[0].pcName, authentication: 'helper-device'};
}

async function audit(database, actor, action, detail) {
  await database.execute(
    "INSERT dbo.AuditLog(EntityType,EntityId,ActionName,UserEmail,Detail) VALUES(N'HelperDevice',NULL,@action,@actor,@detail)",
    {action, actor, detail: JSON.stringify(detail)}
  );
}

export async function cleanupHelperAuthentication(database) {
  await database.execute(`
UPDATE dbo.DfmHelperDeviceRequests SET Status=N'expired' WHERE Status=N'pending' AND ExpiresUtc<=SYSUTCDATETIME();
DELETE FROM dbo.DfmHelperTickets WHERE ExpiresUtc<=SYSUTCDATETIME();
DELETE FROM dbo.DfmHelperSessions WHERE ExpiresUtc<=SYSUTCDATETIME();
DELETE FROM dbo.DfmHelperEnrollment WHERE ExpiresUtc<=SYSUTCDATETIME() OR Used=1;`);
}

export function createHelperRouter({database, authentication, config}) {
  const router = express.Router();
  const {authenticate, requireRoles} = authentication;

  async function authenticateHelper(request, response, next) {
    try {
      const device = await helperDevice(database, bearer(request));
      if (!device) return response.status(401).json({message: 'DFM Helper enrollment is required.', error: 'DFM Helper enrollment is required.'});
      request.user = device;
      request.device = device;
      next();
    } catch (error) {
      next(error);
    }
  }

  router.get('/info', (request, response) => {
    const installerPath = path.join(config.downloadRoot, 'DFM-Helper-Setup.exe');
    response.json({
      publicUrl: config.publicUrl,
      helperPort: config.helperPort,
      installerAvailable: fs.existsSync(installerPath),
      authentication: 'dfm-helper'
    });
  });

  router.post('/auth/ticket', asyncRoute(async (request, response) => {
    const id = token();
    const secret = token();
    await database.execute(
      'INSERT dbo.DfmHelperTickets(TicketId,SecretHash,ExpiresUtc) VALUES(@id,@secretHash,@expires)',
      {id, secretHash: secretHash(secret), expires: new Date(Date.now() + 5 * 60 * 1000)}
    );
    response.json({id, secret});
  }));

  router.post('/auth/claim', asyncRoute(async (request, response) => {
    const id = String(request.body?.id || '');
    const secret = String(request.body?.secret || '');
    const tickets = id && secret ? await database.query(
      'SELECT TicketId,UserId,DeviceId FROM dbo.DfmHelperTickets WHERE TicketId=@id AND SecretHash=@secretHash AND ExpiresUtc>SYSUTCDATETIME()',
      {id, secretHash: secretHash(secret)}
    ) : [];
    if (tickets.length !== 1) throw httpError(400, 'Connection request expired. Try again.');
    if (!tickets[0].userId) return response.json({waiting: true});

    const users = await database.query(DEVICE_LOOKUP.replace('d.SecretHash=@secretHash', 'd.DeviceId=@deviceId AND d.UserId=@userId'), {
      deviceId: tickets[0].deviceId,
      userId: tickets[0].userId
    });
    if (users.length !== 1) throw httpError(403, 'This helper device or DFM account is no longer enabled.');

    const session = token();
    await database.execute(`SET XACT_ABORT ON; BEGIN TRAN;
IF NOT EXISTS(SELECT 1 FROM dbo.DfmHelperTickets WITH(UPDLOCK,HOLDLOCK) WHERE TicketId=@ticketId AND SecretHash=@ticketHash AND UserId=@userId AND DeviceId=@deviceId AND ExpiresUtc>SYSUTCDATETIME())
 THROW 50120,'Connection request expired or already claimed.',1;
INSERT dbo.DfmHelperSessions(SessionHash,UserId,DeviceId,ExpiresUtc) VALUES(@sessionHash,@userId,@deviceId,@expires);
DELETE FROM dbo.DfmHelperTickets WHERE TicketId=@ticketId;
COMMIT;`, {
      ticketId: id,
      ticketHash: secretHash(secret),
      sessionHash: secretHash(session),
      userId: tickets[0].userId,
      deviceId: tickets[0].deviceId,
      expires: new Date(Date.now() + 8 * 60 * 60 * 1000)
    });
    response.cookie(config.sessionCookieName, session, {
      httpOnly: true,
      sameSite: 'strict',
      secure: config.publicUrl.startsWith('https:'),
      path: config.basePath || '/',
      maxAge: 8 * 60 * 60 * 1000
    });
    response.json({user: {...publicUser(users[0]), authentication: 'helper'}});
  }));

  router.post('/auth/logout', asyncRoute(async (request, response) => {
    const session = cookieValue(request, config.sessionCookieName);
    if (session) await database.execute('DELETE FROM dbo.DfmHelperSessions WHERE SessionHash=@sessionHash', {sessionHash: secretHash(session)});
    response.clearCookie(config.sessionCookieName, {path: config.basePath || '/'});
    response.json({ok: true});
  }));

  router.post('/helper/eligibility', asyncRoute(async (request, response) => {
    const user = await findWindowsUser(database, request.body?.username);
    if (!user) throw httpError(403, 'This Windows account is not enabled for DFM. Contact the DFM administrator.');
    response.json({eligible: true, user: {email: user.email, displayName: user.displayName}});
  }));

  router.post('/helper/requests', asyncRoute(async (request, response) => {
    const installation = String(request.body?.secret || '');
    if (!/^[a-f0-9]{64}$/.test(installation)) throw httpError(400, 'Invalid installation credential.');
    const user = await findWindowsUser(database, request.body?.username);
    if (!user) throw httpError(403, 'Only enabled DFM users may request access.');
    const hash = secretHash(installation);
    const existing = await database.query('SELECT RequestId,UserId,Reference,Status FROM dbo.DfmHelperDeviceRequests WHERE SecretHash=@secretHash', {secretHash: hash});
    if (existing.length) {
      if (existing[0].userId !== user.userId) throw httpError(403, 'Account mismatch.');
      return response.json({id: existing[0].requestId, reference: existing[0].reference, status: existing[0].status});
    }
    const recent = await database.query('SELECT COUNT(*) RequestCount FROM dbo.DfmHelperDeviceRequests WHERE UserId=@userId AND CreatedUtc>DATEADD(DAY,-1,SYSUTCDATETIME())', {userId: user.userId});
    if (Number(recent[0]?.requestCount) >= 5) throw httpError(429, 'Too many device requests today. Contact the administrator.');
    const id = token();
    const reference = secretHash(`${id}:${Date.now()}`).toString('hex').slice(0, 8).toUpperCase();
    const pcName = String(request.body?.pcName || 'Unknown PC').trim().slice(0, 100) || 'Unknown PC';
    await database.execute(`INSERT dbo.DfmHelperDeviceRequests(RequestId,UserId,SecretHash,PcName,Reference,ExpiresUtc,Status)
      VALUES(@id,@userId,@secretHash,@pcName,@reference,@expires,N'pending')`, {
      id, userId: user.userId, secretHash: hash, pcName, reference, expires: new Date(Date.now() + 24 * 60 * 60 * 1000)
    });
    await audit(database, user.email, 'device.request', {requestId: id, reference, pcName});
    response.json({id, reference, status: 'pending'});
  }));

  router.post('/helper/requests/status', asyncRoute(async (request, response) => {
    const rows = await database.query(`SELECT r.Status,r.Reference,r.DeviceId,d.Revoked,u.IsActive,r.ExpiresUtc
FROM dbo.DfmHelperDeviceRequests r
JOIN dbo.Users u ON u.UserId=r.UserId
LEFT JOIN dbo.DfmHelperDevices d ON d.DeviceId=r.DeviceId
WHERE r.RequestId=@id AND r.SecretHash=@secretHash`, {
      id: String(request.body?.id || ''),
      secretHash: secretHash(request.body?.secret)
    });
    if (rows.length !== 1) throw httpError(403, 'Device request not found.');
    const row = rows[0];
    if (!row.isActive) throw httpError(403, 'Your DFM account is no longer enabled.');
    if (row.status === 'pending' && new Date(row.expiresUtc).getTime() <= Date.now()) {
      await database.execute("UPDATE dbo.DfmHelperDeviceRequests SET Status=N'expired' WHERE RequestId=@id AND Status=N'pending'", {id: request.body.id});
      row.status = 'expired';
    }
    response.json({status: row.revoked ? 'revoked' : row.status, reference: row.reference, id: row.deviceId || null});
  }));

  router.post('/helper/enroll', asyncRoute(async (request, response) => {
    const code = String(request.body?.code || '');
    const user = await findWindowsUser(database, request.body?.username);
    if (!user) throw httpError(403, 'The Windows account is not enabled for DFM.');
    const rows = await database.query('SELECT UserId FROM dbo.DfmHelperEnrollment WHERE CodeHash=@codeHash AND Used=0 AND ExpiresUtc>SYSUTCDATETIME()', {codeHash: secretHash(code)});
    if (rows.length !== 1 || rows[0].userId !== user.userId) throw httpError(403, 'Enrollment code is invalid, expired, used, or belongs to another Windows account.');
    const deviceSecret = token();
    const deviceId = token();
    const pcName = String(request.body?.pcName || 'Bootstrap PC').slice(0, 100);
    await database.execute(`SET XACT_ABORT ON; BEGIN TRAN;
UPDATE dbo.DfmHelperEnrollment SET Used=1 WHERE CodeHash=@codeHash AND UserId=@userId AND Used=0 AND ExpiresUtc>SYSUTCDATETIME();
IF @@ROWCOUNT<>1 THROW 50121,'Enrollment code is no longer available.',1;
INSERT dbo.DfmHelperDevices(DeviceId,UserId,SecretHash,PcName) VALUES(@deviceId,@userId,@secretHash,@pcName);
COMMIT;`, {codeHash: secretHash(code), userId: user.userId, deviceId, secretHash: secretHash(deviceSecret), pcName});
    await audit(database, user.email, 'device.bootstrap-enroll', {deviceId, pcName});
    response.json({secret: deviceSecret, id: deviceId, user: {id: user.userId, name: user.displayName, username: user.directoryAccount}});
  }));

  router.post('/helper/approve', authenticateHelper, asyncRoute(async (request, response) => {
    const result = await database.query(`UPDATE dbo.DfmHelperTickets SET UserId=@userId,DeviceId=@deviceId
WHERE TicketId=@id AND SecretHash=@secretHash AND ExpiresUtc>SYSUTCDATETIME() AND UserId IS NULL;
SELECT @@ROWCOUNT Approved;`, {
      userId: request.user.userId,
      deviceId: request.device.deviceId,
      id: String(request.body?.id || ''),
      secretHash: secretHash(request.body?.secret)
    });
    if (Number(result[0]?.approved) !== 1) throw httpError(400, 'Connection request is expired or already approved.');
    response.json({ok: true});
  }));

  router.post('/helper/launch', authenticateHelper, asyncRoute(async (request, response) => {
    const id = token();
    const secret = token();
    await database.execute(`INSERT dbo.DfmHelperTickets(TicketId,SecretHash,ExpiresUtc,UserId,DeviceId)
      VALUES(@id,@secretHash,@expires,@userId,@deviceId)`, {
      id,
      secretHash: secretHash(secret),
      expires: new Date(Date.now() + 60 * 1000),
      userId: request.user.userId,
      deviceId: request.device.deviceId
    });
    response.json({id, secret});
  }));

  router.get('/admin/device-requests', authenticate, requireRoles('Master'), asyncRoute(async (request, response) => {
    await database.execute("UPDATE dbo.DfmHelperDeviceRequests SET Status=N'expired' WHERE Status=N'pending' AND ExpiresUtc<=SYSUTCDATETIME()");
    response.json(await database.query(`SELECT r.RequestId Id,r.PcName,r.Reference,r.CreatedUtc,r.ExpiresUtc,r.Status,r.DecidedBy,u.DisplayName,u.Email,u.DirectoryAccount,
      (SELECT COUNT(*) FROM dbo.DfmHelperDevices d WHERE d.UserId=u.UserId AND d.Revoked=0) ApprovedDevices
      FROM dbo.DfmHelperDeviceRequests r JOIN dbo.Users u ON u.UserId=r.UserId ORDER BY r.CreatedUtc DESC`));
  }));

  router.post('/admin/device-requests/:id/:decision', authenticate, requireRoles('Master'), asyncRoute(async (request, response) => {
    const approve = request.params.decision === 'approve';
    if (!approve && request.params.decision !== 'reject') throw httpError(400, 'Invalid decision.');
    const deviceId = approve ? token() : null;
    await database.execute(`SET XACT_ABORT ON; BEGIN TRAN;
DECLARE @userId int,@status nvarchar(20),@secretHash varbinary(32),@pcName nvarchar(100);
SELECT @userId=UserId,@status=Status,@secretHash=SecretHash,@pcName=PcName FROM dbo.DfmHelperDeviceRequests WITH(UPDLOCK,HOLDLOCK) WHERE RequestId=@requestId;
IF @status IS NULL OR @status<>N'pending' THROW 50122,'Request is no longer awaiting approval.',1;
IF @approve=1 AND NOT EXISTS(SELECT 1 FROM dbo.Users WHERE UserId=@userId AND IsActive=1) THROW 50123,'User must be enabled before approval.',1;
IF @approve=1 INSERT dbo.DfmHelperDevices(DeviceId,UserId,SecretHash,PcName) VALUES(@deviceId,@userId,@secretHash,@pcName);
UPDATE dbo.DfmHelperDeviceRequests SET Status=CASE WHEN @approve=1 THEN N'approved' ELSE N'rejected' END,DeviceId=CASE WHEN @approve=1 THEN @deviceId ELSE NULL END,DecidedBy=@actor WHERE RequestId=@requestId;
INSERT dbo.AuditLog(EntityType,EntityId,ActionName,UserEmail,Detail) VALUES(N'HelperDevice',NULL,CASE WHEN @approve=1 THEN N'device.request.approve' ELSE N'device.request.reject' END,@actor,@detail);
COMMIT;`, {
      requestId: request.params.id,
      approve,
      deviceId,
      actor: request.user.email,
      detail: JSON.stringify({requestId: request.params.id, deviceId})
    });
    response.json({ok: true});
  }));

  router.get('/admin/devices', authenticate, requireRoles('Master'), asyncRoute(async (request, response) => {
    response.json(await database.query(`SELECT d.DeviceId Id,d.PcName,d.CreatedUtc,d.Revoked,u.DisplayName,u.Email,u.DirectoryAccount
      FROM dbo.DfmHelperDevices d JOIN dbo.Users u ON u.UserId=d.UserId ORDER BY d.CreatedUtc DESC`));
  }));

  router.post('/admin/devices/:id/revoke', authenticate, requireRoles('Master'), asyncRoute(async (request, response) => {
    await database.execute(`SET XACT_ABORT ON; BEGIN TRAN;
UPDATE dbo.DfmHelperDevices SET Revoked=1 WHERE DeviceId=@deviceId;
DELETE FROM dbo.DfmHelperSessions WHERE DeviceId=@deviceId;
INSERT dbo.AuditLog(EntityType,EntityId,ActionName,UserEmail,Detail) VALUES(N'HelperDevice',NULL,N'device.revoke',@actor,@detail);
COMMIT;`, {deviceId: request.params.id, actor: request.user.email, detail: JSON.stringify({deviceId: request.params.id})});
    response.json({ok: true});
  }));

  router.post('/admin/enrollment', authenticate, requireRoles('Master'), asyncRoute(async (request, response) => {
    const userId = Number(request.body?.userId);
    const users = Number.isInteger(userId) ? await database.query('SELECT UserId,Email FROM dbo.Users WHERE UserId=@userId AND IsActive=1', {userId}) : [];
    if (users.length !== 1) throw httpError(400, 'Select an enabled user.');
    const code = token();
    await database.execute('INSERT dbo.DfmHelperEnrollment(CodeHash,UserId,ExpiresUtc) VALUES(@codeHash,@userId,@expires)', {
      codeHash: secretHash(code), userId, expires: new Date(Date.now() + 24 * 60 * 60 * 1000)
    });
    await audit(database, request.user.email, 'device.enrollment.issue', {userId});
    response.json({code, expiresHours: 24});
  }));

  return router;
}