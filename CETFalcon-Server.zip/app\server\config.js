import path from 'node:path';
import {fileURLToPath} from 'node:url';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function basePath(value) {
  const normalized = String(value || '').trim().replace(/\/$/, '');
  if (normalized && !/^\/[a-zA-Z0-9_/-]+$/.test(normalized)) {
    throw new Error('BASE_PATH must be empty or a URL path beginning with /.');
  }
  return normalized;
}

export function loadConfig(environment = process.env) {
  const host = environment.HOST || '127.0.0.1';
  if (environment.NODE_ENV === 'production' && !['127.0.0.1', '::1', 'localhost'].includes(host)) {
    throw new Error('Production must bind to loopback so IIS remains the only public application entry point.');
  }

  return {
    projectRoot,
    host,
    port: Number(environment.PORT) || 5100,
    basePath: basePath(environment.BASE_PATH),
    publicUrl: String(environment.PUBLIC_URL || 'http://localhost:5100').replace(/\/$/, ''),
    sqlConnectionString: environment.SQL_CONNECTION_STRING || '',
    developmentIdentity: environment.NODE_ENV === 'production' ? '' : String(environment.DEV_WINDOWS_USER || ''),
    sessionCookieName: 'dfm_session',
    helperPort: Number(environment.HELPER_PORT) || 47832,
    staticRoot: path.resolve(projectRoot, environment.STATIC_ROOT || 'public'),
    attachmentRoot: path.resolve(projectRoot, environment.ATTACHMENT_ROOT || 'data/attachments'),
    downloadRoot: path.resolve(projectRoot, environment.DOWNLOAD_ROOT || 'downloads'),
    directory: {
      url: environment.LDAP_URL || '',
      baseDn: environment.LDAP_BASE_DN || '',
      bindDn: environment.LDAP_BIND_DN || '',
      password: environment.LDAP_PASSWORD || '',
      domain: environment.LDAP_DOMAIN || '',
      defaultRole: environment.LDAP_DEFAULT_ROLE || 'Requestor'
    }
  };
}