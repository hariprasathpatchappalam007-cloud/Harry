SERVER TOO BUSY STRESS TEST APPLICATION
========================================

Target:
- Visual Studio 2012
- ASP.NET Web Forms
- C#
- .NET Framework 4.0
- IIS

PURPOSE
-------
This application is intended for a dedicated UAT/test IIS server to create
controlled worker-process pressure and help investigate ASP.NET "Server Too Busy"
conditions.

DO NOT deploy or run this test harness in Production.

QUERY PARAMETERS
----------------
cpu     CPU work in milliseconds. Range: 0-30000
delay   Synchronous request delay in milliseconds. Range: 0-30000
memory  Temporary memory allocation per request in MB. Range: 0-256
hold    true/false. Keeps the memory reference until request completion.

Examples:

1. Request/thread pressure:
   /Default.aspx?delay=10000

2. CPU pressure:
   /Default.aspx?cpu=10000

3. CPU + request/thread pressure:
   /Default.aspx?cpu=5000&delay=10000

4. Memory pressure:
   /Default.aspx?memory=100

5. Combined:
   /Default.aspx?cpu=5000&delay=10000&memory=50&hold=true

RECOMMENDED TEST APPROACH
-------------------------
Start with a single request and confirm the application works.

Then use a load-testing tool such as JMeter or another approved tool against
the UAT URL. Increase concurrency gradually, for example:

5 users -> 10 -> 25 -> 50 -> 100

Monitor:
- w3wp.exe CPU
- w3wp.exe Private Bytes / Working Set
- ASP.NET Requests Queued
- Requests Current
- IIS 5xx responses
- Request execution time
- Thread count
- Application Pool health
- Windows Application Event Log
- IIS logs

IMPORTANT
---------
The application intentionally uses synchronous work and Thread.Sleep. This can
consume ASP.NET worker threads when concurrency is increased.

The test should be performed only on an isolated/UAT server and during an
approved test window.

A "Server Too Busy" event may have multiple causes. This tool is a test
harness for reproducing worker-process/request pressure; it does not prove
that the production incident has the same root cause.
