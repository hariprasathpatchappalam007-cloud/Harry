using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Web.UI;

namespace ServerTooBusyStressApp
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int cpuMs = GetInt("cpu", 0, 0, 30000);
                int delayMs = GetInt("delay", 0, 0, 30000);
                int memoryMb = GetInt("memory", 0, 0, 256);
                bool hold = String.Equals(Request.QueryString["hold"], "true",
                    StringComparison.OrdinalIgnoreCase);

                Stopwatch sw = Stopwatch.StartNew();

                // CPU pressure: intentionally performs arithmetic work.
                if (cpuMs > 0)
                {
                    DoCpuWork(cpuMs);
                }

                // Thread/request pressure: intentionally blocks this ASP.NET request.
                if (delayMs > 0)
                {
                    Thread.Sleep(delayMs);
                }

                // Temporary per-request memory pressure.
                byte[] buffer = null;
                if (memoryMb > 0)
                {
                    buffer = new byte[memoryMb * 1024 * 1024];

                    // Touch pages so the allocation is physically used.
                    for (int i = 0; i < buffer.Length; i += 4096)
                    {
                        buffer[i] = (byte)(i % 251);
                    }
                }

                sw.Stop();

                Response.ContentType = "text/plain";
                Response.Write("Stress request completed\r\n");
                Response.Write("PID: " + Process.GetCurrentProcess().Id + "\r\n");
                Response.Write("CPU(ms): " + cpuMs + "\r\n");
                Response.Write("Delay(ms): " + delayMs + "\r\n");
                Response.Write("Memory(MB): " + memoryMb + "\r\n");
                Response.Write("Elapsed(ms): " + sw.ElapsedMilliseconds + "\r\n");

                // Keep the buffer referenced until the request finishes when requested.
                if (hold && buffer != null)
                {
                    GC.KeepAlive(buffer);
                    Thread.Sleep(1000);
                }
            }
        }

        private static int GetInt(string name, int defaultValue, int min, int max)
        {
            int value;
            if (!Int32.TryParse(
                System.Web.HttpContext.Current.Request.QueryString[name],
                out value))
            {
                return defaultValue;
            }

            if (value < min) return min;
            if (value > max) return max;
            return value;
        }

        private static void DoCpuWork(int milliseconds)
        {
            Stopwatch sw = Stopwatch.StartNew();
            double x = 0.123456789;

            while (sw.ElapsedMilliseconds < milliseconds)
            {
                // Keep the JIT from reducing the loop to a trivial operation.
                for (int i = 0; i < 10000; i++)
                {
                    x = Math.Sqrt(x * 1.000001 + i);
                    x = x * 0.999999 + 0.000001;
                }
            }

            if (x == Double.MinValue)
            {
                throw new ApplicationException("Unreachable");
            }
        }
    }
}
