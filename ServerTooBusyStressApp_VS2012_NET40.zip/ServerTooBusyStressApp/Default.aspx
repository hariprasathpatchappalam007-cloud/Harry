<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="ServerTooBusyStressApp.Default" %>
<!DOCTYPE html>
<html>
<head runat="server">
    <title>Server Too Busy - Test Harness</title>
</head>
<body>
<form id="form1" runat="server">
<div style="font-family:Arial;width:800px;margin:30px;">
    <h2>ASP.NET Worker Process Stress Test</h2>
    <p>Use query-string parameters to generate controlled CPU, memory and request-duration load.</p>
    <p>
        <b>Example:</b><br />
        <code>/Default.aspx?cpu=5000&delay=1000&memory=20</code>
    </p>
    <ul>
        <li><b>cpu</b> = approximate CPU work in milliseconds</li>
        <li><b>delay</b> = synchronous request delay in milliseconds</li>
        <li><b>memory</b> = temporary MB allocated per request</li>
        <li><b>hold</b> = keep allocated memory alive for this request (true/false)</li>
    </ul>
    <p><b>Start small.</b> Run only in a dedicated UAT/test IIS server.</p>
</div>
</form>
</body>
</html>
