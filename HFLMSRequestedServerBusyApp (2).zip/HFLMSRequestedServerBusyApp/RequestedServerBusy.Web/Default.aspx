<%@ Page Language="C#" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>IIS 503.2 - Server Too Busy Demo</title>
    <style>
        body { font: 16px/1.6 "Segoe UI", sans-serif; max-width: 860px; margin: 40px auto; padding: 0 20px; color: #172635; }
        h1 { line-height: 1.2; }
        code, pre { background: #eef2f6; padding: 3px 6px; }
        pre { padding: 16px; overflow-x: auto; }
        .warning { border-left: 4px solid #ab6200; padding: 12px 18px; background: #fff5e3; }
        a { color: #0758a5; }
    </style>
</head>
<body>
    <h1>Genuine IIS 503.2: Server Too Busy</h1>
    <p>ASP.NET / C# 5 / .NET Framework 4.5 / Visual Studio 2013.</p>
    <p class="warning">Local diagnostic sample only. The dedicated IIS configuration limits
        concurrent requests to <strong>2</strong>. Do not deploy this configuration to production.</p>
    <h2>How it works</h2>
    <ol>
        <li><a href="Hold.ashx">Hold.ashx</a> keeps a request open for 5 seconds without blocking a worker thread.</li>
        <li>The probe opens two held requests, then sends six more requests.</li>
        <li>IIS rejects excess requests with HTTP 503.2 before the handler runs.</li>
        <li>After requests drain, <a href="Health.ashx">Health.ashx</a> returns HTTP 200 again.</li>
    </ol>
    <h2>Run the bounded probe</h2>
    <p>From the solution directory, in a second PowerShell window:</p>
    <pre>.\RequestedServerBusy.Probe\bin\Debug\RequestedServerBusy.Probe.exe</pre>
    <p>Use the supplied start script, not plain F5, for the low queue limit.
        No application code generates a 503 response. IIS access logs identify the substatus as 2.</p>
</body>
</html>
