UPDATE MDHUAT.QR_CODE_HANDOFF_DETAILS_LKP
SET DOCUMENT_VALID_TILL =
        CASE
            WHEN QR_DOCUMENT_ID IN (
                'DNopfeTuxRzLp8BZ7uEqIjIyR6p4ycZCMx96Rtzls',
                'honmqJ6FO62Ed9Zxl8oQgCT3XQ0qi8YmpaxfKNazhk',
                'vdFIPmLZdzvfDP5e9HSDzrSyLtj56pdR2sPBDTJyA',
                '7ny4rPwy2kJrJY7q8pX4EMCLK666PO9ZR4DBQOUXnos',
                'xjELjFAznB7SySas8IUqBnd0PfqhB2HHdsbTfgBY6Q'
            ) THEN TRUNC(SYSDATE) + 2
            ELSE TRUNC(SYSDATE) + 1
        END,
    DOCUMENT_ISSUED_DATE =
        CASE
            WHEN QR_DOCUMENT_ID IN (
                'DNopfeTuxRzLp8BZ7uEqIjIyR6p4ycZCMx96Rtzls',
                'honmqJ6FO62Ed9Zxl8oQgCT3XQ0qi8YmpaxfKNazhk',
                'vdFIPmLZdzvfDP5e9HSDzrSyLtj56pdR2sPBDTJyA',
                '7ny4rPwy2kJrJY7q8pX4EMCLK666PO9ZR4DBQOUXnos',
                'xjELjFAznB7SySas8IUqBnd0PfqhB2HHdsbTfgBY6Q'
            ) THEN TRUNC(SYSDATE) - 8
            ELSE TRUNC(SYSDATE) - 9
        END
WHERE QR_DOCUMENT_ID IN (
    'DNopfeTuxRzLp8BZ7uEqIjIyR6p4ycZCMx96Rtzls',
    'honmqJ6FO62Ed9Zxl8oQgCT3XQ0qi8YmpaxfKNazhk',
    'vdFIPmLZdzvfDP5e9HSDzrSyLtj56pdR2sPBDTJyA',
    '7ny4rPwy2kJrJY7q8pX4EMCLK666PO9ZR4DBQOUXnos',
    'xjELjFAznB7SySas8IUqBnd0PfqhB2HHdsbTfgBY6Q',
    'Z3o6pgvJJLcKK0IlV0svRNFyoqtQrB2iNnqu2jU',
    'XU0ktsX40lnxySwzFDPxmckIsa86gsHCY2rHOJyKk',
    'oQGGESLuSs2eOFEU80z3SWcTcdfytCACPzeRjaaovU'
);

COMMIT;
