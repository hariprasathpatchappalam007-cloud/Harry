<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DynamicDataPatchMaker.aspx.cs" Inherits="HF48Workflow.DynamicDataPatchMaker" ValidateRequest="false" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Dynamic Data Patch - Maker</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; background-color: #ccccff; color: #222; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: inline-block; width: 150px; font-weight: bold; font-size: 13px; vertical-align: top; padding-top: 4px; }
        input, select, textarea { padding: 5px 8px; border: 1px solid #aaa; border-radius: 3px; font-size: 13px; }
        .btn { padding: 7px 16px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-primary { background-color: #003366; color: white; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-info { background-color: #17a2b8; color: white; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview, .patch-table { width: 100%; border-collapse: collapse; font-size: 12px; background: white; }
        .gridview th, .patch-table th { background-color: #507CD1; color: white; padding: 8px; text-align: left; white-space: nowrap; }
        .gridview td, .patch-table td { padding: 6px 8px; border-bottom: 1px solid #ddd; vertical-align: top; }
        .who-bar { background: #fff8d8; border: 1px dashed #d8b400; padding: 8px 14px; margin-bottom: 15px; font-size: 12px; border-radius: 3px; }
        .old-value { color: #555; }
        .required { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <h1>Dynamic Data Patch Maker</h1>
            <h2>Submit configured table changes for checker approval</h2>
        </div>
        <div class="container">
            <div class="who-bar">
                <strong>Acting As:</strong>
                <asp:TextBox ID="txtCurrentUser" runat="server" Width="180px" />
                <asp:Button ID="btnSetUser" runat="server" Text="Switch User" CssClass="btn btn-info" OnClick="btnSetUser_Click" />
            </div>

            <asp:Panel ID="pnlMessage" runat="server" Visible="false"><asp:Label ID="lblMessage" runat="server" /></asp:Panel>
            <asp:HiddenField ID="hfConfigId" runat="server" Value="0" />
            <asp:HiddenField ID="hfPrimaryKeyValue" runat="server" Value="" />

            <div class="panel">
                <div class="panel-header">Create Data Patch Request</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>Patch Table</label>
                        <asp:DropDownList ID="ddlPatchTables" runat="server" Width="320px" />
                    </div>
                    <div class="form-group">
                        <label>Record Key Value</label>
                        <asp:TextBox ID="txtPrimaryKeyValue" runat="server" Width="220px" />
                        <asp:Button ID="btnLoadRecord" runat="server" Text="Load Dynamic Fields" CssClass="btn btn-primary" OnClick="btnLoadRecord_Click" />
                    </div>
                    <asp:PlaceHolder ID="phPatchFields" runat="server" />
                    <div class="form-group">
                        <label>Checker</label>
                        <asp:DropDownList ID="ddlChecker" runat="server" Width="260px" />
                    </div>
                    <div class="form-group">
                        <label>Maker Remarks</label>
                        <asp:TextBox ID="txtMakerRemarks" runat="server" Width="520px" TextMode="MultiLine" Rows="3" />
                    </div>
                    <asp:Button ID="btnSubmit" runat="server" Text="Submit To Checker" CssClass="btn btn-success" OnClick="btnSubmit_Click" />
                </div>
            </div>

            <div class="panel">
                <div class="panel-header">My Data Patch Requests</div>
                <div class="panel-body">
                    <asp:GridView ID="gvMyRequests" runat="server" CssClass="gridview" AutoGenerateColumns="true" />
                </div>
            </div>
        </div>
    </form>
</body>
</html>