<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DataSync.aspx.cs" Inherits="HF48Workflow.DataSync" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Application Data Sync - Business Review</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; background: #ccccff; color: #27364b; }
        .header { background: #003366; color: #fff; padding: 16px 30px; }
        .header h1 { margin: 0; font-size: 21px; }
        .header h2 { margin: 4px 0 0; color: #c5dcf4; font-size: 13px; font-weight: normal; }
        .container { max-width: 1500px; margin: 0 auto; padding: 20px 30px; }
        .panel { margin-bottom: 18px; border: 1px solid #b0b0d6; border-radius: 5px; background: #e6e6fa; }
        .panel-header { padding: 10px 15px; border-radius: 4px 4px 0 0; background: #6c7ae0; color: #fff; font-size: 14px; font-weight: bold; }
        .panel-body { padding: 15px; }
        .search-row { display: flex; flex-wrap: wrap; align-items: end; gap: 10px; }
        .search-field label { display: block; margin-bottom: 5px; font-size: 13px; font-weight: bold; }
        .search-field input { box-sizing: border-box; width: 320px; max-width: 100%; padding: 9px 10px; border: 1px solid #9aa8bb; border-radius: 4px; font-size: 14px; }
        .btn { padding: 9px 18px; border: 0; border-radius: 4px; background: #003366; color: #fff; cursor: pointer; font-size: 13px; font-weight: bold; }
        .btn:hover { background: #004488; }
        .btn-sync { background: #218838; }
        .btn-sync:hover { background: #176b2c; }
        .btn-history { background: #6b4ca5; }
        .btn-history:hover { background: #563b87; }
        .btn:disabled { cursor: wait; opacity: .65; }
        .message { display: none; margin-top: 12px; padding: 10px 13px; border: 1px solid; border-radius: 4px; font-size: 13px; }
        .message.info { display: block; border-color: #b8daff; background: #e7f3ff; color: #17456d; }
        .message.success { display: block; border-color: #c3e6cb; background: #d4edda; color: #155724; }
        .message.error { display: block; border-color: #f5c6cb; background: #f8d7da; color: #721c24; }
        .signoff-note { margin: 14px 0 0; color: #46556b; font-size: 12px; }
        .summary { display: none; margin-bottom: 16px; padding: 14px 16px; border: 1px solid #bed4ec; border-left: 5px solid #003366; border-radius: 4px; background: #fff; }
        .summary-title { margin: 0 0 5px; color: #003366; font-size: 16px; font-weight: bold; }
        .summary-detail { margin: 0; color: #526276; font-size: 13px; }
        .legend { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; font-size: 11px; }
        .legend span, .action { display: inline-block; padding: 3px 8px; border-radius: 10px; font-weight: bold; }
        .action-insert, .legend-insert { background: #d4edda; color: #155724; }
        .action-update, .legend-update { background: #fff3cd; color: #856404; }
        .action-no-change, .legend-no-change { background: #e2e3e5; color: #41464b; }
        .selection-toolbar { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin: 0 0 12px; }
        .selection-toolbar .btn { padding: 7px 12px; }
        .selection-note { color: #526276; font-size: 12px; }
        .field-select { width: 18px; height: 18px; cursor: pointer; accent-color: #218838; }
        .old-value { color: #9c2525; text-decoration: line-through; text-decoration-thickness: 2px; }
        .new-value { color: #187438; background: #e4f5e9; font-weight: bold; }
        .not-applicable { color: #8993a0; font-style: italic; }
        .audit-count { color: #526276; font-size: 12px; margin: 10px 0 0; }
        .tabs { display: flex; flex-wrap: wrap; gap: 4px; margin: 0; padding: 0; border-bottom: 2px solid #6c7ae0; }
        .tab { padding: 9px 16px; border: 1px solid #c5c6dc; border-bottom: 0; border-radius: 5px 5px 0 0; background: #e0e0e0; color: #26364d; cursor: pointer; font-size: 13px; font-weight: bold; }
        .tab.active { border-color: #003366; background: #003366; color: #fff; }
        .workflow-tabs { display: flex; gap: 6px; margin-bottom: 18px; border-bottom: 2px solid #003366; }
        .workflow-tab { padding: 11px 20px; border: 1px solid #b0b0d6; border-bottom: 0; border-radius: 6px 6px 0 0; background: #e0e0e0; color: #26364d; cursor: pointer; font-size: 14px; font-weight: bold; }
        .workflow-tab.active { border-color: #003366; background: #003366; color: #fff; }
        .workflow-panel { display: none; }
        .workflow-panel.active { display: block; }
        .tab-count { display: inline-block; min-width: 18px; margin-left: 5px; padding: 1px 5px; border-radius: 9px; background: rgba(255,255,255,.25); text-align: center; }
        .tab-panel { display: none; padding: 14px; border: 1px solid #b0b0d6; border-top: 0; background: #fff; }
        .tab-panel.active { display: block; }
        .table-wrap { overflow-x: auto; }
        .gridview { width: 100%; min-width: 980px; border-collapse: collapse; font-size: 12px; }
        .gridview th { position: sticky; top: 0; padding: 9px 10px; background: #507cd1; color: #fff; text-align: left; }
        .gridview td { max-width: 350px; padding: 8px 10px; border-bottom: 1px solid #e4e8ef; vertical-align: top; overflow-wrap: anywhere; }
        .gridview tbody tr:nth-child(even) { background: #f5f7fb; }
        .gridview tbody tr:hover { background: #eef4ff; }
        .field-name { min-width: 160px; color: #243a5a; font-weight: bold; }
        .empty-value { color: #9aa3ae; font-style: italic; }
        .loading-overlay { position: fixed; z-index: 1000; inset: 0; display: none; align-items: center; justify-content: center; background: rgba(10, 28, 52, .48); }
        .loading-overlay.visible { display: flex; }
        .loading-card { width: min(390px, calc(100% - 40px)); padding: 24px; border-radius: 8px; background: #fff; box-shadow: 0 12px 40px rgba(0,0,0,.25); text-align: center; }
        .spinner { width: 38px; height: 38px; margin: 0 auto 14px; border: 4px solid #d6e0ed; border-top-color: #003366; border-radius: 50%; animation: spin .8s linear infinite; }
        .loading-title { margin: 0 0 5px; color: #003366; font-weight: bold; }
        .loading-detail { margin: 0; color: #66758a; font-size: 12px; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (max-width: 700px) {
            .container { padding: 14px; }
            .header { padding: 14px; }
            .search-field input { width: 100%; }
            .search-field { flex: 1 1 100%; }
            .btn { width: 100%; }
            .tabs { gap: 2px; }
            .tab { flex: 1 1 42%; padding: 9px 6px; }
            .workflow-tab { flex: 1; padding: 10px 6px; }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
    <asp:ScriptManager ID="smMain" runat="server" EnablePageMethods="true" />
    <div class="header">
        <h1>Application Data Sync - Business Review</h1>
        <h2>Compare new origination data, customer search result data, and core data before sign-off</h2>
    </div>
    <main class="container">
        <div class="workflow-tabs" role="tablist" aria-label="Data sync workspace">
            <button id="workspaceTabSearch" type="button" class="workflow-tab active" role="tab"
                aria-selected="true" aria-controls="searchWorkspace"
                onclick="selectWorkspaceTab(this, 'searchWorkspace');">Search &amp; Synchronize</button>
            <button id="workspaceTabAudit" type="button" class="workflow-tab" role="tab"
                aria-selected="false" aria-controls="auditWorkspace"
                onclick="selectWorkspaceTab(this, 'auditWorkspace');">Audit History</button>
        </div>
        <div id="searchWorkspace" class="workflow-panel active" role="tabpanel" aria-labelledby="workspaceTabSearch">
        <section class="panel" aria-labelledby="search-heading">
            <div class="panel-header" id="search-heading">Search an application</div>
            <div class="panel-body">
                <div class="search-row">
                    <div class="search-field">
                        <label for="<%= txtApplicationId.ClientID %>">Application ID</label>
                        <asp:TextBox ID="txtApplicationId" runat="server" MaxLength="200"
                            onkeypress="return handleSearchKey(event);" onkeyup="updateSyncAvailability();"
                            oninput="updateSyncAvailability();" />
                    </div>
                    <button id="btnSearch" type="button" class="btn" onclick="loadApplication();">Search application</button>
                    <button id="btnSync" type="button" class="btn btn-sync" disabled="disabled"
                        onclick="synchronizeApplication();">Synchronize</button>
                    <button id="btnHistory" type="button" class="btn btn-history" disabled="disabled"
                        onclick="showApplicationHistory();">History</button>
                </div>
                <div id="message" class="message" role="status" aria-live="polite"></div>
                <p class="signoff-note"><strong>Business sign-off:</strong> review the differences and select only the fields IT is approved to synchronize. Unselected fields are not changed.</p>
            </div>
        </section>

        <section id="reviewResults" style="display:none;" aria-live="polite">
            <div class="summary">
                <p id="summaryTitle" class="summary-title"></p>
                <p id="summaryDetail" class="summary-detail"></p>
                <div class="legend">
                    <span class="legend-insert">New record to insert</span>
                    <span class="legend-update">Existing value to update</span>
                    <span class="legend-no-change">No change proposed</span>
                    <span class="new-value">Approved new value</span>
                </div>
            </div>
            <div class="selection-toolbar" aria-label="Field selection">
                <button type="button" class="btn" onclick="setAllFields(true);">Select all</button>
                <button type="button" class="btn" onclick="setAllFields(false);">Deselect all</button>
                <span class="selection-note">All fields are selected by default. Unselected fields show old/new as not applicable and will be left unchanged.</span>
            </div>
            <div role="tablist" class="tabs" aria-label="Application data categories">
                <button type="button" class="tab active" role="tab" aria-selected="true" aria-controls="tab-id"
                    onclick="selectTab(this, 'tab-id');">ID Documents <span class="tab-count" id="count-id">0</span></button>
                <button type="button" class="tab" role="tab" aria-selected="false" aria-controls="tab-property"
                    onclick="selectTab(this, 'tab-property');">Property Details <span class="tab-count" id="count-property">0</span></button>
                <button type="button" class="tab" role="tab" aria-selected="false" aria-controls="tab-employment"
                    onclick="selectTab(this, 'tab-employment');">Employment Details <span class="tab-count" id="count-employment">0</span></button>
                <button type="button" class="tab" role="tab" aria-selected="false" aria-controls="tab-finance"
                    onclick="selectTab(this, 'tab-finance');">Finance Details <span class="tab-count" id="count-finance">0</span></button>
                <button type="button" class="tab" role="tab" aria-selected="false" aria-controls="tab-address"
                    onclick="selectTab(this, 'tab-address');">Address Details <span class="tab-count" id="count-address">0</span></button>
            </div>
            <div id="tab-id" class="tab-panel active" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
            <div id="tab-property" class="tab-panel" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
            <div id="tab-employment" class="tab-panel" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
            <div id="tab-finance" class="tab-panel" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
            <div id="tab-address" class="tab-panel" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
        </section>
        </div>
        <div id="auditWorkspace" class="workflow-panel" role="tabpanel" aria-labelledby="workspaceTabAudit">
        <section class="panel" aria-labelledby="audit-heading">
            <div class="panel-header" id="audit-heading">Synchronization audit history</div>
            <div class="panel-body">
                <div class="search-row">
                    <div class="search-field">
                        <label for="auditApplicationId">Application ID filter (blank shows recent activity)</label>
                        <input id="auditApplicationId" type="text" maxlength="200" />
                    </div>
                    <button id="btnAudit" type="button" class="btn" onclick="loadAuditHistory();">Load audit history</button>
                </div>
                <p id="auditMessage" class="audit-count" role="status" aria-live="polite">Choose History beside Synchronize to view the complete history for the searched application.</p>
                <div class="table-wrap">
                    <table id="auditTable" class="gridview">
                        <thead><tr>
                            <th scope="col">Application ID</th>
                            <th scope="col">Synchronized by</th>
                            <th scope="col">Synchronized on</th>
                            <th scope="col">Operation</th>
                            <th scope="col">Field</th>
                            <th scope="col">Old value</th>
                            <th scope="col">New value</th>
                            <th scope="col">Selected / changed</th>
                        </tr></thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </section>
        </div>
    </main>
    <div id="loadingOverlay" class="loading-overlay" aria-hidden="true">
        <div class="loading-card" role="alert" aria-live="assertive">
            <div class="spinner"></div>
            <p id="loadingTitle" class="loading-title">Searching and comparing application data</p>
            <p id="loadingDetail" class="loading-detail">Please wait. This review does not change any records.</p>
        </div>
    </div>
</form>
<script type="text/javascript">
    var currentApplicationId = "";
    var requestInProgress = false;
    var auditRequestInProgress = false;
    var tabMap = {
        "ID Documents": ["tab-id", "count-id"],
        "Property Details": ["tab-property", "count-property"],
        "Employment Details": ["tab-employment", "count-employment"],
        "Finance Details": ["tab-finance", "count-finance"],
        "Address Details": ["tab-address", "count-address"]
    };

    function handleSearchKey(event) {
        event = event || window.event;
        if (event.keyCode === 13) {
            loadApplication();
            if (event.preventDefault) event.preventDefault();
            event.returnValue = false;
            return false;
        }
        return true;
    }

    function setLoading(isLoading, title, detail) {
        requestInProgress = isLoading;
        document.getElementById("loadingOverlay").className = isLoading
            ? "loading-overlay visible" : "loading-overlay";
        document.getElementById("loadingOverlay").setAttribute("aria-hidden", isLoading ? "false" : "true");
        document.getElementById("btnSearch").disabled = isLoading;
        document.getElementById("<%= txtApplicationId.ClientID %>").disabled = isLoading;
        document.getElementById("loadingTitle").textContent = title || "Searching and comparing application data";
        document.getElementById("loadingDetail").textContent = detail || "Please wait. This review does not change any records.";
        updateSyncAvailability();
    }

    function updateSyncAvailability() {
        var input = document.getElementById("<%= txtApplicationId.ClientID %>");
        var applicationId = input.value.replace(/^\s+|\s+$/g, "");
        var checkedFields = document.querySelectorAll("#reviewResults .field-select:checked");
        document.getElementById("btnSync").disabled = requestInProgress
            || !currentApplicationId || applicationId !== currentApplicationId || checkedFields.length === 0;
        document.getElementById("btnHistory").disabled = requestInProgress
            || auditRequestInProgress || !applicationId || applicationId.length > 200;
    }

    function showMessage(text, kind) {
        var element = document.getElementById("message");
        element.className = "message " + kind;
        element.textContent = text;
    }

    function loadApplication() {
        var input = document.getElementById("<%= txtApplicationId.ClientID %>");
        var applicationId = input.value.replace(/^\s+|\s+$/g, "");
        currentApplicationId = "";
        updateSyncAvailability();
        document.getElementById("reviewResults").style.display = "none";
        if (!applicationId || applicationId.length > 200) {
            showMessage("Enter an application ID of 1 to 200 characters.", "error");
            input.focus();
            return;
        }
        showMessage("", "info");
        document.getElementById("message").textContent = "Retrieving the application and comparison records...";
        setLoading(true, "Searching and comparing application data", "Please wait. No records are changed by this search.");
        PageMethods.LoadApplicationData(applicationId, loadSucceeded, loadFailed);
    }

    function loadSucceeded(result, completionMessage) {
        setLoading(false);
        if (!result || !result.Success) {
            currentApplicationId = "";
            updateSyncAvailability();
            showMessage(result && result.Message ? result.Message : "Unable to load application data.", "error");
            return;
        }
        currentApplicationId = result.ApplicationId;
        renderReview(result);
        document.getElementById("reviewResults").style.display = "block";
        selectTab(document.querySelector(".tab"), "tab-id");
        updateSyncAvailability();
        showMessage(completionMessage || "Comparison ready. Review the proposed values in each tab before synchronizing.", "success");
    }

    function loadFailed(error) {
        setLoading(false);
        currentApplicationId = "";
        document.getElementById("reviewResults").style.display = "none";
        updateSyncAvailability();
        var message = error && error.get_message
            ? error.get_message() : "The request could not be completed. Contact IT support.";
        showMessage(message, "error");
    }

    function synchronizeApplication() {
        var input = document.getElementById("<%= txtApplicationId.ClientID %>");
        var applicationId = input.value.replace(/^\s+|\s+$/g, "");
        if (!currentApplicationId || applicationId !== currentApplicationId) {
            showMessage("Search this application again before synchronizing.", "error");
            updateSyncAvailability();
            return;
        }
        var selectedFields = [];
        var checkboxes = document.querySelectorAll("#reviewResults .field-select:checked");
        for (var selectedIndex = 0; selectedIndex < checkboxes.length; selectedIndex++)
            selectedFields.push(checkboxes[selectedIndex].getAttribute("data-field-key"));
        if (selectedFields.length === 0) {
            showMessage("Select at least one field before synchronizing.", "error");
            return;
        }
        if (!window.confirm("Apply the proposed insert or update for application " + applicationId + "?")) return;
        setLoading(true, "Synchronizing application data", "The update is being committed. Please do not close this page.");
        PageMethods.SynchronizeApplicationData(applicationId, selectedFields, syncSucceeded, syncFailed);
    }

    function syncSucceeded(result) {
        setLoading(false);
        if (!result || !result.Success) {
            showMessage(result && result.Message ? result.Message : "Synchronization failed.", "error");
            return;
        }

        var completionMessage = "Synchronization completed. Inserted: " + result.InsertedRows +
            "; updated: " + result.UpdatedRows + "; changed fields: " + result.ChangedFields +
            "; matched customer records: " + result.MatchedCustomerCount + ".";
        setLoading(true, "Refreshing comparison", "Synchronization completed. Reloading the current database values.");
        PageMethods.LoadApplicationData(currentApplicationId, function (comparison) {
            loadSucceeded(comparison, completionMessage + " Comparison refreshed.");
        }, function (error) {
            setLoading(false);
            currentApplicationId = "";
            document.getElementById("reviewResults").style.display = "none";
            updateSyncAvailability();
            var detail = error && error.get_message ? error.get_message() : "The refreshed comparison could not be loaded.";
            showMessage(completionMessage + " " + detail, "error");
        });
    }

    function syncFailed(error) {
        setLoading(false);
        var message = error && error.get_message
            ? error.get_message() : "Synchronization failed. Contact IT support.";
        showMessage(message, "error");
    }

    function selectWorkspaceTab(button, panelId) {
        var buttons = document.querySelectorAll(".workflow-tabs .workflow-tab");
        var panels = document.querySelectorAll(".workflow-panel");
        for (var i = 0; i < buttons.length; i++) {
            buttons[i].className = "workflow-tab";
            buttons[i].setAttribute("aria-selected", "false");
        }
        for (var j = 0; j < panels.length; j++) panels[j].className = "workflow-panel";
        button.className = "workflow-tab active";
        button.setAttribute("aria-selected", "true");
        document.getElementById(panelId).className = "workflow-panel active";
    }

    function selectTab(button, panelId) {
        var buttons = document.querySelectorAll(".tabs .tab");
        var panels = document.querySelectorAll(".tab-panel");
        var i;
        for (i = 0; i < buttons.length; i++) {
            buttons[i].className = "tab";
            buttons[i].setAttribute("aria-selected", "false");
        }
        for (i = 0; i < panels.length; i++) panels[i].className = "tab-panel";
        button.className = "tab active";
        button.setAttribute("aria-selected", "true");
        document.getElementById(panelId).className = "tab-panel active";
    }

    function appendCell(row, value, className) {
        var cell = document.createElement("td");
        if (className) cell.className = className;
        if (value === null || value === undefined || value === "") {
            cell.textContent = "-";
            cell.className = (cell.className ? cell.className + " " : "") + "empty-value";
        } else {
            cell.textContent = value;
        }
        row.appendChild(cell);
        return cell;
    }

    function setAllFields(isSelected) {
        var checkboxes = document.querySelectorAll("#reviewResults .field-select");
        for (var i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = isSelected;
            updateRowSelection(checkboxes[i]);
        }
        updateSyncAvailability();
    }

    function updateRowSelection(checkbox) {
        var row = checkbox.parentNode;
        while (row && row.tagName !== "TR") row = row.parentNode;
        if (!row) return;
        var cells = row.getElementsByTagName("td");
        var actionCell = cells[cells.length - 1];
        var oldCell = row.querySelector(".old-cell");
        var newCell = row.querySelector(".new-cell");
        if (!checkbox.checked) {
            row.className = "action-deselected";
            oldCell.textContent = "Not applicable";
            newCell.textContent = "Not applicable";
            oldCell.className = "old-cell not-applicable";
            newCell.className = "new-cell not-applicable";
            actionCell.textContent = "Not selected";
            actionCell.className = "not-applicable";
        } else {
            row.className = "action-" + row.getAttribute("data-action-class");
            oldCell.textContent = row.getAttribute("data-old-value") || "-";
            newCell.textContent = row.getAttribute("data-new-value") || "-";
            oldCell.className = "old-cell";
            newCell.className = "new-cell";
            if (row.getAttribute("data-action-class") === "update") {
                oldCell.className += " old-value";
                newCell.className += " new-value";
            } else if (row.getAttribute("data-action-class") === "insert") {
                newCell.className += " new-value";
            }
            actionCell.textContent = row.getAttribute("data-action");
            actionCell.className = "";
            var badge = document.createElement("span");
            badge.className = "action action-" + row.getAttribute("data-action-class");
            badge.textContent = row.getAttribute("data-action");
            actionCell.appendChild(badge);
        }
        updateSyncAvailability();
    }

    function renderReview(result) {
        document.getElementById("summaryTitle").textContent =
            result.Operation + " - " + result.ApplicationId;
        document.getElementById("summaryDetail").textContent =
            (result.MasterFound ? "A current master record exists." : "No current master record exists; IT would insert one.") +
            " Matched CORE_CUSTOMER_DETAILS records: " + result.MatchedCustomerCount +
            ". Customer details are shown against the customer ID they matched.";

        var sectionNames = Object.keys(tabMap);
        var sectionIndex;
        for (sectionIndex = 0; sectionIndex < sectionNames.length; sectionIndex++) {
            var sectionName = sectionNames[sectionIndex];
            var targetIds = tabMap[sectionName];
            var panel = document.getElementById(targetIds[0]);
            var table = panel.getElementsByTagName("table")[0];
            var head = table.getElementsByTagName("thead")[0];
            var body = table.getElementsByTagName("tbody")[0];
            while (head.firstChild) head.removeChild(head.firstChild);
            while (body.firstChild) body.removeChild(body.firstChild);

            var headerRow = document.createElement("tr");
            var headers = ["Sync?", "Business field", "New origination data", "Customer search result data",
                "Core data", "Proposed value", "Planned action"];
            for (var h = 0; h < headers.length; h++) {
                var header = document.createElement("th");
                header.textContent = headers[h];
                header.scope = "col";
                headerRow.appendChild(header);
            }
            head.appendChild(headerRow);

            var count = 0;
            for (var rowIndex = 0; rowIndex < result.Rows.length; rowIndex++) {
                var item = result.Rows[rowIndex];
                if (item.Section !== sectionName) continue;
                var row = document.createElement("tr");
                row.className = "action-" + item.ActionClass;
                row.setAttribute("data-action-class", item.ActionClass);
                row.setAttribute("data-action", item.Action);
                row.setAttribute("data-old-value", item.MasterValue || "");
                row.setAttribute("data-new-value", item.ProposedValue || "");
                var selectionCell = document.createElement("td");
                var checkbox = document.createElement("input");
                checkbox.type = "checkbox";
                checkbox.className = "field-select";
                checkbox.checked = true;
                checkbox.setAttribute("data-field-key", item.FieldKey);
                checkbox.setAttribute("aria-label", "Synchronize " + item.FriendlyName);
                checkbox.onchange = function () { updateRowSelection(this); };
                selectionCell.appendChild(checkbox);
                row.appendChild(selectionCell);
                appendCell(row, item.FriendlyName, "field-name");
                appendCell(row, item.LeadValue);
                var oldClass = "old-cell";
                var newClass = "new-cell";
                if (item.ActionClass === "update") {
                    oldClass += " old-value";
                    newClass += " new-value";
                } else if (item.ActionClass === "insert") {
                    newClass += " new-value";
                }
                appendCell(row, item.MasterValue, oldClass);
                appendCell(row, item.CustomerValue);
                appendCell(row, item.ProposedValue, newClass);
                var actionCell = document.createElement("td");
                var action = document.createElement("span");
                action.className = "action action-" + item.ActionClass;
                action.textContent = item.Action;
                actionCell.appendChild(action);
                row.appendChild(actionCell);
                body.appendChild(row);
                updateRowSelection(checkbox);
                count++;
            }
            document.getElementById(targetIds[1]).textContent = count.toString();
        }
        updateSyncAvailability();
    }

    function showApplicationHistory() {
        var applicationId = document.getElementById("<%= txtApplicationId.ClientID %>").value.replace(/^\s+|\s+$/g, "");
        if (!applicationId || applicationId.length > 200) {
            showMessage("Enter an application ID of 1 to 200 characters before opening its history.", "error");
            document.getElementById("<%= txtApplicationId.ClientID %>").focus();
            return;
        }
        document.getElementById("auditApplicationId").value = applicationId;
        selectWorkspaceTab(document.getElementById("workspaceTabAudit"), "auditWorkspace");
        loadAuditHistory();
    }

    function loadAuditHistory() {
        if (auditRequestInProgress) return;
        var filter = document.getElementById("auditApplicationId").value.replace(/^\s+|\s+$/g, "");
        auditRequestInProgress = true;
        document.getElementById("btnAudit").disabled = true;
        document.getElementById("auditApplicationId").disabled = true;
        updateSyncAvailability();
        var table = document.getElementById("auditTable");
        var body = table.getElementsByTagName("tbody")[0];
        while (body.firstChild) body.removeChild(body.firstChild);
        document.getElementById("auditMessage").textContent = filter
            ? "Loading complete synchronization history for application " + filter + "..."
            : "Loading the most recent synchronization history...";
        PageMethods.LoadAuditHistory(filter, auditHistorySucceeded, auditHistoryFailed);
    }

    function auditHistorySucceeded(result) {
        auditRequestInProgress = false;
        document.getElementById("btnAudit").disabled = false;
        document.getElementById("auditApplicationId").disabled = false;
        updateSyncAvailability();
        var table = document.getElementById("auditTable");
        var body = table.getElementsByTagName("tbody")[0];
        while (body.firstChild) body.removeChild(body.firstChild);
        if (!result || !result.Success) {
            document.getElementById("auditMessage").textContent =
                result && result.Message ? result.Message : "Audit history could not be loaded.";
            return;
        }
        for (var i = 0; i < result.Rows.length; i++) {
            var item = result.Rows[i];
            var row = document.createElement("tr");
            appendCell(row, item.ApplicationId);
            appendCell(row, item.SynchronizedBy);
            appendCell(row, item.SynchronizedOn);
            appendCell(row, item.Operation);
            appendCell(row, item.FieldName);
            appendCell(row, item.OldValue);
            appendCell(row, item.NewValue);
            appendCell(row, item.SelectedFieldCount + " selected / " + item.ChangedFieldCount + " changed");
            body.appendChild(row);
        }
        var filter = document.getElementById("auditApplicationId").value.replace(/^\s+|\s+$/g, "");
        document.getElementById("auditMessage").textContent = filter
            ? result.Rows.length + " audit detail row(s) loaded. Complete history for application " + filter + " is shown."
            : result.Rows.length + " audit detail row(s) loaded from the 25 most recent sync runs.";
    }

    function auditHistoryFailed(error) {
        auditRequestInProgress = false;
        document.getElementById("btnAudit").disabled = false;
        document.getElementById("auditApplicationId").disabled = false;
        updateSyncAvailability();
        document.getElementById("auditMessage").textContent = error && error.get_message
            ? error.get_message() : "Audit history could not be loaded. Contact IT support.";
    }
</script>
</body>
</html>
