<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DataSync.aspx.cs" Inherits="HF48Workflow.DataSync" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Application Data Sync</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 24px; background: #f4f6fa; color: #25334a; }
        h1 { color: #003366; }
        .panel { padding: 16px; margin: 16px 0; background: white; border: 1px solid #ccd5e0; }
        .message { display: block; margin: 12px 0; padding: 10px; }
        .success { color: #155724; background: #d4edda; border: 1px solid #c3e6cb; }
        .error { color: #721c24; background: #f8d7da; border: 1px solid #f5c6cb; }
        .hint { font-size: 13px; }
        .grid { border-collapse: collapse; width: 100%; font-size: 12px; }
        .grid th { background: #003366; color: white; text-align: left; }
        .grid th, .grid td { padding: 8px; border: 1px solid #ccd5e0; }
        .scroll { overflow-x: auto; }
        .button { margin-left: 8px; padding: 6px 12px; }
    </style>
</head>
<body>
<form id="form1" runat="server">
    <h1>Application Data Sync</h1>
    <p class="hint">Preview lead data and current master data for one application, then synchronize it.
        Non-NULL customer details matching the application's customer IDs take precedence over lead values.</p>
    <div class="panel">
        <asp:Label ID="lblApplicationId" runat="server" AssociatedControlID="txtApplicationId"
            Text="Application ID: " />
        <asp:TextBox ID="txtApplicationId" runat="server" MaxLength="200" Width="280px" />
        <asp:Button ID="btnPreview" runat="server" Text="Preview" CssClass="button" OnClick="btnPreview_Click" />
        <asp:Button ID="btnSync" runat="server" Text="Synchronize" CssClass="button" OnClick="btnSync_Click"
            OnClientClick="return confirm('Synchronize this application into CORE_FLEX_ALL_APPS_MASTER?');" />
        <asp:Label ID="lblMessage" runat="server" CssClass="message" role="alert" />
    </div>
    <asp:Panel ID="pnlPreview" runat="server" Visible="false">
        <div class="panel">
            <h2>Data to be synchronized</h2>
            <div class="scroll">
                <asp:GridView ID="gvPreview" runat="server" CssClass="grid" AutoGenerateColumns="true"
                    EmptyDataText="No source data found for this application." />
            </div>
        </div>
    </asp:Panel>
</form>
</body>
</html>
