<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DataSync.aspx.cs" Inherits="HF48Workflow.DataSync" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Application Data Sync - Business Review</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; background: #ccccff; color: #27364b; }
        .header { background: #003366; color: #fff; padding: 16px 30px; }
        .header h1 { margin: 0; font-size: 21px; }
        .header h2 { margin: 4px 0 0; color: #c5dcf4; font-size: 13px; font-weight: normal; }
        .container { max-width: 1500px; margin: 0 auto; padding: 20px 30px; }
        .panel { margin-bottom: 18px; border: 1px solid #b0b0d6; border-radius: 5px; background: #e6e6fa; }
        .panel-header { padding: 10px 15px; border-radius: 4px 4px 0 0; background: #6c7ae0; color: #fff; font-size: 14px; font-weight: bold; }
        .panel-body { padding: 15px; }
        .search-row { display: flex; flex-wrap: wrap; align-items: end; gap: 10px; }
        .search-field label { display: block; margin-bottom: 5px; font-size: 13px; font-weight: bold; }
        .search-field input { box-sizing: border-box; width: 320px; max-width: 100%; padding: 9px 10px; border: 1px solid #9aa8bb; border-radius: 4px; font-size: 14px; }
        .btn { padding: 9px 18px; border: 0; border-radius: 4px; background: #003366; color: #fff; cursor: pointer; font-size: 13px; font-weight: bold; }
        .btn:hover { background: #004488; }
        .btn:disabled { cursor: wait; opacity: .65; }
        .message { display: none; margin-top: 12px; padding: 10px 13px; border: 1px solid; border-radius: 4px; font-size: 13px; }
        .message.info { display: block; border-color: #b8daff; background: #e7f3ff; color: #17456d; }
        .message.success { display: block; border-color: #c3e6cb; background: #d4edda; color: #155724; }
        .message.error { display: block; border-color: #f5c6cb; background: #f8d7da; color: #721c24; }
        .signoff-note { margin: 14px 0 0; color: #46556b; font-size: 12px; }
        .summary { display: none; margin-bottom: 16px; padding: 14px 16px; border: 1px solid #bed4ec; border-left: 5px solid #003366; border-radius: 4px; background: #fff; }
        .summary-title { margin: 0 0 5px; color: #003366; font-size: 16px; font-weight: bold; }
        .summary-detail { margin: 0; color: #526276; font-size: 13px; }
        .legend { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; font-size: 11px; }
        .legend span, .action { display: inline-block; padding: 3px 8px; border-radius: 10px; font-weight: bold; }
        .action-insert, .legend-insert { background: #d4edda; color: #155724; }
        .action-update, .legend-update { background: #fff3cd; color: #856404; }
        .action-no-change, .legend-no-change { background: #e2e3e5; color: #41464b; }
        .tabs { display: flex; flex-wrap: wrap; gap: 4px; margin: 0; padding: 0; border-bottom: 2px solid #6c7ae0; }
        .tab { padding: 9px 16px; border: 1px solid #c5c6dc; border-bottom: 0; border-radius: 5px 5px 0 0; background: #e0e0e0; color: #26364d; cursor: pointer; font-size: 13px; font-weight: bold; }
        .tab.active { border-color: #003366; background: #003366; color: #fff; }
        .tab-count { display: inline-block; min-width: 18px; margin-left: 5px; padding: 1px 5px; border-radius: 9px; background: rgba(255,255,255,.25); text-align: center; }
        .tab-panel { display: none; padding: 14px; border: 1px solid #b0b0d6; border-top: 0; background: #fff; }
        .tab-panel.active { display: block; }
        .table-wrap { overflow-x: auto; }
        .gridview { width: 100%; min-width: 980px; border-collapse: collapse; font-size: 12px; }
        .gridview th { position: sticky; top: 0; padding: 9px 10px; background: #507cd1; color: #fff; text-align: left; }
        .gridview td { max-width: 350px; padding: 8px 10px; border-bottom: 1px solid #e4e8ef; vertical-align: top; overflow-wrap: anywhere; }
        .gridview tbody tr:nth-child(even) { background: #f5f7fb; }
        .gridview tbody tr:hover { background: #eef4ff; }
        .field-name { min-width: 160px; color: #243a5a; font-weight: bold; }
        .empty-value { color: #9aa3ae; font-style: italic; }
        .loading-overlay { position: fixed; z-index: 1000; inset: 0; display: none; align-items: center; justify-content: center; background: rgba(10, 28, 52, .48); }
        .loading-overlay.visible { display: flex; }
        .loading-card { width: min(390px, calc(100% - 40px)); padding: 24px; border-radius: 8px; background: #fff; box-shadow: 0 12px 40px rgba(0,0,0,.25); text-align: center; }
        .spinner { width: 38px; height: 38px; margin: 0 auto 14px; border: 4px solid #d6e0ed; border-top-color: #003366; border-radius: 50%; animation: spin .8s linear infinite; }
        .loading-title { margin: 0 0 5px; color: #003366; font-weight: bold; }
        .loading-detail { margin: 0; color: #66758a; font-size: 12px; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (max-width: 700px) {
            .container { padding: 14px; }
            .header { padding: 14px; }
            .search-field input { width: 100%; }
            .search-field { flex: 1 1 100%; }
            .btn { width: 100%; }
            .tabs { gap: 2px; }
            .tab { flex: 1 1 42%; padding: 9px 6px; }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
    <asp:ScriptManager ID="smMain" runat="server" EnablePageMethods="true" />
    <div class="header">
        <h1>Application Data Sync — Business Review</h1>
        <h2>Review lead data, current master data, and matched customer details side by side</h2>
    </div>
    <main class="container">
        <section class="panel" aria-labelledby="search-heading">
            <div class="panel-header" id="search-heading">Search an application</div>
            <div class="panel-body">
                <div class="search-row">
                    <div class="search-field">
                        <label for="<%= txtApplicationId.ClientID %>">Application ID</label>
                        <asp:TextBox ID="txtApplicationId" runat="server" MaxLength="200"
                            onkeypress="return handleSearchKey(event);" />
                    </div>
                    <button id="btnSearch" type="button" class="btn" onclick="loadApplication();">Search application</button>
                </div>
                <div id="message" class="message" role="status" aria-live="polite"></div>
                <p class="signoff-note"><strong>Business sign-off view:</strong> this page is read-only. It shows the values IT proposes to insert or update; no records are changed here.</p>
            </div>
        </section>

        <section id="reviewResults" style="display:none;" aria-live="polite">
            <div class="summary">
                <p id="summaryTitle" class="summary-title"></p>
                <p id="summaryDetail" class="summary-detail"></p>
                <div class="legend">
                    <span class="legend-insert">New record to insert</span>
                    <span class="legend-update">Existing value to update</span>
                    <span class="legend-no-change">No change proposed</span>
                </div>
            </div>
            <div role="tablist" class="tabs" aria-label="Application data categories">
                <button type="button" class="tab active" role="tab" aria-selected="true" aria-controls="tab-id"
                    onclick="selectTab(this, 'tab-id');">ID Documents <span class="tab-count" id="count-id">0</span></button>
                <button type="button" class="tab" role="tab" aria-selected="false" aria-controls="tab-property"
                    onclick="selectTab(this, 'tab-property');">Property Details <span class="tab-count" id="count-property">0</span></button>
                <button type="button" class="tab" role="tab" aria-selected="false" aria-controls="tab-employment"
                    onclick="selectTab(this, 'tab-employment');">Employment Details <span class="tab-count" id="count-employment">0</span></button>
                <button type="button" class="tab" role="tab" aria-selected="false" aria-controls="tab-finance"
                    onclick="selectTab(this, 'tab-finance');">Finance Details <span class="tab-count" id="count-finance">0</span></button>
                <button type="button" class="tab" role="tab" aria-selected="false" aria-controls="tab-address"
                    onclick="selectTab(this, 'tab-address');">Address Details <span class="tab-count" id="count-address">0</span></button>
            </div>
            <div id="tab-id" class="tab-panel active" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
            <div id="tab-property" class="tab-panel" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
            <div id="tab-employment" class="tab-panel" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
            <div id="tab-finance" class="tab-panel" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
            <div id="tab-address" class="tab-panel" role="tabpanel">
                <div class="table-wrap"><table class="gridview"><thead></thead><tbody></tbody></table></div>
            </div>
        </section>
    </main>
    <div id="loadingOverlay" class="loading-overlay" aria-hidden="true">
        <div class="loading-card" role="alert" aria-live="assertive">
            <div class="spinner"></div>
            <p class="loading-title">Searching and comparing application data</p>
            <p class="loading-detail">Please wait. This review does not change any records.</p>
        </div>
    </div>
</form>
<script type="text/javascript">
    var tabMap = {
        "ID Documents": ["tab-id", "count-id"],
        "Property Details": ["tab-property", "count-property"],
        "Employment Details": ["tab-employment", "count-employment"],
        "Finance Details": ["tab-finance", "count-finance"],
        "Address Details": ["tab-address", "count-address"]
    };

    function handleSearchKey(event) {
        event = event || window.event;
        if (event.keyCode === 13) {
            loadApplication();
            if (event.preventDefault) event.preventDefault();
            event.returnValue = false;
            return false;
        }
        return true;
    }

    function setLoading(isLoading) {
        document.getElementById("loadingOverlay").className = isLoading
            ? "loading-overlay visible" : "loading-overlay";
        document.getElementById("loadingOverlay").setAttribute("aria-hidden", isLoading ? "false" : "true");
        document.getElementById("btnSearch").disabled = isLoading;
    }

    function showMessage(text, kind) {
        var element = document.getElementById("message");
        element.className = "message " + kind;
        element.textContent = text;
    }

    function loadApplication() {
        var input = document.getElementById("<%= txtApplicationId.ClientID %>");
        var applicationId = input.value.replace(/^\s+|\s+$/g, "");
        document.getElementById("reviewResults").style.display = "none";
        if (!applicationId || applicationId.length > 200) {
            showMessage("Enter an application ID of 1 to 200 characters.", "error");
            input.focus();
            return;
        }
        showMessage("", "info");
        document.getElementById("message").textContent = "Retrieving the application and comparison records...";
        setLoading(true);
        PageMethods.LoadApplicationData(applicationId, loadSucceeded, loadFailed);
    }

    function loadSucceeded(result) {
        setLoading(false);
        if (!result || !result.Success) {
            showMessage(result && result.Message ? result.Message : "Unable to load application data.", "error");
            return;
        }
        renderReview(result);
        document.getElementById("reviewResults").style.display = "block";
        selectTab(document.querySelector(".tab"), "tab-id");
        showMessage("Comparison ready. Review the proposed values in each tab for business sign-off.", "success");
    }

    function loadFailed(error) {
        setLoading(false);
        var message = error && error.get_message
            ? error.get_message() : "The request could not be completed. Contact IT support.";
        showMessage(message, "error");
    }

    function selectTab(button, panelId) {
        var buttons = document.querySelectorAll(".tabs .tab");
        var panels = document.querySelectorAll(".tab-panel");
        var i;
        for (i = 0; i < buttons.length; i++) {
            buttons[i].className = "tab";
            buttons[i].setAttribute("aria-selected", "false");
        }
        for (i = 0; i < panels.length; i++) panels[i].className = "tab-panel";
        button.className = "tab active";
        button.setAttribute("aria-selected", "true");
        document.getElementById(panelId).className = "tab-panel active";
    }

    function appendCell(row, value, className) {
        var cell = document.createElement("td");
        if (className) cell.className = className;
        if (value === null || value === undefined || value === "") {
            cell.textContent = "—";
            cell.className = (cell.className ? cell.className + " " : "") + "empty-value";
        } else {
            cell.textContent = value;
        }
        row.appendChild(cell);
    }

    function renderReview(result) {
        document.getElementById("summaryTitle").textContent =
            result.Operation + " — " + result.ApplicationId;
        document.getElementById("summaryDetail").textContent =
            (result.MasterFound ? "A current master record exists." : "No current master record exists; IT would insert one.") +
            " Matched CORE_CUSTOMER_DETAILS records: " + result.MatchedCustomerCount +
            ". Customer details are shown against the customer ID they matched.";

        var sectionNames = Object.keys(tabMap);
        var sectionIndex;
        for (sectionIndex = 0; sectionIndex < sectionNames.length; sectionIndex++) {
            var sectionName = sectionNames[sectionIndex];
            var targetIds = tabMap[sectionName];
            var panel = document.getElementById(targetIds[0]);
            var table = panel.getElementsByTagName("table")[0];
            var head = table.getElementsByTagName("thead")[0];
            var body = table.getElementsByTagName("tbody")[0];
            while (head.firstChild) head.removeChild(head.firstChild);
            while (body.firstChild) body.removeChild(body.firstChild);

            var headerRow = document.createElement("tr");
            var headers = ["Business field", "Lead / application data", "Current master data",
                "Matched customer details", "Value IT proposes", "Planned action"];
            for (var h = 0; h < headers.length; h++) {
                var header = document.createElement("th");
                header.textContent = headers[h];
                header.scope = "col";
                headerRow.appendChild(header);
            }
            head.appendChild(headerRow);

            var count = 0;
            for (var rowIndex = 0; rowIndex < result.Rows.length; rowIndex++) {
                var item = result.Rows[rowIndex];
                if (item.Section !== sectionName) continue;
                var row = document.createElement("tr");
                row.className = "action-" + item.ActionClass;
                appendCell(row, item.FriendlyName, "field-name");
                appendCell(row, item.LeadValue);
                appendCell(row, item.MasterValue);
                appendCell(row, item.CustomerValue);
                appendCell(row, item.ProposedValue);
                var actionCell = document.createElement("td");
                var action = document.createElement("span");
                action.className = "action action-" + item.ActionClass;
                action.textContent = item.Action;
                actionCell.appendChild(action);
                row.appendChild(actionCell);
                body.appendChild(row);
                count++;
            }
            document.getElementById(targetIds[1]).textContent = count.toString();
        }
    }
</script>
</body>
</html>
