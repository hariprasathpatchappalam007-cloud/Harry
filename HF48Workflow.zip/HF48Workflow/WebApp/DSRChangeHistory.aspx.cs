using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class DSRChangeHistory : Page
    {
        private string LoadedApplicationID
        {
            get { return ViewState["LoadedApplicationID"] as string; }
            set { ViewState["LoadedApplicationID"] = value; }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            lblMessage.Text = String.Empty;
            pnlResults.Visible = false;
            LoadedApplicationID = null;
            string applicationID = txtApplicationID.Text.Trim();
            if (applicationID.Length == 0 || applicationID.Length > 450)
            {
                lblMessage.Text = "Enter an application ID of 1 to 450 characters.";
                return;
            }
            LoadHistory(applicationID, null, null, true);
        }

        protected void btnCompare_Click(object sender, EventArgs e)
        {
            lblMessage.Text = String.Empty;
            long fromId, toId;
            if (String.IsNullOrEmpty(LoadedApplicationID)
                || !String.Equals(txtApplicationID.Text.Trim(), LoadedApplicationID, StringComparison.Ordinal))
            {
                pnlResults.Visible = false;
                lblMessage.Text = "The application ID changed. Search again before comparing.";
                return;
            }
            if (!Int64.TryParse(ddlFrom.SelectedValue, out fromId)
                || !Int64.TryParse(ddlTo.SelectedValue, out toId))
            {
                pnlResults.Visible = false;
                lblMessage.Text = "Select two valid snapshots, or search again.";
                return;
            }
            LoadHistory(LoadedApplicationID, fromId, toId, false);
        }

        private void LoadHistory(string applicationID, long? fromId, long? toId, bool populateChoices)
        {
            pnlResults.Visible = false;
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
            if (settings == null || String.IsNullOrEmpty(settings.ConnectionString))
            {
                System.Diagnostics.Trace.TraceError("DSR history: LMS_DEV connection string is missing.");
                lblMessage.Text = "The database connection is not configured. Contact support.";
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(settings.ConnectionString))
                using (SqlCommand command = new SqlCommand("dbo.Proc_DSR_GetHistory", connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                using (DataSet data = new DataSet())
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@ApplicationID", SqlDbType.NVarChar, 450).Value = applicationID;
                    command.Parameters.Add("@FromAuditId", SqlDbType.BigInt).Value =
                        fromId.HasValue ? (object)fromId.Value : DBNull.Value;
                    command.Parameters.Add("@ToAuditId", SqlDbType.BigInt).Value =
                        toId.HasValue ? (object)toId.Value : DBNull.Value;
                    adapter.Fill(data);

                    gvHistory.DataSource = data.Tables[0];
                    gvHistory.DataBind();
                    gvServiceRequests.DataSource = data.Tables[1];
                    gvServiceRequests.DataBind();
                    gvComparison.DataSource = data.Tables[2];
                    gvComparison.DataBind();

                    if (populateChoices)
                    {
                        ddlFrom.Items.Clear();
                        ddlTo.Items.Clear();
                        foreach (DataRow row in data.Tables[0].Rows)
                        {
                            string id = Convert.ToString(row["AuditId"], CultureInfo.InvariantCulture);
                            string caption = String.Format(CultureInfo.InvariantCulture,
                                "#{0} | {1:yyyy-MM-dd HH:mm:ss.fffffff} UTC | {2} | {3} | {4}",
                                id, row["ChangedAtUtc"], row["Lead_No"], row["LeadStage"], row["ChangeType"]);
                            ddlFrom.Items.Add(new ListItem(caption, id));
                            ddlTo.Items.Add(new ListItem(caption, id));
                        }
                        if (ddlTo.Items.Count > 0)
                            ddlTo.SelectedIndex = ddlTo.Items.Count - 1;
                    }
                    LoadedApplicationID = applicationID;
                    pnlCompare.Visible = ddlFrom.Items.Count > 1;
                    pnlResults.Visible = true;
                }
            }
            catch (SqlException ex)
            {
                System.Diagnostics.Trace.TraceError("DSR history query failed: {0}", ex);
                lblMessage.Text = ex.Number == 50000
                    ? Server.HtmlEncode(ex.Message)
                    : "Unable to load DSR history. Contact support and check the server log.";
            }
        }
    }
}
