using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Web.Script.Services;
using System.Web;
using System.Web.UI;
using System.Web.Services;

namespace HF48Workflow
{
    public partial class DataSync : Page
    {
        private const string PreviewSessionKey = "DataSyncPreviewApplicationId";
        private static readonly FieldDefinition[] FieldDefinitions = CreateFieldDefinitions();

        [WebMethod(EnableSession = true)]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static ComparisonResponse LoadApplicationData(string applicationId)
        {
            ComparisonResponse response = new ComparisonResponse();
            applicationId = (applicationId ?? String.Empty).Trim();
            if (HttpContext.Current != null && HttpContext.Current.Session != null)
                HttpContext.Current.Session.Remove(PreviewSessionKey);
            if (applicationId.Length == 0 || applicationId.Length > 200)
            {
                response.Message = "Enter an application ID of 1 to 200 characters.";
                return response;
            }

            try
            {
                ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
                if (settings == null || String.IsNullOrEmpty(settings.ConnectionString))
                {
                    response.Message = "The database connection is not configured. Contact IT support.";
                    return response;
                }

                using (DataSet data = new DataSet())
                {
                    SqlParameter matched;
                    using (SqlConnection connection = new SqlConnection(settings.ConnectionString))
                    using (SqlCommand command = new SqlCommand("dbo.Proc_HF48_DataSync_ByApplicationId", connection))
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandTimeout = 30;
                        command.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value = applicationId;
                        command.Parameters.Add("@PreviewOnly", SqlDbType.Bit).Value = true;
                        matched = command.Parameters.Add("@CustomerRowsMatched", SqlDbType.Int);
                        matched.Direction = ParameterDirection.Output;
                        adapter.Fill(data);
                    }

                    if (data.Tables.Count != 3)
                        throw new InvalidOperationException("The data sync procedure did not return all comparison records.");
                    response.MatchedCustomerCount = matched.Value == DBNull.Value
                        ? 0
                        : Convert.ToInt32(matched.Value, CultureInfo.InvariantCulture);

                    DataTable lead = data.Tables[0];
                    DataTable master = data.Tables[1];
                    DataTable customerDetails = data.Tables[2];
                    if (lead.Rows.Count == 0)
                    {
                        response.Message = "No lead data was found for this application ID.";
                        return response;
                    }

                    DataRow leadRow = lead.Rows[0];
                    DataRow masterRow = master.Rows.Count == 0 ? null : master.Rows[0];
                    Dictionary<int, DataRow> customerRows = IndexCustomers(customerDetails);
                    response.ApplicationId = applicationId;
                    response.MasterFound = masterRow != null;
                    response.Operation = response.MasterFound ? "Update existing master record" : "Insert new master record";
                    response.Rows = BuildComparisonRows(leadRow, masterRow, customerRows);
                    if (HttpContext.Current != null && HttpContext.Current.Session != null)
                        HttpContext.Current.Session[PreviewSessionKey] = applicationId;
                    response.Success = true;
                    return response;
                }
            }
            catch (SqlException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync comparison failed: {0}", ex);
                response.Message = ex.Number == 50000
                    ? ex.Message
                    : "The comparison could not be loaded within 30 seconds. Try again or ask IT to check database performance.";
                return response;
            }
            catch (ConfigurationErrorsException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync configuration failed: {0}", ex);
                response.Message = "The database connection is not configured. Contact IT support.";
                return response;
            }
            catch (InvalidOperationException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync returned an unexpected result: {0}", ex);
                response.Message = "The database returned an incomplete comparison. Contact IT support.";
                return response;
            }
        }

        [WebMethod(EnableSession = true)]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static SyncResponse SynchronizeApplicationData(string applicationId)
        {
            SyncResponse response = new SyncResponse();
            applicationId = (applicationId ?? String.Empty).Trim();
            if (applicationId.Length == 0 || applicationId.Length > 200)
            {
                response.Message = "Enter an application ID of 1 to 200 characters.";
                return response;
            }
            HttpContext context = HttpContext.Current;
            string previewApplicationId = context == null || context.Session == null
                ? null
                : context.Session[PreviewSessionKey] as string;
            if (!String.Equals(applicationId, previewApplicationId, StringComparison.Ordinal))
            {
                response.Message = "Search and review this application before synchronizing.";
                return response;
            }

            try
            {
                ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
                if (settings == null || String.IsNullOrEmpty(settings.ConnectionString))
                {
                    response.Message = "The database connection is not configured. Contact IT support.";
                    return response;
                }

                using (SqlConnection connection = new SqlConnection(settings.ConnectionString))
                using (SqlCommand command = new SqlCommand("dbo.Proc_HF48_DataSync_ByApplicationId", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 60;
                    command.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value = applicationId;
                    command.Parameters.Add("@PreviewOnly", SqlDbType.Bit).Value = false;
                    SqlParameter inserted = command.Parameters.Add("@InsertedRows", SqlDbType.Int);
                    inserted.Direction = ParameterDirection.Output;
                    SqlParameter updated = command.Parameters.Add("@UpdatedRows", SqlDbType.Int);
                    updated.Direction = ParameterDirection.Output;
                    SqlParameter matched = command.Parameters.Add("@CustomerRowsMatched", SqlDbType.Int);
                    matched.Direction = ParameterDirection.Output;
                    connection.Open();
                    command.ExecuteNonQuery();

                    response.InsertedRows = Convert.ToInt32(inserted.Value, CultureInfo.InvariantCulture);
                    response.UpdatedRows = Convert.ToInt32(updated.Value, CultureInfo.InvariantCulture);
                    response.MatchedCustomerCount = Convert.ToInt32(matched.Value, CultureInfo.InvariantCulture);
                    response.Success = true;
                    response.Message = "Synchronization completed.";
                    return response;
                }
            }
            catch (SqlException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data synchronization failed: {0}", ex);
                response.Message = ex.Number == 50000
                    ? ex.Message
                    : "Synchronization failed. The database transaction was rolled back; contact IT support.";
                return response;
            }
            catch (ConfigurationErrorsException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync configuration failed: {0}", ex);
                response.Message = "The database connection is not configured. Contact IT support.";
                return response;
            }
        }

        private static Dictionary<int, DataRow> IndexCustomers(DataTable details)
        {
            Dictionary<int, DataRow> customers = new Dictionary<int, DataRow>();
            foreach (DataRow row in details.Rows)
            {
                int slot;
                if (Int32.TryParse(Convert.ToString(row["CustomerSlot"], CultureInfo.InvariantCulture), out slot)
                    && !customers.ContainsKey(slot))
                    customers.Add(slot, row);
            }
            return customers;
        }

        private static List<ComparisonRow> BuildComparisonRows(
            DataRow lead,
            DataRow master,
            Dictionary<int, DataRow> customers)
        {
            List<ComparisonRow> rows = new List<ComparisonRow>(FieldDefinitions.Length);
            foreach (FieldDefinition field in FieldDefinitions)
            {
                DataRow customer = null;
                if (field.CustomerSlot > 0)
                    customers.TryGetValue(field.CustomerSlot, out customer);

                string leadValue = ReadValue(lead, field.LeadColumn);
                string masterValue = ReadValue(master, field.MasterColumn);
                string customerValue = ReadValue(customer, field.CustomerColumn);
                bool hasCustomerValue = HasNonNullValue(customer, field.CustomerColumn);
                if (!hasCustomerValue && customer != null)
                {
                    customerValue = ReadValue(customer, field.CustomerFallbackColumn);
                    hasCustomerValue = HasNonNullValue(customer, field.CustomerFallbackColumn);
                }
                bool hasLeadValue = HasNonNullValue(lead, field.LeadColumn);

                string proposedValue = hasCustomerValue
                    ? customerValue
                    : leadValue;
                if (!hasCustomerValue && !hasLeadValue && field.PreserveMasterWhenMissing)
                    proposedValue = masterValue;

                string action;
                string actionClass;
                if (master == null)
                {
                    action = "Insert";
                    actionClass = "insert";
                }
                else if (String.Equals(Normalize(masterValue), Normalize(proposedValue), StringComparison.OrdinalIgnoreCase))
                {
                    action = "No change";
                    actionClass = "no-change";
                }
                else
                {
                    action = "Update";
                    actionClass = "update";
                }

                rows.Add(new ComparisonRow
                {
                    Section = field.Section,
                    FriendlyName = field.FriendlyName,
                    LeadValue = leadValue,
                    MasterValue = masterValue,
                    CustomerValue = customerValue,
                    ProposedValue = proposedValue,
                    Action = action,
                    ActionClass = actionClass
                });
            }
            return rows;
        }

        private static string ReadValue(DataRow row, string columnName)
        {
            if (row == null || String.IsNullOrEmpty(columnName) || !row.Table.Columns.Contains(columnName))
                return String.Empty;

            object value = row[columnName];
            if (value == null || value == DBNull.Value)
                return String.Empty;
            if (value is DateTime)
                return ((DateTime)value).ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
            return Convert.ToString(value, CultureInfo.InvariantCulture);
        }

        private static bool HasNonNullValue(DataRow row, string columnName)
        {
            return row != null
                && !String.IsNullOrEmpty(columnName)
                && row.Table.Columns.Contains(columnName)
                && row[columnName] != null
                && row[columnName] != DBNull.Value;
        }

        private static string Normalize(string value)
        {
            return (value ?? String.Empty).Trim();
        }

        private static FieldDefinition[] CreateFieldDefinitions()
        {
            List<FieldDefinition> fields = new List<FieldDefinition>();
            AddCustomerFields(fields, 1, String.Empty);
            AddCustomerFields(fields, 2, "2");
            AddCustomerFields(fields, 3, "3");
            AddCustomerFields(fields, 4, "4");
            fields.Add(new FieldDefinition("ID Documents", "Residency type", "RESIDENCYTYPE", "RESIDENCYTYPE", null, 0));
            fields.Add(new FieldDefinition("ID Documents", "Branch code", "BRANCH_CODE", "BRANCH_CODE", "BRANCH_CODE", 1));

            fields.Add(new FieldDefinition("Property Details", "Developer", "DEVELOPER", "DEVELOPER", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Project / property name", "PROPERTYNAME", "PROPERTYNAME", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Property description", "PROPERTYDETAILS", "PROPERTYDETAILS", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Property type", "PROPERTYTYPE", "PROPERTYTYPE", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Built-up area", "BUILTUPAREA", "BUILTUPAREA", null, 0));
            fields.Add(new FieldDefinition("Property Details", "Property / project ID", "PROPERTYID", "PROPERTYID", null, 0));

            fields.Add(new FieldDefinition("Employment Details", "Employment type", "EMPLOYMENTTYPE", "EMPLOYMENTTYPE", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Current employer", "CURRENTEMPLOYER1", "CURRENTEMPLOYER1", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Designation", "DESIGNATION1", "DESIGNATION1", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Applicant 1 income", "INCOME1", "INCOME1", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Applicant 2 income", "INCOME2", "INCOME2", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Applicant 3 income", "INCOME3", "INCOME3", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Applicant 4 income", "INCOME4", "INCOME4", null, 0));
            fields.Add(new FieldDefinition("Employment Details", "Customer category", null, "CORPORATECATEGORY", "CUSTOMER_CATEGORY", 1, true));
            fields.Add(new FieldDefinition("Employment Details", "Staff indicator", null, "STAFF_YN", "STAFF_YN", 1, true));

            fields.Add(new FieldDefinition("Finance Details", "Application status", "CURRENTSTATUS", "CURRENTSTATUS", "CURRENTSTATUS", 1));
            fields.Add(new FieldDefinition("Finance Details", "Pre-approval number", "PREAPPROVALNO", "PREAPPROVALNO", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Original property value", "ORIGINALPROPERTYVALUE", "ORIGINALPROPERTYVALUE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Appraised property value", "APPRAISEDPROPERTYVALUE", "APPRAISEDPROPERTYVALUE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Finance amount", "FINANCEVALUE", "FINANCEVALUE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Down payment", "DOWNPAYMENT", "DOWNPAYMENT", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Debt service ratio (DSR)", "DSR", "DSR", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Finance-to-value (FTV)", "FTV", "FTV", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Installment amount", "INSTALLMENTAMOUNT", "INSTALLMENTAMOUNT", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Istisna tenor", "ISTISNATENOR", "ISTISNATENOR", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Ijara tenor", "IJARATENOR", "IJARATENOR", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Final rate", "FINALRATE", "FINALRATE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Istisna product", "ISTISNAPRODUCT", "ISTISNAPRODUCT", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Ijara product", "IJARAPRODUCT", "IJARAPRODUCT", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Purchase type", "PURCHASETYPE", "PURCHASETYPE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Offer letter acceptance date", "OL_ACCEPTANCE_DATE", "OL_ACCEPTANCE_DATE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Offer letter generation date", "OL_GENERATION_DATE", "OL_GENERATION_DATE", null, 0));
            fields.Add(new FieldDefinition("Finance Details", "Lead last updated", "LASTUPDATED", "LASTUPDATED", null, 0));

            fields.Add(new FieldDefinition("Address Details", "Mobile country code", "MOBILECODE", "MOBILECODE", "MOBILECODE", 1));
            fields.Add(new FieldDefinition("Address Details", "Mobile number", "MOBILENUMBER", "MOBILENUMBER", "MOBILENUMBER", 1));
            fields.Add(new FieldDefinition("Address Details", "Personal email", "PERSONAL_EMAIL", "PERSONAL_EMAIL", "PERSONAL_EMAIL", 1));
            fields.Add(new FieldDefinition("Address Details", "Office email", "OFFICE_EMAIL", "OFFICE_EMAIL", "OFFICE_EMAIL", 1));
            fields.Add(new FieldDefinition("Address Details", "Mailing PO box", "MAILING_POBOX", "MAILING_POBOX", "MAILING_POBOX", 1));
            fields.Add(new FieldDefinition("Address Details", "Mailing city", "MAILING_CITY", "MAILING_CITY", null, 0));
            fields.Add(new FieldDefinition("Address Details", "Mailing country", "MAILING_COUNTRY", "MAILING_COUNTRY", "MAILING_COUNTRY", 1));
            fields.Add(new FieldDefinition("Address Details", "Residential telephone code", "RESI_TEL_CODE", "RESI_TEL_CODE", "RESI_TEL_CODE", 1));
            fields.Add(new FieldDefinition("Address Details", "Residential telephone number", "RESI_TEL_NUM", "RESI_TEL_NUM", "RESI_TEL_NUM", 1, true));
            fields.Add(new FieldDefinition("Address Details", "Office telephone code", "OFFICE_TEL_CODE", "OFFICE_TEL_CODE", null, 0));
            fields.Add(new FieldDefinition("Address Details", "Office telephone number", "OFFICE_TEL_NUM", "OFFICE_TEL_NUM", null, 0, true));
            fields.Add(new FieldDefinition("Address Details", "Residential address line 1", "RESI_ADDRESS1", "RESI_ADDRESS1", "RESI_ADDRESS1", 1, true));
            fields.Add(new FieldDefinition("Address Details", "Residential address line 2", "RESI_ADDRESS2", "RESI_ADDRESS2", "RESI_ADDRESS2", 1, true));
            fields.Add(new FieldDefinition("Address Details", "Residential address line 3", "RESI_ADDRESS3", "RESI_ADDRESS3", "RESI_ADDRESS3", 1, true));
            fields.Add(new FieldDefinition("Address Details", "Home country address line 1", "HOMECOUNTRY_ADD1", "HOMECOUNTRY_ADD1", null, 0));
            fields.Add(new FieldDefinition("Address Details", "Home country address line 2", "HOMECOUNTRY_ADD2", "HOMECOUNTRY_ADD2", null, 0));
            fields.Add(new FieldDefinition("Address Details", "Home country address line 3", "HOMECOUNTRY_ADD3", "HOMECOUNTRY_ADD3", null, 0));
            return fields.ToArray();
        }

        private static void AddCustomerFields(List<FieldDefinition> fields, int slot, string suffix)
        {
            string customerSlot = "CUSTOMERID" + suffix;
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " customer ID",
                customerSlot, customerSlot, "CUSTOMERID", slot));
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " full name",
                "CUSTOMERNAME" + slot, "CUSTOMERNAME" + slot, "CUSTOMERNAME1", slot));
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " nationality",
                "NATIONALITY" + slot, "NATIONALITY" + slot, "NATIONALITY1", slot));
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " passport number",
                slot == 1 ? "PASSPORTNUMBER" : "PASSPORTNUMBER" + slot,
                slot == 1 ? "PASSPORTNUMBER" : "PASSPORTNUMBER" + slot,
                "CUSTOMER_PASSPORTNO", slot, "PASSPORTNUMBER"));
            fields.Add(new FieldDefinition("ID Documents", "Applicant " + slot + " date of birth",
                "DATEOFBIRTH" + slot, "DATEOFBIRTH" + slot, "DATEOFBIRTH1", slot));
        }

        private sealed class FieldDefinition
        {
            public FieldDefinition(string section, string friendlyName, string leadColumn,
                string masterColumn, string customerColumn, int customerSlot)
                : this(section, friendlyName, leadColumn, masterColumn, customerColumn, customerSlot, null, false)
            {
            }

            public FieldDefinition(string section, string friendlyName, string leadColumn,
                string masterColumn, string customerColumn, int customerSlot, bool preserveMasterWhenMissing)
                : this(section, friendlyName, leadColumn, masterColumn, customerColumn, customerSlot, null, preserveMasterWhenMissing)
            {
            }

            public FieldDefinition(string section, string friendlyName, string leadColumn,
                string masterColumn, string customerColumn, int customerSlot, string customerFallbackColumn)
                : this(section, friendlyName, leadColumn, masterColumn, customerColumn, customerSlot, customerFallbackColumn, false)
            {
            }

            private FieldDefinition(string section, string friendlyName, string leadColumn,
                string masterColumn, string customerColumn, int customerSlot,
                string customerFallbackColumn, bool preserveMasterWhenMissing)
            {
                Section = section;
                FriendlyName = friendlyName;
                LeadColumn = leadColumn;
                MasterColumn = masterColumn;
                CustomerColumn = customerColumn;
                CustomerSlot = customerSlot;
                CustomerFallbackColumn = customerFallbackColumn;
                PreserveMasterWhenMissing = preserveMasterWhenMissing;
            }

            public string Section { get; private set; }
            public string FriendlyName { get; private set; }
            public string LeadColumn { get; private set; }
            public string MasterColumn { get; private set; }
            public string CustomerColumn { get; private set; }
            public string CustomerFallbackColumn { get; private set; }
            public int CustomerSlot { get; private set; }
            public bool PreserveMasterWhenMissing { get; private set; }
        }

        public sealed class ComparisonResponse
        {
            public bool Success { get; set; }
            public string Message { get; set; }
            public string ApplicationId { get; set; }
            public string Operation { get; set; }
            public bool MasterFound { get; set; }
            public int MatchedCustomerCount { get; set; }
            public List<ComparisonRow> Rows { get; set; }

            public ComparisonResponse()
            {
                Rows = new List<ComparisonRow>();
            }
        }

        public sealed class ComparisonRow
        {
            public string Section { get; set; }
            public string FriendlyName { get; set; }
            public string LeadValue { get; set; }
            public string MasterValue { get; set; }
            public string CustomerValue { get; set; }
            public string ProposedValue { get; set; }
            public string Action { get; set; }
            public string ActionClass { get; set; }
        }

        public sealed class SyncResponse
        {
            public bool Success { get; set; }
            public string Message { get; set; }
            public int InsertedRows { get; set; }
            public int UpdatedRows { get; set; }
            public int MatchedCustomerCount { get; set; }
        }
    }
}
