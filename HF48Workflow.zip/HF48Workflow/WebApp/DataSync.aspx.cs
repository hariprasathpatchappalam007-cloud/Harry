using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

namespace HF48Workflow
{
    public partial class DataSync : Page
    {
        private string PreviewApplicationId
        {
            get { return ViewState["PreviewApplicationId"] as string; }
            set { ViewState["PreviewApplicationId"] = value; }
        }

        protected void btnPreview_Click(object sender, EventArgs e)
        {
            string applicationId = (txtApplicationId.Text ?? String.Empty).Trim();
            if (applicationId.Length == 0 || applicationId.Length > 200)
            {
                ShowMessage("Enter an application ID of 1 to 200 characters.", false);
                pnlPreview.Visible = false;
                PreviewApplicationId = null;
                return;
            }

            try
            {
                DataTable preview = ExecutePreview(applicationId);
                gvPreview.DataSource = preview;
                gvPreview.DataBind();
                pnlPreview.Visible = true;
                PreviewApplicationId = applicationId;
                ShowMessage(preview.Rows.Count == 0
                    ? "No source lead record was found. Nothing can be synchronized."
                    : "Preview loaded. Review the values before synchronizing.", preview.Rows.Count > 0);
            }
            catch (SqlException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync preview failed: {0}", ex);
                pnlPreview.Visible = false;
                PreviewApplicationId = null;
                ShowMessage(ex.Number == 50000
                    ? Server.HtmlEncode(ex.Message)
                    : "Unable to load the application preview. Check the server log and database deployment.", false);
            }
            catch (ConfigurationErrorsException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync configuration failed: {0}", ex);
                pnlPreview.Visible = false;
                PreviewApplicationId = null;
                ShowMessage("The database connection is not configured. Contact support.", false);
            }
        }

        protected void btnSync_Click(object sender, EventArgs e)
        {
            string applicationId = (txtApplicationId.Text ?? String.Empty).Trim();
            if (String.IsNullOrEmpty(PreviewApplicationId)
                || !String.Equals(applicationId, PreviewApplicationId, StringComparison.Ordinal))
            {
                pnlPreview.Visible = false;
                ShowMessage("Preview this application ID before synchronizing. If the ID changed, preview it again.", false);
                return;
            }

            try
            {
                int insertedRows;
                int updatedRows;
                int customerRows;
                ExecuteSync(applicationId, out insertedRows, out updatedRows, out customerRows);
                PreviewApplicationId = null;
                pnlPreview.Visible = false;
                ShowMessage(String.Format(
                    "Synchronization completed. Inserted: {0}; updated: {1}; matched customer records: {2}.",
                    insertedRows, updatedRows, customerRows), true);
            }
            catch (SqlException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync failed: {0}", ex);
                ShowMessage(ex.Number == 50000
                    ? Server.HtmlEncode(ex.Message)
                    : "Synchronization failed and was rolled back. Check the server log and database deployment.", false);
            }
            catch (ConfigurationErrorsException ex)
            {
                System.Diagnostics.Trace.TraceError("Application data sync configuration failed: {0}", ex);
                ShowMessage("The database connection is not configured. Contact support.", false);
            }
        }

        private DataTable ExecutePreview(string applicationId)
        {
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
            if (settings == null || String.IsNullOrEmpty(settings.ConnectionString))
                throw new ConfigurationErrorsException("LMS_DEV connection string is missing.");

            using (SqlConnection connection = new SqlConnection(settings.ConnectionString))
            using (SqlCommand command = new SqlCommand("dbo.Proc_HF48_DataSync_ByApplicationId", connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            using (DataSet data = new DataSet())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 120;
                command.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value = applicationId;
                command.Parameters.Add("@PreviewOnly", SqlDbType.Bit).Value = true;
                adapter.Fill(data);
                if (data.Tables.Count == 0)
                    throw new InvalidOperationException("The data sync procedure returned no preview result.");
                return data.Tables[0];
            }
        }

        private void ExecuteSync(string applicationId, out int insertedRows, out int updatedRows, out int customerRows)
        {
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
            if (settings == null || String.IsNullOrEmpty(settings.ConnectionString))
                throw new ConfigurationErrorsException("LMS_DEV connection string is missing.");

            using (SqlConnection connection = new SqlConnection(settings.ConnectionString))
            using (SqlCommand command = new SqlCommand("dbo.Proc_HF48_DataSync_ByApplicationId", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 120;
                command.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value = applicationId;
                command.Parameters.Add("@PreviewOnly", SqlDbType.Bit).Value = false;
                SqlParameter inserted = command.Parameters.Add("@InsertedRows", SqlDbType.Int);
                inserted.Direction = ParameterDirection.Output;
                SqlParameter updated = command.Parameters.Add("@UpdatedRows", SqlDbType.Int);
                updated.Direction = ParameterDirection.Output;
                SqlParameter matched = command.Parameters.Add("@CustomerRowsMatched", SqlDbType.Int);
                matched.Direction = ParameterDirection.Output;
                connection.Open();
                command.ExecuteNonQuery();
                insertedRows = Convert.ToInt32(inserted.Value);
                updatedRows = Convert.ToInt32(updated.Value);
                customerRows = Convert.ToInt32(matched.Value);
            }
        }

        private void ShowMessage(string message, bool success)
        {
            lblMessage.Text = message;
            lblMessage.CssClass = success ? "message success" : "message error";
        }
    }
}
