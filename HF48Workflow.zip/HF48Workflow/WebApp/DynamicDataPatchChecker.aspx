<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DynamicDataPatchChecker.aspx.cs" Inherits="HF48Workflow.DynamicDataPatchChecker" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Dynamic Data Patch - Checker</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; background-color: #ccccff; color: #222; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: inline-block; width: 150px; font-weight: bold; font-size: 13px; vertical-align: top; padding-top: 4px; }
        input, select, textarea { padding: 5px 8px; border: 1px solid #aaa; border-radius: 3px; font-size: 13px; }
        .btn { padding: 7px 16px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-info { background-color: #17a2b8; color: white; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-danger { background-color: #dc3545; color: white; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; background: white; }
        .gridview th { background-color: #507CD1; color: white; padding: 8px; text-align: left; white-space: nowrap; }
        .gridview td { padding: 6px 8px; border-bottom: 1px solid #ddd; vertical-align: top; }
        .who-bar { background: #fff8d8; border: 1px dashed #d8b400; padding: 8px 14px; margin-bottom: 15px; font-size: 12px; border-radius: 3px; }
        .old-value { color: #555; }
        .new-value { color: #003366; font-weight: bold; }
    </style>
    <script type="text/javascript">
        function confirmApprove() { return confirm('Approve this data patch and update the main table?'); }
        function confirmReject() { return confirm('Reject this data patch request?'); }
    </script>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <h1>Dynamic Data Patch Checker</h1>
            <h2>Approve or reject data patch requests pending with the current checker</h2>
        </div>
        <div class="container">
            <div class="who-bar">
                <strong>Acting As:</strong>
                <asp:TextBox ID="txtCurrentUser" runat="server" Width="180px" />
                <asp:Button ID="btnSetUser" runat="server" Text="Switch User" CssClass="btn btn-info" OnClick="btnSetUser_Click" />
            </div>

            <asp:Panel ID="pnlMessage" runat="server" Visible="false"><asp:Label ID="lblMessage" runat="server" /></asp:Panel>
            <asp:HiddenField ID="hfRequestId" runat="server" Value="0" />

            <div class="panel">
                <div class="panel-header">Pending With Me</div>
                <div class="panel-body">
                    <asp:GridView ID="gvPending" runat="server" CssClass="gridview" AutoGenerateColumns="false" OnRowCommand="gvPending_RowCommand">
                        <Columns>
                            <asp:BoundField DataField="RequestId" HeaderText="Request Id" />
                            <asp:BoundField DataField="FriendlyName" HeaderText="Table" />
                            <asp:BoundField DataField="PrimaryKeyValue" HeaderText="Record Key" />
                            <asp:BoundField DataField="MakerLoginId" HeaderText="Maker" />
                            <asp:BoundField DataField="CheckerLoginId" HeaderText="Pending With" />
                            <asp:BoundField DataField="SubmittedOn" HeaderText="Submitted On" />
                            <asp:BoundField DataField="ChangedFieldCount" HeaderText="Fields" />
                            <asp:ButtonField Text="View" CommandName="ViewRequest" ButtonType="Button" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>

            <div class="panel">
                <div class="panel-header">Old vs New Data</div>
                <div class="panel-body">
                    <asp:GridView ID="gvRequestDetail" runat="server" CssClass="gridview" AutoGenerateColumns="false">
                        <Columns>
                            <asp:BoundField DataField="DisplayName" HeaderText="Field" />
                            <asp:BoundField DataField="OldValue" HeaderText="Old Data" ItemStyle-CssClass="old-value" />
                            <asp:BoundField DataField="NewValue" HeaderText="New Data" ItemStyle-CssClass="new-value" />
                        </Columns>
                    </asp:GridView>
                    <br />
                    <div class="form-group">
                        <label>Checker Remarks</label>
                        <asp:TextBox ID="txtCheckerRemarks" runat="server" Width="520px" TextMode="MultiLine" Rows="3" />
                    </div>
                    <asp:Button ID="btnApprove" runat="server" Text="Approve And Apply" CssClass="btn btn-success" OnClick="btnApprove_Click" OnClientClick="return confirmApprove();" />
                    <asp:Button ID="btnReject" runat="server" Text="Reject" CssClass="btn btn-danger" OnClick="btnReject_Click" OnClientClick="return confirmReject();" />
                </div>
            </div>

            <div class="panel">
                <div class="panel-header">Complete Request History</div>
                <div class="panel-body">
                    <asp:GridView ID="gvHistory" runat="server" CssClass="gridview" AutoGenerateColumns="true" />
                </div>
            </div>
        </div>
    </form>
</body>
</html>