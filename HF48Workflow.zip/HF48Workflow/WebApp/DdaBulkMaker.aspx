<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DdaBulkMaker.aspx.cs" Inherits="HF48Workflow.DdaBulkMaker" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>DDA Status Change - Maker</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; background-color: #ccccff; color: #222; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: inline-block; width: 180px; font-weight: bold; font-size: 13px; vertical-align: top; padding-top: 4px; }
        input, select, textarea { padding: 5px 8px; border: 1px solid #aaa; border-radius: 3px; font-size: 13px; }
        .btn { padding: 7px 16px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-primary { background-color: #003366; color: white; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-info { background-color: #17a2b8; color: white; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; background: white; }
        .gridview th { background-color: #507CD1; color: white; padding: 8px; text-align: left; white-space: nowrap; }
        .gridview td { padding: 6px 8px; border-bottom: 1px solid #ddd; vertical-align: top; }
        .who-bar { background: #fff8d8; border: 1px dashed #d8b400; padding: 8px 14px; margin-bottom: 15px; font-size: 12px; border-radius: 3px; }
        .hint { margin: 5px 0 12px 184px; color: #555; font-size: 12px; }
        .old-value { color: #7a3434; text-decoration: line-through; }
        .new-value { color: #176b2c; font-weight: bold; background-color: #e4f5e8; }
        .match-warning { color: #9b1c1c; font-weight: bold; }
        .tabs { margin: 0 0 15px 0; border-bottom: 2px solid #6c7ae0; padding-bottom: 8px; }
        .tab { display: inline-block; padding: 8px 14px; margin-right: 5px; background: #d7d7e8; color: #003366; font-weight: bold; text-decoration: none; border-radius: 3px; }
        .tab-active { background: #003366; color: white; }
        .dfm-pager td { padding: 8px 14px; background: #f8fafc; border-top: 1px solid #e2e8f0; text-align: center; }
        .dfm-pager span { display: inline-block; padding: 5px 11px; margin: 0 2px; border-radius: 4px; font-size: .85em; font-weight: 700; background: #1a3c5e; color: #fff; }
        .dfm-pager a { display: inline-block; padding: 5px 11px; margin: 0 2px; border-radius: 4px; font-size: .85em; font-weight: 600; background: #fff; color: #1a3c5e; border: 1px solid #cbd5e1; text-decoration: none; }
        .dfm-pager a:hover { background: #dbeafe; border-color: #93c5fd; }
    </style>
</head>
<body>
    <form id="form1" runat="server" enctype="multipart/form-data">
        <div class="header">
            <h1>DDA Status Change Maker</h1>
            <h2>Filter DDA records, select one or more rows, and submit status changes for checker approval</h2>
            <p><a href="DdaBulkChecker.aspx" style="color:white">Checker / request history</a></p>
        </div>
        <div class="container">
            <asp:Panel ID="pnlMessage" runat="server" Visible="false"><asp:Label ID="lblMessage" runat="server" /></asp:Panel>
            <asp:HiddenField ID="hfPreviewToken" runat="server" />
            <asp:HiddenField ID="hfActiveTab" runat="server" Value="DATA" />

            <div class="tabs">
                <asp:LinkButton ID="lnkStandardDataTab" runat="server" Text="DDA Status Change" CssClass="tab" OnClick="lnkStandardDataTab_Click" CausesValidation="false" />
                <asp:LinkButton ID="lnkDdsSystemDataTab" runat="server" Text="DDS System Data" CssClass="tab" OnClick="lnkDdsSystemDataTab_Click" CausesValidation="false" />
            </div>

            <asp:Panel ID="pnlStandardData" runat="server">
                <div class="panel">
                    <div class="panel-header">Filter DDA records</div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label>Data set</label>
                            <asp:DropDownList ID="ddlStandardTable" runat="server" Width="300px" />
                        </div>
                        <div class="form-group">
                            <label>From date</label>
                            <asp:TextBox ID="txtStandardFromDate" runat="server" placeholder="yyyy-mm-dd" />
                            <label style="width:60px;">To date</label>
                            <asp:TextBox ID="txtStandardToDate" runat="server" placeholder="yyyy-mm-dd" />
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <asp:DropDownList ID="ddlStandardStatus" runat="server" Width="220px">
                                <asp:ListItem Text="-- All statuses --" Value="" />
                                <asp:ListItem Text="Active" Value="Active" />
                                <asp:ListItem Text="Approved" Value="Approved" />
                                <asp:ListItem Text="Cancelled" Value="Cancelled" />
                                <asp:ListItem Text="Declined by CB" Value="Declined by CB" />
                                <asp:ListItem Text="Declined by Ops" Value="Declined by Ops" />
                                <asp:ListItem Text="Initiated" Value="Initiated" />
                                <asp:ListItem Text="Rejected" Value="Rejected" />
                                <asp:ListItem Text="Sent to DIB" Value="Sent to DIB" />
                            </asp:DropDownList>
                            <span class="hint" style="margin-left:8px;">Exact status; leave blank for all statuses.</span>
                        </div>
                        <div class="form-group">
                            <label>Application ID</label>
                            <asp:TextBox ID="txtStandardApplicationId" runat="server" Width="220px" />
                        </div>
                        <div class="form-group">
                            <label></label>
                            <asp:Button ID="btnPreviewStandard" runat="server" Text="Preview Data" CssClass="btn btn-primary" OnClick="btnPreviewStandard_Click" />
                            <asp:Button ID="btnExportStandardCsv" runat="server" Text="Export to CSV" CssClass="btn btn-info" OnClick="btnExportStandardCsv_Click" CausesValidation="false" />
                        </div>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-header"><asp:Label ID="lblStandardDataTitle" runat="server" Text="Preview" /></div>
                    <div class="panel-body">
                        <asp:GridView ID="gvStandardData" runat="server" CssClass="gridview" AutoGenerateColumns="true" OnRowDataBound="gvStandardData_RowDataBound">
                            <Columns>
                                <asp:TemplateField HeaderText="Select">
                                    <ItemTemplate><asp:CheckBox ID="chkStatusChange" runat="server" /></ItemTemplate>
                                </asp:TemplateField>
                                <asp:TemplateField HeaderText="New status">
                                    <ItemTemplate><asp:DropDownList ID="ddlNewStatus" runat="server" /></ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                        </asp:GridView>
                        <div class="form-group">
                            <label>Checker</label>
                            <asp:DropDownList ID="ddlChecker" runat="server" Width="300px" />
                        </div>
                        <div class="form-group">
                            <label>Maker remarks</label>
                            <asp:TextBox ID="txtMakerRemarks" runat="server" Width="520px" TextMode="MultiLine" Rows="3" MaxLength="1000" />
                        </div>
                        <asp:Button ID="btnSubmitStatusChange" runat="server" Text="Submit selected status changes to checker" CssClass="btn btn-success" OnClick="btnSubmitStatusChange_Click" />
                        <div class="panel-header">My DDA Status Change Requests</div>
                        <asp:GridView ID="gvMyRequests" runat="server" CssClass="gridview" AutoGenerateColumns="true" AllowPaging="true" PageSize="10" OnPageIndexChanging="gvMyRequests_PageIndexChanging" />
                    </div>
                </div>
            </asp:Panel>

            <asp:Panel ID="pnlDdsSystemData" runat="server" Visible="false">
                <div class="panel">
                    <div class="panel-header">DDS System Data - DDS_HFLMS_REG_CANC_SYNC</div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label>From response date</label>
                            <asp:TextBox ID="txtDdsFromDate" runat="server" placeholder="yyyy-mm-dd" />
                            <label style="width:60px;">To date</label>
                            <asp:TextBox ID="txtDdsToDate" runat="server" placeholder="yyyy-mm-dd" />
                        </div>
                        <div class="form-group">
                            <label>DDA Status</label>
                            <asp:DropDownList ID="ddlDdsStatus" runat="server" Width="360px">
                                <asp:ListItem Text="-- All statuses --" Value="" />
                                <asp:ListItem Text="Active" Value="Active" />
                                <asp:ListItem Text="CANCELLED" Value="CANCELLED" />
                                <asp:ListItem Text="Cancelled" Value="Cancelled" />
                                <asp:ListItem Text="DDA INITIATION - DDS FILE NOT GENERATED" Value="DDA INITIATION - DDS FILE NOT GENERATED" />
                                <asp:ListItem Text="DDA REGISTRATION CONFIRMATION PENDING" Value="DDA REGISTRATION CONFIRMATION PENDING" />
                                <asp:ListItem Text="DDA REGISTRATION REJECTED BY CENTRAL BANK" Value="DDA REGISTRATION REJECTED BY CENTRAL BANK" />
                                <asp:ListItem Text="Expired" Value="Expired" />
                                <asp:ListItem Text="FILE GENERATED BUT DDA INITIATION CENTRAL BANK response pending" Value="FILE GENERATED BUT DDA INITIATION CENTRAL BANK response pending" />
                                <asp:ListItem Text="REJECTED" Value="REJECTED" />
                            </asp:DropDownList>
                            <span class="hint" style="margin-left:8px;">Exact status; leave blank for all statuses.</span>
                        </div>
                        <div class="form-group">
                            <label>DDA Reference no.</label>
                            <asp:TextBox ID="txtDdsReferenceNo" runat="server" Width="220px" />
                        </div>
                        <div class="form-group">
                            <label>Application ID</label>
                            <asp:TextBox ID="txtDdsApplicationId" runat="server" Width="220px" />
                        </div>
                        <div class="form-group">
                            <label></label>
                            <asp:Button ID="btnPreviewDds" runat="server" Text="Preview Data" CssClass="btn btn-primary" OnClick="btnPreviewDds_Click" />
                            <asp:Button ID="btnExportDdsCsv" runat="server" Text="Export to CSV" CssClass="btn btn-info" OnClick="btnExportDdsCsv_Click" CausesValidation="false" />
                        </div>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-header"><asp:Label ID="lblDdsDataTitle" runat="server" Text="Preview" /></div>
                    <div class="panel-body">
                        <asp:GridView ID="gvDdsSystemData" runat="server" CssClass="gridview" AutoGenerateColumns="true" AllowPaging="true" PageSize="10" OnPageIndexChanging="gvDdsSystemData_PageIndexChanging">
                            <PagerStyle CssClass="dfm-pager" HorizontalAlign="Center" />
                            <PagerSettings Mode="NumericFirstLast" PageButtonCount="10" FirstPageText="&amp;laquo;" LastPageText="&amp;raquo;" />
                        </asp:GridView>
                    </div>
                </div>
            </asp:Panel>
        </div>
    </form>
</body>
</html>
