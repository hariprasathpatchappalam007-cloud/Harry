<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DSRChangeHistory.aspx.cs" Inherits="HF48Workflow.DSRChangeHistory" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>DSR Change History</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 24px; background: #f4f6fa; color: #25334a; }
        h1 { color: #003366; }
        .panel { padding: 16px; margin: 16px 0; background: white; border: 1px solid #ccd5e0; }
        .scroll { overflow-x: auto; }
        .grid { border-collapse: collapse; width: 100%; font-size: 12px; }
        .grid th { background: #003366; color: white; }
        .grid th, .grid td { padding: 8px; border: 1px solid #ccd5e0; white-space: nowrap; }
        .error { color: #a11919; display: block; margin: 12px 0; }
        .hint { font-size: 13px; }
        select { max-width: 100%; margin: 6px; }
    </style>
</head>
<body>
<form id="form1" runat="server">
    <h1>DSR Change History</h1>
    <p class="hint">DSR changes at every lead stage. Event times are UTC; lead creation/update dates retain the source time zone.
        Only changes recorded after audit deployment are available. NULL means no value, not zero.</p>
    <div class="panel">
        <asp:Label ID="lblApplication" runat="server" AssociatedControlID="txtApplicationID" Text="Application ID (APP_REF_NO): " />
        <asp:TextBox ID="txtApplicationID" runat="server" MaxLength="450" Width="260px" />
        <asp:Button ID="btnSearch" runat="server" Text="Search" OnClick="btnSearch_Click" />
        <asp:Label ID="lblMessage" runat="server" CssClass="error" role="alert" />
    </div>
    <asp:Panel ID="pnlResults" runat="server" Visible="false">
        <h2>Change events: before and after</h2>
        <p class="hint">I = inserted values; U = updated values; D = deleted values.
            Stage-only changes are not recorded. LeadStage is the stage visible when the finance write runs.
            ServiceRequestCount = 0 means no matching service request existed in that snapshot.</p>
        <div class="panel scroll">
            <asp:GridView ID="gvHistory" runat="server" CssClass="grid" AutoGenerateColumns="false"
                EnableViewState="false" EmptyDataText="No recorded DSR changes for this application.">
                <Columns>
                    <asp:BoundField DataField="AuditId" HeaderText="Event" />
                    <asp:BoundField DataField="ChangedAtUtc" HeaderText="Changed at (UTC)" DataFormatString="{0:yyyy-MM-dd HH:mm:ss.fffffff}" />
                    <asp:BoundField DataField="ChangeType" HeaderText="Operation" />
                    <asp:BoundField DataField="Lead_No" HeaderText="Lead no." />
                    <asp:BoundField DataField="ApplicationID" HeaderText="Application ID" NullDisplayText="NULL" />
                    <asp:BoundField DataField="LeadStage" HeaderText="Stage at change" NullDisplayText="NULL" />
                    <asp:BoundField DataField="OldLEAD_DSR" HeaderText="DSR before" NullDisplayText="NULL" />
                    <asp:BoundField DataField="NewLEAD_DSR" HeaderText="DSR after" NullDisplayText="NULL" />
                    <asp:BoundField DataField="OldLEAD_DSR_PRODUCT" HeaderText="Product DSR before" NullDisplayText="NULL" />
                    <asp:BoundField DataField="NewLEAD_DSR_PRODUCT" HeaderText="Product DSR after" NullDisplayText="NULL" />
                    <asp:BoundField DataField="OldLead_Stress_DSR" HeaderText="Stress DSR before" NullDisplayText="NULL" />
                    <asp:BoundField DataField="NewLead_Stress_DSR" HeaderText="Stress DSR after" NullDisplayText="NULL" />
                    <asp:BoundField DataField="OldLeadFTV" HeaderText="FTV before" NullDisplayText="NULL" />
                    <asp:BoundField DataField="NewLeadFTV" HeaderText="FTV after" NullDisplayText="NULL" />
                    <asp:BoundField DataField="OldIstisnaProduct" HeaderText="Istisna before" NullDisplayText="NULL" />
                    <asp:BoundField DataField="NewIstisnaProduct" HeaderText="Istisna after" NullDisplayText="NULL" />
                    <asp:BoundField DataField="OldConversionProduct" HeaderText="Conversion before" NullDisplayText="NULL" />
                    <asp:BoundField DataField="NewConversionProduct" HeaderText="Conversion after" NullDisplayText="NULL" />
                    <asp:BoundField DataField="LeadCreatedOn" HeaderText="Lead created (source)" DataFormatString="{0:yyyy-MM-dd HH:mm:ss}" NullDisplayText="NULL" />
                    <asp:BoundField DataField="LeadUpdatedOn" HeaderText="Lead updated (source)" DataFormatString="{0:yyyy-MM-dd HH:mm:ss}" NullDisplayText="NULL" />
                    <asp:BoundField DataField="ServiceRequestCount" HeaderText="SR count" />
                    <asp:BoundField DataField="DatabaseLogin" HeaderText="SQL login" />
                    <asp:BoundField DataField="ClientHost" HeaderText="Client host" />
                    <asp:BoundField DataField="ClientProgram" HeaderText="Client program" />
                </Columns>
            </asp:GridView>
        </div>
        <h2>Service requests at each DSR change</h2>
        <p class="hint">Historical copies linked by ApplicationID = APP_REF_NO, not live ticket stages.
            All matching requests are shown; independent requests do not hide a DSR event.</p>
        <div class="panel scroll">
            <asp:GridView ID="gvServiceRequests" runat="server" CssClass="grid" AutoGenerateColumns="false"
                EnableViewState="false" EmptyDataText="No matching service requests were captured for these events.">
                <Columns>
                    <asp:BoundField DataField="AuditId" HeaderText="DSR event" />
                    <asp:BoundField DataField="ChangedAtUtc" HeaderText="Snapshot time (UTC)" DataFormatString="{0:yyyy-MM-dd HH:mm:ss.fffffff}" />
                    <asp:BoundField DataField="LeadStage" HeaderText="Lead stage" NullDisplayText="NULL" />
                    <asp:BoundField DataField="SRNo" HeaderText="SR no." />
                    <asp:BoundField DataField="Category" HeaderText="Category" NullDisplayText="NULL" />
                    <asp:BoundField DataField="SubCategory" HeaderText="Subcategory" NullDisplayText="NULL" />
                    <asp:BoundField DataField="CAS_stage" HeaderText="CAS stage at change" NullDisplayText="NULL" />
                    <asp:BoundField DataField="ApplicationID" HeaderText="Application ID" />
                </Columns>
            </asp:GridView>
        </div>
        <asp:Panel ID="pnlCompare" runat="server" CssClass="panel" Visible="false">
            <h2>Compare two recorded snapshots</h2>
            <p class="hint">Compare post-change DSR values. Delta = To minus From in stored units, not a percentage conversion.
                Select events for the same lead; repeated stages can be compared. A NULL endpoint has no numeric delta.
                These are DSR events, not stage-entry or stage-exit baselines.</p>
            <asp:Label ID="lblFrom" runat="server" AssociatedControlID="ddlFrom" Text="From:" />
            <asp:DropDownList ID="ddlFrom" runat="server" />
            <br />
            <asp:Label ID="lblTo" runat="server" AssociatedControlID="ddlTo" Text="To:" />
            <asp:DropDownList ID="ddlTo" runat="server" />
            <asp:Button ID="btnCompare" runat="server" Text="Compare" OnClick="btnCompare_Click" />
            <div class="scroll">
                <asp:GridView ID="gvComparison" runat="server" CssClass="grid" AutoGenerateColumns="false" EnableViewState="false">
                    <Columns>
                        <asp:BoundField DataField="FromAuditId" HeaderText="From event" />
                        <asp:BoundField DataField="FromTimeUtc" HeaderText="From time (UTC)" DataFormatString="{0:yyyy-MM-dd HH:mm:ss.fffffff}" />
                        <asp:BoundField DataField="FromStage" HeaderText="From stage" NullDisplayText="NULL" />
                        <asp:BoundField DataField="ToAuditId" HeaderText="To event" />
                        <asp:BoundField DataField="ToTimeUtc" HeaderText="To time (UTC)" DataFormatString="{0:yyyy-MM-dd HH:mm:ss.fffffff}" />
                        <asp:BoundField DataField="ToStage" HeaderText="To stage" NullDisplayText="NULL" />
                        <asp:BoundField DataField="FieldName" HeaderText="DSR field" />
                        <asp:BoundField DataField="FromValue" HeaderText="From value" NullDisplayText="NULL" />
                        <asp:BoundField DataField="ToValue" HeaderText="To value" NullDisplayText="NULL" />
                        <asp:BoundField DataField="Delta" HeaderText="Delta (To - From)" NullDisplayText="N/A (NULL endpoint)" />
                        <asp:BoundField DataField="Result" HeaderText="Result" />
                    </Columns>
                </asp:GridView>
            </div>
        </asp:Panel>
    </asp:Panel>
</form>
</body>
</html>
