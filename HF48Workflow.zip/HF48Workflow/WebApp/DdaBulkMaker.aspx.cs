using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace HF48Workflow
{
    public partial class DdaBulkMaker : Page, IDdaApplicationHost
    {
        private const int MaxAttachmentBytes = 5242880;
        private const string StandardSelectionSessionKey = "DdaStandardDataSelection";
        private const string StandardPageSessionKey = "DdaStandardDataPageIndex";
        private bool _isFileDownload;
        public string LoginId { get { return DdaApplicationSupport.GetLoginId(this); } }

        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        public DataSet Query(string procedure, Action<SqlCommand> parameters)
        {
            return DdaApplicationSupport.Query(this, procedure, parameters);
        }

        public void Run(Action operation)
        {
            DdaApplicationSupport.Run(operation, ShowMessage);
        }

        private SqlConnection OpenConnection()
        {
            return DdaApplicationSupport.OpenConnection();
        }

        private SqlCommand Command(SqlConnection connection, string procedure)
        {
            return DdaApplicationSupport.Command(this, connection, procedure);
        }

        private static void Bind(GridView grid, DataTable data)
        {
            DdaApplicationSupport.Bind(grid, data);
        }

        protected override void OnInit(EventArgs e)
        {
            DdaApplicationSupport.InitializePage(this);
            base.OnInit(e);
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            DataTable preview = Session["DdaStandardDataPreview"] as DataTable;
            if (preview != null)
            {
                int pageIndex = Session[StandardPageSessionKey] == null
                    ? 0 : Convert.ToInt32(Session[StandardPageSessionKey], CultureInfo.InvariantCulture);
                int pageCount = Math.Max(1, (int)Math.Ceiling((double)preview.Rows.Count / gvStandardData.PageSize));
                gvStandardData.PageIndex = Math.Min(Math.Max(pageIndex, 0), pageCount - 1);
                gvStandardData.DataSource = preview;
                gvStandardData.DataBind();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            txtStandardFromDate.Attributes["type"] = "date";
            txtStandardToDate.Attributes["type"] = "date";
            txtDdsFromDate.Attributes["type"] = "date";
            txtDdsToDate.Attributes["type"] = "date";
            if (!IsPostBack)
            {
                txtCurrentUser.Text = Session["UserID"] as string ?? LoginId;
                ddlStandardTable.Items.Add(new ListItem("Registration", "CORE_DDA_REGISTRATION_DETAILS"));
                ddlStandardTable.Items.Add(new ListItem("Cancellation", "CORE_DDA_CANCELLATION_DETAILS"));
                ddlStandardTable.Items.Add(new ListItem("Legacy Registration", "CORE_FLEX_DDA_REGISTRATION_DETAILS"));
                if (String.IsNullOrWhiteSpace(LoginId))
                    ShowMessage("Enter your user ID and select Switch User to continue.", false);
                else LoadMyRequests();
            }
            else if (Session["DdaStandardDataPreview"] is DataTable)
                CaptureStandardSelection();
            ApplyActiveTab();
        }

        private void LoadMyRequests()
        {
            gvMyRequests.DataSource = ExecuteDataTable("dbo.Proc_DDA_ApplicationRequests", delegate(SqlCommand cmd)
            {
                cmd.Parameters.Add("@LoginId", SqlDbType.NVarChar, 100).Value = LoginId;
            });
            gvMyRequests.DataBind();
        }

        private void DownloadTemplate(string fileName, string content)
        {
            _isFileDownload = true;
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.ContentEncoding = Encoding.UTF8;
            Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
            Response.BinaryWrite(new UTF8Encoding(true).GetBytes(content));
            Response.Flush();
            Context.ApplicationInstance.CompleteRequest();
        }

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Run(delegate
            {
                string login = (txtCurrentUser.Text ?? "").Trim();
                if (login.Length == 0 || login.Length > 100)
                    throw new ArgumentException("Enter a username of up to 100 characters.");
                Session["UserID"] = login;
                LoadMyRequests();
                ShowMessage("Acting user set to: " + LoginId, true);
            });
        }

        protected void gvMyRequests_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvMyRequests.PageIndex = e.NewPageIndex;
            LoadMyRequests();
        }

        protected void lnkBulkTab_Click(object sender, EventArgs e)
        {
            hfActiveTab.Value = "DATA";
            ApplyActiveTab();
        }

        protected void lnkStandardDataTab_Click(object sender, EventArgs e)
        {
            hfActiveTab.Value = "DATA";
            ApplyActiveTab();
        }

        protected void lnkDdsSystemDataTab_Click(object sender, EventArgs e)
        {
            hfActiveTab.Value = "DDS";
            ApplyActiveTab();
        }

        private void ApplyActiveTab()
        {
            bool showStandardData = string.Equals(hfActiveTab.Value, "DATA", StringComparison.Ordinal);
            bool showDdsSystemData = string.Equals(hfActiveTab.Value, "DDS", StringComparison.Ordinal);
            pnlStandardData.Visible = showStandardData;
            pnlDdsSystemData.Visible = showDdsSystemData;
            lnkStandardDataTab.CssClass = showStandardData ? "tab tab-active" : "tab";
            lnkDdsSystemDataTab.CssClass = showDdsSystemData ? "tab tab-active" : "tab";
        }

        protected void btnPreviewStandard_Click(object sender, EventArgs e)
        {
            hfActiveTab.Value = "DATA";
            ApplyActiveTab();

            DateTime fromDate;
            DateTime toDate;
            DateTime? from = ParseOptionalDate(txtStandardFromDate.Text, "From date", out fromDate);
            DateTime? to = ParseOptionalDate(txtStandardToDate.Text, "To date", out toDate);
            if (!string.IsNullOrWhiteSpace(txtStandardFromDate.Text) && !from.HasValue)
                return;
            if (!string.IsNullOrWhiteSpace(txtStandardToDate.Text) && !to.HasValue)
                return;
            if (from.HasValue && to.HasValue && from.Value.Date > to.Value.Date)
            {
                ShowMessage("From date must be on or before To date.", false);
                return;
            }
            if (string.IsNullOrEmpty(ddlStandardTable.SelectedValue))
            {
                ShowMessage("Select a standard DDA data set.", false);
                return;
            }

            DataTable data = ExecuteDataTable("dbo.Proc_DDA_ApplicationGetStandardData", delegate(SqlCommand cmd)
            {
                cmd.Parameters.Add("@TableName", SqlDbType.NVarChar, 128).Value = ddlStandardTable.SelectedValue;
                cmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = from.HasValue ? (object)from.Value.Date : DBNull.Value;
                cmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = to.HasValue ? (object)to.Value.Date : DBNull.Value;
                cmd.Parameters.Add("@Status", SqlDbType.NVarChar, 100).Value = string.IsNullOrWhiteSpace(ddlStandardStatus.SelectedValue) ? (object)DBNull.Value : ddlStandardStatus.SelectedValue;
                cmd.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value = string.IsNullOrWhiteSpace(txtStandardApplicationId.Text) ? (object)DBNull.Value : txtStandardApplicationId.Text.Trim();
            });

            gvStandardData.PageIndex = 0;
            Session[StandardPageSessionKey] = 0;
            Session[StandardSelectionSessionKey] = new Dictionary<int, string[]>();
            Session["DdaStandardDataTarget"] = ddlStandardTable.SelectedValue == "CORE_DDA_REGISTRATION_DETAILS" ? "R"
                : ddlStandardTable.SelectedValue == "CORE_FLEX_DDA_REGISTRATION_DETAILS" ? "F" : "C";
            gvStandardData.DataSource = data;
            gvStandardData.DataBind();
            lblStandardDataTitle.Text = ddlStandardTable.SelectedItem.Text + " - " + data.Rows.Count + " record(s)";
            Session["DdaStandardDataPreview"] = data;
            Session["DdaStandardDataFilter"] = StandardDataFilterKey();
            ShowMessage("Preview loaded. " + data.Rows.Count + " record(s) match the selected filters.", true);
        }

        protected void gvStandardData_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            DataRowView dataRow = e.Row.DataItem as DataRowView;
            int rowIndex = gvStandardData.PageIndex * gvStandardData.PageSize + e.Row.RowIndex;
            CheckBox selected = (CheckBox)e.Row.FindControl("chkStatusChange");
            DropDownList status = (DropDownList)e.Row.FindControl("ddlNewStatus");
            status.Items.Add(new ListItem("-- Select status --", ""));
            foreach (string value in new[] { "Active", "Approved", "Cancelled", "Declined by CB",
                "Declined by Ops", "Initiated", "Rejected", "Sent to DIB" })
                status.Items.Add(new ListItem(value, value));

            TextBox newDdaReference = (TextBox)e.Row.FindControl("txtNewDdaReference");
            string originalReference = dataRow == null ? String.Empty : Convert.ToString(dataRow["DDA_REF_NO"]);
            newDdaReference.Text = originalReference;
            newDdaReference.Enabled = !String.Equals(Convert.ToString(Session["DdaStandardDataTarget"]), "C", StringComparison.Ordinal);

            Dictionary<int, string[]> selections = Session[StandardSelectionSessionKey] as Dictionary<int, string[]>;
            string[] selection;
            if (selections != null && selections.TryGetValue(rowIndex, out selection))
            {
                selected.Checked = true;
                status.SelectedValue = selection[0];
                newDdaReference.Text = selection[1];
            }
        }

        protected void gvStandardData_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            CaptureStandardSelection();
            gvStandardData.PageIndex = e.NewPageIndex;
            Session[StandardPageSessionKey] = e.NewPageIndex;
            DataTable preview = Session["DdaStandardDataPreview"] as DataTable;
            if (preview != null)
            {
                gvStandardData.DataSource = preview;
                gvStandardData.DataBind();
            }
        }

        private void CaptureStandardSelection()
        {
            Dictionary<int, string[]> selections = Session[StandardSelectionSessionKey] as Dictionary<int, string[]>;
            if (selections == null)
            {
                selections = new Dictionary<int, string[]>();
                Session[StandardSelectionSessionKey] = selections;
            }
            foreach (GridViewRow gridRow in gvStandardData.Rows)
            {
                if (gridRow.RowType != DataControlRowType.DataRow) continue;
                int rowIndex = gvStandardData.PageIndex * gvStandardData.PageSize + gridRow.RowIndex;
                CheckBox selected = (CheckBox)gridRow.FindControl("chkStatusChange");
                if (!selected.Checked)
                {
                    selections.Remove(rowIndex);
                    continue;
                }
                DropDownList status = (DropDownList)gridRow.FindControl("ddlNewStatus");
                TextBox newReference = (TextBox)gridRow.FindControl("txtNewDdaReference");
                selections[rowIndex] = new string[] { status.SelectedValue, newReference.Text.Trim() };
            }
        }

        protected void btnSubmitStatusChange_Click(object sender, EventArgs e)
        {
            Run(delegate
            {
                CaptureStandardSelection();
                DataTable preview = Session["DdaStandardDataPreview"] as DataTable;
                if (preview == null
                    || !String.Equals(Convert.ToString(Session["DdaStandardDataFilter"]),
                        StandardDataFilterKey(), StringComparison.Ordinal))
                    throw new ArgumentException("The filtered preview expired or the filters changed. Preview the records again.");
                if (String.IsNullOrWhiteSpace(txtMakerRemarks.Text) || txtMakerRemarks.Text.Trim().Length > 1000)
                    throw new ArgumentException("Enter maker remarks of up to 1000 characters.");
                if (fuAttachment.HasFile && fuAttachment.PostedFile.ContentLength > MaxAttachmentBytes)
                    throw new ArgumentException("The supporting attachment must not exceed 5 MB.");

                string target = ddlStandardTable.SelectedValue == "CORE_DDA_REGISTRATION_DETAILS" ? "R"
                    : ddlStandardTable.SelectedValue == "CORE_FLEX_DDA_REGISTRATION_DETAILS" ? "F"
                    : ddlStandardTable.SelectedValue == "CORE_DDA_CANCELLATION_DETAILS" ? "C" : null;
                if (target == null) throw new ArgumentException("Select a valid DDA data set.");

                StringBuilder rowsXml = new StringBuilder();
                int selected = 0;
                Dictionary<int, string[]> selections = Session[StandardSelectionSessionKey] as Dictionary<int, string[]>;
                if (selections == null) selections = new Dictionary<int, string[]>();
                List<int> rowIndexes = new List<int>(selections.Keys);
                rowIndexes.Sort();
                using (XmlWriter writer = XmlWriter.Create(rowsXml, new XmlWriterSettings { OmitXmlDeclaration = true }))
                {
                    writer.WriteStartElement("Rows");
                    foreach (int rowIndex in rowIndexes)
                    {
                        if (rowIndex < 0 || rowIndex >= preview.Rows.Count)
                            throw new ArgumentException("The selected preview expired. Fetch the records again.");
                        selected++;
                        DataRow row = preview.Rows[rowIndex];
                        string status = selections[rowIndex][0];
                        string applicationId = GetDataValue(row, "APPLICATIONID");
                        string refNbr = GetDataValue(row, "REF_NBR");
                        string internalRef = GetDataValue(row, "DDS_INTERNAL_REF");
                        string ddaReference = GetDataValue(row, "DDA_REF_NO");
                        string newDdaReference = target == "C" ? ddaReference : selections[rowIndex][1];
                        string oldStatus = target == "C"
                            ? GetDataValue(row, "CANCELLATION_STATUS") : GetDataValue(row, "DDS_STATUS");
                        string matchBy = target == "C" ? "DDA_REF_NO"
                            : target == "F" || !String.IsNullOrWhiteSpace(refNbr) ? "REF_NBR" : "DDS_INTERNAL_REF";
                        string matchValue = matchBy == "REF_NBR" ? refNbr
                            : matchBy == "DDS_INTERNAL_REF" ? internalRef : ddaReference;
                        if (String.IsNullOrWhiteSpace(applicationId) || applicationId.Length > 200
                            || String.IsNullOrWhiteSpace(matchValue) || matchValue.Length > 200
                            || status.Length == 0 || newDdaReference.Length > 200)
                            throw new ArgumentException("Every selected row must have an Application ID, a usable reference, a proposed status, and a valid DDA reference.");
                        writer.WriteStartElement("Row");
                        writer.WriteAttributeString("TargetCode", target);
                        writer.WriteAttributeString("ApplicationId", applicationId);
                        writer.WriteAttributeString("MatchBy", matchBy);
                        writer.WriteAttributeString("RefNbr", refNbr);
                        writer.WriteAttributeString("InternalRef", internalRef);
                        writer.WriteAttributeString("DdaRefNo", ddaReference);
                        writer.WriteAttributeString("CurrentStatus", oldStatus);
                        writer.WriteAttributeString("NewStatus", status);
                        writer.WriteAttributeString("NewDdaRefNo", newDdaReference);
                        writer.WriteEndElement();
                    }
                    writer.WriteEndElement();
                }
                if (selected == 0) throw new ArgumentException("Select at least one row to submit.");

                int requestId;
                byte[] attachment = fuAttachment.HasFile ? ReadPostedFile(fuAttachment.PostedFile) : null;
                using (SqlConnection connection = OpenConnection())
                using (SqlCommand command = Command(connection, "dbo.Proc_DDA_ApplicationSubmit"))
                {
                    command.Parameters.Add("@Remarks", SqlDbType.NVarChar, 1000).Value = txtMakerRemarks.Text.Trim();
                    command.Parameters.Add("@Rows", SqlDbType.Xml).Value = rowsXml.ToString();
                    command.Parameters.Add("@AttachmentName", SqlDbType.NVarChar, 260).Value =
                        fuAttachment.HasFile ? (object)DdaBulkCsv.SafeFileName(fuAttachment.FileName) : DBNull.Value;
                    command.Parameters.Add("@AttachmentType", SqlDbType.NVarChar, 150).Value =
                        fuAttachment.HasFile ? (object)(fuAttachment.PostedFile.ContentType ?? "application/octet-stream") : DBNull.Value;
                    command.Parameters.Add("@AttachmentData", SqlDbType.VarBinary, -1).Value =
                        attachment == null ? (object)DBNull.Value : attachment;
                    SqlParameter id = command.Parameters.Add("@RequestId", SqlDbType.Int);
                    id.Direction = ParameterDirection.Output;
                    command.ExecuteNonQuery();
                    requestId = Convert.ToInt32(id.Value, CultureInfo.InvariantCulture);
                }

                Session.Remove("DdaStandardDataPreview");
                Session.Remove("DdaStandardDataFilter");
                Session.Remove(StandardSelectionSessionKey);
                Session.Remove(StandardPageSessionKey);
                Session.Remove("DdaStandardDataTarget");
                gvStandardData.DataSource = null;
                gvStandardData.DataBind();
                txtMakerRemarks.Text = String.Empty;
                ShowMessage("DDA status change request " + requestId.ToString(CultureInfo.InvariantCulture)
                    + " submitted for checker approval. The source rows are unchanged until approval.", true);
                LoadMyRequests();
            });
        }

        private DateTime? ParseOptionalDate(string input, string fieldName, out DateTime parsed)
        {
            parsed = DateTime.MinValue;
            if (string.IsNullOrWhiteSpace(input)) return null;
            if (DateTime.TryParseExact(input.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed))
                return parsed.Date;
            ShowMessage(fieldName + " must be a valid date.", false);
            return null;
        }

        protected void btnExportStandardCsv_Click(object sender, EventArgs e)
        {
            hfActiveTab.Value = "DATA";
            ApplyActiveTab();
            DataTable data = Session["DdaStandardDataPreview"] as DataTable;
            if (data == null || data.Rows.Count == 0)
            {
                ShowMessage("Preview data before exporting to CSV.", false);
                return;
            }
            if (!string.Equals(Convert.ToString(Session["DdaStandardDataFilter"]), StandardDataFilterKey(), StringComparison.Ordinal))
            {
                ShowMessage("The filters have changed. Preview the current filters before exporting.", false);
                return;
            }

            string templateName;
            string csv = BuildStandardTemplateCsv(data, ddlStandardTable.SelectedValue, out templateName);
            string fileName = templateName + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".csv";
            DownloadTemplate(fileName, csv);
        }

        private string BuildStandardTemplateCsv(DataTable data, string tableName, out string templateName)
        {
            bool cancellation = tableName == "CORE_DDA_CANCELLATION_DETAILS";
            bool declineTemplate = !cancellation &&
                (ddlStandardStatus.SelectedValue == "Declined by CB" ||
                 ddlStandardStatus.SelectedValue == "Rejected" ||
                 ddlStandardStatus.SelectedValue == "Declined by Ops");
            templateName = cancellation ? "DDA_Cancellation_Template" :
                declineTemplate ? "DDA_Decline_Template" : "DDA_Registration_Template";

            string statusColumn = cancellation ? "CANCELLATION_STATUS" : "DDS_STATUS";
            string[] columns = cancellation
                ? new string[] { "REF_NBR", "DDS_INTERNAL_REF", "CANCELLATION_STATUS", "DDA_REF_NO" }
                : new string[] { "REF_NBR", "DDS_INTERNAL_REF", "STATUS", "DDA_REF_NO" };
            StringBuilder csv = new StringBuilder();
            AppendTemplateCsvRow(csv, columns);

            foreach (DataRow row in data.Rows)
            {
                string status = GetDataValue(row, statusColumn);
                bool declined = !cancellation && IsDeclineStatus(status);
                string ddaReferenceNo = declined ? "" : GetDataValue(row, "DDA_REF_NO");
                AppendTemplateCsvRow(csv, new string[]
                {
                    GetDataValue(row, "REF_NBR"),
                    GetDataValue(row, "DDS_INTERNAL_REF"),
                    status,
                    ddaReferenceNo
                });
            }
            return csv.ToString();
        }

        private bool IsDeclineStatus(string status)
        {
            return string.Equals(status, "Declined by CB", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Declined by Ops", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Rejected", StringComparison.OrdinalIgnoreCase);
        }

        private string GetDataValue(DataRow row, string columnName)
        {
            if (!row.Table.Columns.Contains(columnName) || row[columnName] == DBNull.Value) return "";
            return Convert.ToString(row[columnName], CultureInfo.InvariantCulture);
        }

        private void AppendTemplateCsvRow(StringBuilder csv, string[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                if (i > 0) csv.Append(',');
                csv.Append(DdaBulkCsv.Escape(DdaBulkCsv.ExcelTextCell(values[i])));
            }
            csv.Append("\r\n");
        }

        protected void btnPreviewDds_Click(object sender, EventArgs e)
        {
            hfActiveTab.Value = "DDS";
            ApplyActiveTab();

            DateTime fromDate;
            DateTime toDate;
            DateTime? from = ParseOptionalDate(txtDdsFromDate.Text, "From response date", out fromDate);
            DateTime? to = ParseOptionalDate(txtDdsToDate.Text, "To date", out toDate);
            if (!string.IsNullOrWhiteSpace(txtDdsFromDate.Text) && !from.HasValue)
                return;
            if (!string.IsNullOrWhiteSpace(txtDdsToDate.Text) && !to.HasValue)
                return;
            if (from.HasValue && to.HasValue && from.Value.Date > to.Value.Date)
            {
                ShowMessage("From response date must be on or before To date.", false);
                return;
            }

            DataTable data = ExecuteDataTable("dbo.Proc_DDA_ApplicationGetDdsSystemData", delegate(SqlCommand cmd)
            {
                cmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = from.HasValue ? (object)from.Value.Date : DBNull.Value;
                cmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = to.HasValue ? (object)to.Value.Date : DBNull.Value;
                cmd.Parameters.Add("@Status", SqlDbType.NVarChar, 100).Value = string.IsNullOrWhiteSpace(ddlDdsStatus.SelectedValue) ? (object)DBNull.Value : ddlDdsStatus.SelectedValue;
                cmd.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value = string.IsNullOrWhiteSpace(txtDdsApplicationId.Text) ? (object)DBNull.Value : txtDdsApplicationId.Text.Trim();
                cmd.Parameters.Add("@DdaReferenceNo", SqlDbType.NVarChar, 200).Value = string.IsNullOrWhiteSpace(txtDdsReferenceNo.Text) ? (object)DBNull.Value : txtDdsReferenceNo.Text.Trim();
            });

            gvDdsSystemData.PageIndex = 0;
            gvDdsSystemData.DataSource = data;
            gvDdsSystemData.DataBind();
            lblDdsDataTitle.Text = "DDS System Data - " + data.Rows.Count + " record(s)";
            Session["DdsSystemDataPreview"] = data;
            Session["DdsSystemDataFilter"] = DdsSystemDataFilterKey();
            ShowMessage("DDS System Data preview loaded. " + data.Rows.Count + " record(s) match the selected filters.", true);
        }

        protected void btnExportDdsCsv_Click(object sender, EventArgs e)
        {
            hfActiveTab.Value = "DDS";
            ApplyActiveTab();
            DataTable data = Session["DdsSystemDataPreview"] as DataTable;
            if (data == null || data.Rows.Count == 0)
            {
                ShowMessage("Preview DDS System Data before exporting to CSV.", false);
                return;
            }
            if (!string.Equals(Convert.ToString(Session["DdsSystemDataFilter"]), DdsSystemDataFilterKey(), StringComparison.Ordinal))
            {
                ShowMessage("The filters have changed. Preview the current filters before exporting.", false);
                return;
            }

            string fileName = "DDS_System_Data_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".csv";
            DownloadTemplate(fileName, BuildExcelTextCsv(data));
        }

        protected void gvDdsSystemData_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            DataTable data = Session["DdsSystemDataPreview"] as DataTable;
            if (data == null)
            {
                ShowMessage("Preview DDS System Data before changing pages.", false);
                return;
            }
            gvDdsSystemData.PageIndex = e.NewPageIndex;
            gvDdsSystemData.DataSource = data;
            gvDdsSystemData.DataBind();
        }

        private string BuildExcelTextCsv(DataTable data)
        {
            StringBuilder csv = new StringBuilder();
            for (int columnIndex = 0; columnIndex < data.Columns.Count; columnIndex++)
            {
                if (columnIndex > 0) csv.Append(',');
                csv.Append(DdaBulkCsv.Escape(data.Columns[columnIndex].ColumnName));
            }
            csv.Append("\r\n");
            foreach (DataRow row in data.Rows)
            {
                for (int columnIndex = 0; columnIndex < data.Columns.Count; columnIndex++)
                {
                    if (columnIndex > 0) csv.Append(',');
                    object cell = row[columnIndex];
                    string value = cell == DBNull.Value ? "" : cell is DateTime
                        ? ((DateTime)cell).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)
                        : Convert.ToString(cell, CultureInfo.InvariantCulture);
                    csv.Append(DdaBulkCsv.Escape(DdaBulkCsv.ExcelTextCell(value)));
                }
                csv.Append("\r\n");
            }
            return csv.ToString();
        }

        private string StandardDataFilterKey()
        {
            return string.Join("|", new string[]
            {
                ddlStandardTable.SelectedValue,
                (txtStandardFromDate.Text ?? "").Trim(),
                (txtStandardToDate.Text ?? "").Trim(),
                ddlStandardStatus.SelectedValue,
                (txtStandardApplicationId.Text ?? "").Trim()
            });
        }

        private string DdsSystemDataFilterKey()
        {
            return string.Join("|", new string[]
            {
                (txtDdsFromDate.Text ?? "").Trim(),
                (txtDdsToDate.Text ?? "").Trim(),
                ddlDdsStatus.SelectedValue,
                (txtDdsReferenceNo.Text ?? "").Trim(),
                (txtDdsApplicationId.Text ?? "").Trim()
            });
        }

        private DataTable ExecuteDataTable(string procedureName, Action<SqlCommand> addParameters)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (addParameters != null) addParameters(cmd);
                DataTable dt = new DataTable();
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    conn.Open();
                    adapter.Fill(dt);
                }
                return dt;
            }
        }

        private byte[] ReadPostedFile(HttpPostedFile postedFile)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = postedFile.InputStream.Read(buffer, 0, buffer.Length)) > 0)
                    memory.Write(buffer, 0, bytesRead);
                return memory.ToArray();
            }
        }

        public void ShowMessage(string message, bool success)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = success ? "msg-success" : "msg-error";
            lblMessage.Text = HttpUtility.HtmlEncode(message);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (!_isFileDownload) base.Render(writer);
        }
    }
}
