namespace HF48Workflow
{
    public partial class DSRChangeHistory
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.Label lblApplication;
        protected global::System.Web.UI.WebControls.TextBox txtApplicationID;
        protected global::System.Web.UI.WebControls.Button btnSearch;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.Panel pnlResults;
        protected global::System.Web.UI.WebControls.GridView gvHistory;
        protected global::System.Web.UI.WebControls.GridView gvServiceRequests;
        protected global::System.Web.UI.WebControls.Panel pnlCompare;
        protected global::System.Web.UI.WebControls.Label lblFrom;
        protected global::System.Web.UI.WebControls.DropDownList ddlFrom;
        protected global::System.Web.UI.WebControls.Label lblTo;
        protected global::System.Web.UI.WebControls.DropDownList ddlTo;
        protected global::System.Web.UI.WebControls.Button btnCompare;
        protected global::System.Web.UI.WebControls.GridView gvComparison;
    }
}
