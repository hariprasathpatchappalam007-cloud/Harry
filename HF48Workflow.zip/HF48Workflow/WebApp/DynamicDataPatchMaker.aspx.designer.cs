namespace HF48Workflow
{
    public partial class DynamicDataPatchMaker
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.TextBox txtCurrentUser;
        protected global::System.Web.UI.WebControls.Button btnSetUser;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hfConfigId;
        protected global::System.Web.UI.WebControls.HiddenField hfPrimaryKeyValue;
        protected global::System.Web.UI.WebControls.DropDownList ddlPatchTables;
        protected global::System.Web.UI.WebControls.TextBox txtPrimaryKeyValue;
        protected global::System.Web.UI.WebControls.Button btnLoadRecord;
        protected global::System.Web.UI.WebControls.PlaceHolder phPatchFields;
        protected global::System.Web.UI.WebControls.DropDownList ddlChecker;
        protected global::System.Web.UI.WebControls.TextBox txtMakerRemarks;
        protected global::System.Web.UI.WebControls.Button btnSubmit;
        protected global::System.Web.UI.WebControls.GridView gvMyRequests;
    }
}