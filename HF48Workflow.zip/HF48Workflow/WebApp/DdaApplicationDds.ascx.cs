using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class DdaApplicationDds : UserControl
    {
        private IDdaApplicationHost Host { get { return (IDdaApplicationHost)Page; } }
        private string CacheKey
        {
            get
            {
                if (ViewState["DdsKey"] == null) ViewState["DdsKey"] = "DdaApplicationDds_" + Guid.NewGuid().ToString("N");
                return (string)ViewState["DdsKey"];
            }
        }

        private DataTable Fetch()
        {
            if (String.IsNullOrWhiteSpace(txtApplicationId.Text) || txtApplicationId.Text.Length > 200)
                throw new ArgumentException("Enter an exact Application ID for DDS data.");
            DateTime? from = DateValue(txtFrom.Text);
            DateTime? to = DateValue(txtTo.Text);
            if (from.HasValue && to.HasValue && from.Value > to.Value)
                throw new ArgumentException("DDS response from date must not exceed the to date.");
            using (DataSet data = Host.Query("dbo.Proc_DDA_ApplicationDdsData", delegate(SqlCommand command)
            {
                command.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value = txtApplicationId.Text.Trim();
                command.Parameters.Add("@FromDate", SqlDbType.Date).Value = from.HasValue ? (object)from.Value : DBNull.Value;
                command.Parameters.Add("@ToDate", SqlDbType.Date).Value = to.HasValue ? (object)to.Value : DBNull.Value;
                command.Parameters.Add("@Status", SqlDbType.NVarChar, 100).Value =
                    String.IsNullOrWhiteSpace(txtStatus.Text) ? (object)DBNull.Value : txtStatus.Text.Trim();
                command.Parameters.Add("@DdaReferenceNo", SqlDbType.NVarChar, 200).Value =
                    String.IsNullOrWhiteSpace(txtReference.Text) ? (object)DBNull.Value : txtReference.Text.Trim();
            }))
                return data.Tables[0].Copy();
        }

        private static DateTime? DateValue(string text)
        {
            if (String.IsNullOrWhiteSpace(text)) return null;
            DateTime date;
            if (!DateTime.TryParseExact(text.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                throw new ArgumentException("Enter DDS response dates as yyyy-MM-dd.");
            return date;
        }

        protected void Fetch_Click(object sender, EventArgs e)
        {
            Host.Run(delegate
            {
                DataTable data = Fetch();
                Session[CacheKey] = data;
                ViewState["DdsFilters"] = FilterKey();
                gvDds.PageIndex = 0;
                gvDds.DataSource = data;
                gvDds.DataBind();
                lblCount.Text = data.Rows.Count.ToString(CultureInfo.InvariantCulture) + " record(s)";
            });
        }

        private string FilterKey()
        {
            return String.Join("|", new[] { txtApplicationId.Text.Trim(), txtReference.Text.Trim(),
                txtFrom.Text.Trim(), txtTo.Text.Trim(), txtStatus.Text.Trim() });
        }

        protected void Page_Changing(object sender, GridViewPageEventArgs e)
        {
            Host.Run(delegate
            {
                DataTable data = Session[CacheKey] as DataTable;
                if (data == null || !String.Equals(FilterKey(), ViewState["DdsFilters"] as string, StringComparison.Ordinal))
                    throw new ArgumentException("Fetch DDS data again before changing pages.");
                gvDds.PageIndex = e.NewPageIndex;
                gvDds.DataSource = data;
                gvDds.DataBind();
            });
        }

        protected void Export_Click(object sender, EventArgs e)
        {
            Host.Run(delegate
            {
                DataTable data = Session[CacheKey] as DataTable;
                if (data == null || !String.Equals(FilterKey(), ViewState["DdsFilters"] as string, StringComparison.Ordinal))
                    throw new ArgumentException("Fetch DDS data with the current filters before exporting.");
                StringBuilder csv = new StringBuilder();
                for (int i = 0; i < data.Columns.Count; i++)
                {
                    if (i > 0) csv.Append(',');
                    csv.Append(DdaBulkCsv.Escape(data.Columns[i].ColumnName));
                }
                csv.Append("\r\n");
                foreach (DataRow row in data.Rows)
                {
                    for (int i = 0; i < data.Columns.Count; i++)
                    {
                        if (i > 0) csv.Append(',');
                        string value = row[i] is DateTime
                            ? ((DateTime)row[i]).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)
                            : Convert.ToString(row[i], CultureInfo.InvariantCulture);
                        csv.Append(DdaBulkCsv.Escape(DdaBulkCsv.ExcelTextCell(value)));
                    }
                    csv.Append("\r\n");
                }
                byte[] bytes = Encoding.UTF8.GetBytes(csv.ToString());
                Response.Clear();
                Response.ContentType = "text/csv";
                Response.AddHeader("Content-Disposition", "attachment; filename=DDA_DDS_System_Data.csv");
                Response.BinaryWrite(Encoding.UTF8.GetPreamble());
                Response.BinaryWrite(bytes);
                Response.Flush();
                Response.SuppressContent = true;
                Context.ApplicationInstance.CompleteRequest();
            });
        }
    }
}
