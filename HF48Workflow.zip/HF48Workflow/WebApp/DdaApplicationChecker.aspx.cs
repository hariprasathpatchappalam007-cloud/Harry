using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Web;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class DdaApplicationChecker : DdaApplicationPage
    {
        protected override Label MessageLabel { get { return lblMessage; } }
        protected override string AccessRole { get { return null; } }
        private int SelectedRequestId
        {
            get { return ViewState["RequestId"] == null ? 0 : (int)ViewState["RequestId"]; }
            set { ViewState["RequestId"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            litLogin.Text = LoginId;
            if (!IsPostBack) Run(delegate
            {
                Refresh();
                if (!String.IsNullOrEmpty(Request.QueryString["requestId"]))
                {
                    int id;
                    if (!Int32.TryParse(Request.QueryString["requestId"], out id) || id <= 0)
                        throw new ArgumentException("The request ID is invalid.");
                    LoadRequest(id);
                }
            });
        }

        private void Refresh()
        {
            LoadPending();
            LoadHistory();
        }

        private void LoadPending()
        {
            using (DataSet data = Query("dbo.Proc_DDA_ApplicationRequests", delegate(SqlCommand command)
            {
                command.Parameters.Add("@PendingOnly", SqlDbType.Bit).Value = true;
            })) Bind(gvPending, data.Tables[0]);
        }

        private void LoadHistory()
        {
            using (DataSet data = Query("dbo.Proc_DDA_ApplicationRequests", null)) Bind(gvHistory, data.Tables[0]);
        }

        private void LoadRequest(int requestId)
        {
            pnlReview.Visible = false;
            SelectedRequestId = 0;
            using (DataSet data = Query("dbo.Proc_DDA_ApplicationReview", delegate(SqlCommand command)
            {
                command.Parameters.Add("@RequestId", SqlDbType.Int).Value = requestId;
            }))
            {
                DataRow summary = data.Tables[0].Rows[0];
                Bind(gvSummary, data.Tables[0]);
                Bind(gvDetails, data.Tables[1]);
                Bind(gvAudit, data.Tables[2]);
                SelectedRequestId = requestId;
                bool canDecide = Convert.ToString(summary["StatusCode"]) == "P"
                    && String.Equals(Convert.ToString(summary["CheckerLoginId"]), LoginId, StringComparison.OrdinalIgnoreCase)
                    && !String.Equals(Convert.ToString(summary["MakerLoginId"]), LoginId, StringComparison.OrdinalIgnoreCase);
                btnApprove.Enabled = btnReject.Enabled = canDecide;
                btnAttachment.Enabled = !String.IsNullOrEmpty(Convert.ToString(summary["AttachmentName"]));
                pnlReview.Visible = true;
                txtRemarks.Text = String.Empty;
            }
        }

        private void Decide(string decision)
        {
            Run(delegate
            {
                if (SelectedRequestId <= 0) throw new ArgumentException("Select a request to review.");
                if (String.IsNullOrWhiteSpace(txtRemarks.Text) || txtRemarks.Text.Length > 1000)
                    throw new ArgumentException("Enter checker remarks of up to 1000 characters.");
                int id = SelectedRequestId;
                using (SqlConnection connection = OpenConnection())
                using (SqlCommand command = Command(connection, "dbo.Proc_DDA_ApplicationCheck"))
                {
                    command.Parameters.Add("@RequestId", SqlDbType.Int).Value = id;
                    command.Parameters.Add("@Decision", SqlDbType.Char, 1).Value = decision;
                    command.Parameters.Add("@Remarks", SqlDbType.NVarChar, 1000).Value = txtRemarks.Text.Trim();
                    command.ExecuteNonQuery();
                }
                btnApprove.Enabled = btnReject.Enabled = false;
                ShowMessage(decision == "A" ? "Request approved. Selected source rows and DDA movement history were updated."
                    : "Request rejected. Source records and movement history were not changed.", true);
                LoadRequest(id);
                Refresh();
            });
        }

        protected void Attachment_Click(object sender, EventArgs e)
        {
            Run(delegate
            {
                if (SelectedRequestId <= 0) throw new ArgumentException("Select a request before downloading.");
                using (DataSet data = Query("dbo.Proc_DDA_ApplicationReview", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@RequestId", SqlDbType.Int).Value = SelectedRequestId;
                    command.Parameters.Add("@FileOnly", SqlDbType.Bit).Value = true;
                }))
                {
                    DataRow row = data.Tables[0].Rows[0];
                    byte[] bytes = row["AttachmentData"] as byte[];
                    if (bytes == null) throw new ArgumentException("No supporting attachment was provided.");
                    string name = DdaBulkCsv.SafeFileName(Convert.ToString(row["AttachmentName"]));
                    Response.Clear();
                    Response.ContentType = "application/octet-stream";
                    Response.AddHeader("X-Content-Type-Options", "nosniff");
                    Response.AddHeader("Content-Disposition", "attachment; filename*=UTF-8''" + Uri.EscapeDataString(name));
                    Response.BinaryWrite(bytes);
                    Response.Flush();
                    Response.SuppressContent = true;
                    Context.ApplicationInstance.CompleteRequest();
                }
            });
        }

        protected void Approve_Click(object sender, EventArgs e) { Decide("A"); }
        protected void Reject_Click(object sender, EventArgs e) { Decide("R"); }
        protected void Refresh_Click(object sender, EventArgs e) { Run(Refresh); }
        protected void Pending_Selected(object sender, EventArgs e)
        {
            Run(delegate { LoadRequest(Convert.ToInt32(gvPending.SelectedDataKey.Value, CultureInfo.InvariantCulture)); });
        }
        protected void History_Selected(object sender, EventArgs e)
        {
            Run(delegate { LoadRequest(Convert.ToInt32(gvHistory.SelectedDataKey.Value, CultureInfo.InvariantCulture)); });
        }
        protected void Pending_Page(object sender, GridViewPageEventArgs e)
        {
            gvPending.PageIndex = e.NewPageIndex;
            Run(LoadPending);
        }
        protected void History_Page(object sender, GridViewPageEventArgs e)
        {
            gvHistory.PageIndex = e.NewPageIndex;
            Run(LoadHistory);
        }
        protected void RequestsTab_Click(object sender, EventArgs e) { views.ActiveViewIndex = 0; }
        protected void DdsTab_Click(object sender, EventArgs e) { views.ActiveViewIndex = 1; }
    }
}
