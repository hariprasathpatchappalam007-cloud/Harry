<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DdaApplicationMaker.aspx.cs" Inherits="HF48Workflow.DdaApplicationMaker" %>
<%@ Register Src="DdaApplicationDds.ascx" TagPrefix="dda" TagName="DdsData" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server"><title>DDA Application Update - Maker</title><link rel="stylesheet" href="DdaApplication.css" /></head>
<body><form id="form1" runat="server" enctype="multipart/form-data">
<header><h1>DDA Application Update - Maker</h1>
    <a href="DdaApplicationChecker.aspx">Checker / request history</a><a href="DdaBulkMaker.aspx">Existing CSV workflow</a>
</header>
<main>
<p>Authenticated user: <asp:Literal ID="litLogin" runat="server" Mode="Encode" /></p>
<asp:Label ID="lblMessage" runat="server" />
<div class="tabs">
    <asp:LinkButton runat="server" Text="Application Status Update" OnClick="UpdateTab_Click" CausesValidation="false" />
    <asp:LinkButton runat="server" Text="DDS System Data" OnClick="DdsTab_Click" CausesValidation="false" />
</div>
<asp:MultiView ID="views" runat="server" ActiveViewIndex="0">
<asp:View runat="server">
<section>
<h2>Fetch DDA records</h2>
<asp:Label runat="server" AssociatedControlID="ddlTarget" Text="Source table" />
<asp:DropDownList ID="ddlTarget" runat="server">
    <asp:ListItem Value="R">Core DDA registration</asp:ListItem>
    <asp:ListItem Value="F">Core Flex DDA registration</asp:ListItem>
    <asp:ListItem Value="C">Core DDA cancellation</asp:ListItem>
</asp:DropDownList>
<asp:Label runat="server" AssociatedControlID="txtApplicationId" Text="Exact Application ID" />
<asp:TextBox ID="txtApplicationId" runat="server" MaxLength="200" />
<asp:Button runat="server" Text="Fetch Records" OnClick="Fetch_Click" />
<p class="hint">Select the rows to update. Registration DDA references are prefilled when available.
Core registration matches Application ID plus REF_NBR or DDS_INTERNAL_REF; Core Flex uses REF_NBR;
cancellation uses DDA_REF_NO. Nothing changes in the source until checker approval.</p>
<div class="scroll">
<asp:GridView ID="gvRecords" runat="server" AutoGenerateColumns="false" CssClass="grid"
    OnRowDataBound="Records_Bound" EmptyDataText="No records found.">
<Columns>
    <asp:TemplateField HeaderText="Select"><ItemTemplate><asp:CheckBox ID="chkSelect" runat="server" /></ItemTemplate></asp:TemplateField>
    <asp:BoundField DataField="ApplicationId" HeaderText="Application ID" />
    <asp:BoundField DataField="RefNbr" HeaderText="REF_NBR" />
    <asp:BoundField DataField="InternalRef" HeaderText="DDS_INTERNAL_REF" />
    <asp:BoundField DataField="DdaRefNo" HeaderText="Current DDA_REF_NO" />
    <asp:BoundField DataField="CurrentStatus" HeaderText="Current status" />
    <asp:TemplateField HeaderText="Match by"><ItemTemplate><asp:DropDownList ID="ddlMatch" runat="server" /></ItemTemplate></asp:TemplateField>
    <asp:TemplateField HeaderText="Proposed status"><ItemTemplate><asp:DropDownList ID="ddlStatus" runat="server" /></ItemTemplate></asp:TemplateField>
    <asp:TemplateField HeaderText="DDA_REF_NO after approval"><ItemTemplate><asp:TextBox ID="txtDdaRef" runat="server" MaxLength="200" /></ItemTemplate></asp:TemplateField>
</Columns>
</asp:GridView>
</div>
<asp:Label runat="server" AssociatedControlID="ddlChecker" Text="Assign checker" />
<asp:DropDownList ID="ddlChecker" runat="server" />
<br /><asp:Label runat="server" AssociatedControlID="txtRemarks" Text="Maker remarks (required)" />
<asp:TextBox ID="txtRemarks" runat="server" TextMode="MultiLine" Rows="3" MaxLength="1000" Width="450px" />
<br /><asp:Label runat="server" AssociatedControlID="fuAttachment" Text="Supporting attachment (optional, 5 MB maximum)" />
<asp:FileUpload ID="fuAttachment" runat="server" />
<br /><asp:Button ID="btnSubmit" runat="server" Text="Submit Selected Rows to Checker" OnClick="Submit_Click" />
</section>
<section><h2>My DDA application requests</h2>
<asp:Button runat="server" Text="Refresh History" OnClick="Refresh_Click" />
<div class="scroll"><asp:GridView ID="gvHistory" runat="server" CssClass="grid" AutoGenerateColumns="false"
    AllowPaging="true" PageSize="15" OnPageIndexChanging="History_Page">
<Columns>
    <asp:HyperLinkField DataTextField="RequestId" HeaderText="Review" DataNavigateUrlFields="RequestId" DataNavigateUrlFormatString="DdaApplicationChecker.aspx?requestId={0}" />
    <asp:BoundField DataField="RequestStatus" HeaderText="Status" />
    <asp:BoundField DataField="CheckerLoginId" HeaderText="Checker" />
    <asp:BoundField DataField="RecordCount" HeaderText="Records" />
    <asp:BoundField DataField="MakerRemarks" HeaderText="Maker remarks" />
    <asp:BoundField DataField="SubmittedOn" HeaderText="Submitted" DataFormatString="{0:yyyy-MM-dd HH:mm:ss}" />
    <asp:BoundField DataField="CheckedOn" HeaderText="Checked" DataFormatString="{0:yyyy-MM-dd HH:mm:ss}" />
</Columns></asp:GridView></div></section>
</asp:View>
<asp:View runat="server"><section><dda:DdsData ID="ddsData" runat="server" /></section></asp:View>
</asp:MultiView>
</main></form></body></html>
