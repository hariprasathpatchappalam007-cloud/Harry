namespace HF48Workflow
{
    public partial class DdaBulkMaker
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.TextBox txtCurrentUser;
        protected global::System.Web.UI.WebControls.Button btnSetUser;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hfActiveTab;
        protected global::System.Web.UI.WebControls.LinkButton lnkStandardDataTab;
        protected global::System.Web.UI.WebControls.LinkButton lnkDdsSystemDataTab;
        protected global::System.Web.UI.WebControls.FileUpload fuAttachment;
        protected global::System.Web.UI.WebControls.TextBox txtMakerRemarks;
        protected global::System.Web.UI.WebControls.GridView gvMyRequests;
        protected global::System.Web.UI.WebControls.Panel pnlStandardData;
        protected global::System.Web.UI.WebControls.DropDownList ddlStandardTable;
        protected global::System.Web.UI.WebControls.TextBox txtStandardFromDate;
        protected global::System.Web.UI.WebControls.TextBox txtStandardToDate;
        protected global::System.Web.UI.WebControls.DropDownList ddlStandardStatus;
        protected global::System.Web.UI.WebControls.TextBox txtStandardApplicationId;
        protected global::System.Web.UI.WebControls.Button btnPreviewStandard;
        protected global::System.Web.UI.WebControls.Button btnExportStandardCsv;
        protected global::System.Web.UI.WebControls.Label lblStandardDataTitle;
        protected global::System.Web.UI.WebControls.GridView gvStandardData;
        protected global::System.Web.UI.WebControls.Panel pnlDdsSystemData;
        protected global::System.Web.UI.WebControls.TextBox txtDdsFromDate;
        protected global::System.Web.UI.WebControls.TextBox txtDdsToDate;
        protected global::System.Web.UI.WebControls.DropDownList ddlDdsStatus;
        protected global::System.Web.UI.WebControls.TextBox txtDdsReferenceNo;
        protected global::System.Web.UI.WebControls.TextBox txtDdsApplicationId;
        protected global::System.Web.UI.WebControls.Button btnPreviewDds;
        protected global::System.Web.UI.WebControls.Button btnExportDdsCsv;
        protected global::System.Web.UI.WebControls.Label lblDdsDataTitle;
        protected global::System.Web.UI.WebControls.GridView gvDdsSystemData;
    }
}
