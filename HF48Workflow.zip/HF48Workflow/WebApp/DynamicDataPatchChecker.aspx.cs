using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class DynamicDataPatchChecker : System.Web.UI.Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                string fromTextbox = (txtCurrentUser.Text ?? "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                return System.Web.HttpContext.Current.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null) txtCurrentUser.Text = Session["UserID"].ToString();
                LoadPending();
                LoadHistory();
            }
        }

        private void LoadPending()
        {
            gvPending.DataSource = ExecuteDataTable("Proc_DDP_GetRequests", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@Mode", "CHECKER");
            });
            gvPending.DataBind();
        }

        private void LoadHistory()
        {
            gvHistory.DataSource = ExecuteDataTable("Proc_DDP_GetRequests", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@Mode", "ALL");
            });
            gvHistory.DataBind();
        }

        private void LoadRequestDetail(int requestId)
        {
            gvRequestDetail.DataSource = ExecuteDataTable("Proc_DDP_GetRequestDetail", delegate(SqlCommand cmd) { cmd.Parameters.AddWithValue("@RequestId", requestId); });
            gvRequestDetail.DataBind();
        }

        protected void gvPending_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "ViewRequest") return;
            int index = Convert.ToInt32(e.CommandArgument);
            int requestId = Convert.ToInt32(gvPending.Rows[index].Cells[0].Text);
            hfRequestId.Value = requestId.ToString();
            LoadRequestDetail(requestId);
            ShowMessage("Request loaded. Review old and new data before decision.", true);
        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            CheckRequest('A');
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCheckerRemarks.Text.Trim())) { ShowMessage("Checker remarks are required for rejection.", false); return; }
            CheckRequest('R');
        }

        private void CheckRequest(char decision)
        {
            int requestId;
            if (!int.TryParse(hfRequestId.Value, out requestId) || requestId <= 0) { ShowMessage("Select a request first.", false); return; }

            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_DDP_CheckRequest", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@CheckerLoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@Decision", decision.ToString());
                cmd.Parameters.AddWithValue("@Remarks", string.IsNullOrEmpty(txtCheckerRemarks.Text.Trim()) ? (object)DBNull.Value : txtCheckerRemarks.Text.Trim());
                SqlParameter status = new SqlParameter("@Status", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
                SqlParameter message = new SqlParameter("@Message", SqlDbType.NVarChar, 500) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(status);
                cmd.Parameters.Add(message);
                conn.Open();
                cmd.ExecuteNonQuery();
                ShowMessage(message.Value.ToString(), status.Value.ToString() == "SUCCESS");
            }

            hfRequestId.Value = "0";
            txtCheckerRemarks.Text = "";
            gvRequestDetail.DataSource = null;
            gvRequestDetail.DataBind();
            LoadPending();
            LoadHistory();
        }

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Session["UserID"] = (txtCurrentUser.Text ?? "").Trim();
            ShowMessage("Acting user set to: " + CurrentUser, true);
            LoadPending();
            LoadHistory();
        }

        private DataTable ExecuteDataTable(string procedureName, Action<SqlCommand> addParameters)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (addParameters != null) addParameters(cmd);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);
                return dt;
            }
        }

        private void ShowMessage(string message, bool success)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = success ? "msg-success" : "msg-error";
            lblMessage.Text = message;
        }
    }
}