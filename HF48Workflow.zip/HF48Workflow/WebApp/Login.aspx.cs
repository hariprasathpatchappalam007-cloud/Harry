using System;
using System.Configuration;
using System.Net;
using System.Web;
using System.Web.Services.Protocols;
using System.Web.UI;
using DiagnosticsTrace = System.Diagnostics.Trace;

namespace HF48Workflow
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            Response.Headers["X-Frame-Options"] = "DENY";
            Response.Headers["Referrer-Policy"] = "no-referrer";
            pnlTransportWarning.Visible = !Request.IsSecureConnection;
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            txtPassword.Text = string.Empty;
            lblStatus.Text = string.Empty;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password))
            {
                lblStatus.Text = "Enter your username and password.";
                return;
            }

            try
            {
                using (AuthServiceClient client = new AuthServiceClient())
                {
                    if (!client.IsAuthenticated("dib.ae", username, password))
                    {
                        lblStatus.Text = "Invalid username or password, or the account cannot sign in.";
                        return;
                    }
                }

                lblStatus.Text = "Credentials verified for "
                    + HttpUtility.HtmlEncode("dib.ae\\" + username) + ".";
            }
            catch (ConfigurationErrorsException)
            {
                DiagnosticsTrace.TraceError("Login requires a valid AuthServiceUrl application setting.");
                lblStatus.Text = "The authentication service URL is not configured correctly.";
            }
            catch (SoapException)
            {
                DiagnosticsTrace.TraceError("Login received an authentication service SOAP fault.");
                lblStatus.Text = "Directory authentication is temporarily unavailable. Try again later.";
            }
            catch (WebException exception)
            {
                DiagnosticsTrace.TraceError("Login could not contact the authentication service. Status: {0}", exception.Status);
                lblStatus.Text = "Cannot contact the authentication service. Try again later.";
            }
            catch (InvalidOperationException)
            {
                DiagnosticsTrace.TraceError("Login received an invalid authentication service response.");
                lblStatus.Text = "The authentication service returned an unexpected response.";
            }
        }
    }
}
