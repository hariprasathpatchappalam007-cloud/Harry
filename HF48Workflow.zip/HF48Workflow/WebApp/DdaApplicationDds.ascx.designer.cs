namespace HF48Workflow
{
    public partial class DdaApplicationDds
    {
        protected global::System.Web.UI.WebControls.TextBox txtApplicationId;
        protected global::System.Web.UI.WebControls.TextBox txtReference;
        protected global::System.Web.UI.WebControls.TextBox txtFrom;
        protected global::System.Web.UI.WebControls.TextBox txtTo;
        protected global::System.Web.UI.WebControls.TextBox txtStatus;
        protected global::System.Web.UI.WebControls.Label lblCount;
        protected global::System.Web.UI.WebControls.GridView gvDds;
    }
}
