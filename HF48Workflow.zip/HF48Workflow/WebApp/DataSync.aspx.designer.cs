namespace HF48Workflow
{
    public partial class DataSync
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.ScriptManager smMain;
        protected global::System.Web.UI.WebControls.TextBox txtApplicationId;
    }
}
