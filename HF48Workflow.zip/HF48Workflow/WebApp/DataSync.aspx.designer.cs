namespace HF48Workflow
{
    public partial class DataSync
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.Label lblApplicationId;
        protected global::System.Web.UI.WebControls.TextBox txtApplicationId;
        protected global::System.Web.UI.WebControls.Button btnPreview;
        protected global::System.Web.UI.WebControls.Button btnSync;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.Panel pnlPreview;
        protected global::System.Web.UI.WebControls.GridView gvPreview;
    }
}
