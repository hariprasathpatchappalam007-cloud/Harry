namespace HF48Workflow
{
    public partial class DdaBulkChecker
    {
        protected global::System.Web.UI.WebControls.Literal litLogin;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.MultiView views;
        protected global::System.Web.UI.WebControls.GridView gvPending;
        protected global::System.Web.UI.WebControls.Panel pnlReview;
        protected global::System.Web.UI.WebControls.GridView gvSummary;
        protected global::System.Web.UI.WebControls.GridView gvDetails;
        protected global::System.Web.UI.WebControls.GridView gvAudit;
        protected global::System.Web.UI.WebControls.Button btnAttachment;
        protected global::System.Web.UI.WebControls.TextBox txtRemarks;
        protected global::System.Web.UI.WebControls.Button btnApprove;
        protected global::System.Web.UI.WebControls.Button btnReject;
        protected global::System.Web.UI.WebControls.GridView gvHistory;
    }
}
