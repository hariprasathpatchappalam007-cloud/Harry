namespace HF48Workflow
{
    public partial class DdaBulkChecker
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.TextBox txtCurrentUser;
        protected global::System.Web.UI.WebControls.Button btnSetUser;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hfRequestId;
        protected global::System.Web.UI.WebControls.GridView gvPending;
        protected global::System.Web.UI.WebControls.Button btnDownloadSource;
        protected global::System.Web.UI.WebControls.Button btnDownloadAttachment;
        protected global::System.Web.UI.WebControls.Button btnExportExcel;
        protected global::System.Web.UI.WebControls.GridView gvRequestDetail;
        protected global::System.Web.UI.WebControls.GridView gvAudit;
        protected global::System.Web.UI.WebControls.TextBox txtCheckerRemarks;
        protected global::System.Web.UI.WebControls.Button btnApprove;
        protected global::System.Web.UI.WebControls.Button btnReject;
        protected global::System.Web.UI.WebControls.GridView gvHistory;
    }
}
