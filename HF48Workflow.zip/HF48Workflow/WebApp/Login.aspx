<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="HF48Workflow.Login" EnableSessionState="false" EnableViewState="false" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>DIB UAT Sign In</title>
</head>
<body>
    <form id="form1" runat="server" defaultbutton="btnLogin">
        <h1>DIB UAT Sign In</h1>
        <p>Domain: dib.ae</p>
        <asp:Panel ID="pnlTransportWarning" runat="server" Visible="false" role="alert">
            This page is using HTTP. Credentials are not protected in transit.
            Use test credentials only.
        </asp:Panel>
        <p>
            <asp:Label runat="server" AssociatedControlID="txtUsername" Text="Username" />
            <asp:TextBox ID="txtUsername" runat="server" MaxLength="256" autocomplete="username" />
        </p>
        <p>Enter your account name only, without a domain prefix or @dib.ae suffix.</p>
        <p>
            <asp:Label runat="server" AssociatedControlID="txtPassword" Text="Password" />
            <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" autocomplete="current-password" />
        </p>
        <asp:Button ID="btnLogin" runat="server" Text="Sign in" OnClick="btnLogin_Click" />
        <p><asp:Label ID="lblStatus" runat="server" role="status" /></p>
    </form>
</body>
</html>
