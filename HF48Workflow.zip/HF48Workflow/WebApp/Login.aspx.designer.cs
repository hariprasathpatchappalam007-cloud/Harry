namespace HF48Workflow
{
    public partial class Login
    {
        protected global::System.Web.UI.WebControls.Panel pnlTransportWarning;
        protected global::System.Web.UI.WebControls.TextBox txtUsername;
        protected global::System.Web.UI.WebControls.TextBox txtPassword;
        protected global::System.Web.UI.WebControls.Button btnLogin;
        protected global::System.Web.UI.WebControls.Label lblStatus;
    }
}
