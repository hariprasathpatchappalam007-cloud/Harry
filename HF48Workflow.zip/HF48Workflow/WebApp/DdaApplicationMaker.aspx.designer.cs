namespace HF48Workflow
{
    public partial class DdaApplicationMaker
    {
        protected global::System.Web.UI.WebControls.Literal litLogin;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.MultiView views;
        protected global::System.Web.UI.WebControls.DropDownList ddlTarget;
        protected global::System.Web.UI.WebControls.TextBox txtApplicationId;
        protected global::System.Web.UI.WebControls.GridView gvRecords;
        protected global::System.Web.UI.WebControls.DropDownList ddlChecker;
        protected global::System.Web.UI.WebControls.TextBox txtRemarks;
        protected global::System.Web.UI.WebControls.FileUpload fuAttachment;
        protected global::System.Web.UI.WebControls.Button btnSubmit;
        protected global::System.Web.UI.WebControls.GridView gvHistory;
    }
}
