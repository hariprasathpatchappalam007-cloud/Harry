using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Text;
using System.Web.UI.WebControls;
using System.Xml;

namespace HF48Workflow
{
    public partial class DdaApplicationMaker : DdaApplicationPage
    {
        protected override Label MessageLabel { get { return lblMessage; } }
        protected override string AccessRole { get { return "M"; } }
        private string SnapshotKey
        {
            get
            {
                if (ViewState["SnapshotKey"] == null)
                    ViewState["SnapshotKey"] = "DdaApplicationPreview_" + Guid.NewGuid().ToString("N");
                return (string)ViewState["SnapshotKey"];
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            litLogin.Text = LoginId;
            if (!IsPostBack) Run(delegate { LoadCheckers(); LoadHistory(); btnSubmit.Enabled = false; });
        }

        private void LoadCheckers()
        {
            using (DataSet data = Query("dbo.Proc_DDA_ApplicationCheckers", null))
            {
                ddlChecker.DataSource = data.Tables[0];
                ddlChecker.DataTextField = "LoginId";
                ddlChecker.DataValueField = "LoginId";
                ddlChecker.DataBind();
                ddlChecker.Items.Insert(0, new ListItem("-- Select checker --", ""));
            }
        }

        private void LoadHistory()
        {
            using (DataSet data = Query("dbo.Proc_DDA_ApplicationRequests", null)) Bind(gvHistory, data.Tables[0]);
        }

        protected void Fetch_Click(object sender, EventArgs e)
        {
            Session.Remove(SnapshotKey);
            btnSubmit.Enabled = false;
            gvRecords.DataSource = null;
            gvRecords.DataBind();
            Run(delegate
            {
                if (String.IsNullOrWhiteSpace(txtApplicationId.Text) || txtApplicationId.Text.Trim().Length > 200)
                    throw new ArgumentException("Enter an exact Application ID of up to 200 characters.");
                using (DataSet data = Query("dbo.Proc_DDA_ApplicationFetch", delegate(SqlCommand command)
                {
                    command.Parameters.Add("@TargetCode", SqlDbType.Char, 1).Value = ddlTarget.SelectedValue;
                    command.Parameters.Add("@ApplicationId", SqlDbType.NVarChar, 200).Value = txtApplicationId.Text.Trim();
                }))
                {
                    ViewState["LoadedTarget"] = ddlTarget.SelectedValue;
                    ViewState["LoadedApplication"] = txtApplicationId.Text.Trim();
                    Session[SnapshotKey] = data.Tables[0].Copy();
                    Bind(gvRecords, data.Tables[0]);
                    btnSubmit.Enabled = data.Tables[0].Rows.Count > 0;
                    ShowMessage(data.Tables[0].Rows.Count.ToString(CultureInfo.InvariantCulture)
                        + " record(s) fetched. Select rows and proposed values.", true);
                }
            });
        }

        protected void Records_Bound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            DataRowView row = (DataRowView)e.Row.DataItem;
            string target = ViewState["LoadedTarget"] as string;
            DropDownList match = (DropDownList)e.Row.FindControl("ddlMatch");
            if (target == "C") match.Items.Add(new ListItem("DDA_REF_NO", "DDA_REF_NO"));
            else
            {
                if (!String.IsNullOrWhiteSpace(Convert.ToString(row["RefNbr"])))
                    match.Items.Add(new ListItem("REF_NBR", "REF_NBR"));
                if (target == "R" && !String.IsNullOrWhiteSpace(Convert.ToString(row["InternalRef"])))
                    match.Items.Add(new ListItem("DDS_INTERNAL_REF", "DDS_INTERNAL_REF"));
            }
            DropDownList status = (DropDownList)e.Row.FindControl("ddlStatus");
            status.Items.Add(new ListItem("-- Select status --", ""));
            foreach (string value in target == "C"
                ? new[] { "Cancelled", "Sent to DIB", "Declined by CB", "Rejected" }
                : new[] { "Active", "Declined by CB", "Rejected" })
                status.Items.Add(new ListItem(value, value));
            TextBox reference = (TextBox)e.Row.FindControl("txtDdaRef");
            reference.Text = Convert.ToString(row["DdaRefNo"]);
            reference.ReadOnly = target == "C";
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            Run(delegate
            {
                DataTable snapshot = Session[SnapshotKey] as DataTable;
                string target = ViewState["LoadedTarget"] as string;
                if (snapshot == null || snapshot.Rows.Count != gvRecords.Rows.Count
                    || target != ddlTarget.SelectedValue
                    || !String.Equals(ViewState["LoadedApplication"] as string, txtApplicationId.Text.Trim(), StringComparison.Ordinal))
                    throw new ArgumentException("The fetched data expired or the source filters changed. Fetch records again.");
                if (String.IsNullOrWhiteSpace(ddlChecker.SelectedValue) || String.IsNullOrWhiteSpace(txtRemarks.Text)
                    || txtRemarks.Text.Length > 1000)
                    throw new ArgumentException("Select a checker and enter maker remarks of up to 1000 characters.");
                if (fuAttachment.HasFile && (fuAttachment.PostedFile.ContentLength <= 0
                    || fuAttachment.PostedFile.ContentLength > 5242880))
                    throw new ArgumentException("Supporting attachments must be non-empty and no larger than 5 MB.");
                StringBuilder xml = new StringBuilder();
                int selected = 0;
                using (XmlWriter writer = XmlWriter.Create(xml, new XmlWriterSettings { OmitXmlDeclaration = true }))
                {
                    writer.WriteStartElement("Rows");
                    foreach (GridViewRow gridRow in gvRecords.Rows)
                    {
                        if (!((CheckBox)gridRow.FindControl("chkSelect")).Checked) continue;
                        selected++;
                        DataRow row = snapshot.Rows[gridRow.RowIndex];
                        string status = ((DropDownList)gridRow.FindControl("ddlStatus")).SelectedValue;
                        string reference = ((TextBox)gridRow.FindControl("txtDdaRef")).Text.Trim();
                        string match = ((DropDownList)gridRow.FindControl("ddlMatch")).SelectedValue;
                        if (status.Length == 0 || match.Length == 0 || reference.Length > 200)
                            throw new ArgumentException("Select a match key and proposed status for each checked row; references cannot exceed 200 characters.");
                        writer.WriteStartElement("Row");
                        writer.WriteAttributeString("TargetCode", target);
                        writer.WriteAttributeString("MatchBy", match);
                        foreach (string name in new[] { "ApplicationId", "RefNbr", "InternalRef", "DdaRefNo", "CurrentStatus" })
                            writer.WriteAttributeString(name, Convert.ToString(row[name], CultureInfo.InvariantCulture));
                        writer.WriteAttributeString("NewStatus", status);
                        writer.WriteAttributeString("NewDdaRefNo", reference);
                        writer.WriteEndElement();
                    }
                    writer.WriteEndElement();
                }
                if (selected == 0) throw new ArgumentException("Select at least one source record.");
                byte[] attachment = null;
                if (fuAttachment.HasFile)
                {
                    using (MemoryStream memory = new MemoryStream())
                    {
                        fuAttachment.PostedFile.InputStream.CopyTo(memory);
                        attachment = memory.ToArray();
                    }
                    if (attachment.Length > 5242880) throw new ArgumentException("Supporting attachment exceeds 5 MB.");
                }
                int requestId;
                using (SqlConnection connection = OpenConnection())
                using (SqlCommand command = Command(connection, "dbo.Proc_DDA_ApplicationSubmit"))
                {
                    command.Parameters.Add("@CheckerLoginId", SqlDbType.NVarChar, 100).Value = ddlChecker.SelectedValue;
                    command.Parameters.Add("@Remarks", SqlDbType.NVarChar, 1000).Value = txtRemarks.Text.Trim();
                    command.Parameters.Add("@Rows", SqlDbType.Xml).Value = xml.ToString();
                    command.Parameters.Add("@AttachmentName", SqlDbType.NVarChar, 260).Value =
                        attachment == null ? (object)DBNull.Value : DdaBulkCsv.SafeFileName(fuAttachment.FileName);
                    command.Parameters.Add("@AttachmentType", SqlDbType.NVarChar, 150).Value =
                        attachment == null ? (object)DBNull.Value : "application/octet-stream";
                    command.Parameters.Add("@AttachmentData", SqlDbType.VarBinary, -1).Value = (object)attachment ?? DBNull.Value;
                    SqlParameter id = command.Parameters.Add("@RequestId", SqlDbType.Int);
                    id.Direction = ParameterDirection.Output;
                    command.ExecuteNonQuery();
                    requestId = (int)id.Value;
                }
                Session.Remove(SnapshotKey);
                btnSubmit.Enabled = false;
                gvRecords.DataSource = null;
                gvRecords.DataBind();
                ShowMessage("DDA request " + requestId.ToString(CultureInfo.InvariantCulture)
                    + " submitted. Source records remain unchanged until approval.", true);
                LoadHistory();
            });
        }

        protected void UpdateTab_Click(object sender, EventArgs e) { views.ActiveViewIndex = 0; }
        protected void DdsTab_Click(object sender, EventArgs e) { views.ActiveViewIndex = 1; }
        protected void Refresh_Click(object sender, EventArgs e) { Run(LoadHistory); }
        protected void History_Page(object sender, GridViewPageEventArgs e)
        {
            gvHistory.PageIndex = e.NewPageIndex;
            Run(LoadHistory);
        }
    }
}
