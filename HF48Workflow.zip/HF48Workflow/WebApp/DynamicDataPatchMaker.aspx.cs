using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace HF48Workflow
{
    public partial class DynamicDataPatchMaker : System.Web.UI.Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                string fromTextbox = (txtCurrentUser.Text ?? "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                return System.Web.HttpContext.Current.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null) txtCurrentUser.Text = Session["UserID"].ToString();
                LoadPatchTables();
                LoadCheckers();
                LoadMyRequests();
            }
        }

        private void LoadPatchTables()
        {
            DataTable dt = ExecuteDataTable("Proc_DDP_GetTableConfig", delegate(SqlCommand cmd) { cmd.Parameters.AddWithValue("@OnlyActive", 1); });
            ddlPatchTables.DataSource = dt;
            ddlPatchTables.DataTextField = "FriendlyName";
            ddlPatchTables.DataValueField = "ConfigId";
            ddlPatchTables.DataBind();
            ddlPatchTables.Items.Insert(0, new ListItem("-- Select Configured Table --", ""));
        }

        private void LoadCheckers()
        {
            DataTable dt = ExecuteDataTable("Proc_DDP_GetUsers", delegate(SqlCommand cmd) { cmd.Parameters.AddWithValue("@OnlyCheckers", 1); });
            ddlChecker.DataSource = dt;
            ddlChecker.DataTextField = "LoginId";
            ddlChecker.DataValueField = "LoginId";
            ddlChecker.DataBind();
            ddlChecker.Items.Insert(0, new ListItem("-- Select Checker --", ""));
        }

        private void LoadMyRequests()
        {
            gvMyRequests.DataSource = ExecuteDataTable("Proc_DDP_GetRequests", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@Mode", "MAKER");
            });
            gvMyRequests.DataBind();
        }

        protected void btnLoadRecord_Click(object sender, EventArgs e)
        {
            int configId;
            if (!int.TryParse(ddlPatchTables.SelectedValue, out configId) || configId <= 0) { ShowMessage("Select a configured table.", false); return; }
            if (string.IsNullOrEmpty(txtPrimaryKeyValue.Text.Trim())) { ShowMessage("Record Key Value is required.", false); return; }

            hfConfigId.Value = configId.ToString();
            hfPrimaryKeyValue.Value = txtPrimaryKeyValue.Text.Trim();
            DataTable dt = LoadPatchFields(configId, txtPrimaryKeyValue.Text.Trim());
            if (dt.Rows.Count == 0) { ShowMessage("No editable fields were found, or the record does not exist.", false); return; }
            RenderPatchFields(dt);
            ShowMessage("Record loaded. Update only the fields that require data patching.", true);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int configId;
            if (!int.TryParse(hfConfigId.Value, out configId) || configId <= 0) { ShowMessage("Load a record before submitting.", false); return; }
            if (string.IsNullOrEmpty(hfPrimaryKeyValue.Value)) { ShowMessage("Record Key Value is missing.", false); return; }
            if (string.IsNullOrEmpty(ddlChecker.SelectedValue)) { ShowMessage("Select a checker.", false); return; }

            DataTable fields = LoadPatchFields(configId, hfPrimaryKeyValue.Value);
            string xml = BuildFieldXml(fields);

            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_DDP_SubmitRequest", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ConfigId", configId);
                cmd.Parameters.AddWithValue("@PrimaryKeyValue", hfPrimaryKeyValue.Value);
                cmd.Parameters.AddWithValue("@CheckerLoginId", ddlChecker.SelectedValue);
                cmd.Parameters.AddWithValue("@MakerLoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@MakerRemarks", string.IsNullOrEmpty(txtMakerRemarks.Text.Trim()) ? (object)DBNull.Value : txtMakerRemarks.Text.Trim());
                cmd.Parameters.Add("@ChangedFieldsXml", SqlDbType.Xml).Value = xml;
                SqlParameter requestId = new SqlParameter("@RequestId", SqlDbType.Int) { Direction = ParameterDirection.Output };
                SqlParameter status = new SqlParameter("@Status", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
                SqlParameter message = new SqlParameter("@Message", SqlDbType.NVarChar, 500) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(requestId);
                cmd.Parameters.Add(status);
                cmd.Parameters.Add(message);
                conn.Open();
                cmd.ExecuteNonQuery();
                bool success = status.Value.ToString() == "SUCCESS";
                ShowMessage(message.Value.ToString(), success);
                if (success)
                {
                    hfConfigId.Value = "0";
                    hfPrimaryKeyValue.Value = "";
                    txtPrimaryKeyValue.Text = "";
                    txtMakerRemarks.Text = "";
                    phPatchFields.Controls.Clear();
                }
            }

            LoadMyRequests();
        }

        private DataTable LoadPatchFields(int configId, string primaryKeyValue)
        {
            return ExecuteDataTable("Proc_DDP_GetRecordForPatch", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@ConfigId", configId);
                cmd.Parameters.AddWithValue("@PrimaryKeyValue", primaryKeyValue);
            });
        }

        private void RenderPatchFields(DataTable dt)
        {
            StringBuilder html = new StringBuilder();
            html.Append("<table class='patch-table'><tr><th>Field</th><th>Current Value</th><th>New Value</th></tr>");
            foreach (DataRow row in dt.Rows)
            {
                string id = row["FieldConfigId"].ToString();
                string display = HttpUtility.HtmlEncode(row["DisplayName"].ToString());
                string oldValue = HttpUtility.HtmlEncode(row["OldValue"].ToString());
                string required = Convert.ToBoolean(row["IsRequired"]) ? " <span class='required'>*</span>" : "";
                html.Append("<tr><td>").Append(display).Append(required).Append("</td><td class='old-value'>")
                    .Append(oldValue).Append("</td><td><input type='text' name='dp_").Append(id)
                    .Append("' value='").Append(oldValue.Replace("'", "&#39;")).Append("' style='width:95%;' /></td></tr>");
            }
            html.Append("</table><br />");
            phPatchFields.Controls.Clear();
            phPatchFields.Controls.Add(new LiteralControl(html.ToString()));
        }

        private string BuildFieldXml(DataTable fields)
        {
            XmlDocument doc = new XmlDocument();
            XmlElement root = doc.CreateElement("Fields");
            doc.AppendChild(root);
            foreach (DataRow row in fields.Rows)
            {
                string key = "dp_" + row["FieldConfigId"].ToString();
                XmlElement field = doc.CreateElement("Field");
                field.SetAttribute("FieldConfigId", row["FieldConfigId"].ToString());
                field.SetAttribute("NewValue", Request.Form[key] ?? "");
                root.AppendChild(field);
            }
            return doc.OuterXml;
        }

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Session["UserID"] = (txtCurrentUser.Text ?? "").Trim();
            ShowMessage("Acting user set to: " + CurrentUser, true);
            LoadMyRequests();
        }

        private DataTable ExecuteDataTable(string procedureName, Action<SqlCommand> addParameters)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (addParameters != null) addParameters(cmd);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);
                return dt;
            }
        }

        private void ShowMessage(string message, bool success)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = success ? "msg-success" : "msg-error";
            lblMessage.Text = message;
        }
    }
}