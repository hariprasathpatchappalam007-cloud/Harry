using System;
using System.Diagnostics;
using System.DirectoryServices;
using System.Runtime.InteropServices;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace HF48Workflow
{
    [WebService(Namespace = "https://dib.ae/HF48Workflow/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class AuthService : WebService
    {
        [WebMethod]
        public bool IsAuthenticated(string domain, string username, string pwd)
        {
            if (!string.Equals(domain, "dib.ae", StringComparison.OrdinalIgnoreCase)
                || string.IsNullOrWhiteSpace(username)
                || username.Length > 256
                || username.IndexOfAny(new[] { '\\', '/', '@', '\0' }) >= 0
                || string.IsNullOrEmpty(pwd))
            {
                Trace.TraceWarning("AuthService rejected an invalid domain, username format, or empty credential.");
                return false;
            }

            try
            {
                using (DirectoryEntry entry = new DirectoryEntry(
                    "LDAP://dib.ae",
                    "dib.ae\\" + username,
                    pwd,
                    AuthenticationTypes.Secure | AuthenticationTypes.Signing | AuthenticationTypes.Sealing))
                using (DirectorySearcher search = new DirectorySearcher(entry))
                {
                    search.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName="
                        + EscapeLdapFilterValue(username) + "))";
                    search.PropertiesToLoad.Add("cn");
                    search.SizeLimit = 1;
                    search.ClientTimeout = TimeSpan.FromSeconds(5);
                    search.ServerTimeLimit = TimeSpan.FromSeconds(5);
                    search.ReferralChasing = ReferralChasingOption.None;

                    bool authenticated = search.FindOne() != null;
                    if (!authenticated)
                        Trace.TraceWarning("AuthService did not find a matching directory user.");
                    return authenticated;
                }
            }
            catch (COMException exception)
            {
                // AD reports failed credential binds as ERROR_LOGON_FAILURE.
                if (exception.ErrorCode == unchecked((int)0x8007052E))
                {
                    Trace.TraceWarning("AuthService rejected directory credentials.");
                    return false;
                }

                Trace.TraceError("AuthService directory operation failed. HRESULT: {0:X8}", exception.ErrorCode);
                throw new SoapException("Directory authentication is temporarily unavailable.",
                    SoapException.ServerFaultCode);
            }
        }

        private static string EscapeLdapFilterValue(string value)
        {
            return value.Replace("\\", "\\5c")
                .Replace("*", "\\2a")
                .Replace("(", "\\28")
                .Replace(")", "\\29")
                .Replace("\0", "\\00");
        }
    }
}
