using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public interface IDdaApplicationHost
    {
        string LoginId { get; }
        DataSet Query(string procedure, Action<SqlCommand> parameters);
        void Run(Action operation);
        void ShowMessage(string message, bool success);
    }

    public static class DdaApplicationSupport
    {
        public static void InitializePage(Page page)
        {
            page.ViewStateUserKey = page.Session.SessionID;
            page.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            page.Response.Cache.SetNoStore();
            page.Response.Headers["X-Frame-Options"] = "SAMEORIGIN";
        }

        public static string GetLoginId(Page page)
        {
            string login = page.Session["UserID"] as string;
            if (String.IsNullOrWhiteSpace(login) && page.User != null && page.User.Identity.IsAuthenticated)
                login = page.User.Identity.Name;
            if (String.IsNullOrWhiteSpace(login)) return String.Empty;
            if (login.Length > 100)
                throw new HttpException(400, "The DDA user ID cannot exceed 100 characters.");
            return login;
        }

        public static SqlConnection OpenConnection()
        {
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
            if (settings == null || String.IsNullOrWhiteSpace(settings.ConnectionString))
                throw new ConfigurationErrorsException("The DDA database connection is not configured.");
            SqlConnection connection = new SqlConnection(settings.ConnectionString);
            try { connection.Open(); }
            catch { connection.Dispose(); throw; }
            return connection;
        }

        public static SqlCommand Command(Page page, SqlConnection connection, string procedure)
        {
            SqlCommand command = new SqlCommand(procedure, connection);
            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 120;
            command.Parameters.Add("@LoginId", SqlDbType.NVarChar, 100).Value = GetLoginId(page);
            return command;
        }

        public static DataSet Query(Page page, string procedure, Action<SqlCommand> parameters)
        {
            using (SqlConnection connection = OpenConnection())
            using (SqlCommand command = Command(page, connection, procedure))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                if (parameters != null) parameters(command);
                DataSet data = new DataSet();
                adapter.Fill(data);
                return data;
            }
        }

        public static void Run(Action operation, Action<string, bool> showMessage)
        {
            try { operation(); }
            catch (SqlException exception)
            {
                Trace.TraceError("DDA application workflow: {0}", exception);
                showMessage(exception.Number >= 51600 && exception.Number <= 51699
                    ? exception.Message : "The DDA database operation failed. Contact support.", false);
            }
            catch (ConfigurationErrorsException exception)
            {
                Trace.TraceError("DDA application workflow: {0}", exception);
                showMessage("The DDA database connection is not configured. Contact support.", false);
            }
            catch (ArgumentException exception)
            {
                showMessage(exception.Message, false);
            }
        }

        public static void Bind(GridView grid, DataTable data)
        {
            grid.DataSource = data;
            grid.DataBind();
        }
    }
}
