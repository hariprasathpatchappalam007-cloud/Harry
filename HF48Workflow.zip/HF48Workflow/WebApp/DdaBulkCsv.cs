using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;

namespace HF48Workflow
{
    internal static class DdaBulkCsv
    {
        internal static List<string[]> Parse(string csv)
        {
            List<string[]> rows = new List<string[]>();
            List<string> fields = new List<string>();
            StringBuilder field = new StringBuilder();
            bool quoted = false;

            for (int i = 0; i < csv.Length; i++)
            {
                char current = csv[i];
                if (quoted)
                {
                    if (current == '"')
                    {
                        if (i + 1 < csv.Length && csv[i + 1] == '"')
                        {
                            field.Append('"');
                            i++;
                        }
                        else
                        {
                            quoted = false;
                        }
                    }
                    else
                    {
                        field.Append(current);
                    }
                }
                else if (current == '"' && field.Length == 0)
                {
                    quoted = true;
                }
                else if (current == ',')
                {
                    fields.Add(field.ToString());
                    field.Length = 0;
                }
                else if (current == '\r' || current == '\n')
                {
                    fields.Add(field.ToString());
                    field.Length = 0;
                    if (fields.Exists(delegate(string value) { return !string.IsNullOrWhiteSpace(value); }))
                        rows.Add(fields.ToArray());
                    fields.Clear();
                    if (current == '\r' && i + 1 < csv.Length && csv[i + 1] == '\n') i++;
                }
                else
                {
                    field.Append(current);
                }
            }

            if (quoted) throw new InvalidDataException("The CSV contains an unclosed quoted field.");
            fields.Add(field.ToString());
            if (fields.Exists(delegate(string value) { return !string.IsNullOrWhiteSpace(value); }))
                rows.Add(fields.ToArray());

            return rows;
        }

        internal static string Escape(string value)
        {
            if (value == null) value = "";
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }

        internal static string SafeFileName(string fileName)
        {
            string value = Path.GetFileName(fileName ?? "");
            foreach (char invalid in Path.GetInvalidFileNameChars())
                value = value.Replace(invalid, '_');
            return string.IsNullOrWhiteSpace(value) ? "attachment" : value;
        }
    }
}
