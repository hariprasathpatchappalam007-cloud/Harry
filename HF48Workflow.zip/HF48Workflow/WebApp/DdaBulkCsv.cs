using System;
using System.IO;

namespace HF48Workflow
{
    internal static class DdaBulkCsv
    {
        internal static string Escape(string value)
        {
            if (value == null) value = "";
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }

        internal static string ExcelTextCell(string value)
        {
            if (value == null) value = "";
            return "=\"" + value.Replace("\"", "\"\"") + "\"";
        }

        internal static string SafeFileName(string fileName)
        {
            string value = Path.GetFileName(fileName ?? "");
            foreach (char invalid in Path.GetInvalidFileNameChars())
                value = value.Replace(invalid, '_');
            return string.IsNullOrWhiteSpace(value) ? "attachment" : value;
        }
    }
}
