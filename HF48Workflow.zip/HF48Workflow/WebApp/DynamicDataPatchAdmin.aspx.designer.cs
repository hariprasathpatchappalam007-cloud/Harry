namespace HF48Workflow
{
    public partial class DynamicDataPatchAdmin
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.TextBox txtCurrentUser;
        protected global::System.Web.UI.WebControls.Button btnSetUser;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hfConfigId;
        protected global::System.Web.UI.WebControls.DropDownList ddlUsers;
        protected global::System.Web.UI.WebControls.CheckBox chkAdmin;
        protected global::System.Web.UI.WebControls.CheckBox chkMaker;
        protected global::System.Web.UI.WebControls.CheckBox chkChecker;
        protected global::System.Web.UI.WebControls.CheckBox chkUserActive;
        protected global::System.Web.UI.WebControls.Button btnSaveUser;
        protected global::System.Web.UI.WebControls.GridView gvUserAccess;
        protected global::System.Web.UI.WebControls.DropDownList ddlTables;
        protected global::System.Web.UI.WebControls.TextBox txtFriendlyName;
        protected global::System.Web.UI.WebControls.DropDownList ddlPrimaryKey;
        protected global::System.Web.UI.WebControls.TextBox txtDisplayColumns;
        protected global::System.Web.UI.WebControls.CheckBox chkTableActive;
        protected global::System.Web.UI.WebControls.Button btnSaveTable;
        protected global::System.Web.UI.WebControls.Button btnRefreshFields;
        protected global::System.Web.UI.WebControls.GridView gvTableConfig;
        protected global::System.Web.UI.WebControls.GridView gvFieldConfig;
        protected global::System.Web.UI.WebControls.Button btnSaveFields;
    }
}