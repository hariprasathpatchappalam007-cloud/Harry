using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class DdaBulkChecker : Page
    {
        private bool _isFileDownload;

        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                string fromTextbox = (txtCurrentUser.Text ?? "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                if (Context.User != null && Context.User.Identity != null && !string.IsNullOrEmpty(Context.User.Identity.Name))
                    return Context.User.Identity.Name;
                return "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null) txtCurrentUser.Text = Session["UserID"].ToString();
                btnApprove.Enabled = false;
                btnReject.Enabled = false;
                LoadPending();
                LoadHistory();
            }
        }

        private void LoadPending()
        {
            gvPending.DataSource = ExecuteDataTable("Proc_DDA_BulkGetRequests", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@Mode", "CHECKER");
            });
            gvPending.DataBind();
        }

        private void LoadHistory()
        {
            gvHistory.DataSource = ExecuteDataTable("Proc_DDA_BulkGetRequests", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@Mode", "ALL");
            });
            gvHistory.DataBind();
        }

        private void LoadRequest(int requestId, bool allowDecision)
        {
            Action<SqlCommand> parameters = delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
            };
            gvRequestDetail.PageIndex = 0;
            gvAudit.PageIndex = 0;
            gvRequestDetail.DataSource = ExecuteDataTable("Proc_DDA_BulkGetDetails", parameters);
            gvRequestDetail.DataBind();
            gvAudit.DataSource = ExecuteDataTable("Proc_DDA_BulkGetAudit", parameters);
            gvAudit.DataBind();
            btnApprove.Enabled = allowDecision;
            btnReject.Enabled = allowDecision;
        }

        protected void gvPending_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "ViewRequest") return;
            int rowIndex = Convert.ToInt32(e.CommandArgument);
            int requestId = Convert.ToInt32(gvPending.DataKeys[rowIndex].Value);
            hfRequestId.Value = requestId.ToString();
            LoadRequest(requestId, true);
            ShowMessage("Request loaded. Review every row, the source list, attachment, and history before deciding.", true);
        }

        protected void gvPending_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvPending.PageIndex = e.NewPageIndex;
            LoadPending();
        }

        protected void gvHistory_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "ViewHistory") return;
            int rowIndex = Convert.ToInt32(e.CommandArgument);
            int requestId = Convert.ToInt32(gvHistory.DataKeys[rowIndex].Value);
            hfRequestId.Value = requestId.ToString();
            LoadRequest(requestId, false);
            ShowMessage("Historical request loaded in read-only mode.", true);
        }

        protected void gvHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvHistory.PageIndex = e.NewPageIndex;
            LoadHistory();
        }

        protected void gvRequestDetail_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            int requestId;
            if (!int.TryParse(hfRequestId.Value, out requestId) || requestId <= 0)
            {
                ShowMessage("Select a request before changing detail pages.", false);
                return;
            }
            gvRequestDetail.PageIndex = e.NewPageIndex;
            gvRequestDetail.DataSource = ExecuteDataTable("Proc_DDA_BulkGetDetails", RequestParameters(requestId));
            gvRequestDetail.DataBind();
        }

        protected void gvAudit_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            int requestId;
            if (!int.TryParse(hfRequestId.Value, out requestId) || requestId <= 0)
            {
                ShowMessage("Select a request before changing audit pages.", false);
                return;
            }
            gvAudit.PageIndex = e.NewPageIndex;
            gvAudit.DataSource = ExecuteDataTable("Proc_DDA_BulkGetAudit", RequestParameters(requestId));
            gvAudit.DataBind();
        }

        private Action<SqlCommand> RequestParameters(int requestId)
        {
            return delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
            };
        }

        protected void gvRequestDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            DataRowView data = e.Row.DataItem as DataRowView;
            if (data != null && string.Equals(Convert.ToString(data["OldDdaRefNo"]), Convert.ToString(data["NewDdaRefNo"]), StringComparison.Ordinal))
            {
                e.Row.Cells[5].CssClass = "";
                e.Row.Cells[6].CssClass = "";
                e.Row.Cells[6].Text = "Unchanged";
            }
        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            CheckRequest("A");
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCheckerRemarks.Text))
            {
                ShowMessage("Checker remarks are required for rejection.", false);
                return;
            }
            CheckRequest("R");
        }

        private void CheckRequest(string decision)
        {
            int requestId;
            if (!int.TryParse(hfRequestId.Value, out requestId) || requestId <= 0)
            {
                ShowMessage("Select a pending request first.", false);
                return;
            }

            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_DDA_BulkCheck", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@CheckerLoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@Decision", decision);
                cmd.Parameters.AddWithValue("@Remarks", string.IsNullOrWhiteSpace(txtCheckerRemarks.Text) ? (object)DBNull.Value : txtCheckerRemarks.Text.Trim());
                SqlParameter status = new SqlParameter("@Status", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
                SqlParameter message = new SqlParameter("@Message", SqlDbType.NVarChar, 500) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(status);
                cmd.Parameters.Add(message);
                conn.Open();
                cmd.ExecuteNonQuery();

                bool success = Convert.ToString(status.Value) == "SUCCESS";
                ShowMessage(Convert.ToString(message.Value), success);
                if (success)
                {
                    hfRequestId.Value = "0";
                    txtCheckerRemarks.Text = "";
                    gvRequestDetail.DataSource = null;
                    gvRequestDetail.DataBind();
                    gvAudit.DataSource = null;
                    gvAudit.DataBind();
                    btnApprove.Enabled = false;
                    btnReject.Enabled = false;
                }
            }

            LoadPending();
            LoadHistory();
        }

        protected void btnDownloadSource_Click(object sender, EventArgs e)
        {
            DownloadRequestFile("SOURCE");
        }

        protected void btnDownloadAttachment_Click(object sender, EventArgs e)
        {
            DownloadRequestFile("ATTACHMENT");
        }

        private void DownloadRequestFile(string fileType)
        {
            int requestId;
            if (!int.TryParse(hfRequestId.Value, out requestId) || requestId <= 0)
            {
                ShowMessage("Select a request before downloading its files.", false);
                return;
            }

            DataTable dt = ExecuteDataTable("Proc_DDA_BulkGetFile", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
                cmd.Parameters.AddWithValue("@FileType", fileType);
            });
            if (dt.Rows.Count == 0 || dt.Rows[0]["FileData"] == DBNull.Value)
            {
                ShowMessage("The requested file is not available for this request.", false);
                return;
            }

            DataRow row = dt.Rows[0];
            byte[] data = (byte[])row["FileData"];
            _isFileDownload = true;
            Response.Clear();
            Response.ContentType = fileType == "SOURCE" ? "text/csv" : "application/octet-stream";
            Response.AddHeader("Content-Disposition", "attachment; filename=\"" + DdaBulkCsv.SafeFileName(Convert.ToString(row["FileName"])) + "\"");
            Response.BinaryWrite(data);
            Response.Flush();
            Context.ApplicationInstance.CompleteRequest();
        }

        protected void btnExportExcel_Click(object sender, EventArgs e)
        {
            int requestId;
            if (!int.TryParse(hfRequestId.Value, out requestId) || requestId <= 0)
            {
                ShowMessage("Select a request before exporting.", false);
                return;
            }

            DataTable dt = ExecuteDataTable("Proc_DDA_BulkGetDetails", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@RequestId", requestId);
                cmd.Parameters.AddWithValue("@LoginId", CurrentUser);
            });
            if (dt.Rows.Count == 0)
            {
                ShowMessage("No request details are available to export.", false);
                return;
            }

            StringBuilder csv = new StringBuilder();
            for (int columnIndex = 0; columnIndex < dt.Columns.Count; columnIndex++)
            {
                if (columnIndex > 0) csv.Append(',');
                csv.Append(DdaBulkCsv.Escape(dt.Columns[columnIndex].ColumnName));
            }
            csv.Append("\r\n");
            foreach (DataRow row in dt.Rows)
            {
                for (int columnIndex = 0; columnIndex < dt.Columns.Count; columnIndex++)
                {
                    if (columnIndex > 0) csv.Append(',');
                    string value = row[columnIndex] == DBNull.Value ? "" : Convert.ToString(row[columnIndex]);
                    csv.Append(DdaBulkCsv.Escape(DdaBulkCsv.ExcelTextCell(value)));
                }
                csv.Append("\r\n");
            }

            _isFileDownload = true;
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.ContentEncoding = Encoding.UTF8;
            Response.AddHeader("Content-Disposition", "attachment; filename=\"DDA_Bulk_Request_" + requestId + ".csv\"");
            Response.BinaryWrite(new UTF8Encoding(true).GetBytes(csv.ToString()));
            Response.Flush();
            Context.ApplicationInstance.CompleteRequest();
        }

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Session["UserID"] = (txtCurrentUser.Text ?? "").Trim();
            hfRequestId.Value = "0";
            LoadPending();
            LoadHistory();
            gvRequestDetail.DataSource = null;
            gvRequestDetail.DataBind();
            gvAudit.DataSource = null;
            gvAudit.DataBind();
            btnApprove.Enabled = false;
            btnReject.Enabled = false;
            ShowMessage("Acting user set to: " + CurrentUser, true);
        }

        private DataTable ExecuteDataTable(string procedureName, Action<SqlCommand> addParameters)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (addParameters != null) addParameters(cmd);
                DataTable dt = new DataTable();
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    conn.Open();
                    adapter.Fill(dt);
                }
                return dt;
            }
        }

        private void ShowMessage(string message, bool success)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = success ? "msg-success" : "msg-error";
            lblMessage.Text = HttpUtility.HtmlEncode(message);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (!_isFileDownload) base.Render(writer);
        }
    }
}
