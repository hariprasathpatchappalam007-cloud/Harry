using System;
using System.Configuration;
using System.Diagnostics;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace HF48Workflow
{
    [WebServiceBinding(Name = "AuthServiceSoap", Namespace = "https://dib.ae/HF48Workflow/")]
    internal sealed class AuthServiceClient : SoapHttpClientProtocol
    {
        public AuthServiceClient()
        {
            Uri endpoint;
            if (!Uri.TryCreate(ConfigurationManager.AppSettings["AuthServiceUrl"], UriKind.Absolute, out endpoint)
                || (endpoint.Scheme != Uri.UriSchemeHttp && endpoint.Scheme != Uri.UriSchemeHttps)
                || !string.IsNullOrEmpty(endpoint.UserInfo)
                || !string.IsNullOrEmpty(endpoint.Query)
                || !string.IsNullOrEmpty(endpoint.Fragment))
                throw new ConfigurationErrorsException("Configure AuthServiceUrl with the ASMX endpoint URL.");

            if (endpoint.Scheme == Uri.UriSchemeHttp)
                Trace.TraceWarning("AuthServiceUrl uses HTTP; submitted credentials are not protected in transit.");

            Url = endpoint.AbsoluteUri;
            Timeout = 15000;
            AllowAutoRedirect = false;
            UseDefaultCredentials = false;
        }

        [SoapDocumentMethod("https://dib.ae/HF48Workflow/IsAuthenticated",
            RequestNamespace = "https://dib.ae/HF48Workflow/",
            ResponseNamespace = "https://dib.ae/HF48Workflow/",
            Use = System.Web.Services.Description.SoapBindingUse.Literal,
            ParameterStyle = SoapParameterStyle.Wrapped)]
        public bool IsAuthenticated(string domain, string username, string pwd)
        {
            object[] results = Invoke("IsAuthenticated", new object[] { domain, username, pwd });
            return (bool)results[0];
        }
    }
}
