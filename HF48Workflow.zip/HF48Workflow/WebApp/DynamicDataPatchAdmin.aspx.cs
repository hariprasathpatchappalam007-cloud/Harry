using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class DynamicDataPatchAdmin : System.Web.UI.Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                string fromTextbox = (txtCurrentUser.Text ?? "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                return System.Web.HttpContext.Current.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null) txtCurrentUser.Text = Session["UserID"].ToString();
                LoadUsers();
                LoadAvailableTables();
                LoadUserAccess();
                LoadTableConfig();
            }
        }

        private void LoadUsers()
        {
            DataTable dt = ExecuteDataTable("Proc_DDP_GetUsers", delegate(SqlCommand cmd) { cmd.Parameters.AddWithValue("@OnlyCheckers", 0); });
            ddlUsers.DataSource = dt;
            ddlUsers.DataTextField = "LoginId";
            ddlUsers.DataValueField = "LoginId";
            ddlUsers.DataBind();
        }

        private void LoadAvailableTables()
        {
            DataTable dt = ExecuteDataTable("Proc_DDP_GetAvailableTables", null);
            ddlTables.DataSource = dt;
            ddlTables.DataTextField = "FullTableName";
            ddlTables.DataValueField = "FullTableName";
            ddlTables.DataBind();
            ddlTables.Items.Insert(0, new ListItem("-- Select Table --", ""));
        }

        private void LoadColumns(string fullTableName)
        {
            ddlPrimaryKey.Items.Clear();
            if (string.IsNullOrEmpty(fullTableName) || fullTableName.IndexOf('.') < 0) return;

            string[] parts = fullTableName.Split('.');
            DataTable dt = ExecuteDataTable("Proc_DDP_GetTableColumns", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@SchemaName", parts[0]);
                cmd.Parameters.AddWithValue("@TableName", parts[1]);
            });

            ddlPrimaryKey.DataSource = dt;
            ddlPrimaryKey.DataTextField = "ColumnName";
            ddlPrimaryKey.DataValueField = "ColumnName";
            ddlPrimaryKey.DataBind();
        }

        private void LoadUserAccess()
        {
            gvUserAccess.DataSource = ExecuteDataTable("Proc_DDP_GetUserAccess", null);
            gvUserAccess.DataBind();
        }

        private void LoadTableConfig()
        {
            gvTableConfig.DataSource = ExecuteDataTable("Proc_DDP_GetTableConfig", delegate(SqlCommand cmd) { cmd.Parameters.AddWithValue("@OnlyActive", 0); });
            gvTableConfig.DataBind();
        }

        private void LoadFieldConfig(int configId)
        {
            gvFieldConfig.DataSource = ExecuteDataTable("Proc_DDP_GetFieldConfig", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@ConfigId", configId);
                cmd.Parameters.AddWithValue("@OnlyEditable", 0);
            });
            gvFieldConfig.DataBind();
        }

        protected void ddlTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadColumns(ddlTables.SelectedValue);
            if (!string.IsNullOrEmpty(ddlTables.SelectedValue) && string.IsNullOrEmpty(txtFriendlyName.Text.Trim()))
                txtFriendlyName.Text = ddlTables.SelectedValue;
        }

        protected void btnSaveUser_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ddlUsers.SelectedValue)) { ShowMessage("Select a user.", false); return; }

            ExecuteStatusProcedure("Proc_DDP_SaveUserAccess", delegate(SqlCommand cmd)
            {
                cmd.Parameters.AddWithValue("@LoginId", ddlUsers.SelectedValue);
                cmd.Parameters.AddWithValue("@CanAdmin", chkAdmin.Checked);
                cmd.Parameters.AddWithValue("@CanMake", chkMaker.Checked);
                cmd.Parameters.AddWithValue("@CanCheck", chkChecker.Checked);
                cmd.Parameters.AddWithValue("@IsActive", chkUserActive.Checked);
                cmd.Parameters.AddWithValue("@ActionBy", CurrentUser);
            });
            LoadUserAccess();
        }

        protected void btnSaveTable_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ddlTables.SelectedValue) || ddlTables.SelectedValue.IndexOf('.') < 0) { ShowMessage("Select a database table.", false); return; }
            if (string.IsNullOrEmpty(txtFriendlyName.Text.Trim())) { ShowMessage("Friendly Name is required.", false); return; }
            if (string.IsNullOrEmpty(ddlPrimaryKey.SelectedValue)) { ShowMessage("Primary Key Column is required.", false); return; }

            string[] parts = ddlTables.SelectedValue.Split('.');
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_DDP_SaveTableConfig", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                int configId;
                int.TryParse(hfConfigId.Value, out configId);
                cmd.Parameters.AddWithValue("@ConfigId", configId);
                cmd.Parameters.AddWithValue("@SchemaName", parts[0]);
                cmd.Parameters.AddWithValue("@TableName", parts[1]);
                cmd.Parameters.AddWithValue("@FriendlyName", txtFriendlyName.Text.Trim());
                cmd.Parameters.AddWithValue("@PrimaryKeyColumn", ddlPrimaryKey.SelectedValue);
                cmd.Parameters.AddWithValue("@DisplayColumnsCsv", string.IsNullOrEmpty(txtDisplayColumns.Text.Trim()) ? (object)DBNull.Value : txtDisplayColumns.Text.Trim());
                cmd.Parameters.AddWithValue("@IsActive", chkTableActive.Checked);
                cmd.Parameters.AddWithValue("@ActionBy", CurrentUser);
                SqlParameter saved = new SqlParameter("@SavedConfigId", SqlDbType.Int) { Direction = ParameterDirection.Output };
                SqlParameter status = new SqlParameter("@Status", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
                SqlParameter message = new SqlParameter("@Message", SqlDbType.NVarChar, 500) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(saved);
                cmd.Parameters.Add(status);
                cmd.Parameters.Add(message);
                conn.Open();
                cmd.ExecuteNonQuery();
                hfConfigId.Value = saved.Value.ToString();
                ShowMessage(message.Value.ToString(), status.Value.ToString() == "SUCCESS");
            }

            LoadTableConfig();
            LoadFieldConfig(Convert.ToInt32(hfConfigId.Value));
        }

        protected void btnRefreshFields_Click(object sender, EventArgs e)
        {
            int configId;
            if (!int.TryParse(hfConfigId.Value, out configId) || configId <= 0) { ShowMessage("Select or save a table configuration first.", false); return; }

            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_DDP_RefreshFieldConfig", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ConfigId", configId);
                cmd.Parameters.AddWithValue("@ActionBy", CurrentUser);
                conn.Open();
                cmd.ExecuteNonQuery();
            }

            LoadFieldConfig(configId);
            ShowMessage("Fields refreshed from selected table.", true);
        }

        protected void btnSaveFields_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in gvFieldConfig.Rows)
            {
                int fieldConfigId = Convert.ToInt32(row.Cells[0].Text);
                TextBox txtDisplayName = (TextBox)row.FindControl("txtDisplayName");
                CheckBox chkEditable = (CheckBox)row.FindControl("chkEditable");
                CheckBox chkRequired = (CheckBox)row.FindControl("chkRequired");
                TextBox txtSortOrder = (TextBox)row.FindControl("txtSortOrder");
                int sortOrder;
                if (!int.TryParse(txtSortOrder.Text.Trim(), out sortOrder)) sortOrder = 0;

                using (SqlConnection conn = new SqlConnection(ConnStr))
                using (SqlCommand cmd = new SqlCommand("Proc_DDP_SaveFieldConfig", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FieldConfigId", fieldConfigId);
                    cmd.Parameters.AddWithValue("@DisplayName", txtDisplayName.Text.Trim());
                    cmd.Parameters.AddWithValue("@IsEditable", chkEditable.Checked);
                    cmd.Parameters.AddWithValue("@IsRequired", chkRequired.Checked);
                    cmd.Parameters.AddWithValue("@SortOrder", sortOrder);
                    cmd.Parameters.AddWithValue("@ActionBy", CurrentUser);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            ShowMessage("Field configuration saved.", true);
            int configId;
            if (int.TryParse(hfConfigId.Value, out configId)) LoadFieldConfig(configId);
        }

        protected void gvTableConfig_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "SelectConfig") return;
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = gvTableConfig.Rows[index];
            int configId = Convert.ToInt32(row.Cells[0].Text);
            hfConfigId.Value = configId.ToString();
            txtFriendlyName.Text = row.Cells[1].Text.Replace("&nbsp;", "");
            string fullTableName = row.Cells[2].Text.Replace("&nbsp;", "");
            ddlTables.SelectedValue = fullTableName;
            LoadColumns(fullTableName);
            ddlPrimaryKey.SelectedValue = row.Cells[3].Text.Replace("&nbsp;", "");
            LoadFieldConfig(configId);
            ShowMessage("Configuration selected. You can edit table settings or field rules.", true);
        }

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Session["UserID"] = (txtCurrentUser.Text ?? "").Trim();
            ShowMessage("Acting user set to: " + CurrentUser, true);
        }

        private DataTable ExecuteDataTable(string procedureName, Action<SqlCommand> addParameters)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (addParameters != null) addParameters(cmd);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);
                return dt;
            }
        }

        private void ExecuteStatusProcedure(string procedureName, Action<SqlCommand> addParameters)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                addParameters(cmd);
                SqlParameter status = new SqlParameter("@Status", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
                SqlParameter message = new SqlParameter("@Message", SqlDbType.NVarChar, 500) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(status);
                cmd.Parameters.Add(message);
                conn.Open();
                cmd.ExecuteNonQuery();
                ShowMessage(message.Value.ToString(), status.Value.ToString() == "SUCCESS");
            }
        }

        private void ShowMessage(string message, bool success)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = success ? "msg-success" : "msg-error";
            lblMessage.Text = message;
        }
    }
}