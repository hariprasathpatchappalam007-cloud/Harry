<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="DdaApplicationDds.ascx.cs" Inherits="HF48Workflow.DdaApplicationDds" %>
<h2>DDS System Data</h2>
<p class="hint">Read-only data from DDS_HFLMS_REG_CANC_SYNC. Application ID and DDA reference matching are exact.</p>
<asp:Label runat="server" AssociatedControlID="txtApplicationId" Text="Application ID" />
<asp:TextBox ID="txtApplicationId" runat="server" MaxLength="200" />
<asp:Label runat="server" AssociatedControlID="txtReference" Text="DDA reference" />
<asp:TextBox ID="txtReference" runat="server" MaxLength="200" /><br />
<asp:Label runat="server" AssociatedControlID="txtFrom" Text="Response from (yyyy-MM-dd)" />
<asp:TextBox ID="txtFrom" runat="server" MaxLength="10" />
<asp:Label runat="server" AssociatedControlID="txtTo" Text="Response to (yyyy-MM-dd)" />
<asp:TextBox ID="txtTo" runat="server" MaxLength="10" />
<asp:Label runat="server" AssociatedControlID="txtStatus" Text="Status" />
<asp:TextBox ID="txtStatus" runat="server" MaxLength="100" />
<asp:Button runat="server" Text="Fetch DDS Data" OnClick="Fetch_Click" />
<asp:Button runat="server" Text="Export DDS CSV" OnClick="Export_Click" />
<asp:Label ID="lblCount" runat="server" />
<div class="scroll"><asp:GridView ID="gvDds" runat="server" CssClass="grid" AutoGenerateColumns="true"
    AllowPaging="true" PageSize="20" OnPageIndexChanging="Page_Changing" EmptyDataText="No DDS rows found." /></div>
