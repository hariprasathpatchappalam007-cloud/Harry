using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public abstract class DdaApplicationPage : Page
    {
        protected abstract Label MessageLabel { get; }
        protected abstract string AccessRole { get; }

        public string LoginId
        {
            get
            {
                string login = Session["UserID"] as string;
                if (String.IsNullOrWhiteSpace(login) && User != null && User.Identity.IsAuthenticated)
                    login = User.Identity.Name;
                if (String.IsNullOrWhiteSpace(login) || login.Length > 100)
                    throw new HttpException(401, "A valid authenticated DDA login is required.");
                return login;
            }
        }

        protected override void OnInit(EventArgs e)
        {
            ViewStateUserKey = Session.SessionID + ":" + LoginId;
            base.OnInit(e);
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            Response.Headers["X-Frame-Options"] = "SAMEORIGIN";
            try
            {
                using (SqlConnection connection = OpenConnection())
                using (SqlCommand command = Command(connection, "dbo.Proc_DDA_ApplicationAccess"))
                {
                    command.Parameters.Add("@Role", SqlDbType.Char, 1).Value = (object)AccessRole ?? DBNull.Value;
                    command.ExecuteNonQuery();
                }
            }
            catch (SqlException exception)
            {
                TraceError(exception);
                throw new HttpException(exception.Number == 51601 ? 403 : 503,
                    "DDA access could not be verified.", exception);
            }
        }

        protected SqlConnection OpenConnection()
        {
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["LMS_DEV"];
            if (settings == null || String.IsNullOrWhiteSpace(settings.ConnectionString))
                throw new ConfigurationErrorsException("The DDA database connection is not configured.");
            SqlConnection connection = new SqlConnection(settings.ConnectionString);
            try { connection.Open(); }
            catch { connection.Dispose(); throw; }
            return connection;
        }

        public SqlCommand Command(SqlConnection connection, string procedure)
        {
            SqlCommand command = new SqlCommand(procedure, connection);
            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 120;
            command.Parameters.Add("@LoginId", SqlDbType.NVarChar, 100).Value = LoginId;
            return command;
        }

        public DataSet Query(string procedure, Action<SqlCommand> parameters)
        {
            using (SqlConnection connection = OpenConnection())
            using (SqlCommand command = Command(connection, procedure))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                if (parameters != null) parameters(command);
                DataSet data = new DataSet();
                adapter.Fill(data);
                return data;
            }
        }

        public void Run(Action operation)
        {
            try { operation(); }
            catch (SqlException exception)
            {
                TraceError(exception);
                ShowMessage(exception.Number >= 51600 && exception.Number <= 51699
                    ? exception.Message : "The DDA database operation failed. Contact support.", false);
            }
            catch (ConfigurationErrorsException exception)
            {
                TraceError(exception);
                ShowMessage("The DDA database connection is not configured. Contact support.", false);
            }
            catch (ArgumentException exception)
            {
                ShowMessage(exception.Message, false);
            }
        }

        private static void TraceError(Exception exception)
        {
            System.Diagnostics.Trace.TraceError("DDA application workflow: {0}", exception);
        }

        public void ShowMessage(string message, bool success)
        {
            MessageLabel.Text = HttpUtility.HtmlEncode(message);
            MessageLabel.CssClass = success ? "message success" : "message error";
        }

        protected static void Bind(GridView grid, DataTable data)
        {
            grid.DataSource = data;
            grid.DataBind();
        }
    }
}
