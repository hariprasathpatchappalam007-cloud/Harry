using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Web.Services.Protocols;
using System.Xml;
using HF48Workflow;

public static class AuthenticationChecks
{
    private static int passed;

    private static void Check(bool condition, string name)
    {
        if (!condition)
            throw new Exception("FAILED: " + name);
        Console.WriteLine("PASS: " + name);
        passed++;
    }

    public static void Run()
    {
        var service = new AuthService();
        Check(!service.IsAuthenticated("other.example", "test-user", "synthetic"), "Reject alternate LDAP domain");
        Check(!service.IsAuthenticated(null, "test-user", "synthetic"), "Reject missing domain");
        Check(!service.IsAuthenticated("dib.ae", "test-user", ""), "Reject empty password before LDAP bind");
        Check(!service.IsAuthenticated("dib.ae", " ", "synthetic"), "Reject blank username");
        Check(!service.IsAuthenticated("dib.ae", "dib\\test-user", "synthetic"), "Reject qualified username");
        Check(!service.IsAuthenticated("dib.ae", "test-user@dib.ae", "synthetic"), "Reject UPN input for SAM search");
        Check(!service.IsAuthenticated("dib.ae", new string('a', 257), "synthetic"), "Reject overlong username");
        var escape = typeof(AuthService).GetMethod("EscapeLdapFilterValue", BindingFlags.NonPublic | BindingFlags.Static);
        Check((string)escape.Invoke(null, new object[] { "a*)(x=\\\0" }) == "a\\2a\\29\\28x=\\5c\\00",
            "Escape every LDAP filter metacharacter");

        var clientType = typeof(AuthService).Assembly.GetType("HF48Workflow.AuthServiceClient", true);
        var settings = ConfigurationManager.AppSettings;
        var readOnly = typeof(System.Collections.Specialized.NameObjectCollectionBase)
            .GetProperty("IsReadOnly", BindingFlags.Instance | BindingFlags.NonPublic);
        bool originalReadOnly = (bool)readOnly.GetValue(settings, null);
        string originalUrl = settings["AuthServiceUrl"];
        readOnly.SetValue(settings, false, null);
        try
        {
            foreach (string invalidUrl in new[] { "", "file:///C:/test",
                "http://user:synthetic@localhost/AuthService.asmx", "http://localhost/AuthService.asmx?WSDL" })
            {
                settings["AuthServiceUrl"] = invalidUrl;
                bool rejected = false;
                try
                {
                    using (var client = (SoapHttpClientProtocol)Activator.CreateInstance(clientType)) { }
                }
                catch (TargetInvocationException exception)
                {
                    rejected = exception.InnerException is ConfigurationErrorsException;
                }
                Check(rejected, "Reject invalid endpoint: " + (invalidUrl == "" ? "missing URL" : invalidUrl));
            }
            TestSoap(clientType, settings, "true", false);
            TestSoap(clientType, settings, "false", false);
            TestSoap(clientType, settings, null, true);
        }
        finally
        {
            settings["AuthServiceUrl"] = originalUrl;
            readOnly.SetValue(settings, originalReadOnly, null);
        }
        Console.WriteLine("Completed " + passed + " checks without contacting Active Directory.");
    }

    private static void TestSoap(Type clientType,
        System.Collections.Specialized.NameValueCollection settings, string result, bool fault)
    {
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        int port = ((IPEndPoint)listener.LocalEndpoint).Port;
        settings["AuthServiceUrl"] = "http://127.0.0.1:" + port + "/AuthService.asmx";
        Exception serverError = null;
        bool requestValid = false;
        var thread = new Thread(delegate()
        {
            try
            {
                using (var connection = listener.AcceptTcpClient())
                {
                    connection.ReceiveTimeout = 5000;
                    var stream = connection.GetStream();
                    var reader = new StreamReader(stream, Encoding.UTF8);
                    string line = reader.ReadLine();
                    int contentLength = 0;
                    bool action = false;
                    while (!string.IsNullOrEmpty(line = reader.ReadLine()))
                    {
                        if (line.StartsWith("Content-Length:", StringComparison.OrdinalIgnoreCase))
                            contentLength = int.Parse(line.Substring(15).Trim());
                        if (line.StartsWith("SOAPAction:", StringComparison.OrdinalIgnoreCase))
                            action = line.Contains("https://dib.ae/HF48Workflow/IsAuthenticated");
                        if (line.Equals("Expect: 100-continue", StringComparison.OrdinalIgnoreCase))
                        {
                            byte[] interim = Encoding.ASCII.GetBytes("HTTP/1.1 100 Continue\r\n\r\n");
                            stream.Write(interim, 0, interim.Length);
                        }
                    }
                    char[] body = new char[contentLength];
                    int read = 0;
                    while (read < body.Length)
                    {
                        int count = reader.Read(body, read, body.Length - read);
                        if (count == 0)
                            throw new EndOfStreamException();
                        read += count;
                    }
                    var document = new XmlDocument();
                    document.LoadXml(new string(body));
                    var namespaces = new XmlNamespaceManager(document.NameTable);
                    namespaces.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                    namespaces.AddNamespace("a", "https://dib.ae/HF48Workflow/");
                    string path = "/s:Envelope/s:Body/a:IsAuthenticated/";
                    requestValid = action
                        && document.SelectSingleNode(path + "a:domain", namespaces).InnerText == "dib.ae"
                        && document.SelectSingleNode(path + "a:username", namespaces).InnerText == "test<&user"
                        && document.SelectSingleNode(path + "a:pwd", namespaces).InnerText == "synthetic<&password";
                    string responseBody = fault
                        ? "<soap:Fault><faultcode>soap:Server</faultcode><faultstring>Directory unavailable</faultstring></soap:Fault>"
                        : "<IsAuthenticatedResponse xmlns=\"https://dib.ae/HF48Workflow/\"><IsAuthenticatedResult>"
                            + result + "</IsAuthenticatedResult></IsAuthenticatedResponse>";
                    byte[] response = Encoding.UTF8.GetBytes(
                        "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body>"
                        + responseBody + "</soap:Body></soap:Envelope>");
                    byte[] header = Encoding.ASCII.GetBytes("HTTP/1.1 "
                        + (fault ? "500 Internal Server Error" : "200 OK")
                        + "\r\nContent-Type: text/xml; charset=utf-8\r\nConnection: close\r\nContent-Length: "
                        + response.Length + "\r\n\r\n");
                    stream.Write(header, 0, header.Length);
                    stream.Write(response, 0, response.Length);
                }
            }
            catch (Exception exception)
            {
                serverError = exception;
            }
        });
        thread.IsBackground = true;
        thread.Start();
        try
        {
            using (var client = (SoapHttpClientProtocol)Activator.CreateInstance(clientType))
            {
                Check(!client.UseDefaultCredentials && !client.AllowAutoRedirect && client.Timeout == 15000,
                    "Anonymous client has bounded timeout and no redirects");
                bool gotFault = false;
                object actual = null;
                try
                {
                    actual = clientType.GetMethod("IsAuthenticated")
                        .Invoke(client, new object[] { "dib.ae", "test<&user", "synthetic<&password" });
                }
                catch (TargetInvocationException exception)
                {
                    if (!(exception.InnerException is SoapException))
                        throw;
                    gotFault = true;
                }
                if (!thread.Join(10000))
                    throw new Exception("SOAP fixture did not finish");
                if (serverError != null)
                    throw new Exception("SOAP fixture failed", serverError);
                Check(requestValid, "SOAP action, namespaces and XML-escaped input round trip");
                Check(fault ? gotFault : !gotFault && (bool)actual == (result == "true"),
                    fault ? "Preserve SOAP fault as infrastructure error" : "Read SOAP boolean " + result);
            }
        }
        finally
        {
            listener.Stop();
            thread.Join(1000);
        }
    }
}
