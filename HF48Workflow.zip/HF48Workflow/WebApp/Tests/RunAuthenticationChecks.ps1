$ErrorActionPreference = 'Stop'
$assemblyPath = Join-Path $PSScriptRoot '..\bin\HF48Workflow.dll'
$assembly = [System.Reflection.Assembly]::LoadFrom((Resolve-Path $assemblyPath).Path)
Add-Type -Path (Join-Path $PSScriptRoot 'AuthenticationChecks.cs') -ReferencedAssemblies @(
    $assembly.Location,
    'System.Web.dll',
    'System.Web.Services.dll',
    'System.DirectoryServices.dll',
    'System.Configuration.dll',
    'System.Xml.dll'
)
[AuthenticationChecks]::Run()
