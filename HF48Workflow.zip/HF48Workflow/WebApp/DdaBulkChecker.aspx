<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DdaBulkChecker.aspx.cs" Inherits="HF48Workflow.DdaBulkChecker" %>
<%@ Register Src="DdaApplicationDds.ascx" TagPrefix="dda" TagName="DdsData" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>DDA Status Change - Checker</title>
    <link rel="stylesheet" href="DdaApplication.css" />
</head>
<body>
<form id="form1" runat="server">
    <header>
        <h1>DDA Status Change - Checker</h1>
        <a href="DdaBulkMaker.aspx">DDA status change maker</a>
    </header>
    <main>
        <p>Authenticated user: <asp:Literal ID="litLogin" runat="server" Mode="Encode" /></p>
        <asp:Label ID="lblMessage" runat="server" />
        <div class="tabs">
            <asp:LinkButton runat="server" Text="Requests and History" OnClick="RequestsTab_Click" CausesValidation="false" />
            <asp:LinkButton runat="server" Text="DDS System Data" OnClick="DdsTab_Click" CausesValidation="false" />
        </div>
        <asp:MultiView ID="views" runat="server" ActiveViewIndex="0">
            <asp:View runat="server">
                <section>
                    <h2>Pending with me</h2>
                    <asp:Button runat="server" Text="Refresh Requests" OnClick="Refresh_Click" />
                    <div class="scroll">
                        <asp:GridView ID="gvPending" runat="server" CssClass="grid" AutoGenerateColumns="false"
                            DataKeyNames="RequestId" OnSelectedIndexChanged="Pending_Selected" AllowPaging="true"
                            PageSize="15" OnPageIndexChanging="Pending_Page">
                            <Columns>
                                <asp:CommandField ShowSelectButton="true" SelectText="Review" />
                                <asp:BoundField DataField="RequestId" HeaderText="Request" />
                                <asp:BoundField DataField="MakerLoginId" HeaderText="Maker" />
                                <asp:BoundField DataField="MakerRemarks" HeaderText="Maker remarks" />
                                <asp:BoundField DataField="RecordCount" HeaderText="Applications" />
                                <asp:BoundField DataField="SubmittedOn" HeaderText="Submitted" DataFormatString="{0:yyyy-MM-dd HH:mm:ss}" />
                            </Columns>
                        </asp:GridView>
                    </div>
                </section>
                <asp:Panel ID="pnlReview" runat="server" Visible="false">
                    <section>
                        <h2>Review selected applications</h2>
                        <div class="scroll"><asp:GridView ID="gvSummary" runat="server" CssClass="grid" AutoGenerateColumns="true" /></div>
                        <asp:Button ID="btnAttachment" runat="server" Text="Download Supporting Attachment" OnClick="Attachment_Click" />
                        <div class="scroll"><asp:GridView ID="gvDetails" runat="server" CssClass="grid" AutoGenerateColumns="true" /></div>
                        <h2>Request audit</h2>
                        <div class="scroll"><asp:GridView ID="gvAudit" runat="server" CssClass="grid" AutoGenerateColumns="true" /></div>
                        <asp:Label runat="server" AssociatedControlID="txtRemarks" Text="Checker remarks (required)" />
                        <asp:TextBox ID="txtRemarks" runat="server" TextMode="MultiLine" Rows="3" MaxLength="1000" Width="450px" />
                        <br />
                        <asp:Button ID="btnApprove" runat="server" Text="Approve all selected applications"
                            OnClick="Approve_Click" OnClientClick="return confirm('Apply all reviewed DDA status changes and write movement history?');" />
                        <asp:Button ID="btnReject" runat="server" Text="Reject request" OnClick="Reject_Click"
                            OnClientClick="return confirm('Reject this DDA request without changing source records?');" />
                    </section>
                </asp:Panel>
                <section>
                    <h2>My request history</h2>
                    <div class="scroll">
                        <asp:GridView ID="gvHistory" runat="server" CssClass="grid" AutoGenerateColumns="false"
                            DataKeyNames="RequestId" OnSelectedIndexChanged="History_Selected" AllowPaging="true"
                            PageSize="15" OnPageIndexChanging="History_Page">
                            <Columns>
                                <asp:CommandField ShowSelectButton="true" SelectText="Review history" />
                                <asp:BoundField DataField="RequestId" HeaderText="Request" />
                                <asp:BoundField DataField="RequestStatus" HeaderText="Status" />
                                <asp:BoundField DataField="MakerLoginId" HeaderText="Maker" />
                                <asp:BoundField DataField="CheckerLoginId" HeaderText="Checker" />
                                <asp:BoundField DataField="SubmittedOn" HeaderText="Submitted" DataFormatString="{0:yyyy-MM-dd HH:mm:ss}" />
                                <asp:BoundField DataField="CheckedOn" HeaderText="Checked" DataFormatString="{0:yyyy-MM-dd HH:mm:ss}" />
                                <asp:BoundField DataField="CheckerRemarks" HeaderText="Checker remarks" />
                            </Columns>
                        </asp:GridView>
                    </div>
                </section>
            </asp:View>
            <asp:View runat="server"><section><dda:DdsData ID="ddsData" runat="server" /></section></asp:View>
        </asp:MultiView>
    </main>
</form>
</body>
</html>
