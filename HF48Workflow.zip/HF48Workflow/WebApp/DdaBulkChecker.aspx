<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DdaBulkChecker.aspx.cs" Inherits="HF48Workflow.DdaBulkChecker" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>DDA Bulk Update - Checker</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; background-color: #ccccff; color: #222; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: inline-block; width: 150px; font-weight: bold; font-size: 13px; vertical-align: top; padding-top: 4px; }
        input, textarea { padding: 5px 8px; border: 1px solid #aaa; border-radius: 3px; font-size: 13px; }
        .btn { padding: 7px 16px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-info { background-color: #17a2b8; color: white; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-danger { background-color: #dc3545; color: white; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; background: white; }
        .gridview th { background-color: #507CD1; color: white; padding: 8px; text-align: left; white-space: nowrap; }
        .gridview td { padding: 6px 8px; border-bottom: 1px solid #ddd; vertical-align: top; }
        .who-bar { background: #fff8d8; border: 1px dashed #d8b400; padding: 8px 14px; margin-bottom: 15px; font-size: 12px; border-radius: 3px; }
        .old-value { color: #7a3434; text-decoration: line-through; }
        .new-value { color: #176b2c; font-weight: bold; background-color: #e4f5e8; }
        .dfm-pager td { padding: 8px 14px; background: #f8fafc; border-top: 1px solid #e2e8f0; text-align: center; }
        .dfm-pager span { display: inline-block; padding: 5px 11px; margin: 0 2px; border-radius: 4px; font-size: .85em; font-weight: 700; background: #1a3c5e; color: #fff; }
        .dfm-pager a { display: inline-block; padding: 5px 11px; margin: 0 2px; border-radius: 4px; font-size: .85em; font-weight: 600; background: #fff; color: #1a3c5e; border: 1px solid #cbd5e1; text-decoration: none; }
        .dfm-pager a:hover { background: #dbeafe; border-color: #93c5fd; }
    </style>
    <script type="text/javascript">
        function confirmApprove() { return confirm('Approve this DDA bulk request and apply all updates?'); }
        function confirmReject() { return confirm('Reject this DDA bulk request?'); }
    </script>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <h1>DDA Bulk Update Checker</h1>
            <h2>Review matched records, any supporting document, and audit history before deciding</h2>
        </div>
        <div class="container">
            <div class="who-bar">
                <strong>Acting As:</strong>
                <asp:TextBox ID="txtCurrentUser" runat="server" Width="180px" />
                <asp:Button ID="btnSetUser" runat="server" Text="Switch User" CssClass="btn btn-info" OnClick="btnSetUser_Click" />
            </div>
            <asp:Panel ID="pnlMessage" runat="server" Visible="false"><asp:Label ID="lblMessage" runat="server" /></asp:Panel>
            <asp:HiddenField ID="hfRequestId" runat="server" Value="0" />

            <div class="panel">
                <div class="panel-header">Pending With Me</div>
                <div class="panel-body">
                    <asp:GridView ID="gvPending" runat="server" CssClass="gridview" AutoGenerateColumns="false" DataKeyNames="RequestId" AllowPaging="true" PageSize="10" OnPageIndexChanging="gvPending_PageIndexChanging" OnRowCommand="gvPending_RowCommand">
                        <PagerStyle CssClass="dfm-pager" HorizontalAlign="Center" />
                        <PagerSettings Mode="NumericFirstLast" PageButtonCount="10" FirstPageText="&amp;laquo;" LastPageText="&amp;raquo;" />
                        <Columns>
                            <asp:BoundField DataField="RequestId" HeaderText="Request Id" />
                            <asp:BoundField DataField="OperationName" HeaderText="Operation" />
                            <asp:BoundField DataField="MakerLoginId" HeaderText="Maker" />
                            <asp:BoundField DataField="SubmittedOn" HeaderText="Submitted On" />
                            <asp:BoundField DataField="RecordCount" HeaderText="Records" />
                            <asp:BoundField DataField="MakerRemarks" HeaderText="Maker Remarks" />
                            <asp:ButtonField Text="Review" CommandName="ViewRequest" ButtonType="Button" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>

            <div class="panel">
                <div class="panel-header">Request Details</div>
                <div class="panel-body">
                    <div class="form-group">
                        <asp:Button ID="btnDownloadSource" runat="server" Text="Download Source CSV" CssClass="btn btn-info" OnClick="btnDownloadSource_Click" />
                        <asp:Button ID="btnDownloadAttachment" runat="server" Text="Download Attachment (if provided)" CssClass="btn btn-info" OnClick="btnDownloadAttachment_Click" />
                        <asp:Button ID="btnExportExcel" runat="server" Text="Export Details to Excel (CSV)" CssClass="btn btn-info" OnClick="btnExportExcel_Click" />
                    </div>
                    <asp:GridView ID="gvRequestDetail" runat="server" CssClass="gridview" AutoGenerateColumns="false" AllowPaging="true" PageSize="10" OnPageIndexChanging="gvRequestDetail_PageIndexChanging" OnRowDataBound="gvRequestDetail_RowDataBound">
                        <PagerStyle CssClass="dfm-pager" HorizontalAlign="Center" />
                        <PagerSettings Mode="NumericFirstLast" PageButtonCount="10" FirstPageText="&amp;laquo;" LastPageText="&amp;raquo;" />
                        <Columns>
                            <asp:BoundField DataField="InputRowNo" HeaderText="CSV Row" />
                            <asp:BoundField DataField="TargetTable" HeaderText="Target Table" />
                            <asp:BoundField DataField="ApplicationId" HeaderText="Application ID" />
                            <asp:BoundField DataField="RefNbr" HeaderText="REF_NBR" />
                            <asp:BoundField DataField="InternalRef" HeaderText="DDS_INTERNAL_REF" />
                            <asp:BoundField DataField="OldDdaRefNo" HeaderText="Current DDA_REF_NO" ItemStyle-CssClass="old-value" />
                            <asp:BoundField DataField="NewDdaRefNo" HeaderText="DDA_REF_NO after approval" ItemStyle-CssClass="new-value" />
                            <asp:BoundField DataField="OldStatus" HeaderText="Current Status" ItemStyle-CssClass="old-value" />
                            <asp:BoundField DataField="NewStatus" HeaderText="Status to set" ItemStyle-CssClass="new-value" />
                        </Columns>
                    </asp:GridView>
                    <br />
                    <strong>Transaction history / audit log</strong>
                    <br /><br />
                    <asp:GridView ID="gvAudit" runat="server" CssClass="gridview" AutoGenerateColumns="true" AllowPaging="true" PageSize="10" OnPageIndexChanging="gvAudit_PageIndexChanging">
                        <PagerStyle CssClass="dfm-pager" HorizontalAlign="Center" />
                        <PagerSettings Mode="NumericFirstLast" PageButtonCount="10" FirstPageText="&amp;laquo;" LastPageText="&amp;raquo;" />
                    </asp:GridView>
                    <br />
                    <div class="form-group">
                        <label>Checker remarks</label>
                        <asp:TextBox ID="txtCheckerRemarks" runat="server" Width="520px" TextMode="MultiLine" Rows="3" />
                    </div>
                    <asp:Button ID="btnApprove" runat="server" Text="Approve And Apply" CssClass="btn btn-success" OnClick="btnApprove_Click" OnClientClick="return confirmApprove();" />
                    <asp:Button ID="btnReject" runat="server" Text="Reject" CssClass="btn btn-danger" OnClick="btnReject_Click" OnClientClick="return confirmReject();" />
                </div>
            </div>

            <div class="panel">
                <div class="panel-header">Request History</div>
                <div class="panel-body">
                    <asp:GridView ID="gvHistory" runat="server" CssClass="gridview" AutoGenerateColumns="false" DataKeyNames="RequestId" AllowPaging="true" PageSize="10" OnPageIndexChanging="gvHistory_PageIndexChanging" OnRowCommand="gvHistory_RowCommand">
                        <PagerStyle CssClass="dfm-pager" HorizontalAlign="Center" />
                        <PagerSettings Mode="NumericFirstLast" PageButtonCount="10" FirstPageText="&amp;laquo;" LastPageText="&amp;raquo;" />
                        <Columns>
                            <asp:BoundField DataField="RequestId" HeaderText="Request Id" />
                            <asp:BoundField DataField="OperationName" HeaderText="Operation" />
                            <asp:BoundField DataField="StatusDesc" HeaderText="Status" />
                            <asp:BoundField DataField="MakerLoginId" HeaderText="Maker" />
                            <asp:BoundField DataField="CheckerLoginId" HeaderText="Checker" />
                            <asp:BoundField DataField="SubmittedOn" HeaderText="Submitted On" />
                            <asp:BoundField DataField="CheckedOn" HeaderText="Checked On" />
                            <asp:ButtonField Text="View Audit" CommandName="ViewHistory" ButtonType="Button" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
        </div>
    </form>
</body>
</html>
