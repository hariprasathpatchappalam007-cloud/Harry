USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[dbo].[DDA_BulkRequest]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[DDA_BulkRequest]
    (
        RequestId             INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        OperationCode         VARCHAR(10) NOT NULL,
        StatusCode            CHAR(1) NOT NULL DEFAULT 'P',
        MakerLoginId          NVARCHAR(100) NOT NULL,
        CheckerLoginId        NVARCHAR(100) NOT NULL,
        MakerRemarks          NVARCHAR(1000) NULL,
        CheckerRemarks        NVARCHAR(1000) NULL,
        SubmittedOn           DATETIME NOT NULL DEFAULT GETDATE(),
        CheckedOn             DATETIME NULL,
        SourceFileName        NVARCHAR(260) NOT NULL,
        SourceFileData        VARBINARY(MAX) NOT NULL,
        AttachmentFileName    NVARCHAR(260) NOT NULL,
        AttachmentContentType NVARCHAR(150) NOT NULL,
        AttachmentData        VARBINARY(MAX) NOT NULL,
        CONSTRAINT CK_DDA_BulkRequest_Operation CHECK (OperationCode IN ('CANCEL', 'REGISTER', 'DECLINE')),
        CONSTRAINT CK_DDA_BulkRequest_Status CHECK (StatusCode IN ('P', 'A', 'R'))
    )
END
GO

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('[dbo].[DDA_BulkRequest]') AND name = 'AttachmentFileName' AND is_nullable = 0)
    ALTER TABLE [dbo].[DDA_BulkRequest] ALTER COLUMN AttachmentFileName NVARCHAR(260) NULL
GO
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('[dbo].[DDA_BulkRequest]') AND name = 'AttachmentContentType' AND is_nullable = 0)
    ALTER TABLE [dbo].[DDA_BulkRequest] ALTER COLUMN AttachmentContentType NVARCHAR(150) NULL
GO
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('[dbo].[DDA_BulkRequest]') AND name = 'AttachmentData' AND is_nullable = 0)
    ALTER TABLE [dbo].[DDA_BulkRequest] ALTER COLUMN AttachmentData VARBINARY(MAX) NULL
GO

IF OBJECT_ID('[dbo].[DDA_BulkRequestDetail]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[DDA_BulkRequestDetail]
    (
        DetailId          INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        RequestId         INT NOT NULL,
        InputRowNo        INT NOT NULL,
        TargetTable       NVARCHAR(100) NOT NULL,
        MatchBy           NVARCHAR(30) NULL,
        ApplicationId     NVARCHAR(200) NULL,
        RefNbr             NVARCHAR(200) NULL,
        DdaRefNo           NVARCHAR(200) NULL,
        InternalRef        NVARCHAR(200) NULL,
        CurrentStatus      NVARCHAR(100) NULL,
        ProposedStatus     NVARCHAR(100) NULL,
        ProposedDdaRefNo   NVARCHAR(200) NULL,
        CONSTRAINT FK_DDA_BulkRequestDetail_Request FOREIGN KEY (RequestId) REFERENCES [dbo].[DDA_BulkRequest](RequestId)
    )
END
GO

IF OBJECT_ID('[dbo].[DDA_BulkAudit]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[DDA_BulkAudit]
    (
        AuditId        INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        RequestId      INT NOT NULL,
        DetailId       INT NULL,
        ActionName     NVARCHAR(50) NOT NULL,
        ActionBy       NVARCHAR(100) NOT NULL,
        ActionOn       DATETIME NOT NULL DEFAULT GETDATE(),
        TargetTable    NVARCHAR(100) NULL,
        ApplicationId  NVARCHAR(200) NULL,
        RefNbr         NVARCHAR(200) NULL,
        DdaRefNo       NVARCHAR(200) NULL,
        OldStatus      NVARCHAR(100) NULL,
        NewStatus      NVARCHAR(100) NULL,
        OldDdaRefNo    NVARCHAR(200) NULL,
        NewDdaRefNo    NVARCHAR(200) NULL,
        Remarks        NVARCHAR(1000) NULL,
        CONSTRAINT FK_DDA_BulkAudit_Request FOREIGN KEY (RequestId) REFERENCES [dbo].[DDA_BulkRequest](RequestId)
    )
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID('[dbo].[DDA_BulkRequest]') AND name = 'IX_DDA_BulkRequest_Checker_Status')
    CREATE INDEX IX_DDA_BulkRequest_Checker_Status ON [dbo].[DDA_BulkRequest](CheckerLoginId, StatusCode, SubmittedOn)
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID('[dbo].[DDA_BulkRequestDetail]') AND name = 'IX_DDA_BulkRequestDetail_Request')
    CREATE INDEX IX_DDA_BulkRequestDetail_Request ON [dbo].[DDA_BulkRequestDetail](RequestId, DetailId)
GO

IF OBJECT_ID('[dbo].[Proc_DDA_BulkGetUsers]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDA_BulkGetUsers]
GO
CREATE PROCEDURE [dbo].[Proc_DDA_BulkGetUsers]
AS
BEGIN
    SET NOCOUNT ON

    SELECT DISTINCT u.LoginId
    FROM [dbo].[FRM_user] u
    INNER JOIN [dbo].[DDP_UserAccess] a ON a.LoginId = u.LoginId
    WHERE ISNULL(u.LoginId, '') <> ''
      AND a.CanCheck = 1
      AND a.IsActive = 1
    ORDER BY u.LoginId
END
GO

IF OBJECT_ID('[dbo].[Proc_DDA_BulkPreview]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDA_BulkPreview]
GO
CREATE PROCEDURE [dbo].[Proc_DDA_BulkPreview]
    @OperationCode VARCHAR(10),
    @RowsXml       XML
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @Input TABLE
    (
        InputRowNo    INT NOT NULL PRIMARY KEY,
        ApplicationId NVARCHAR(200) NULL,
        RefNbr        NVARCHAR(200) NULL,
        DdaRefNo      NVARCHAR(200) NULL,
        InternalRef   NVARCHAR(200) NULL,
        SourceStatus  NVARCHAR(100) NULL
    )

    INSERT INTO @Input (InputRowNo, ApplicationId, RefNbr, DdaRefNo, InternalRef, SourceStatus)
    SELECT
        R.value('@RowNo[1]', 'INT'),
        NULL,
        NULLIF(R.value('@REF_NBR[1]', 'NVARCHAR(200)'), ''),
        NULLIF(R.value('@DDA_REF_NO[1]', 'NVARCHAR(200)'), ''),
        NULLIF(R.value('@DDS_INTERNAL_REF[1]', 'NVARCHAR(200)'), ''),
        NULLIF(R.value('@STATUS[1]', 'NVARCHAR(100)'), '')
    FROM @RowsXml.nodes('/Rows/Row') AS X(R)

    IF @OperationCode NOT IN ('CANCEL', 'REGISTER', 'DECLINE') OR NOT EXISTS (SELECT 1 FROM @Input)
    BEGIN
        RAISERROR('A supported operation and at least one source row are required.', 16, 1)
        RETURN
    END
    IF EXISTS (SELECT 1 FROM @Input WHERE (RefNbr IS NULL AND InternalRef IS NULL) OR SourceStatus IS NULL)
    BEGIN
        RAISERROR('Every CSV row must include a reference number and target status.', 16, 1)
        RETURN
    END
    IF EXISTS (
        SELECT 1 FROM @Input
        WHERE (@OperationCode = 'CANCEL' AND SourceStatus NOT IN ('Cancelled', 'Sent to DIB', 'Declined by CB', 'Rejected'))
           OR (@OperationCode = 'REGISTER' AND SourceStatus NOT IN ('Active', 'Declined by CB', 'Rejected'))
           OR (@OperationCode = 'DECLINE' AND SourceStatus NOT IN ('Declined by CB', 'Rejected'))
           OR (@OperationCode = 'REGISTER' AND SourceStatus = 'Active' AND DdaRefNo IS NULL)
           OR (@OperationCode = 'DECLINE' AND DdaRefNo IS NOT NULL)
    )
    BEGIN
        RAISERROR('A CSV row has a status or DDA reference that is invalid for the selected operation.', 16, 1)
        RETURN
    END

    CREATE TABLE #Matches
    (
        InputRowNo        INT NOT NULL,
        TargetTable       NVARCHAR(100) NOT NULL,
        MatchBy           NVARCHAR(30) NULL,
        ApplicationId     NVARCHAR(200) NULL,
        RefNbr            NVARCHAR(200) NULL,
        DdaRefNo          NVARCHAR(200) NULL,
        InternalRef       NVARCHAR(200) NULL,
        CurrentStatus     NVARCHAR(100) NULL,
        ProposedStatus    NVARCHAR(100) NULL,
        ProposedDdaRefNo  NVARCHAR(200) NULL
    )

    IF @OperationCode = 'CANCEL'
    BEGIN
        INSERT INTO #Matches
        SELECT i.InputRowNo, 'CORE_DDA_CANCELLATION_DETAILS',
               CASE WHEN i.RefNbr IS NOT NULL AND i.InternalRef IS NOT NULL THEN 'BOTH'
                    WHEN i.RefNbr IS NOT NULL THEN 'REF_NBR' ELSE 'DDS_INTERNAL_REF' END,
               CONVERT(NVARCHAR(200), d.APPLICATIONID), CONVERT(NVARCHAR(200), d.REF_NBR),
               CONVERT(NVARCHAR(200), d.DDA_REF_NO), CONVERT(NVARCHAR(200), d.DDS_INTERNAL_REF),
               CONVERT(NVARCHAR(100), d.CANCELLATION_STATUS), i.SourceStatus, CONVERT(NVARCHAR(200), d.DDA_REF_NO)
        FROM @Input i
        INNER JOIN [dbo].[CORE_DDA_CANCELLATION_DETAILS] d
            ON (i.RefNbr IS NULL OR CONVERT(NVARCHAR(200), d.REF_NBR) = i.RefNbr)
           AND (i.InternalRef IS NULL OR CONVERT(NVARCHAR(200), d.DDS_INTERNAL_REF) = i.InternalRef)

        INSERT INTO #Matches
        SELECT m.InputRowNo, 'CORE_DDA_REGISTRATION_DETAILS', NULL,
               CONVERT(NVARCHAR(200), d.APPLICATIONID), CONVERT(NVARCHAR(200), d.REF_NBR),
               CONVERT(NVARCHAR(200), d.DDA_REF_NO), CONVERT(NVARCHAR(200), d.DDS_INTERNAL_REF),
               CONVERT(NVARCHAR(100), d.DDS_STATUS), 'CANCELLED', CONVERT(NVARCHAR(200), d.DDA_REF_NO)
        FROM #Matches m
        INNER JOIN [dbo].[CORE_DDA_REGISTRATION_DETAILS] d
            ON CONVERT(NVARCHAR(200), d.DDA_REF_NO) = m.DdaRefNo
        WHERE m.TargetTable = 'CORE_DDA_CANCELLATION_DETAILS'
          AND m.ProposedStatus = 'Cancelled'
          AND m.DdaRefNo IS NOT NULL

        INSERT INTO #Matches
        SELECT m.InputRowNo, 'CORE_FLEX_DDA_REGISTRATION_DETAILS', NULL,
               CONVERT(NVARCHAR(200), d.APPLICATIONID), CONVERT(NVARCHAR(200), d.REF_NBR),
               CONVERT(NVARCHAR(200), d.DDA_REF_NO), NULL,
               CONVERT(NVARCHAR(100), d.DDS_STATUS), 'CANCELLED', CONVERT(NVARCHAR(200), d.DDA_REF_NO)
        FROM #Matches m
        INNER JOIN [dbo].[CORE_FLEX_DDA_REGISTRATION_DETAILS] d
            ON CONVERT(NVARCHAR(200), d.DDA_REF_NO) = m.DdaRefNo
        WHERE m.TargetTable = 'CORE_DDA_CANCELLATION_DETAILS'
          AND m.ProposedStatus = 'Cancelled'
          AND m.DdaRefNo IS NOT NULL
    END

    IF @OperationCode = 'REGISTER'
    BEGIN
        INSERT INTO #Matches
        SELECT i.InputRowNo, 'CORE_DDA_REGISTRATION_DETAILS',
               CASE WHEN i.RefNbr IS NOT NULL AND i.InternalRef IS NOT NULL THEN 'BOTH'
                    WHEN i.InternalRef IS NOT NULL THEN 'DDS_INTERNAL_REF' ELSE 'REF_NBR' END,
               CONVERT(NVARCHAR(200), d.APPLICATIONID), CONVERT(NVARCHAR(200), d.REF_NBR),
               CONVERT(NVARCHAR(200), d.DDA_REF_NO), CONVERT(NVARCHAR(200), d.DDS_INTERNAL_REF),
               CONVERT(NVARCHAR(100), d.DDS_STATUS), i.SourceStatus,
               CASE WHEN i.SourceStatus = 'Active' THEN i.DdaRefNo ELSE CONVERT(NVARCHAR(200), d.DDA_REF_NO) END
        FROM @Input i
        INNER JOIN [dbo].[CORE_DDA_REGISTRATION_DETAILS] d
            ON (i.RefNbr IS NULL OR CONVERT(NVARCHAR(200), d.REF_NBR) = i.RefNbr)
           AND (i.InternalRef IS NULL OR CONVERT(NVARCHAR(200), d.DDS_INTERNAL_REF) = i.InternalRef)
    END

    IF @OperationCode = 'DECLINE'
    BEGIN
        INSERT INTO #Matches
        SELECT i.InputRowNo, 'CORE_DDA_REGISTRATION_DETAILS',
               CASE WHEN i.RefNbr IS NOT NULL AND i.InternalRef IS NOT NULL THEN 'BOTH'
                    WHEN i.RefNbr IS NOT NULL THEN 'REF_NBR' ELSE 'DDS_INTERNAL_REF' END,
               CONVERT(NVARCHAR(200), d.APPLICATIONID), CONVERT(NVARCHAR(200), d.REF_NBR),
               CONVERT(NVARCHAR(200), d.DDA_REF_NO), CONVERT(NVARCHAR(200), d.DDS_INTERNAL_REF),
               CONVERT(NVARCHAR(100), d.DDS_STATUS), i.SourceStatus, CONVERT(NVARCHAR(200), d.DDA_REF_NO)
        FROM @Input i
        INNER JOIN [dbo].[CORE_DDA_REGISTRATION_DETAILS] d
            ON (i.RefNbr IS NULL OR CONVERT(NVARCHAR(200), d.REF_NBR) = i.RefNbr)
           AND (i.InternalRef IS NULL OR CONVERT(NVARCHAR(200), d.DDS_INTERNAL_REF) = i.InternalRef)

        INSERT INTO #Matches
        SELECT i.InputRowNo, 'CORE_DDA_CANCELLATION_DETAILS',
               CASE WHEN i.RefNbr IS NOT NULL AND i.InternalRef IS NOT NULL THEN 'BOTH'
                    WHEN i.RefNbr IS NOT NULL THEN 'REF_NBR' ELSE 'DDS_INTERNAL_REF' END,
               CONVERT(NVARCHAR(200), d.APPLICATIONID), CONVERT(NVARCHAR(200), d.REF_NBR),
               CONVERT(NVARCHAR(200), d.DDA_REF_NO), CONVERT(NVARCHAR(200), d.DDS_INTERNAL_REF),
               CONVERT(NVARCHAR(100), d.CANCELLATION_STATUS), i.SourceStatus, CONVERT(NVARCHAR(200), d.DDA_REF_NO)
        FROM @Input i
        INNER JOIN [dbo].[CORE_DDA_CANCELLATION_DETAILS] d
            ON (i.RefNbr IS NULL OR CONVERT(NVARCHAR(200), d.REF_NBR) = i.RefNbr)
           AND (i.InternalRef IS NULL OR CONVERT(NVARCHAR(200), d.DDS_INTERNAL_REF) = i.InternalRef)
    END

    SELECT i.InputRowNo, CAST(NULL AS NVARCHAR(100)) AS TargetTable,
           i.ApplicationId, i.RefNbr, i.DdaRefNo, i.InternalRef,
           CAST(NULL AS NVARCHAR(100)) AS CurrentStatus,
           CAST(NULL AS NVARCHAR(100)) AS ProposedStatus,
           CAST(NULL AS NVARCHAR(200)) AS ProposedDdaRefNo,
           CAST(NULL AS NVARCHAR(30)) AS MatchBy,
           CAST('Not found' AS NVARCHAR(20)) AS MatchStatus
    FROM @Input i
    WHERE NOT EXISTS (SELECT 1 FROM #Matches m WHERE m.InputRowNo = i.InputRowNo)

    UNION ALL

    SELECT m.InputRowNo, m.TargetTable, m.ApplicationId, m.RefNbr, m.DdaRefNo, m.InternalRef,
           m.CurrentStatus, m.ProposedStatus, m.ProposedDdaRefNo, m.MatchBy,
           CASE
               WHEN @OperationCode = 'REGISTER'
                    AND (SELECT COUNT(1) FROM #Matches m2 WHERE m2.InputRowNo = m.InputRowNo) > 1
                    THEN 'Ambiguous'
               WHEN (SELECT COUNT(1)
                     FROM #Matches m2
                     WHERE m2.InputRowNo = m.InputRowNo
                       AND m2.TargetTable = m.TargetTable
                       AND ISNULL(m2.ApplicationId, '') = ISNULL(m.ApplicationId, '')
                       AND ISNULL(m2.RefNbr, '') = ISNULL(m.RefNbr, '')
                       AND ISNULL(m2.DdaRefNo, '') = ISNULL(m.DdaRefNo, '')) > 1
                    THEN 'Ambiguous'
               ELSE 'Ready'
           END AS MatchStatus
    FROM #Matches m
    ORDER BY InputRowNo, TargetTable, ApplicationId
END
GO

IF OBJECT_ID('[dbo].[Proc_DDA_BulkSubmit]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDA_BulkSubmit]
GO
CREATE PROCEDURE [dbo].[Proc_DDA_BulkSubmit]
    @OperationCode         VARCHAR(10),
    @MakerLoginId          NVARCHAR(100),
    @CheckerLoginId        NVARCHAR(100),
    @MakerRemarks          NVARCHAR(1000) = NULL,
    @SourceFileName        NVARCHAR(260),
    @SourceFileData        VARBINARY(MAX),
    @AttachmentFileName    NVARCHAR(260),
    @AttachmentContentType NVARCHAR(150),
    @AttachmentData        VARBINARY(MAX),
    @DetailsXml            XML,
    @RequestId             INT OUTPUT,
    @Status                NVARCHAR(50) OUTPUT,
    @Message               NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    BEGIN TRY
        IF @OperationCode NOT IN ('CANCEL', 'REGISTER', 'DECLINE')
            RAISERROR('The selected DDA operation is invalid.', 16, 1)
        IF ISNULL(LTRIM(RTRIM(@MakerLoginId)), '') = '' OR ISNULL(LTRIM(RTRIM(@CheckerLoginId)), '') = ''
            RAISERROR('Maker and checker login IDs are required.', 16, 1)
        IF @MakerLoginId = @CheckerLoginId
            RAISERROR('The maker cannot be the checker for the same request.', 16, 1)
        IF ISNULL(DATALENGTH(@SourceFileData), 0) = 0
            RAISERROR('The source CSV is required.', 16, 1)
        IF NOT EXISTS (
            SELECT 1 FROM [dbo].[DDP_UserAccess]
            WHERE LoginId = @CheckerLoginId AND CanCheck = 1 AND IsActive = 1
        )
            RAISERROR('The selected checker is not active or is not enabled for checking.', 16, 1)
        IF EXISTS (
            SELECT 1
            FROM @DetailsXml.nodes('/Details/Detail') AS X(D)
            WHERE D.value('@TargetTable[1]', 'NVARCHAR(100)') NOT IN
                ('CORE_DDA_REGISTRATION_DETAILS', 'CORE_DDA_CANCELLATION_DETAILS',
                 'CORE_FLEX_DDA_REGISTRATION_DETAILS', 'CORE_FLEX_DDA_CANCELLATION_DETAILS')
        )
            RAISERROR('The request contains an unsupported DDA target table.', 16, 1)
        IF @OperationCode = 'REGISTER' AND EXISTS (
            SELECT 1
            FROM @DetailsXml.nodes('/Details/Detail') AS X(D)
            WHERE D.value('@TargetTable[1]', 'NVARCHAR(100)') <> 'CORE_DDA_REGISTRATION_DETAILS'
               OR D.value('@MatchBy[1]', 'NVARCHAR(30)') NOT IN ('DDS_INTERNAL_REF', 'REF_NBR', 'BOTH')
        )
            RAISERROR('Registration details do not match the permitted target.', 16, 1)
        IF @OperationCode = 'DECLINE' AND EXISTS (
            SELECT 1
            FROM @DetailsXml.nodes('/Details/Detail') AS X(D)
            WHERE D.value('@TargetTable[1]', 'NVARCHAR(100)') NOT IN
                ('CORE_DDA_REGISTRATION_DETAILS', 'CORE_DDA_CANCELLATION_DETAILS')
        )
            RAISERROR('Decline details do not match the permitted target.', 16, 1)
        IF (@OperationCode = 'CANCEL' AND EXISTS (
            SELECT 1
            FROM @DetailsXml.nodes('/Details/Detail') AS X(D)
            WHERE D.value('@TargetTable[1]', 'NVARCHAR(100)') NOT IN
                    ('CORE_DDA_CANCELLATION_DETAILS', 'CORE_DDA_REGISTRATION_DETAILS', 'CORE_FLEX_DDA_REGISTRATION_DETAILS')
               OR (D.value('@TargetTable[1]', 'NVARCHAR(100)') = 'CORE_DDA_CANCELLATION_DETAILS'
                   AND D.value('@ProposedStatus[1]', 'NVARCHAR(100)') NOT IN ('Cancelled', 'Sent to DIB', 'Declined by CB', 'Rejected'))
               OR (D.value('@TargetTable[1]', 'NVARCHAR(100)') IN ('CORE_DDA_REGISTRATION_DETAILS', 'CORE_FLEX_DDA_REGISTRATION_DETAILS')
                   AND (D.value('@ProposedStatus[1]', 'NVARCHAR(100)') <> 'CANCELLED'
                     OR NOT EXISTS (
                         SELECT 1
                         FROM @DetailsXml.nodes('/Details/Detail') AS P(P)
                         WHERE P.value('@InputRowNo[1]', 'INT') = D.value('@InputRowNo[1]', 'INT')
                           AND P.value('@TargetTable[1]', 'NVARCHAR(100)') = 'CORE_DDA_CANCELLATION_DETAILS'
                           AND P.value('@ProposedStatus[1]', 'NVARCHAR(100)') = 'Cancelled'
                     )))
        ))
            RAISERROR('Cancellation target status does not match the selected source status.', 16, 1)
        IF EXISTS (
            SELECT 1
            FROM @DetailsXml.nodes('/Details/Detail') AS X(D)
            WHERE D.value('@InternalRef[1]', 'NVARCHAR(200)') = ''
              AND D.value('@RefNbr[1]', 'NVARCHAR(200)') = ''
              AND D.value('@DdaRefNo[1]', 'NVARCHAR(200)') = ''
               OR D.value('@ProposedStatus[1]', 'NVARCHAR(100)') = ''
        )
            RAISERROR('Every selected target record requires a reference and status.', 16, 1)
        IF @OperationCode = 'REGISTER' AND EXISTS (
            SELECT 1
            FROM @DetailsXml.nodes('/Details/Detail') AS X(D)
            WHERE (D.value('@ProposedStatus[1]', 'NVARCHAR(100)') = 'Active'
                   AND D.value('@ProposedDdaRefNo[1]', 'NVARCHAR(200)') = '')
               OR D.value('@ProposedStatus[1]', 'NVARCHAR(100)') NOT IN ('Active', 'Declined by CB', 'Rejected')
        )
            RAISERROR('Registration status must be Active, Declined by CB, or Rejected; Active requires a DDA reference.', 16, 1)
        IF @OperationCode = 'DECLINE' AND EXISTS (
            SELECT 1
            FROM @DetailsXml.nodes('/Details/Detail') AS X(D)
            WHERE D.value('@ProposedStatus[1]', 'NVARCHAR(100)') NOT IN ('Declined by CB', 'Rejected')
        )
            RAISERROR('Decline status must be Declined by CB or Rejected.', 16, 1)
        BEGIN TRANSACTION
        INSERT INTO [dbo].[DDA_BulkRequest]
            (OperationCode, MakerLoginId, CheckerLoginId, MakerRemarks, SourceFileName, SourceFileData,
             AttachmentFileName, AttachmentContentType, AttachmentData)
        VALUES
            (@OperationCode, @MakerLoginId, @CheckerLoginId, @MakerRemarks, @SourceFileName, @SourceFileData,
             @AttachmentFileName, @AttachmentContentType, @AttachmentData)

        SET @RequestId = SCOPE_IDENTITY()

        INSERT INTO [dbo].[DDA_BulkRequestDetail]
            (RequestId, InputRowNo, TargetTable, MatchBy, ApplicationId, RefNbr, DdaRefNo, InternalRef,
             CurrentStatus, ProposedStatus, ProposedDdaRefNo)
        SELECT @RequestId,
               D.value('@InputRowNo[1]', 'INT'),
               D.value('@TargetTable[1]', 'NVARCHAR(100)'),
               NULLIF(D.value('@MatchBy[1]', 'NVARCHAR(30)'), ''),
               NULLIF(D.value('@ApplicationId[1]', 'NVARCHAR(200)'), ''),
               NULLIF(D.value('@RefNbr[1]', 'NVARCHAR(200)'), ''),
               NULLIF(D.value('@DdaRefNo[1]', 'NVARCHAR(200)'), ''),
               NULLIF(D.value('@InternalRef[1]', 'NVARCHAR(200)'), ''),
               NULLIF(D.value('@CurrentStatus[1]', 'NVARCHAR(100)'), ''),
               NULLIF(D.value('@ProposedStatus[1]', 'NVARCHAR(100)'), ''),
               NULLIF(D.value('@ProposedDdaRefNo[1]', 'NVARCHAR(200)'), '')
        FROM @DetailsXml.nodes('/Details/Detail') AS X(D)

        IF @@ROWCOUNT = 0
        BEGIN
            ROLLBACK TRANSACTION
            SET @RequestId = 0
            SET @Status = 'FAILURE'
            SET @Message = 'The request has no matched DDA records.'
            RETURN
        END

        INSERT INTO [dbo].[DDA_BulkAudit](RequestId, ActionName, ActionBy, Remarks)
        VALUES(@RequestId, 'SUBMITTED', @MakerLoginId, @MakerRemarks)

        COMMIT TRANSACTION
        SET @Status = 'SUCCESS'
        SET @Message = 'DDA bulk request submitted to the selected checker.'
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
        SET @RequestId = 0
        SET @Status = 'FAILURE'
        SET @Message = LEFT(ERROR_MESSAGE(), 500)
    END CATCH
END
GO

IF OBJECT_ID('[dbo].[Proc_DDA_BulkGetRequests]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDA_BulkGetRequests]
GO
CREATE PROCEDURE [dbo].[Proc_DDA_BulkGetRequests]
    @LoginId NVARCHAR(100),
    @Mode    NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON

    SELECT r.RequestId, r.OperationCode,
           CASE r.OperationCode WHEN 'CANCEL' THEN 'DDA Cancellation'
                                WHEN 'REGISTER' THEN 'DDA Registration Status'
                                WHEN 'DECLINE' THEN 'DDA Decline / Rejection'
                                ELSE r.OperationCode END AS OperationName,
           r.MakerLoginId, r.CheckerLoginId,
           CASE r.StatusCode WHEN 'P' THEN 'Pending with ' + r.CheckerLoginId
                             WHEN 'A' THEN 'Approved'
                             WHEN 'R' THEN 'Rejected'
                             ELSE r.StatusCode END AS StatusDesc,
           r.MakerRemarks, r.CheckerRemarks, r.SubmittedOn, r.CheckedOn,
           r.SourceFileName, r.AttachmentFileName,
           (SELECT COUNT(1) FROM [dbo].[DDA_BulkRequestDetail] d WHERE d.RequestId = r.RequestId) AS RecordCount
    FROM [dbo].[DDA_BulkRequest] r
    WHERE (@Mode = 'CHECKER' AND r.CheckerLoginId = @LoginId AND r.StatusCode = 'P')
       OR (@Mode = 'MAKER' AND r.MakerLoginId = @LoginId)
       OR (@Mode = 'ALL' AND (r.MakerLoginId = @LoginId OR r.CheckerLoginId = @LoginId))
    ORDER BY r.SubmittedOn DESC
END
GO

IF OBJECT_ID('[dbo].[Proc_DDA_BulkGetDetails]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDA_BulkGetDetails]
GO
CREATE PROCEDURE [dbo].[Proc_DDA_BulkGetDetails]
    @RequestId INT,
    @LoginId   NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON

    SELECT d.InputRowNo, d.TargetTable, d.MatchBy, d.ApplicationId, d.RefNbr,
           d.DdaRefNo AS OldDdaRefNo, d.ProposedDdaRefNo AS NewDdaRefNo,
           d.InternalRef, d.CurrentStatus AS OldStatus, d.ProposedStatus AS NewStatus
    FROM [dbo].[DDA_BulkRequestDetail] d
    INNER JOIN [dbo].[DDA_BulkRequest] r ON r.RequestId = d.RequestId
    WHERE d.RequestId = @RequestId
      AND (r.MakerLoginId = @LoginId OR r.CheckerLoginId = @LoginId)
    ORDER BY d.InputRowNo, d.TargetTable, d.DetailId
END
GO

IF OBJECT_ID('[dbo].[Proc_DDA_BulkGetAudit]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDA_BulkGetAudit]
GO
CREATE PROCEDURE [dbo].[Proc_DDA_BulkGetAudit]
    @RequestId INT,
    @LoginId   NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON

    SELECT a.AuditId, a.ActionName, a.ActionBy, a.ActionOn, a.TargetTable,
           a.ApplicationId, a.RefNbr, a.DdaRefNo, a.OldStatus, a.NewStatus,
           a.OldDdaRefNo, a.NewDdaRefNo, a.Remarks
    FROM [dbo].[DDA_BulkAudit] a
    INNER JOIN [dbo].[DDA_BulkRequest] r ON r.RequestId = a.RequestId
    WHERE a.RequestId = @RequestId
      AND (r.MakerLoginId = @LoginId OR r.CheckerLoginId = @LoginId)
    ORDER BY a.AuditId
END
GO

IF OBJECT_ID('[dbo].[Proc_DDA_BulkGetFile]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDA_BulkGetFile]
GO
CREATE PROCEDURE [dbo].[Proc_DDA_BulkGetFile]
    @RequestId INT,
    @LoginId   NVARCHAR(100),
    @FileType  VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON

    SELECT CASE @FileType WHEN 'SOURCE' THEN r.SourceFileName ELSE r.AttachmentFileName END AS FileName,
           CASE @FileType WHEN 'SOURCE' THEN 'text/csv' ELSE r.AttachmentContentType END AS ContentType,
           CASE @FileType WHEN 'SOURCE' THEN r.SourceFileData ELSE r.AttachmentData END AS FileData
    FROM [dbo].[DDA_BulkRequest] r
    WHERE r.RequestId = @RequestId
      AND @FileType IN ('SOURCE', 'ATTACHMENT')
      AND (r.MakerLoginId = @LoginId OR r.CheckerLoginId = @LoginId)
END
GO

IF OBJECT_ID('[dbo].[Proc_DDA_BulkCheck]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDA_BulkCheck]
GO
CREATE PROCEDURE [dbo].[Proc_DDA_BulkCheck]
    @RequestId      INT,
    @CheckerLoginId NVARCHAR(100),
    @Decision       CHAR(1),
    @Remarks        NVARCHAR(1000) = NULL,
    @Status         NVARCHAR(50) OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @OperationCode VARCHAR(10), @AssignedChecker NVARCHAR(100), @CurrentStatus CHAR(1),
            @MakerLoginId NVARCHAR(100), @DetailId INT, @InputRowNo INT, @TargetTable NVARCHAR(100),
            @MatchBy NVARCHAR(30), @ApplicationId NVARCHAR(200), @RefNbr NVARCHAR(200),
            @DdaRefNo NVARCHAR(200), @InternalRef NVARCHAR(200), @OldStatus NVARCHAR(100),
            @NewStatus NVARCHAR(100), @NewDdaRefNo NVARCHAR(200), @RowsAffected INT

    BEGIN TRY
        BEGIN TRANSACTION

        SELECT @OperationCode = OperationCode, @AssignedChecker = CheckerLoginId,
               @CurrentStatus = StatusCode, @MakerLoginId = MakerLoginId
        FROM [dbo].[DDA_BulkRequest] WITH (UPDLOCK, HOLDLOCK)
        WHERE RequestId = @RequestId

        IF @OperationCode IS NULL
        BEGIN
            ROLLBACK TRANSACTION
            SET @Status = 'FAILURE'
            SET @Message = 'Request was not found.'
            RETURN
        END
        IF @AssignedChecker <> @CheckerLoginId
        BEGIN
            ROLLBACK TRANSACTION
            SET @Status = 'FAILURE'
            SET @Message = 'This request is assigned to a different checker.'
            RETURN
        END
        IF @CurrentStatus <> 'P'
        BEGIN
            ROLLBACK TRANSACTION
            SET @Status = 'FAILURE'
            SET @Message = 'This request has already been checked.'
            RETURN
        END
        IF @Decision NOT IN ('A', 'R')
        BEGIN
            ROLLBACK TRANSACTION
            SET @Status = 'FAILURE'
            SET @Message = 'Select approve or reject.'
            RETURN
        END
        IF @Decision = 'R' AND ISNULL(LTRIM(RTRIM(@Remarks)), '') = ''
        BEGIN
            ROLLBACK TRANSACTION
            SET @Status = 'FAILURE'
            SET @Message = 'Checker remarks are required for rejection.'
            RETURN
        END

        IF @Decision = 'A'
        BEGIN
            DECLARE detail_cursor CURSOR LOCAL FAST_FORWARD FOR
                SELECT DetailId, InputRowNo, TargetTable, MatchBy, ApplicationId, RefNbr,
                       DdaRefNo, InternalRef, CurrentStatus, ProposedStatus, ProposedDdaRefNo
                FROM [dbo].[DDA_BulkRequestDetail]
                WHERE RequestId = @RequestId
                ORDER BY DetailId

            OPEN detail_cursor
            FETCH NEXT FROM detail_cursor INTO @DetailId, @InputRowNo, @TargetTable, @MatchBy,
                @ApplicationId, @RefNbr, @DdaRefNo, @InternalRef, @OldStatus, @NewStatus, @NewDdaRefNo

            WHILE @@FETCH_STATUS = 0
            BEGIN
                SET @RowsAffected = 0

                IF @OperationCode = 'REGISTER' AND @TargetTable = 'CORE_DDA_REGISTRATION_DETAILS'
                BEGIN
                    UPDATE [dbo].[CORE_DDA_REGISTRATION_DETAILS]
                    SET DDS_STATUS = @NewStatus,
                        DDA_REF_NO = CASE WHEN @NewStatus = 'Active' THEN @NewDdaRefNo ELSE DDA_REF_NO END
                    WHERE CONVERT(NVARCHAR(200), APPLICATIONID) = @ApplicationId
                      AND CONVERT(NVARCHAR(100), DDS_STATUS) = @OldStatus
                      AND ISNULL(CONVERT(NVARCHAR(200), DDA_REF_NO), '') = ISNULL(@DdaRefNo, '')
                      AND ((@MatchBy = 'DDS_INTERNAL_REF' AND CONVERT(NVARCHAR(200), DDS_INTERNAL_REF) = @InternalRef)
                        OR (@MatchBy = 'REF_NBR' AND CONVERT(NVARCHAR(200), REF_NBR) = @RefNbr)
                        OR (@MatchBy = 'BOTH' AND CONVERT(NVARCHAR(200), DDS_INTERNAL_REF) = @InternalRef
                            AND CONVERT(NVARCHAR(200), REF_NBR) = @RefNbr))
                    SET @RowsAffected = @@ROWCOUNT
                END
                ELSE IF @OperationCode = 'CANCEL' AND @TargetTable = 'CORE_DDA_REGISTRATION_DETAILS'
                BEGIN
                    UPDATE [dbo].[CORE_DDA_REGISTRATION_DETAILS]
                    SET DDS_STATUS = @NewStatus
                    WHERE CONVERT(NVARCHAR(200), DDA_REF_NO) = @DdaRefNo
                      AND ISNULL(CONVERT(NVARCHAR(200), APPLICATIONID), '') = ISNULL(@ApplicationId, '')
                      AND ISNULL(CONVERT(NVARCHAR(200), REF_NBR), '') = ISNULL(@RefNbr, '')
                      AND ISNULL(CONVERT(NVARCHAR(100), DDS_STATUS), '') = ISNULL(@OldStatus, '')
                    SET @RowsAffected = @@ROWCOUNT
                END
                ELSE IF @OperationCode = 'CANCEL' AND @TargetTable = 'CORE_DDA_CANCELLATION_DETAILS'
                BEGIN
                    UPDATE [dbo].[CORE_DDA_CANCELLATION_DETAILS]
                    SET CANCELLATION_STATUS = @NewStatus
                    WHERE ISNULL(CONVERT(NVARCHAR(200), APPLICATIONID), '') = ISNULL(@ApplicationId, '')
                      AND ISNULL(CONVERT(NVARCHAR(200), DDA_REF_NO), '') = ISNULL(@DdaRefNo, '')
                      AND ((@MatchBy = 'REF_NBR' AND CONVERT(NVARCHAR(200), REF_NBR) = @RefNbr)
                        OR (@MatchBy = 'DDS_INTERNAL_REF' AND CONVERT(NVARCHAR(200), DDS_INTERNAL_REF) = @InternalRef)
                        OR (@MatchBy = 'BOTH' AND CONVERT(NVARCHAR(200), REF_NBR) = @RefNbr
                            AND CONVERT(NVARCHAR(200), DDS_INTERNAL_REF) = @InternalRef))
                      AND ISNULL(CONVERT(NVARCHAR(100), CANCELLATION_STATUS), '') = ISNULL(@OldStatus, '')
                    SET @RowsAffected = @@ROWCOUNT
                END
                ELSE IF @OperationCode = 'CANCEL' AND @TargetTable = 'CORE_FLEX_DDA_REGISTRATION_DETAILS'
                BEGIN
                    UPDATE [dbo].[CORE_FLEX_DDA_REGISTRATION_DETAILS]
                    SET DDS_STATUS = @NewStatus
                    WHERE ISNULL(CONVERT(NVARCHAR(200), APPLICATIONID), '') = ISNULL(@ApplicationId, '')
                      AND ISNULL(CONVERT(NVARCHAR(200), REF_NBR), '') = ISNULL(@RefNbr, '')
                      AND CONVERT(NVARCHAR(200), DDA_REF_NO) = @DdaRefNo
                      AND ISNULL(CONVERT(NVARCHAR(100), DDS_STATUS), '') = ISNULL(@OldStatus, '')
                    SET @RowsAffected = @@ROWCOUNT
                END
                ELSE IF @OperationCode = 'DECLINE' AND @TargetTable = 'CORE_DDA_REGISTRATION_DETAILS'
                BEGIN
                    UPDATE [dbo].[CORE_DDA_REGISTRATION_DETAILS]
                    SET DDS_STATUS = @NewStatus
                    WHERE CONVERT(NVARCHAR(200), APPLICATIONID) = @ApplicationId
                      AND ((@MatchBy = 'REF_NBR' AND CONVERT(NVARCHAR(200), REF_NBR) = @RefNbr)
                        OR (@MatchBy = 'DDS_INTERNAL_REF' AND CONVERT(NVARCHAR(200), DDS_INTERNAL_REF) = @InternalRef)
                        OR (@MatchBy = 'BOTH' AND CONVERT(NVARCHAR(200), REF_NBR) = @RefNbr
                            AND CONVERT(NVARCHAR(200), DDS_INTERNAL_REF) = @InternalRef))
                      AND CONVERT(NVARCHAR(100), DDS_STATUS) = @OldStatus
                    SET @RowsAffected = @@ROWCOUNT
                END
                ELSE IF @OperationCode = 'DECLINE' AND @TargetTable = 'CORE_DDA_CANCELLATION_DETAILS'
                BEGIN
                    UPDATE [dbo].[CORE_DDA_CANCELLATION_DETAILS]
                    SET CANCELLATION_STATUS = @NewStatus
                    WHERE CONVERT(NVARCHAR(200), APPLICATIONID) = @ApplicationId
                      AND ((@MatchBy = 'REF_NBR' AND CONVERT(NVARCHAR(200), REF_NBR) = @RefNbr)
                        OR (@MatchBy = 'DDS_INTERNAL_REF' AND CONVERT(NVARCHAR(200), DDS_INTERNAL_REF) = @InternalRef)
                        OR (@MatchBy = 'BOTH' AND CONVERT(NVARCHAR(200), REF_NBR) = @RefNbr
                            AND CONVERT(NVARCHAR(200), DDS_INTERNAL_REF) = @InternalRef))
                      AND CONVERT(NVARCHAR(100), CANCELLATION_STATUS) = @OldStatus
                    SET @RowsAffected = @@ROWCOUNT
                END

                IF @RowsAffected <> 1
                    RAISERROR('A DDA row changed or became ambiguous after preview. No updates were applied; reload and submit a new request.', 16, 1)

                INSERT INTO [dbo].[DDA_BulkAudit]
                    (RequestId, DetailId, ActionName, ActionBy, TargetTable, ApplicationId, RefNbr,
                     DdaRefNo, OldStatus, NewStatus, OldDdaRefNo, NewDdaRefNo, Remarks)
                VALUES
                    (@RequestId, @DetailId, 'UPDATE', @CheckerLoginId, @TargetTable, @ApplicationId, @RefNbr,
                     @DdaRefNo, @OldStatus, @NewStatus, @DdaRefNo, @NewDdaRefNo, @Remarks)

                FETCH NEXT FROM detail_cursor INTO @DetailId, @InputRowNo, @TargetTable, @MatchBy,
                    @ApplicationId, @RefNbr, @DdaRefNo, @InternalRef, @OldStatus, @NewStatus, @NewDdaRefNo
            END

            CLOSE detail_cursor
            DEALLOCATE detail_cursor

            UPDATE [dbo].[DDA_BulkRequest]
            SET StatusCode = 'A', CheckerRemarks = @Remarks, CheckedOn = GETDATE()
            WHERE RequestId = @RequestId
            INSERT INTO [dbo].[DDA_BulkAudit](RequestId, ActionName, ActionBy, Remarks)
            VALUES(@RequestId, 'APPROVED', @CheckerLoginId, @Remarks)
        END
        ELSE
        BEGIN
            UPDATE [dbo].[DDA_BulkRequest]
            SET StatusCode = 'R', CheckerRemarks = @Remarks, CheckedOn = GETDATE()
            WHERE RequestId = @RequestId
            INSERT INTO [dbo].[DDA_BulkAudit](RequestId, ActionName, ActionBy, Remarks)
            VALUES(@RequestId, 'REJECTED', @CheckerLoginId, @Remarks)
        END

        COMMIT TRANSACTION
        SET @Status = 'SUCCESS'
        SET @Message = CASE @Decision WHEN 'A' THEN 'DDA bulk request approved and applied.' ELSE 'DDA bulk request rejected.' END
    END TRY
    BEGIN CATCH
        IF CURSOR_STATUS('local', 'detail_cursor') >= 0 CLOSE detail_cursor
        IF CURSOR_STATUS('local', 'detail_cursor') > -3 DEALLOCATE detail_cursor
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
        SET @Status = 'FAILURE'
        SET @Message = LEFT(ERROR_MESSAGE(), 500)
    END CATCH
END
GO
