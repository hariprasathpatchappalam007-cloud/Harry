-- Deploy in the selected DDA application database. SQL Server 2012+, compatibility 100.
-- Existing CSV maker/checker objects are not modified.
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET XACT_ABORT ON;
GO
IF OBJECT_ID(N'dbo.DDA_Movement_history', N'U') IS NULL
    THROW 51600, 'DDA application updates require the existing DDA_Movement_history table.', 1;

IF OBJECT_ID(N'dbo.DDA_ApplicationRequest', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DDA_ApplicationRequest
    (
        RequestId INT IDENTITY PRIMARY KEY,
        StatusCode CHAR(1) NOT NULL DEFAULT 'P' CHECK (StatusCode IN ('P','A','R')),
        MakerLoginId NVARCHAR(100) NOT NULL,
        CheckerLoginId NVARCHAR(100) NULL,
        MakerRemarks NVARCHAR(1000) NOT NULL,
        CheckerRemarks NVARCHAR(1000) NULL,
        SubmittedOn DATETIME2(7) NOT NULL DEFAULT SYSDATETIME(),
        CheckedOn DATETIME2(7) NULL,
        AttachmentName NVARCHAR(260) NULL,
        AttachmentType NVARCHAR(150) NULL,
        AttachmentData VARBINARY(MAX) NULL
    );
    CREATE INDEX IX_DDA_ApplicationRequest_Checker ON dbo.DDA_ApplicationRequest(CheckerLoginId, StatusCode);
END;
DECLARE @RequestCheckName SYSNAME;
DECLARE @DropRequestCheckSql NVARCHAR(4000);
SELECT TOP (1) @RequestCheckName = name
FROM sys.check_constraints
WHERE parent_object_id = OBJECT_ID(N'dbo.DDA_ApplicationRequest')
  AND definition LIKE N'%CheckerLoginId%';
IF @RequestCheckName IS NOT NULL
BEGIN
    SET @DropRequestCheckSql = N'ALTER TABLE dbo.DDA_ApplicationRequest DROP CONSTRAINT ' + QUOTENAME(@RequestCheckName);
    EXEC sys.sp_executesql @DropRequestCheckSql;
END;
IF EXISTS
(
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.DDA_ApplicationRequest')
      AND name = N'CheckerLoginId' AND is_nullable = 0
)
BEGIN
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.DDA_ApplicationRequest')
        AND name = N'IX_DDA_ApplicationRequest_Checker')
        DROP INDEX IX_DDA_ApplicationRequest_Checker ON dbo.DDA_ApplicationRequest;
    ALTER TABLE dbo.DDA_ApplicationRequest ALTER COLUMN CheckerLoginId NVARCHAR(100) NULL;
END;
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id = OBJECT_ID(N'dbo.DDA_ApplicationRequest')
      AND name = N'CK_DDA_ApplicationRequest_DistinctUsers')
    ALTER TABLE dbo.DDA_ApplicationRequest ADD CONSTRAINT CK_DDA_ApplicationRequest_DistinctUsers
        CHECK (CheckerLoginId IS NULL OR MakerLoginId <> CheckerLoginId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.DDA_ApplicationRequest')
    AND name = N'IX_DDA_ApplicationRequest_Checker')
    CREATE INDEX IX_DDA_ApplicationRequest_Checker ON dbo.DDA_ApplicationRequest(CheckerLoginId, StatusCode);
IF OBJECT_ID(N'dbo.DDA_ApplicationDetail', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DDA_ApplicationDetail
    (
        DetailId INT IDENTITY PRIMARY KEY,
        RequestId INT NOT NULL REFERENCES dbo.DDA_ApplicationRequest(RequestId),
        TargetCode CHAR(1) NOT NULL CHECK (TargetCode IN ('R','F','C')),
        ApplicationId NVARCHAR(200) NOT NULL,
        MatchBy VARCHAR(20) NOT NULL,
        MatchValue NVARCHAR(200) NOT NULL,
        RefNbr NVARCHAR(200) NULL,
        InternalRef NVARCHAR(200) NULL,
        OldDdaRefNo NVARCHAR(200) NULL,
        NewDdaRefNo NVARCHAR(200) NULL,
        OldStatus NVARCHAR(100) NULL,
        NewStatus NVARCHAR(100) NOT NULL,
        CONSTRAINT CK_DDA_ApplicationDetail_MatchKey
            CHECK ((TargetCode = 'R' AND MatchBy IN ('REF_NBR','DDS_INTERNAL_REF'))
                OR (TargetCode = 'F' AND MatchBy = 'REF_NBR')
                OR (TargetCode = 'C' AND MatchBy IN ('DDA_REF_NO','DDS_INTERNAL_REF')))
    );
    CREATE INDEX IX_DDA_ApplicationDetail_Request ON dbo.DDA_ApplicationDetail(RequestId, DetailId);
END;
DECLARE @LegacyMatchConstraint SYSNAME;
DECLARE @DropMatchConstraintSql NVARCHAR(500);
SELECT @LegacyMatchConstraint = name
FROM sys.check_constraints
WHERE parent_object_id = OBJECT_ID(N'dbo.DDA_ApplicationDetail')
  AND name <> N'CK_DDA_ApplicationDetail_MatchKey'
  AND definition LIKE N'%MatchBy%';
IF @LegacyMatchConstraint IS NOT NULL
BEGIN
    SET @DropMatchConstraintSql = N'ALTER TABLE dbo.DDA_ApplicationDetail DROP CONSTRAINT '
        + QUOTENAME(@LegacyMatchConstraint);
    EXEC sys.sp_executesql @DropMatchConstraintSql;
END;
IF NOT EXISTS
(
    SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id = OBJECT_ID(N'dbo.DDA_ApplicationDetail')
      AND name = N'CK_DDA_ApplicationDetail_MatchKey'
)
    ALTER TABLE dbo.DDA_ApplicationDetail ADD CONSTRAINT CK_DDA_ApplicationDetail_MatchKey
        CHECK ((TargetCode = 'R' AND MatchBy IN ('REF_NBR','DDS_INTERNAL_REF'))
            OR (TargetCode = 'F' AND MatchBy = 'REF_NBR')
            OR (TargetCode = 'C' AND MatchBy IN ('DDA_REF_NO','DDS_INTERNAL_REF')));
IF OBJECT_ID(N'dbo.DDA_ApplicationDetailSource', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DDA_ApplicationDetailSource
    (
        SourceSnapshotId BIGINT IDENTITY PRIMARY KEY,
        DetailId INT NOT NULL REFERENCES dbo.DDA_ApplicationDetail(DetailId),
        RefNbr NVARCHAR(200) NULL,
        InternalRef NVARCHAR(200) NULL,
        DdaRefNo NVARCHAR(200) NULL,
        OldStatus NVARCHAR(100) NULL
    );
    CREATE INDEX IX_DDA_ApplicationDetailSource_Detail
        ON dbo.DDA_ApplicationDetailSource(DetailId, SourceSnapshotId);
END;
INSERT dbo.DDA_ApplicationDetailSource (DetailId, RefNbr, InternalRef, DdaRefNo, OldStatus)
SELECT d.DetailId, d.RefNbr, d.InternalRef, d.OldDdaRefNo, d.OldStatus
FROM dbo.DDA_ApplicationDetail d
WHERE NOT EXISTS
(
    SELECT 1 FROM dbo.DDA_ApplicationDetailSource s WHERE s.DetailId = d.DetailId
);
IF OBJECT_ID(N'dbo.DDA_ApplicationAudit', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DDA_ApplicationAudit
    (
        AuditId BIGINT IDENTITY PRIMARY KEY,
        RequestId INT NOT NULL REFERENCES dbo.DDA_ApplicationRequest(RequestId),
        DetailId INT NULL REFERENCES dbo.DDA_ApplicationDetail(DetailId),
        ActionName VARCHAR(20) NOT NULL,
        ActionBy NVARCHAR(100) NOT NULL,
        ActionOn DATETIME2(7) NOT NULL DEFAULT SYSDATETIME(),
        OldStatus NVARCHAR(100) NULL,
        NewStatus NVARCHAR(100) NULL,
        OldDdaRefNo NVARCHAR(200) NULL,
        NewDdaRefNo NVARCHAR(200) NULL,
        Remarks NVARCHAR(1000) NULL
    );
    CREATE INDEX IX_DDA_ApplicationAudit_Request ON dbo.DDA_ApplicationAudit(RequestId, AuditId);
END;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationAccess', N'P') IS NOT NULL
    DROP PROCEDURE dbo.Proc_DDA_ApplicationAccess;
GO
-- Internal source reader. Do not grant direct application-user EXECUTE on this helper.
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationSource', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Proc_DDA_ApplicationSource AS RETURN;');
GO
ALTER PROCEDURE dbo.Proc_DDA_ApplicationSource
    @TargetCode CHAR(1), @ApplicationId NVARCHAR(200),
    @MatchBy VARCHAR(20) = NULL, @MatchValue NVARCHAR(200) = NULL, @LockRows BIT = 0
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Table SYSNAME, @Status SYSNAME, @Internal NVARCHAR(100), @Sql NVARCHAR(MAX);
    SELECT @Table = CASE @TargetCode WHEN 'R' THEN 'CORE_DDA_REGISTRATION_DETAILS'
        WHEN 'F' THEN 'CORE_FLEX_DDA_REGISTRATION_DETAILS' WHEN 'C' THEN 'CORE_DDA_CANCELLATION_DETAILS' END,
        @Status = CASE WHEN @TargetCode = 'C' THEN 'CANCELLATION_STATUS' ELSE 'DDS_STATUS' END,
        @Internal = CASE WHEN @TargetCode = 'F' THEN N'CAST(NULL AS NVARCHAR(200))' ELSE N'DDS_INTERNAL_REF' END;
    IF @Table IS NULL OR NULLIF(LTRIM(RTRIM(@ApplicationId)), N'') IS NULL
        THROW 51602, 'Select a DDA table and enter an exact Application ID.', 1;
    IF @MatchBy IS NOT NULL AND NOT
        ((@TargetCode = 'R' AND @MatchBy IN ('REF_NBR','DDS_INTERNAL_REF'))
        OR (@TargetCode = 'F' AND @MatchBy = 'REF_NBR')
        OR (@TargetCode = 'C' AND @MatchBy IN ('DDA_REF_NO','DDS_INTERNAL_REF')))
        THROW 51603, 'The match key is not valid for this DDA table.', 1;
    IF @MatchBy IS NOT NULL AND NULLIF(@MatchValue, N'') IS NULL
        THROW 51604, 'A non-empty match reference is required.', 1;
    IF @LockRows = 1 AND @@TRANCOUNT = 0
        THROW 51605, 'Locked DDA source reads require a transaction.', 1;

    SET @Sql = N'SELECT APPLICATIONID AS ApplicationId, REF_NBR AS RefNbr,
        DDA_REF_NO AS DdaRefNo, ' + @Internal + N' AS InternalRef, '
        + QUOTENAME(@Status) + N' AS CurrentStatus
        FROM dbo.' + QUOTENAME(@Table)
        + CASE WHEN @LockRows = 1 THEN N' WITH (UPDLOCK, HOLDLOCK)' ELSE N'' END
        + N' WHERE APPLICATIONID = @App'
        + CASE WHEN @MatchBy IS NULL THEN N'' ELSE N' AND ' + QUOTENAME(@MatchBy) + N' = @Key' END
        + N';';
    EXEC sys.sp_executesql @Sql, N'@App NVARCHAR(200), @Key NVARCHAR(200)', @ApplicationId, @MatchValue;
END;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationFetch', N'P') IS NOT NULL
    DROP PROCEDURE dbo.Proc_DDA_ApplicationFetch;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationCheckers', N'P') IS NOT NULL
    DROP PROCEDURE dbo.Proc_DDA_ApplicationCheckers;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationSubmit', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Proc_DDA_ApplicationSubmit AS RETURN;');
GO
ALTER PROCEDURE dbo.Proc_DDA_ApplicationSubmit
    @LoginId NVARCHAR(100), @Remarks NVARCHAR(1000),
    @Rows XML, @AttachmentName NVARCHAR(260) = NULL, @AttachmentType NVARCHAR(150) = NULL,
    @AttachmentData VARBINARY(MAX) = NULL, @RequestId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF NULLIF(LTRIM(RTRIM(@LoginId)), N'') IS NULL
        THROW 51601, 'A DDA user ID is required for audit tracking.', 1;
    IF NULLIF(LTRIM(RTRIM(@Remarks)), N'') IS NULL
        THROW 51606, 'Enter maker remarks.', 1;
    IF DATALENGTH(@AttachmentData) > 5242880
        THROW 51607, 'Supporting attachment exceeds 5 MB.', 1;
    IF @AttachmentData IS NOT NULL AND (NULLIF(@AttachmentName, N'') IS NULL OR NULLIF(@AttachmentType, N'') IS NULL)
        THROW 51608, 'Attachment metadata is required.', 1;
    SET @RequestId = NULL;
    DECLARE @Input TABLE
    (
        RowNo INT IDENTITY PRIMARY KEY, TargetCode NVARCHAR(4000), ApplicationId NVARCHAR(4000),
        MatchBy NVARCHAR(4000), RefNbr NVARCHAR(4000), InternalRef NVARCHAR(4000),
        DdaRefNo NVARCHAR(4000), CurrentStatus NVARCHAR(4000),
        NewStatus NVARCHAR(4000), NewDdaRefNo NVARCHAR(4000)
    );
    INSERT @Input
    SELECT r.value('@TargetCode', 'NVARCHAR(4000)'), r.value('@ApplicationId', 'NVARCHAR(4000)'),
        r.value('@MatchBy', 'NVARCHAR(4000)'), NULLIF(r.value('@RefNbr', 'NVARCHAR(4000)'), N''),
        NULLIF(r.value('@InternalRef', 'NVARCHAR(4000)'), N''), NULLIF(r.value('@DdaRefNo', 'NVARCHAR(4000)'), N''),
        NULLIF(r.value('@CurrentStatus', 'NVARCHAR(4000)'), N''), r.value('@NewStatus', 'NVARCHAR(4000)'),
        NULLIF(r.value('@NewDdaRefNo', 'NVARCHAR(4000)'), N'')
    FROM @Rows.nodes('/Rows/Row') x(r);
    IF NOT EXISTS (SELECT 1 FROM @Input) OR EXISTS
    (
        SELECT 1 FROM @Input WHERE TargetCode NOT IN ('R','F','C') OR DATALENGTH(TargetCode) <> 2
          OR NULLIF(LTRIM(RTRIM(ApplicationId)), N'') IS NULL OR DATALENGTH(ApplicationId) > 400
          OR DATALENGTH(MatchBy) > 40 OR DATALENGTH(RefNbr) > 400 OR DATALENGTH(InternalRef) > 400
          OR DATALENGTH(DdaRefNo) > 400 OR DATALENGTH(NewDdaRefNo) > 400
          OR DATALENGTH(CurrentStatus) > 200 OR DATALENGTH(NewStatus) > 200
          OR NewStatus NOT IN ('Active','Approved','Cancelled','Declined by CB','Declined by Ops','Initiated','Rejected','Sent to DIB')
          OR (TargetCode IN ('R','F') AND NewStatus = 'Active' AND NULLIF(LTRIM(RTRIM(NewDdaRefNo)), N'') IS NULL)
          OR (TargetCode = 'C' AND ISNULL(NewDdaRefNo, N'') <> ISNULL(DdaRefNo, N''))
    )
        THROW 51609, 'Select valid rows and statuses. Cancellation DDA references cannot be changed; Active registration requires a reference.', 1;

    DECLARE @Source TABLE
        (ApplicationId NVARCHAR(200), RefNbr NVARCHAR(200), DdaRefNo NVARCHAR(200), InternalRef NVARCHAR(200), CurrentStatus NVARCHAR(100));
    DECLARE @N INT = 1, @Count INT = (SELECT COUNT(*) FROM @Input), @Target CHAR(1),
        @App NVARCHAR(200), @By VARCHAR(20), @Key NVARCHAR(200), @Internal NVARCHAR(200),
        @DdaRef NVARCHAR(200), @MatchCount INT, @PrimaryMatchCount INT,
        @MatchError NVARCHAR(2048), @DetailId INT;
    BEGIN TRY
        BEGIN TRANSACTION;
        INSERT dbo.DDA_ApplicationRequest
            (MakerLoginId, CheckerLoginId, MakerRemarks, AttachmentName, AttachmentType, AttachmentData)
        VALUES (@LoginId, NULL, @Remarks, @AttachmentName, @AttachmentType, @AttachmentData);
        SET @RequestId = SCOPE_IDENTITY();
        WHILE @N <= @Count
        BEGIN
            DELETE @Source;
            SELECT @Target = TargetCode, @App = ApplicationId, @By = MatchBy,
                @Internal = InternalRef, @DdaRef = DdaRefNo,
                @Key = CASE MatchBy WHEN 'REF_NBR' THEN RefNbr WHEN 'DDS_INTERNAL_REF' THEN InternalRef
                    WHEN 'DDA_REF_NO' THEN DdaRefNo END
            FROM @Input WHERE RowNo = @N;
            INSERT @Source EXEC dbo.Proc_DDA_ApplicationSource @Target, @App, @By, @Key, 1;
            SET @MatchCount = (SELECT COUNT(*) FROM @Source);
            -- Core registration may fall back to a unique internal reference.
            IF @Target = 'R' AND @By = 'REF_NBR' AND @MatchCount <> 1
                AND NULLIF(@Internal, N'') IS NOT NULL
            BEGIN
                SET @By = 'DDS_INTERNAL_REF';
                SET @Key = @Internal;
                DELETE @Source;
                INSERT @Source EXEC dbo.Proc_DDA_ApplicationSource @Target, @App, @By, @Key, 1;
                SET @MatchCount = (SELECT COUNT(*) FROM @Source);
            END;
            IF @Target = 'C' AND @By = 'DDA_REF_NO' AND @MatchCount <> 1
                AND NULLIF(@Internal, N'') IS NOT NULL
            BEGIN
                SET @PrimaryMatchCount = @MatchCount;
                SET @By = 'DDS_INTERNAL_REF';
                SET @Key = @Internal;
                DELETE @Source;
                INSERT @Source EXEC dbo.Proc_DDA_ApplicationSource @Target, @App, @By, @Key, 1;
                SET @MatchCount = (SELECT COUNT(*) FROM @Source);
                IF @PrimaryMatchCount > 1 AND @MatchCount <> 1
                BEGIN
                    SET @By = 'DDA_REF_NO';
                    SET @Key = @DdaRef;
                    DELETE @Source;
                    INSERT @Source EXEC dbo.Proc_DDA_ApplicationSource @Target, @App, @By, @Key, 1;
                    SET @MatchCount = (SELECT COUNT(*) FROM @Source);
                END;
            END;
            UPDATE @Source SET RefNbr = NULLIF(RefNbr, N''), InternalRef = NULLIF(InternalRef, N''),
                DdaRefNo = NULLIF(DdaRefNo, N''), CurrentStatus = NULLIF(CurrentStatus, N'');
            IF @MatchCount = 0
            BEGIN
                SET @MatchError = N'A selected Application ID/reference matches zero or multiple records. Fetch again or choose a unique reference. No source record matched Application ID [' +
                    COALESCE(@App, N'') + N'] and ' + CONVERT(NVARCHAR(20), @By) + N' [' + COALESCE(@Key, N'') + N'].';
                THROW 51610, @MatchError, 1;
            END;
            IF @MatchCount > 1 AND NOT (@Target = 'C' AND @By = 'DDA_REF_NO')
            BEGIN
                SET @MatchError = N'A selected Application ID/reference matches zero or multiple records. Fetch again or choose a unique reference. Multiple source records matched Application ID [' +
                    COALESCE(@App, N'') + N'] and ' + CONVERT(NVARCHAR(20), @By) + N' [' + COALESCE(@Key, N'') + N'].';
                THROW 51610, @MatchError, 1;
            END;
            IF @Target = 'C' AND @By = 'DDA_REF_NO' AND @MatchCount > 1
                AND (EXISTS
                    (SELECT CurrentStatus FROM @Source
                     EXCEPT SELECT CurrentStatus FROM @Input WHERE RowNo = @N)
                  OR EXISTS
                    (SELECT CurrentStatus FROM @Input WHERE RowNo = @N
                     EXCEPT SELECT CurrentStatus FROM @Source))
                THROW 51610, 'Duplicate cancellation rows have different statuses. Fetch and review the rows before submitting one group update.', 1;
            IF @MatchCount = 1 AND EXISTS
            (
                SELECT RefNbr, InternalRef, DdaRefNo, CurrentStatus FROM @Source
                EXCEPT SELECT RefNbr, InternalRef, DdaRefNo, CurrentStatus FROM @Input WHERE RowNo = @N
            )
                THROW 51611, 'Source values changed after fetching. Fetch again before submitting.', 1;
            IF EXISTS
            (
                SELECT 1 FROM dbo.DDA_ApplicationDetail d INNER JOIN @Source s ON s.ApplicationId = d.ApplicationId
                WHERE d.RequestId = @RequestId AND d.TargetCode = @Target
                  AND ISNULL(d.RefNbr, N'') = ISNULL(s.RefNbr, N'')
                  AND ISNULL(d.InternalRef, N'') = ISNULL(s.InternalRef, N'')
                  AND ISNULL(d.OldDdaRefNo, N'') = ISNULL(s.DdaRefNo, N'')
            )
                THROW 51612, 'The same source record was selected more than once.', 1;
            IF NOT EXISTS
            (
                SELECT CurrentStatus, DdaRefNo FROM @Input WHERE RowNo = @N
                EXCEPT SELECT NewStatus, NewDdaRefNo FROM @Input WHERE RowNo = @N
            )
                THROW 51613, 'A selected row has no status or DDA-reference change.', 1;
            INSERT dbo.DDA_ApplicationDetail
                (RequestId, TargetCode, ApplicationId, MatchBy, MatchValue, RefNbr, InternalRef,
                 OldDdaRefNo, NewDdaRefNo, OldStatus, NewStatus)
            SELECT @RequestId, @Target, @App, @By, @Key, RefNbr, InternalRef, DdaRefNo, NewDdaRefNo, CurrentStatus, NewStatus
            FROM @Input WHERE RowNo = @N;
            SET @DetailId = SCOPE_IDENTITY();
            INSERT dbo.DDA_ApplicationDetailSource
                (DetailId, RefNbr, InternalRef, DdaRefNo, OldStatus)
            SELECT @DetailId, RefNbr, InternalRef, DdaRefNo, CurrentStatus
            FROM @Source;
            SET @N = @N + 1;
        END;
        INSERT dbo.DDA_ApplicationAudit(RequestId, ActionName, ActionBy, Remarks)
        VALUES (@RequestId, 'SUBMITTED', @LoginId, @Remarks);
        COMMIT TRANSACTION;
        SELECT @RequestId AS RequestId;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        SET @RequestId = NULL;
        THROW;
    END CATCH;
END;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationRequests', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Proc_DDA_ApplicationRequests AS RETURN;');
GO
ALTER PROCEDURE dbo.Proc_DDA_ApplicationRequests @LoginId NVARCHAR(100), @PendingOnly BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF NULLIF(LTRIM(RTRIM(@LoginId)), N'') IS NULL
        THROW 51601, 'A DDA user ID is required for request history.', 1;
    SELECT r.RequestId, r.StatusCode,
        CASE r.StatusCode WHEN 'P' THEN 'Pending' WHEN 'A' THEN 'Approved' ELSE 'Rejected' END AS RequestStatus,
        r.MakerLoginId, r.CheckerLoginId, r.MakerRemarks, r.CheckerRemarks, r.SubmittedOn, r.CheckedOn,
        r.AttachmentName, (SELECT COUNT(*) FROM dbo.DDA_ApplicationDetail d WHERE d.RequestId = r.RequestId) AS RecordCount
    FROM dbo.DDA_ApplicationRequest r
    WHERE (@PendingOnly = 1 AND r.StatusCode = 'P')
       OR (@PendingOnly = 0 AND (r.CheckerLoginId = @LoginId OR r.MakerLoginId = @LoginId))
    ORDER BY r.RequestId DESC;
END;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationReview', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Proc_DDA_ApplicationReview AS RETURN;');
GO
ALTER PROCEDURE dbo.Proc_DDA_ApplicationReview @LoginId NVARCHAR(100), @RequestId INT, @FileOnly BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF NULLIF(LTRIM(RTRIM(@LoginId)), N'') IS NULL
        THROW 51601, 'A DDA user ID is required to review a request.', 1;
    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.DDA_ApplicationRequest
        WHERE RequestId = @RequestId
          AND (MakerLoginId = @LoginId OR CheckerLoginId = @LoginId
            OR StatusCode = 'P')
    )
        THROW 51614, 'Request is not available to this user.', 1;
    IF @FileOnly = 1
    BEGIN
        SELECT AttachmentName, AttachmentType, AttachmentData FROM dbo.DDA_ApplicationRequest WHERE RequestId = @RequestId;
        RETURN;
    END;
    SELECT RequestId, StatusCode, MakerLoginId, CheckerLoginId, MakerRemarks, CheckerRemarks,
        SubmittedOn, CheckedOn, AttachmentName FROM dbo.DDA_ApplicationRequest WHERE RequestId = @RequestId;
    SELECT DetailId, TargetCode,
        CASE TargetCode WHEN 'R' THEN 'Core registration' WHEN 'F' THEN 'Core Flex registration' ELSE 'Cancellation' END AS TargetName,
        ApplicationId, MatchBy, MatchValue, RefNbr, InternalRef, OldDdaRefNo, NewDdaRefNo, OldStatus, NewStatus,
        (SELECT COUNT(*) FROM dbo.DDA_ApplicationDetailSource s WHERE s.DetailId = d.DetailId)
            AS [Source records affected]
    FROM dbo.DDA_ApplicationDetail d WHERE RequestId = @RequestId ORDER BY DetailId;
    SELECT a.AuditId, a.DetailId, a.ActionName, a.ActionBy, a.ActionOn, a.OldStatus, a.NewStatus,
        a.OldDdaRefNo, a.NewDdaRefNo, a.Remarks
    FROM dbo.DDA_ApplicationAudit a WHERE a.RequestId = @RequestId ORDER BY a.AuditId;
END;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationCheck', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Proc_DDA_ApplicationCheck AS RETURN;');
GO
ALTER PROCEDURE dbo.Proc_DDA_ApplicationCheck
    @LoginId NVARCHAR(100), @RequestId INT, @Decision CHAR(1), @Remarks NVARCHAR(1000)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF NULLIF(LTRIM(RTRIM(@LoginId)), N'') IS NULL
        THROW 51601, 'A DDA user ID is required to decide a request.', 1;
    IF @Decision IS NULL OR @Decision NOT IN ('A','R') OR NULLIF(LTRIM(RTRIM(@Remarks)), N'') IS NULL
        THROW 51615, 'Select approve/reject and enter checker remarks.', 1;
    DECLARE @Maker NVARCHAR(100), @State CHAR(1);
    DECLARE @DetailId INT = 0, @NextId INT, @Target CHAR(1), @App NVARCHAR(200),
        @By VARCHAR(20), @Key NVARCHAR(200), @OldStatus NVARCHAR(100), @NewStatus NVARCHAR(100),
        @OldDda NVARCHAR(200), @NewDda NVARCHAR(200), @Ref NVARCHAR(200), @Internal NVARCHAR(200);
    DECLARE @Table SYSNAME, @Status SYSNAME, @Sql NVARCHAR(MAX), @Affected INT,
        @HistoryRef NVARCHAR(200), @SrNo INT, @Now DATETIME2(7), @HistoryLock INT,
        @MatchCount INT, @ExpectedCount INT, @MatchError NVARCHAR(2048),
        @HistorySnapshotId BIGINT, @NextHistorySnapshotId BIGINT;
    DECLARE @Source TABLE
        (ApplicationId NVARCHAR(200), RefNbr NVARCHAR(200), DdaRefNo NVARCHAR(200), InternalRef NVARCHAR(200), CurrentStatus NVARCHAR(100));
    BEGIN TRY
        BEGIN TRANSACTION;
        SELECT @Maker = MakerLoginId, @State = StatusCode
        FROM dbo.DDA_ApplicationRequest WITH (UPDLOCK, HOLDLOCK) WHERE RequestId = @RequestId;
        IF @State IS NULL OR @Maker = @LoginId OR @State <> 'P'
            THROW 51616, 'Only a distinct checker can decide a pending request.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.DDA_ApplicationDetail WHERE RequestId = @RequestId)
            THROW 51617, 'The request has no detail rows.', 1;

        IF @Decision = 'A'
        BEGIN
            -- Serialize this workflow's history allocation; table lock also protects MAX+1.
            EXEC @HistoryLock = sys.sp_getapplock @Resource = N'DDA_Application_MovementHistory',
                @LockMode = 'Exclusive', @LockOwner = 'Transaction', @LockTimeout = 10000;
            IF @HistoryLock < 0
                THROW 51618, 'Could not obtain the DDA movement-history allocation lock.', 1;
            WHILE 1 = 1
            BEGIN
                SET @NextId = NULL;
                SELECT @NextId = MIN(DetailId) FROM dbo.DDA_ApplicationDetail
                WHERE RequestId = @RequestId AND DetailId > @DetailId;
                IF @NextId IS NULL BREAK;
                SET @DetailId = @NextId;
                SELECT @Target = TargetCode, @App = ApplicationId, @By = MatchBy, @Key = MatchValue,
                    @OldStatus = OldStatus, @NewStatus = NewStatus, @OldDda = OldDdaRefNo,
                    @NewDda = NewDdaRefNo, @Ref = RefNbr, @Internal = InternalRef
                FROM dbo.DDA_ApplicationDetail WHERE DetailId = @DetailId;
                SELECT @ExpectedCount = COUNT(*)
                FROM dbo.DDA_ApplicationDetailSource WHERE DetailId = @DetailId;
                IF @ExpectedCount = 0
                    THROW 51617, 'The request is missing its source-row snapshot.', 1;
                DELETE @Source;
                INSERT @Source EXEC dbo.Proc_DDA_ApplicationSource @Target, @App, @By, @Key, 1;
                SET @MatchCount = (SELECT COUNT(*) FROM @Source);
                UPDATE @Source SET RefNbr = NULLIF(RefNbr, N''), InternalRef = NULLIF(InternalRef, N''),
                    DdaRefNo = NULLIF(DdaRefNo, N''), CurrentStatus = NULLIF(CurrentStatus, N'');
                IF @MatchCount = 0
                BEGIN
                    SET @MatchError = N'Approval found no source record for Application ID [' + COALESCE(@App, N'') +
                        N'] and ' + CONVERT(NVARCHAR(20), @By) + N' [' + COALESCE(@Key, N'') +
                        N']. No changes were committed; reject the request and fetch the records again.';
                    THROW 51619, @MatchError, 1;
                END;
                IF @MatchCount <> @ExpectedCount
                BEGIN
                    SET @MatchError = CASE WHEN @MatchCount > @ExpectedCount
                        THEN N'Approval found multiple source records for Application ID ['
                        ELSE N'Approval found a changed number of source records for Application ID [' END
                        + COALESCE(@App, N'') + N'] and ' + CONVERT(NVARCHAR(20), @By) + N' [' +
                        COALESCE(@Key, N'') + N']. Expected ' + CONVERT(NVARCHAR(20), @ExpectedCount) +
                        N' row(s), found ' + CONVERT(NVARCHAR(20), @MatchCount) +
                        N'. No changes were committed; reject the request and fetch the records again.';
                    THROW 51619, @MatchError, 1;
                END;
                IF @ExpectedCount > 1 AND NOT (@Target = 'C' AND @By = 'DDA_REF_NO')
                    THROW 51619, 'Multiple source rows are only supported for a cancellation DDA reference group.', 1;
                IF EXISTS
                (
                    SELECT RefNbr, InternalRef, DdaRefNo, CurrentStatus, COUNT(*)
                    FROM @Source
                    GROUP BY RefNbr, InternalRef, DdaRefNo, CurrentStatus
                    EXCEPT
                    SELECT RefNbr, InternalRef, DdaRefNo, OldStatus, COUNT(*)
                    FROM dbo.DDA_ApplicationDetailSource
                    WHERE DetailId = @DetailId
                    GROUP BY RefNbr, InternalRef, DdaRefNo, OldStatus
                )
                OR EXISTS
                (
                    SELECT RefNbr, InternalRef, DdaRefNo, OldStatus, COUNT(*)
                    FROM dbo.DDA_ApplicationDetailSource
                    WHERE DetailId = @DetailId
                    GROUP BY RefNbr, InternalRef, DdaRefNo, OldStatus
                    EXCEPT
                    SELECT RefNbr, InternalRef, DdaRefNo, CurrentStatus, COUNT(*)
                    FROM @Source
                    GROUP BY RefNbr, InternalRef, DdaRefNo, CurrentStatus
                )
                    THROW 51620, 'Source changed since maker submission. Reject the stale request and fetch again.', 1;

                SELECT @Table = CASE @Target WHEN 'R' THEN 'CORE_DDA_REGISTRATION_DETAILS'
                    WHEN 'F' THEN 'CORE_FLEX_DDA_REGISTRATION_DETAILS' WHEN 'C' THEN 'CORE_DDA_CANCELLATION_DETAILS' END,
                    @Status = CASE WHEN @Target = 'C' THEN 'CANCELLATION_STATUS' ELSE 'DDS_STATUS' END;
                SET @Sql = N'UPDATE dbo.' + QUOTENAME(@Table) + N' SET ' + QUOTENAME(@Status) + N' = @NewStatus';
                IF @Target IN ('R','F')
                    SET @Sql = @Sql + N', DDA_REF_NO = @NewDda';
                SET @Sql = @Sql + N' WHERE APPLICATIONID = @App AND ' + QUOTENAME(@By)
                    + N' = @Key; SET @Affected = @@ROWCOUNT;';
                EXEC sys.sp_executesql @Sql,
                    N'@NewStatus NVARCHAR(100), @NewDda NVARCHAR(200), @App NVARCHAR(200), @Key NVARCHAR(200), @Affected INT OUTPUT',
                    @NewStatus, @NewDda, @App, @Key, @Affected OUTPUT;
                IF @Affected <> @ExpectedCount
                    THROW 51621, 'Approval did not update the expected number of source records.', 1;
                DELETE @Source;
                INSERT @Source EXEC dbo.Proc_DDA_ApplicationSource @Target, @App, @By, @Key, 1;
                UPDATE @Source SET RefNbr = NULLIF(RefNbr, N''), InternalRef = NULLIF(InternalRef, N''),
                    DdaRefNo = NULLIF(DdaRefNo, N''), CurrentStatus = NULLIF(CurrentStatus, N'');
                IF (SELECT COUNT(*) FROM @Source) <> @ExpectedCount OR EXISTS
                    (SELECT CurrentStatus, DdaRefNo FROM @Source EXCEPT SELECT @NewStatus, @NewDda)
                    THROW 51622, 'Stored source values do not match the approved values.', 1;

                SET @Now = SYSDATETIME();
                SET @HistorySnapshotId = 0;
                WHILE 1 = 1
                BEGIN
                    SET @NextHistorySnapshotId = NULL;
                    SELECT @NextHistorySnapshotId = MIN(SourceSnapshotId)
                    FROM dbo.DDA_ApplicationDetailSource
                    WHERE DetailId = @DetailId AND SourceSnapshotId > @HistorySnapshotId;
                    IF @NextHistorySnapshotId IS NULL BREAK;
                    SET @HistorySnapshotId = @NextHistorySnapshotId;
                    SELECT @HistoryRef = COALESCE(NULLIF(RefNbr, N''), @NewDda, @OldDda)
                    FROM dbo.DDA_ApplicationDetailSource
                    WHERE SourceSnapshotId = @HistorySnapshotId;
                    IF @HistoryRef IS NULL
                        THROW 51623, 'Movement history requires REF_NBR or a DDA_REF_NO. Reject and refetch with a DDA reference.', 1;
                    SELECT @SrNo = ISNULL(MAX(SRNO), 0) + 1
                    FROM dbo.DDA_Movement_history WITH (TABLOCKX, HOLDLOCK)
                    WHERE APPLICATIONID = @App AND NBR_Refno = @HistoryRef;
                    INSERT dbo.DDA_Movement_history
                        (APPLICATIONID, NBR_Refno, SRNO, FROM_STAGE, To_STAGE, Status,
                         Updatedby_user, Updatedon_Date, REMARKS, FILE_NAME, Process_Method)
                    VALUES (@App, @HistoryRef, @SrNo, @OldStatus, @NewStatus, @NewStatus,
                        @LoginId, @Now, @Remarks, NULL, 'Manual Update');
                END;
                INSERT dbo.DDA_ApplicationAudit
                    (RequestId, DetailId, ActionName, ActionBy, OldStatus, NewStatus, OldDdaRefNo, NewDdaRefNo, Remarks)
                VALUES (@RequestId, @DetailId, 'UPDATED', @LoginId, @OldStatus, @NewStatus, @OldDda, @NewDda, @Remarks);
            END;
        END;
        UPDATE dbo.DDA_ApplicationRequest
        SET StatusCode = @Decision, CheckerLoginId = @LoginId, CheckerRemarks = @Remarks, CheckedOn = SYSDATETIME()
        WHERE RequestId = @RequestId;
        INSERT dbo.DDA_ApplicationAudit(RequestId, ActionName, ActionBy, Remarks)
        VALUES (@RequestId, CASE @Decision WHEN 'A' THEN 'APPROVED' ELSE 'REJECTED' END, @LoginId, @Remarks);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationDdsData', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Proc_DDA_ApplicationDdsData AS RETURN;');
GO
ALTER PROCEDURE dbo.Proc_DDA_ApplicationDdsData
    @LoginId NVARCHAR(100), @ApplicationId NVARCHAR(200), @FromDate DATE = NULL,
    @ToDate DATE = NULL, @Status NVARCHAR(100) = NULL, @DdaReferenceNo NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF NULLIF(LTRIM(RTRIM(@LoginId)), N'') IS NULL
        THROW 51601, 'A DDA user ID is required to fetch DDS data.', 1;
    IF NULLIF(LTRIM(RTRIM(@ApplicationId)), N'') IS NULL OR @FromDate > @ToDate
        THROW 51623, 'Enter an exact Application ID and a valid response-date range.', 1;
    SELECT SRNO, DDAInternalReferenceNo, ApplicationID, DDAReferenceNo, DDAStatus,
        DDARemarks, CentralBankResponseDate, Purpose, Frequency
    FROM dbo.DDS_HFLMS_REG_CANC_SYNC
    WHERE ApplicationID = @ApplicationId
      AND (@FromDate IS NULL OR CentralBankResponseDate >= @FromDate)
      AND (@ToDate IS NULL OR CentralBankResponseDate < DATEADD(DAY, 1, @ToDate))
      AND (@Status IS NULL OR LTRIM(RTRIM(DDAStatus)) = @Status)
      AND (@DdaReferenceNo IS NULL OR DDAReferenceNo = @DdaReferenceNo)
    ORDER BY CentralBankResponseDate DESC, SRNO DESC;
END;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationGetStandardData', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Proc_DDA_ApplicationGetStandardData AS RETURN;');
GO
ALTER PROCEDURE dbo.Proc_DDA_ApplicationGetStandardData
    @TableName NVARCHAR(128),
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @Status NVARCHAR(100) = NULL,
    @ApplicationId NVARCHAR(200) = NULL,
    @RefNbr NVARCHAR(200) = NULL,
    @DdaReferenceNo NVARCHAR(200) = NULL,
    @DdsInternalRef NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @TableName = N'CORE_FLEX_DDA_REGISTRATION_DETAILS' AND @DdsInternalRef IS NOT NULL
        THROW 51625, 'DDS_INTERNAL_REF filtering is not applicable to Core Flex registration.', 1;

    IF @TableName = N'CORE_DDA_REGISTRATION_DETAILS'
    BEGIN
        SELECT TOP (1000) APPLICATIONID, REF_NBR, DDA_REF_NO, PURPOSE, DDS_STATUS, DDS_INTERNAL_REF
        FROM dbo.CORE_DDA_REGISTRATION_DETAILS
        WHERE (@FromDate IS NULL OR Maker_dt_stamp >= @FromDate)
          AND (@ToDate IS NULL OR Maker_dt_stamp < DATEADD(DAY, 1, @ToDate))
          AND (@Status IS NULL OR LTRIM(RTRIM(CONVERT(NVARCHAR(100), DDS_STATUS))) = @Status)
          AND (@ApplicationId IS NULL OR CONVERT(NVARCHAR(200), APPLICATIONID) LIKE N'%' + @ApplicationId + N'%')
          AND (@RefNbr IS NULL OR REF_NBR = @RefNbr)
          AND (@DdaReferenceNo IS NULL OR DDA_REF_NO = @DdaReferenceNo)
          AND (@DdsInternalRef IS NULL OR DDS_INTERNAL_REF = @DdsInternalRef)
        ORDER BY Maker_dt_stamp DESC, APPLICATIONID DESC;
    END
    ELSE IF @TableName = N'CORE_DDA_CANCELLATION_DETAILS'
    BEGIN
        SELECT TOP (1000) APPLICATIONID, REF_NBR, DDA_REF_NO, PURPOSE, CANCELLATION_STATUS, DDS_INTERNAL_REF
        FROM dbo.CORE_DDA_CANCELLATION_DETAILS
        WHERE (@FromDate IS NULL OR Maker_dt_stamp >= @FromDate)
          AND (@ToDate IS NULL OR Maker_dt_stamp < DATEADD(DAY, 1, @ToDate))
          AND (@Status IS NULL OR LTRIM(RTRIM(CONVERT(NVARCHAR(100), CANCELLATION_STATUS))) = @Status)
          AND (@ApplicationId IS NULL OR CONVERT(NVARCHAR(200), APPLICATIONID) LIKE N'%' + @ApplicationId + N'%')
          AND (@RefNbr IS NULL OR REF_NBR = @RefNbr)
          AND (@DdaReferenceNo IS NULL OR DDA_REF_NO = @DdaReferenceNo)
          AND (@DdsInternalRef IS NULL OR DDS_INTERNAL_REF = @DdsInternalRef)
        ORDER BY Maker_dt_stamp DESC, APPLICATIONID DESC;
    END
    ELSE IF @TableName = N'CORE_FLEX_DDA_REGISTRATION_DETAILS'
    BEGIN
        SELECT TOP (1000) APPLICATIONID, REF_NBR, DDA_REF_NO, PURPOSE, DDS_STATUS
        FROM dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS
        WHERE (@FromDate IS NULL OR Maker_dt_stamp >= @FromDate)
          AND (@ToDate IS NULL OR Maker_dt_stamp < DATEADD(DAY, 1, @ToDate))
          AND (@Status IS NULL OR LTRIM(RTRIM(CONVERT(NVARCHAR(100), DDS_STATUS))) = @Status)
          AND (@ApplicationId IS NULL OR CONVERT(NVARCHAR(200), APPLICATIONID) LIKE N'%' + @ApplicationId + N'%')
          AND (@RefNbr IS NULL OR REF_NBR = @RefNbr)
          AND (@DdaReferenceNo IS NULL OR DDA_REF_NO = @DdaReferenceNo)
        ORDER BY Maker_dt_stamp DESC, APPLICATIONID DESC;
    END
    ELSE
        THROW 51624, 'Unsupported DDA standard data set.', 1;
END;
GO
IF OBJECT_ID(N'dbo.Proc_DDA_ApplicationGetDdsSystemData', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Proc_DDA_ApplicationGetDdsSystemData AS RETURN;');
GO
ALTER PROCEDURE dbo.Proc_DDA_ApplicationGetDdsSystemData
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @Status NVARCHAR(100) = NULL,
    @ApplicationId NVARCHAR(200) = NULL,
    @DdaReferenceNo NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (1000) SRNO, DDAInternalReferenceNo, ApplicationID, DDAReferenceNo, DDAStatus,
           DDARemarks, CentralBankResponseDate, Purpose, Frequency
    FROM dbo.DDS_HFLMS_REG_CANC_SYNC
    WHERE (@FromDate IS NULL OR CentralBankResponseDate >= @FromDate)
      AND (@ToDate IS NULL OR CentralBankResponseDate < DATEADD(DAY, 1, @ToDate))
      AND (@Status IS NULL OR LTRIM(RTRIM(CONVERT(NVARCHAR(100), DDAStatus))) = @Status)
      AND (@ApplicationId IS NULL OR CONVERT(NVARCHAR(200), ApplicationID) LIKE N'%' + @ApplicationId + N'%')
      AND (@DdaReferenceNo IS NULL OR CONVERT(NVARCHAR(200), DDAReferenceNo) LIKE N'%' + @DdaReferenceNo + N'%')
    ORDER BY CentralBankResponseDate DESC, SRNO DESC;
END;
GO
