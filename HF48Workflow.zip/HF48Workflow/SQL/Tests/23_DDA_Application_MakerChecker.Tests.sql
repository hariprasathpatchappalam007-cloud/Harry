-- SQLCMD mode from workspace root. NEW disposable DDA_Application_Test_* database only.
:ON ERROR EXIT
IF DB_NAME() NOT LIKE N'DDA[_]Application[_]Test[_]%'
    THROW 51700, 'DDA tests require a new disposable DDA_Application_Test_* database.', 1;
DECLARE @Sql NVARCHAR(400) = N'ALTER DATABASE ' + QUOTENAME(DB_NAME()) + N' SET COMPATIBILITY_LEVEL = 100;';
EXEC sys.sp_executesql @Sql;
GO
CREATE TABLE dbo.CORE_DDA_REGISTRATION_DETAILS
    (APPLICATIONID NVARCHAR(200), REF_NBR NVARCHAR(200), DDA_REF_NO NVARCHAR(200),
     DDS_INTERNAL_REF NVARCHAR(200), DDS_STATUS NVARCHAR(100), PURPOSE NVARCHAR(100),
     Maker_dt_stamp DATETIME2);
CREATE TABLE dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS
    (APPLICATIONID NVARCHAR(200), REF_NBR NVARCHAR(200), DDA_REF_NO NVARCHAR(200),
     DDS_STATUS NVARCHAR(100), PURPOSE NVARCHAR(100), Maker_dt_stamp DATETIME2);
CREATE TABLE dbo.CORE_DDA_CANCELLATION_DETAILS
    (APPLICATIONID NVARCHAR(200), REF_NBR NVARCHAR(200), DDA_REF_NO NVARCHAR(200),
     DDS_INTERNAL_REF NVARCHAR(200), CANCELLATION_STATUS NVARCHAR(100), PURPOSE NVARCHAR(100),
     Maker_dt_stamp DATETIME2);
CREATE TABLE dbo.DDA_Movement_history
(
    APPLICATIONID NVARCHAR(200), NBR_Refno NVARCHAR(200), SRNO INT,
    FROM_STAGE NVARCHAR(100), To_STAGE NVARCHAR(100), Status NVARCHAR(100),
    Updatedby_user NVARCHAR(100), Updatedon_Date DATETIME2(7), REMARKS NVARCHAR(1000),
    FILE_NAME NVARCHAR(260) NULL, Process_Method NVARCHAR(100),
    PRIMARY KEY (APPLICATIONID, NBR_Refno, SRNO)
);
CREATE TABLE dbo.DDS_HFLMS_REG_CANC_SYNC
(
    SRNO INT, DDAInternalReferenceNo NVARCHAR(200), ApplicationID NVARCHAR(200),
    DDAReferenceNo NVARCHAR(200), DDAStatus NVARCHAR(100), DDARemarks NVARCHAR(1000),
    CentralBankResponseDate DATETIME, Purpose NVARCHAR(100), Frequency NVARCHAR(100)
);
GO
:r .\SQL\23_DDA_Application_MakerChecker.sql
GO
ALTER TABLE dbo.DDA_ApplicationDetail DROP CONSTRAINT CK_DDA_ApplicationDetail_MatchKey;
ALTER TABLE dbo.DDA_ApplicationDetail ADD CHECK
    ((TargetCode = 'R' AND MatchBy IN ('REF_NBR','DDS_INTERNAL_REF'))
        OR (TargetCode = 'F' AND MatchBy = 'REF_NBR')
        OR (TargetCode = 'C' AND MatchBy = 'DDA_REF_NO'));
GO
:r .\SQL\23_DDA_Application_MakerChecker.sql
GO
SET NOCOUNT ON;
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, DDS_STATUS, PURPOSE, Maker_dt_stamp)
VALUES
    ('APP1','REG1','OLD1','INT1','Pending','Takaful','2026-03-13T14:00:00'),
    ('APP1','','OLD2','INT2','Pending','Takaful','2026-03-13T14:30:00'),
    ('OTHER_APP','REG1','OLD1','INT1','Pending','Takaful','2026-03-13T14:45:00');
INSERT dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_STATUS, PURPOSE, Maker_dt_stamp)
VALUES ('APP1','FLEX1','FLEXOLD','Pending','Takaful','2026-03-13T14:00:00');
INSERT dbo.CORE_DDA_CANCELLATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, CANCELLATION_STATUS, PURPOSE, Maker_dt_stamp)
VALUES
    ('APP1','CANC1','CANCEL1','CINT1','Sent to DIB','Takaful','2026-03-13T14:00:00'),
    ('OTHER_APP','CANC1','CANCEL1','CINT1','Sent to DIB','Takaful','2026-03-13T14:45:00');
INSERT dbo.DDA_Movement_history VALUES
    ('APP1','REG1',4,'Old','Pending','Pending','maker',SYSDATETIME(),'',NULL,'Registration');
INSERT dbo.DDS_HFLMS_REG_CANC_SYNC VALUES
    (1,'INT1','APP1','OLD1','Active','DDS sample','2026-03-13T15:41:00','Takaful','Monthly'),
    (2,'INT1','OTHER_APP','OLD1','Active','Other app','2026-03-13T15:41:00','Takaful','Monthly');

DECLARE @StandardPreview TABLE
(
    APPLICATIONID NVARCHAR(200), REF_NBR NVARCHAR(200), DDA_REF_NO NVARCHAR(200),
    PURPOSE NVARCHAR(100), DDS_STATUS NVARCHAR(100), DDS_INTERNAL_REF NVARCHAR(200)
);
INSERT @StandardPreview
EXEC dbo.Proc_DDA_ApplicationGetStandardData
    @TableName=N'CORE_DDA_REGISTRATION_DETAILS', @FromDate='2026-03-13',
    @ToDate='2026-03-13', @Status=N'Pending', @ApplicationId=N'APP1';
IF (SELECT COUNT(*) FROM @StandardPreview) <> 2
    THROW 51700, 'The consolidated standard-data filter returned an unexpected result.', 1;

DECLARE @DdsPreview TABLE
(
    SRNO INT, DDAInternalReferenceNo NVARCHAR(200), ApplicationID NVARCHAR(200),
    DDAReferenceNo NVARCHAR(200), DDAStatus NVARCHAR(100), DDARemarks NVARCHAR(1000),
    CentralBankResponseDate DATETIME, Purpose NVARCHAR(100), Frequency NVARCHAR(100)
);
INSERT @DdsPreview
EXEC dbo.Proc_DDA_ApplicationGetDdsSystemData
    @FromDate='2026-03-13', @ToDate='2026-03-13', @ApplicationId=N'APP1';
IF (SELECT COUNT(*) FROM @DdsPreview) <> 1
    THROW 51700, 'The consolidated DDS-data filter returned an unexpected result.', 1;

EXEC dbo.Proc_DDA_ApplicationDdsData 'maker','APP1';

DECLARE @Id INT, @Caught BIT = 0, @ErrorMessage NVARCHAR(2048), @Rows XML =
N'<Rows>
<Row TargetCode="R" ApplicationId="APP1" MatchBy="REF_NBR" RefNbr="REG1" InternalRef="INT1" DdaRefNo="OLD1" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="AMENDED1" />
<Row TargetCode="R" ApplicationId="APP1" MatchBy="DDS_INTERNAL_REF" RefNbr="" InternalRef="INT2" DdaRefNo="OLD2" CurrentStatus="Pending" NewStatus="Rejected" NewDdaRefNo="OLD2" />
<Row TargetCode="F" ApplicationId="APP1" MatchBy="REF_NBR" RefNbr="FLEX1" InternalRef="" DdaRefNo="FLEXOLD" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="FLEXOLD" />
<Row TargetCode="C" ApplicationId="APP1" MatchBy="DDA_REF_NO" RefNbr="CANC1" InternalRef="CINT1" DdaRefNo="CANCEL1" CurrentStatus="Sent to DIB" NewStatus="Cancelled" NewDdaRefNo="CANCEL1" />
</Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Review four updates',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
IF @Id IS NULL OR (SELECT COUNT(*) FROM dbo.DDA_ApplicationDetail WHERE RequestId=@Id)<>4
    THROW 51700, 'Request details were not captured.', 1;
IF EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='APP1'
    AND DDS_STATUS<>'Pending')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS
        WHERE APPLICATIONID='APP1' AND REF_NBR='REG1' AND DDS_STATUS='Pending' AND DDA_REF_NO='OLD1')
    OR (SELECT COUNT(*) FROM dbo.DDA_Movement_history)<>1
    THROW 51700, 'Submission changed source/history before approval.', 1;

IF EXISTS(SELECT 1 FROM dbo.DDA_ApplicationRequest WHERE RequestId=@Id AND CheckerLoginId IS NOT NULL)
    THROW 51700, 'A checker was assigned during maker submission.', 1;
EXEC dbo.Proc_DDA_ApplicationRequests 'other',1;
EXEC dbo.Proc_DDA_ApplicationReview 'other',@Id;
EXEC dbo.Proc_DDA_ApplicationCheck 'other',@Id,'A','Approved manual updates';
IF NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='APP1'
    AND REF_NBR='REG1' AND DDS_STATUS='Active' AND DDA_REF_NO='AMENDED1')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='APP1'
        AND DDS_INTERNAL_REF='INT2' AND DDS_STATUS='Rejected' AND DDA_REF_NO='OLD2')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS
        WHERE APPLICATIONID='APP1' AND DDS_STATUS='Active' AND DDA_REF_NO='FLEXOLD')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_CANCELLATION_DETAILS
        WHERE APPLICATIONID='APP1' AND CANCELLATION_STATUS='Cancelled' AND DDA_REF_NO='CANCEL1')
    THROW 51700, 'An exact target update failed.', 1;
IF EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='OTHER_APP' AND DDS_STATUS<>'Pending')
    OR EXISTS(SELECT 1 FROM dbo.CORE_DDA_CANCELLATION_DETAILS WHERE APPLICATIONID='OTHER_APP' AND CANCELLATION_STATUS<>'Sent to DIB')
    THROW 51700, 'An update crossed application boundaries.', 1;
IF (SELECT COUNT(*) FROM dbo.DDA_ApplicationAudit WHERE RequestId=@Id AND ActionName='UPDATED')<>4
    OR (SELECT COUNT(*) FROM dbo.DDA_Movement_history WHERE Process_Method='Manual Update')<>4
    OR NOT EXISTS(SELECT 1 FROM dbo.DDA_Movement_history WHERE APPLICATIONID='APP1'
        AND NBR_Refno='REG1' AND SRNO=5 AND FROM_STAGE='Pending' AND To_STAGE='Active'
        AND Status='Active' AND Updatedby_user='other' AND Updatedon_Date IS NOT NULL)
    OR NOT EXISTS(SELECT 1 FROM dbo.DDA_ApplicationRequest WHERE RequestId=@Id AND CheckerLoginId='other')
    OR NOT EXISTS(SELECT 1 FROM dbo.DDA_ApplicationDetail WHERE RequestId=@Id
        AND OldDdaRefNo='OLD1' AND NewDdaRefNo='AMENDED1')
    OR NOT EXISTS(SELECT 1 FROM dbo.DDA_Movement_history WHERE NBR_Refno='OLD2' AND SRNO=1)
    THROW 51700, 'Movement history allocation/mapping or row audit failed.', 1;
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Replay';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51616 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Repeated approval was accepted.', 1;
EXEC dbo.Proc_DDA_ApplicationReview 'maker',@Id;

-- A duplicate registration REF_NBR may still resolve uniquely by internal reference.
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, DDS_STATUS, PURPOSE, Maker_dt_stamp)
VALUES
    ('DUPREG','SHAREDREF','DUP-DDA-1','UNIQUE-1','Pending','Takaful','2026-03-13T14:00:00'),
    ('DUPREG','SHAREDREF','DUP-DDA-2','UNIQUE-2','Pending','Takaful','2026-03-13T14:00:00');
SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="DUPREG" MatchBy="REF_NBR" RefNbr="SHAREDREF" InternalRef="UNIQUE-2" DdaRefNo="DUP-DDA-2" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="DUP-DDA-2" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Resolve duplicate reference',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
IF NOT EXISTS(SELECT 1 FROM dbo.DDA_ApplicationDetail
    WHERE RequestId=@Id AND MatchBy='DDS_INTERNAL_REF' AND MatchValue='UNIQUE-2')
    THROW 51700, 'A duplicate registration REF_NBR did not fall back to its unique internal reference.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'other',@Id,'A','Approve unique internal reference';
IF NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS
        WHERE APPLICATIONID='DUPREG' AND DDS_INTERNAL_REF='UNIQUE-2' AND DDS_STATUS='Active')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS
        WHERE APPLICATIONID='DUPREG' AND DDS_INTERNAL_REF='UNIQUE-1' AND DDS_STATUS='Pending')
    THROW 51700, 'The unique internal-reference fallback updated the wrong registration row.', 1;

-- A duplicate cancellation DDA_REF_NO may resolve uniquely by internal reference.
INSERT dbo.CORE_DDA_CANCELLATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, CANCELLATION_STATUS)
VALUES
    ('DUPCANCEL','CREF-1','SHARED-CAN','CANCEL-INT-1','Initiated'),
    ('DUPCANCEL','CREF-2','SHARED-CAN','CANCEL-INT-2','Initiated');
SET @Rows=N'<Rows><Row TargetCode="C" ApplicationId="DUPCANCEL" MatchBy="DDA_REF_NO" RefNbr="CREF-2" InternalRef="CANCEL-INT-2" DdaRefNo="SHARED-CAN" CurrentStatus="Initiated" NewStatus="Cancelled" NewDdaRefNo="SHARED-CAN" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Resolve duplicate cancellation reference',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
IF NOT EXISTS(SELECT 1 FROM dbo.DDA_ApplicationDetail
    WHERE RequestId=@Id AND MatchBy='DDS_INTERNAL_REF' AND MatchValue='CANCEL-INT-2')
    THROW 51700, 'A duplicate cancellation DDA_REF_NO did not fall back to its unique internal reference.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'other',@Id,'A','Approve unique cancellation internal reference';
IF NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_CANCELLATION_DETAILS
        WHERE APPLICATIONID='DUPCANCEL' AND DDS_INTERNAL_REF='CANCEL-INT-2' AND CANCELLATION_STATUS='Cancelled')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_CANCELLATION_DETAILS
        WHERE APPLICATIONID='DUPCANCEL' AND DDS_INTERNAL_REF='CANCEL-INT-1' AND CANCELLATION_STATUS='Initiated')
    THROW 51700, 'The unique cancellation internal-reference fallback updated the wrong row.', 1;

-- Rejection cannot change source/history.
SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="APP1" MatchBy="REF_NBR" RefNbr="REG1" InternalRef="INT1" DdaRefNo="AMENDED1" CurrentStatus="Active" NewStatus="Rejected" NewDdaRefNo="AMENDED1" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Reject test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'R','Rejected by checker';
IF NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='APP1' AND REF_NBR='REG1' AND DDS_STATUS='Active')
    OR (SELECT COUNT(*) FROM dbo.DDA_Movement_history)<>7
    THROW 51700, 'Rejection changed source/history.', 1;

-- A post-submission concurrent change makes approval stale.
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Stale test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
UPDATE dbo.CORE_DDA_REGISTRATION_DETAILS SET DDS_STATUS='Concurrent' WHERE APPLICATIONID='APP1' AND REF_NBR='REG1';
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Stale approval';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51620 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 OR NOT EXISTS(SELECT 1 FROM dbo.DDA_ApplicationRequest WHERE RequestId=@Id AND StatusCode='P')
    OR EXISTS(SELECT 1 FROM dbo.DDA_ApplicationAudit WHERE RequestId=@Id AND ActionName='UPDATED')
    THROW 51700, 'Stale approval was not atomic.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'R','Refetch changed data';
UPDATE dbo.CORE_DDA_REGISTRATION_DETAILS SET DDS_STATUS='Active'
WHERE APPLICATIONID='APP1' AND REF_NBR='REG1';

-- Duplicate source matches must not update several rows.
INSERT dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_STATUS)
VALUES ('DUP','R','D','Pending'),('DUP','R','D','Pending');
SET @Rows=N'<Rows><Row TargetCode="F" ApplicationId="DUP" MatchBy="REF_NBR" RefNbr="R" InternalRef="" DdaRefNo="D" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="D" /></Rows>';
SET @Caught=0;
SET @ErrorMessage=N'';
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Ambiguous test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51610 THROW;
    SET @ErrorMessage=ERROR_MESSAGE();
    SET @Caught=1;
END CATCH;
IF @Caught=0 OR CHARINDEX(N'Multiple source records matched',@ErrorMessage)=0
    THROW 51700, 'Ambiguous source selection was accepted or not reported clearly.', 1;

INSERT dbo.CORE_DDA_CANCELLATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, CANCELLATION_STATUS)
VALUES
    ('DUPCANAMB','CAN-1','DUP-CAN','DUP-CAN-INT','Initiated'),
    ('DUPCANAMB','CAN-2','DUP-CAN','DUP-CAN-INT','Initiated');
SET @Rows=N'<Rows><Row TargetCode="C" ApplicationId="DUPCANAMB" MatchBy="DDA_REF_NO" RefNbr="CAN-1" InternalRef="DUP-CAN-INT" DdaRefNo="DUP-CAN" CurrentStatus="Initiated" NewStatus="Cancelled" NewDdaRefNo="DUP-CAN" /></Rows>';
SET @Caught=0;
SET @ErrorMessage=N'';
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Unresolved cancellation duplicate test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51610 THROW;
    SET @ErrorMessage=ERROR_MESSAGE();
    SET @Caught=1;
END CATCH;
IF @Caught=0 OR CHARINDEX(N'Multiple source records matched',@ErrorMessage)=0
    OR CHARINDEX(N'DDS_INTERNAL_REF',@ErrorMessage)=0
    THROW 51700, 'An unresolved cancellation duplicate was accepted or the failed key was omitted from the diagnostic.', 1;

SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="MISSING" MatchBy="REF_NBR" RefNbr="NO-REF" InternalRef="NO-INTERNAL" DdaRefNo="" CurrentStatus="Pending" NewStatus="Rejected" NewDdaRefNo="" /></Rows>';
SET @Caught=0;
SET @ErrorMessage=N'';
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Missing source test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51610 THROW;
    SET @ErrorMessage=ERROR_MESSAGE();
    SET @Caught=1;
END CATCH;
IF @Caught=0 OR CHARINDEX(N'No source record matched',@ErrorMessage)=0
    THROW 51700, 'A missing source record was accepted or not reported clearly.', 1;

-- A duplicate inserted after maker submission must make checker approval fail atomically.
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, DDS_STATUS)
VALUES ('DUPCHECK','UNIQUE-REF','CHECK-DDA','CHECK-INT','Pending');
SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="DUPCHECK" MatchBy="REF_NBR" RefNbr="UNIQUE-REF" InternalRef="CHECK-INT" DdaRefNo="CHECK-DDA" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="CHECK-DDA" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Checker duplicate test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, DDS_STATUS)
VALUES ('DUPCHECK','UNIQUE-REF','CHECK-DDA-2','CHECK-INT-2','Pending');
SET @Caught=0;
SET @ErrorMessage=N'';
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'other',@Id,'A','Duplicate detected during approval';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51619 THROW;
    SET @ErrorMessage=ERROR_MESSAGE();
    SET @Caught=1;
END CATCH;
IF @Caught=0 OR CHARINDEX(N'multiple source records',LOWER(@ErrorMessage))=0
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS
        WHERE APPLICATIONID='DUPCHECK' AND DDS_INTERNAL_REF='CHECK-INT' AND DDS_STATUS='Pending')
    OR NOT EXISTS(SELECT 1 FROM dbo.DDA_ApplicationRequest WHERE RequestId=@Id AND StatusCode='P')
    THROW 51700, 'Duplicate source data during approval did not fail atomically with a clear message.', 1;
DELETE dbo.CORE_DDA_REGISTRATION_DETAILS
WHERE APPLICATIONID='DUPCHECK' AND DDS_INTERNAL_REF='CHECK-INT-2';
EXEC dbo.Proc_DDA_ApplicationCheck 'other',@Id,'R','Resolve duplicate source row';

-- No self-checking, missing audit identity, invalid statuses or cancellation reference edits.
SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="APP1" MatchBy="REF_NBR" RefNbr="REG1" InternalRef="INT1" DdaRefNo="AMENDED1" CurrentStatus="Active" NewStatus="Rejected" NewDdaRefNo="AMENDED1" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'dual','Self test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'dual',@Id,'A','Self approval';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51616 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Maker approved their own request.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'R','Self-check blocked';
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit N'','Missing identity',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51601 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'A request without an audit user ID was accepted.', 1;
SET @Rows=N'<Rows><Row TargetCode="C" ApplicationId="APP1" MatchBy="DDA_REF_NO" RefNbr="CANC1" InternalRef="CINT1" DdaRefNo="CANCEL1" CurrentStatus="Cancelled" NewStatus="Rejected" NewDdaRefNo="CHANGED" /></Rows>';
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Wrong cancellation ref',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51609 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Cancellation reference was editable.', 1;

-- Force a history failure AFTER the source update; all changes must roll back.
INSERT dbo.CORE_DDA_CANCELLATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, CANCELLATION_STATUS)
VALUES ('FAIL','FAILREF','FAILDDA','FAILINT','Sent to DIB');
GO
CREATE TRIGGER dbo.Test_RejectDdaHistory ON dbo.DDA_Movement_history AFTER INSERT AS
BEGIN
    IF EXISTS(SELECT 1 FROM inserted WHERE APPLICATIONID='FAIL')
        THROW 51701, 'Deliberate movement-history failure.', 1;
END;
GO
DECLARE @Rows XML=N'<Rows><Row TargetCode="C" ApplicationId="FAIL" MatchBy="DDA_REF_NO" RefNbr="FAILREF" InternalRef="FAILINT" DdaRefNo="FAILDDA" CurrentStatus="Sent to DIB" NewStatus="Cancelled" NewDdaRefNo="FAILDDA" /></Rows>', @Id INT, @Caught BIT=0;
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','History rollback test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Fail history insert';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51701 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_CANCELLATION_DETAILS WHERE APPLICATIONID='FAIL' AND CANCELLATION_STATUS='Sent to DIB')
    OR NOT EXISTS(SELECT 1 FROM dbo.DDA_ApplicationRequest WHERE RequestId=@Id AND StatusCode='P')
    OR EXISTS(SELECT 1 FROM dbo.DDA_Movement_history WHERE APPLICATIONID='FAIL')
    OR EXISTS(SELECT 1 FROM dbo.DDA_ApplicationAudit WHERE RequestId=@Id AND ActionName='UPDATED')
    THROW 51700, 'History failure did not roll back the source, audit and decision.', 1;
DROP TRIGGER dbo.Test_RejectDdaHistory;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Retry after history fix';
GO
-- Earlier details must also roll back if a later detail becomes stale.
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, DDS_STATUS)
VALUES
    ('ATOMIC','A1','DA1','IA1','Pending'),('ATOMIC','A2','DA2','IA2','Pending');
DECLARE @Rows XML=N'<Rows>
<Row TargetCode="R" ApplicationId="ATOMIC" MatchBy="REF_NBR" RefNbr="A1" InternalRef="IA1" DdaRefNo="DA1" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="DA1" />
<Row TargetCode="R" ApplicationId="ATOMIC" MatchBy="REF_NBR" RefNbr="A2" InternalRef="IA2" DdaRefNo="DA2" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="DA2" />
</Rows>', @Id INT, @Caught BIT=0;
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Multi-row atomic test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
UPDATE dbo.CORE_DDA_REGISTRATION_DETAILS SET DDS_STATUS='Concurrent' WHERE APPLICATIONID='ATOMIC' AND REF_NBR='A2';
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Later row stale';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51620 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 OR EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS
        WHERE APPLICATIONID='ATOMIC' AND REF_NBR='A1' AND DDS_STATUS<>'Pending')
    OR EXISTS(SELECT 1 FROM dbo.DDA_Movement_history WHERE APPLICATIONID='ATOMIC')
    OR EXISTS(SELECT 1 FROM dbo.DDA_ApplicationAudit WHERE RequestId=@Id AND ActionName='UPDATED')
    THROW 51700, 'A stale later detail did not roll back earlier details.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'R','Refetch atomic request';

-- A cancellation must not cascade to matching registration rows.
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, DDS_STATUS)
VALUES ('NC','NCR','NC-D','NC-I','Active');
INSERT dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_STATUS)
VALUES ('NC','NCF','NC-D','Active');
INSERT dbo.CORE_DDA_CANCELLATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, CANCELLATION_STATUS)
VALUES ('NC','NCC','NC-D','NC-CI','Sent to DIB');
SET @Rows=N'<Rows><Row TargetCode="C" ApplicationId="NC" MatchBy="DDA_REF_NO" RefNbr="NCC" InternalRef="NC-CI" DdaRefNo="NC-D" CurrentStatus="Sent to DIB" NewStatus="Cancelled" NewDdaRefNo="NC-D" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','No cascade / attachment test',@Rows,N'proof.txt',N'text/plain',0x444441,@Id OUTPUT;
EXEC dbo.Proc_DDA_ApplicationReview 'maker',@Id,1;
EXEC dbo.Proc_DDA_ApplicationReview 'other',@Id,1;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Cancel only';
IF NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='NC' AND DDS_STATUS='Active' AND DDA_REF_NO='NC-D')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='NC' AND DDS_STATUS='Active' AND DDA_REF_NO='NC-D')
    THROW 51700, 'Cancellation cascaded to registration.', 1;

-- Missing old DDA reference may be filled; history falls back to approved DDA reference.
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS
    (APPLICATIONID, REF_NBR, DDA_REF_NO, DDS_INTERNAL_REF, DDS_STATUS)
VALUES ('NEWREF',NULL,'','NEW-I','Pending');
SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="NEWREF" MatchBy="DDS_INTERNAL_REF" RefNbr="" InternalRef="NEW-I" DdaRefNo="" CurrentStatus="Pending" NewStatus="Rejected" NewDdaRefNo="" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Missing history reference test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','History reference unavailable';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51623 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='NEWREF' AND DDS_STATUS='Pending')
    THROW 51700, 'A status change without a history reference was committed.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'R','History reference unavailable';
SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="APP1" MatchBy="REF_NBR" RefNbr="REG1" InternalRef="INT1" DdaRefNo="AMENDED1" CurrentStatus="Active" NewStatus="Active" NewDdaRefNo="AMENDED1" /></Rows>';
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','No-op test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51613 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Unchanged status proposal was accepted.', 1;
GO
-- A trusted app SQL principal needs public procedure EXECUTE, not table rights.
CREATE USER DdaApplicationTestWeb WITHOUT LOGIN;
GRANT EXECUTE ON dbo.Proc_DDA_ApplicationSubmit TO DdaApplicationTestWeb;
GRANT EXECUTE ON dbo.Proc_DDA_ApplicationCheck TO DdaApplicationTestWeb;
GO
EXECUTE AS USER = 'DdaApplicationTestWeb';
DECLARE @Rows XML=N'<Rows><Row TargetCode="R" ApplicationId="APP1" MatchBy="REF_NBR" RefNbr="REG1" InternalRef="INT1" DdaRefNo="AMENDED1" CurrentStatus="Active" NewStatus="Rejected" NewDdaRefNo="AMENDED1" /></Rows>', @Id INT;
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','Least-privilege app test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Procedure-only update';
REVERT;
DROP USER DdaApplicationTestWeb;
PRINT 'PASS: DDA exact matching, duplicate-reference fallback/rejection, checker-pool decisions, snapshots, history allocation, no cascade, attachments, multi-row rollback and procedure-only permissions without DDP_UserAccess/FRM_user.';
GO
