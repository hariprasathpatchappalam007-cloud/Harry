-- SQLCMD mode from workspace root. NEW disposable DDA_Application_Test_* database only.
:ON ERROR EXIT
IF DB_NAME() NOT LIKE N'DDA[_]Application[_]Test[_]%'
    THROW 51700, 'DDA tests require a new disposable DDA_Application_Test_* database.', 1;
DECLARE @Sql NVARCHAR(400) = N'ALTER DATABASE ' + QUOTENAME(DB_NAME()) + N' SET COMPATIBILITY_LEVEL = 100;';
EXEC sys.sp_executesql @Sql;
GO
CREATE TABLE dbo.FRM_user(LoginId NVARCHAR(100) PRIMARY KEY);
CREATE TABLE dbo.DDP_UserAccess
    (LoginId NVARCHAR(100) PRIMARY KEY, CanMake BIT, CanCheck BIT, IsActive BIT);
CREATE TABLE dbo.CORE_DDA_REGISTRATION_DETAILS
    (APPLICATIONID NVARCHAR(200), REF_NBR NVARCHAR(200), DDA_REF_NO NVARCHAR(200),
     DDS_INTERNAL_REF NVARCHAR(200), DDS_STATUS NVARCHAR(100));
CREATE TABLE dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS
    (APPLICATIONID NVARCHAR(200), REF_NBR NVARCHAR(200), DDA_REF_NO NVARCHAR(200), DDS_STATUS NVARCHAR(100));
CREATE TABLE dbo.CORE_DDA_CANCELLATION_DETAILS
    (APPLICATIONID NVARCHAR(200), REF_NBR NVARCHAR(200), DDA_REF_NO NVARCHAR(200),
     DDS_INTERNAL_REF NVARCHAR(200), CANCELLATION_STATUS NVARCHAR(100));
CREATE TABLE dbo.DDA_Movement_history
(
    APPLICATIONID NVARCHAR(200), NBR_Refno NVARCHAR(200), SRNO INT,
    FROM_STAGE NVARCHAR(100), To_STAGE NVARCHAR(100), Status NVARCHAR(100),
    Updatedby_user NVARCHAR(100), Updatedon_Date DATETIME2(7), REMARKS NVARCHAR(1000),
    FILE_NAME NVARCHAR(260) NULL, Process_Method NVARCHAR(100),
    PRIMARY KEY (APPLICATIONID, NBR_Refno, SRNO)
);
CREATE TABLE dbo.DDS_HFLMS_REG_CANC_SYNC
(
    SRNO INT, DDAInternalReferenceNo NVARCHAR(200), ApplicationID NVARCHAR(200),
    DDAReferenceNo NVARCHAR(200), DDAStatus NVARCHAR(100), DDARemarks NVARCHAR(1000),
    CentralBankResponseDate DATETIME, Purpose NVARCHAR(100), Frequency NVARCHAR(100)
);
GO
:r .\SQL\23_DDA_Application_MakerChecker.sql
:r .\SQL\23_DDA_Application_MakerChecker.sql
GO
SET NOCOUNT ON;
INSERT dbo.FRM_user VALUES ('maker'),('checker'),('other'),('disabled'),('dual');
INSERT dbo.DDP_UserAccess VALUES ('maker',1,0,1),('checker',0,1,1),('other',0,1,1),('disabled',1,1,0),('dual',1,1,1);
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS VALUES
    ('APP1','REG1','OLD1','INT1','Pending'),
    ('APP1','','OLD2','INT2','Pending'),
    ('OTHER_APP','REG1','OLD1','INT1','Pending');
INSERT dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS VALUES ('APP1','FLEX1','FLEXOLD','Pending');
INSERT dbo.CORE_DDA_CANCELLATION_DETAILS VALUES
    ('APP1','CANC1','CANCEL1','CINT1','Sent to DIB'),
    ('OTHER_APP','CANC1','CANCEL1','CINT1','Sent to DIB');
INSERT dbo.DDA_Movement_history VALUES
    ('APP1','REG1',4,'Old','Pending','Pending','maker',SYSDATETIME(),'',NULL,'Registration');
INSERT dbo.DDS_HFLMS_REG_CANC_SYNC VALUES
    (1,'INT1','APP1','OLD1','Active','DDS sample','2026-03-13T15:41:00','Takaful','Monthly'),
    (2,'INT1','OTHER_APP','OLD1','Active','Other app','2026-03-13T15:41:00','Takaful','Monthly');

EXEC dbo.Proc_DDA_ApplicationFetch 'maker','R','APP1';
EXEC dbo.Proc_DDA_ApplicationCheckers 'maker';
EXEC dbo.Proc_DDA_ApplicationDdsData 'maker','APP1';

DECLARE @Id INT, @Rows XML =
N'<Rows>
<Row TargetCode="R" ApplicationId="APP1" MatchBy="REF_NBR" RefNbr="REG1" InternalRef="INT1" DdaRefNo="OLD1" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="NEW1" />
<Row TargetCode="R" ApplicationId="APP1" MatchBy="DDS_INTERNAL_REF" RefNbr="" InternalRef="INT2" DdaRefNo="OLD2" CurrentStatus="Pending" NewStatus="Rejected" NewDdaRefNo="OLD2" />
<Row TargetCode="F" ApplicationId="APP1" MatchBy="REF_NBR" RefNbr="FLEX1" InternalRef="" DdaRefNo="FLEXOLD" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="FLEXNEW" />
<Row TargetCode="C" ApplicationId="APP1" MatchBy="DDA_REF_NO" RefNbr="CANC1" InternalRef="CINT1" DdaRefNo="CANCEL1" CurrentStatus="Sent to DIB" NewStatus="Cancelled" NewDdaRefNo="CANCEL1" />
</Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','Review four updates',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
IF @Id IS NULL OR (SELECT COUNT(*) FROM dbo.DDA_ApplicationDetail WHERE RequestId=@Id)<>4
    THROW 51700, 'Request details were not captured.', 1;
IF EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='APP1' AND DDS_STATUS<>'Pending')
    OR (SELECT COUNT(*) FROM dbo.DDA_Movement_history)<>1
    THROW 51700, 'Submission changed source/history before approval.', 1;

DECLARE @Caught BIT=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'other',@Id,'A','Not assigned';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51616 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Unassigned checker approved a request.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Approved manual updates';
IF NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='APP1'
    AND REF_NBR='REG1' AND DDS_STATUS='Active' AND DDA_REF_NO='NEW1')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='APP1'
        AND DDS_INTERNAL_REF='INT2' AND DDS_STATUS='Rejected' AND DDA_REF_NO='OLD2')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS
        WHERE APPLICATIONID='APP1' AND DDS_STATUS='Active' AND DDA_REF_NO='FLEXNEW')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_CANCELLATION_DETAILS
        WHERE APPLICATIONID='APP1' AND CANCELLATION_STATUS='Cancelled' AND DDA_REF_NO='CANCEL1')
    THROW 51700, 'An exact target update failed.', 1;
IF EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='OTHER_APP' AND DDS_STATUS<>'Pending')
    OR EXISTS(SELECT 1 FROM dbo.CORE_DDA_CANCELLATION_DETAILS WHERE APPLICATIONID='OTHER_APP' AND CANCELLATION_STATUS<>'Sent to DIB')
    THROW 51700, 'An update crossed application boundaries.', 1;
IF (SELECT COUNT(*) FROM dbo.DDA_ApplicationAudit WHERE RequestId=@Id AND ActionName='UPDATED')<>4
    OR (SELECT COUNT(*) FROM dbo.DDA_Movement_history WHERE Process_Method='Manual Update')<>4
    OR NOT EXISTS(SELECT 1 FROM dbo.DDA_Movement_history WHERE APPLICATIONID='APP1'
        AND NBR_Refno='REG1' AND SRNO=5 AND FROM_STAGE='Pending' AND To_STAGE='Active'
        AND Status='Active' AND Updatedby_user='checker' AND Updatedon_Date IS NOT NULL)
    OR NOT EXISTS(SELECT 1 FROM dbo.DDA_Movement_history WHERE NBR_Refno='OLD2' AND SRNO=1)
    THROW 51700, 'Movement history allocation/mapping or row audit failed.', 1;
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Replay';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51616 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Repeated approval was accepted.', 1;
EXEC dbo.Proc_DDA_ApplicationReview 'maker',@Id;

-- Rejection cannot change source/history.
SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="APP1" MatchBy="REF_NBR" RefNbr="REG1" InternalRef="INT1" DdaRefNo="NEW1" CurrentStatus="Active" NewStatus="Rejected" NewDdaRefNo="NEW1" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','Reject test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'R','Rejected by checker';
IF NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='APP1' AND REF_NBR='REG1' AND DDS_STATUS='Active')
    OR (SELECT COUNT(*) FROM dbo.DDA_Movement_history)<>5
    THROW 51700, 'Rejection changed source/history.', 1;

-- A post-submission concurrent change makes approval stale.
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','Stale test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
UPDATE dbo.CORE_DDA_REGISTRATION_DETAILS SET DDS_STATUS='Concurrent' WHERE APPLICATIONID='APP1' AND REF_NBR='REG1';
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Stale approval';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51620 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 OR NOT EXISTS(SELECT 1 FROM dbo.DDA_ApplicationRequest WHERE RequestId=@Id AND StatusCode='P')
    OR EXISTS(SELECT 1 FROM dbo.DDA_ApplicationAudit WHERE RequestId=@Id AND ActionName='UPDATED')
    THROW 51700, 'Stale approval was not atomic.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'R','Refetch changed data';

-- Duplicate source matches must not update several rows.
INSERT dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS VALUES ('DUP','R','D','Pending'),('DUP','R','D','Pending');
SET @Rows=N'<Rows><Row TargetCode="F" ApplicationId="DUP" MatchBy="REF_NBR" RefNbr="R" InternalRef="" DdaRefNo="D" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="D" /></Rows>';
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','Ambiguous test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51610 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Ambiguous source selection was accepted.', 1;

-- No self-checking, inactive makers, invalid statuses or cancellation reference edits.
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit 'dual','dual','Self test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51606 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Self approval assignment was accepted.', 1;
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationFetch 'disabled','R','APP1';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51601 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Inactive maker could fetch data.', 1;
SET @Rows=N'<Rows><Row TargetCode="C" ApplicationId="APP1" MatchBy="DDA_REF_NO" RefNbr="CANC1" InternalRef="CINT1" DdaRefNo="CANCEL1" CurrentStatus="Cancelled" NewStatus="Rejected" NewDdaRefNo="CHANGED" /></Rows>';
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','Wrong cancellation ref',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51609 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Cancellation reference was editable.', 1;

-- Force a history failure AFTER the source update; all changes must roll back.
INSERT dbo.CORE_DDA_CANCELLATION_DETAILS VALUES ('FAIL','FAILREF','FAILDDA','FAILINT','Sent to DIB');
GO
CREATE TRIGGER dbo.Test_RejectDdaHistory ON dbo.DDA_Movement_history AFTER INSERT AS
BEGIN
    IF EXISTS(SELECT 1 FROM inserted WHERE APPLICATIONID='FAIL')
        THROW 51701, 'Deliberate movement-history failure.', 1;
END;
GO
DECLARE @Rows XML=N'<Rows><Row TargetCode="C" ApplicationId="FAIL" MatchBy="DDA_REF_NO" RefNbr="FAILREF" InternalRef="FAILINT" DdaRefNo="FAILDDA" CurrentStatus="Sent to DIB" NewStatus="Cancelled" NewDdaRefNo="FAILDDA" /></Rows>', @Id INT, @Caught BIT=0;
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','History rollback test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Fail history insert';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51701 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_CANCELLATION_DETAILS WHERE APPLICATIONID='FAIL' AND CANCELLATION_STATUS='Sent to DIB')
    OR NOT EXISTS(SELECT 1 FROM dbo.DDA_ApplicationRequest WHERE RequestId=@Id AND StatusCode='P')
    OR EXISTS(SELECT 1 FROM dbo.DDA_Movement_history WHERE APPLICATIONID='FAIL')
    OR EXISTS(SELECT 1 FROM dbo.DDA_ApplicationAudit WHERE RequestId=@Id AND ActionName='UPDATED')
    THROW 51700, 'History failure did not roll back the source, audit and decision.', 1;
DROP TRIGGER dbo.Test_RejectDdaHistory;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Retry after history fix';
GO
-- Earlier details must also roll back if a later detail becomes stale.
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS VALUES
    ('ATOMIC','A1','DA1','IA1','Pending'),('ATOMIC','A2','DA2','IA2','Pending');
DECLARE @Rows XML=N'<Rows>
<Row TargetCode="R" ApplicationId="ATOMIC" MatchBy="REF_NBR" RefNbr="A1" InternalRef="IA1" DdaRefNo="DA1" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="DA1" />
<Row TargetCode="R" ApplicationId="ATOMIC" MatchBy="REF_NBR" RefNbr="A2" InternalRef="IA2" DdaRefNo="DA2" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="DA2" />
</Rows>', @Id INT, @Caught BIT=0;
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','Multi-row atomic test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
UPDATE dbo.CORE_DDA_REGISTRATION_DETAILS SET DDS_STATUS='Concurrent' WHERE APPLICATIONID='ATOMIC' AND REF_NBR='A2';
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Later row stale';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51620 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 OR EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS
        WHERE APPLICATIONID='ATOMIC' AND REF_NBR='A1' AND DDS_STATUS<>'Pending')
    OR EXISTS(SELECT 1 FROM dbo.DDA_Movement_history WHERE APPLICATIONID='ATOMIC')
    OR EXISTS(SELECT 1 FROM dbo.DDA_ApplicationAudit WHERE RequestId=@Id AND ActionName='UPDATED')
    THROW 51700, 'A stale later detail did not roll back earlier details.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'R','Refetch atomic request';

-- A cancellation must not cascade to matching registration rows.
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS VALUES ('NC','NCR','NC-D','NC-I','Active');
INSERT dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS VALUES ('NC','NCF','NC-D','Active');
INSERT dbo.CORE_DDA_CANCELLATION_DETAILS VALUES ('NC','NCC','NC-D','NC-CI','Sent to DIB');
SET @Rows=N'<Rows><Row TargetCode="C" ApplicationId="NC" MatchBy="DDA_REF_NO" RefNbr="NCC" InternalRef="NC-CI" DdaRefNo="NC-D" CurrentStatus="Sent to DIB" NewStatus="Cancelled" NewDdaRefNo="NC-D" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','No cascade / attachment test',@Rows,N'proof.txt',N'text/plain',0x444441,@Id OUTPUT;
EXEC dbo.Proc_DDA_ApplicationReview 'maker',@Id,1;
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationReview 'other',@Id,1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51614 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Another checker could download a private attachment.', 1;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Cancel only';
IF NOT EXISTS(SELECT 1 FROM dbo.CORE_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='NC' AND DDS_STATUS='Active' AND DDA_REF_NO='NC-D')
    OR NOT EXISTS(SELECT 1 FROM dbo.CORE_FLEX_DDA_REGISTRATION_DETAILS WHERE APPLICATIONID='NC' AND DDS_STATUS='Active' AND DDA_REF_NO='NC-D')
    THROW 51700, 'Cancellation cascaded to registration.', 1;

-- Missing old DDA reference may be filled; history falls back to approved DDA reference.
INSERT dbo.CORE_DDA_REGISTRATION_DETAILS VALUES ('NEWREF',NULL,'','NEW-I','Pending');
SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="NEWREF" MatchBy="DDS_INTERNAL_REF" RefNbr="" InternalRef="NEW-I" DdaRefNo="" CurrentStatus="Pending" NewStatus="Active" NewDdaRefNo="NEW-DDA" /></Rows>';
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','New reference test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Set previously blank DDA reference';
IF NOT EXISTS(SELECT 1 FROM dbo.DDA_Movement_history WHERE APPLICATIONID='NEWREF' AND NBR_Refno='NEW-DDA' AND SRNO=1)
    THROW 51700, 'History did not use the approved DDA reference fallback.', 1;
SET @Rows=N'<Rows><Row TargetCode="R" ApplicationId="NEWREF" MatchBy="DDS_INTERNAL_REF" RefNbr="" InternalRef="NEW-I" DdaRefNo="NEW-DDA" CurrentStatus="Active" NewStatus="Active" NewDdaRefNo="NEW-DDA" /></Rows>';
SET @Caught=0;
BEGIN TRY
    EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','No-op test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER()<>51613 THROW;
    SET @Caught=1;
END CATCH;
IF @Caught=0 THROW 51700, 'Unchanged proposal was accepted.', 1;
GO
-- A trusted app SQL principal needs public procedure EXECUTE, not table rights.
CREATE USER DdaApplicationTestWeb WITHOUT LOGIN;
GRANT EXECUTE ON dbo.Proc_DDA_ApplicationFetch TO DdaApplicationTestWeb;
GRANT EXECUTE ON dbo.Proc_DDA_ApplicationSubmit TO DdaApplicationTestWeb;
GRANT EXECUTE ON dbo.Proc_DDA_ApplicationCheck TO DdaApplicationTestWeb;
GO
EXECUTE AS USER = 'DdaApplicationTestWeb';
EXEC dbo.Proc_DDA_ApplicationFetch 'maker','R','NEWREF';
DECLARE @Rows XML=N'<Rows><Row TargetCode="R" ApplicationId="NEWREF" MatchBy="DDS_INTERNAL_REF" RefNbr="" InternalRef="NEW-I" DdaRefNo="NEW-DDA" CurrentStatus="Active" NewStatus="Rejected" NewDdaRefNo="NEW-DDA" /></Rows>', @Id INT;
EXEC dbo.Proc_DDA_ApplicationSubmit 'maker','checker','Least-privilege app test',@Rows,DEFAULT,DEFAULT,DEFAULT,@Id OUTPUT;
EXEC dbo.Proc_DDA_ApplicationCheck 'checker',@Id,'A','Procedure-only update';
REVERT;
DROP USER DdaApplicationTestWeb;
PRINT 'PASS: DDA exact matching, roles, decisions, snapshots, history allocation, no cascade, attachments, blank references, multi-row rollback and procedure-only permissions.';
GO
