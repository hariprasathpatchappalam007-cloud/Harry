-- SQLCMD mode, run from workspace root in a NEW disposable DSR_Audit_Test_* database.
:ON ERROR EXIT
IF DB_NAME() NOT LIKE N'DSR[_]Audit[_]Test[_]%'
    THROW 51000, 'Tests require a disposable DSR_Audit_Test_* database.', 1;
GO
CREATE TABLE dbo.lead_details
(
    Lead_No VARCHAR(30) NOT NULL PRIMARY KEY,
    APP_REF_NO VARCHAR(50) NULL,
    lead_stage VARCHAR(50) NULL,
    CreatedOn_Date DATETIME NULL,
    UpdatedOn_date DATETIME NULL
);
CREATE TABLE dbo.lead_details_finance
(
    Lead_No VARCHAR(30) NOT NULL PRIMARY KEY,
    LEAD_DSR NUMERIC(28,20) NULL,
    LEAD_DSR_PRODUCT NUMERIC(28,20) NULL,
    Lead_Stress_DSR NUMERIC(28,20) NULL,
    lead_ftv NUMERIC(28,20) NULL,
    LEAD_Product_ISTINSNA VARCHAR(30) NULL,
    Lead_Conversion_Product VARCHAR(30) NULL
);
CREATE TABLE dbo.FRM_service_request
(
    SRNo INT NOT NULL PRIMARY KEY,
    Category NVARCHAR(100) NULL,
    SubCategory NVARCHAR(100) NULL,
    CAS_stage NVARCHAR(100) NULL,
    ApplicationID VARCHAR(50) NULL
);
GO
:r .\SQL\18_DSR_Change_Audit.sql
-- Re-running deployment must preserve audit tables and replace executable objects safely.
:r .\SQL\18_DSR_Change_Audit.sql
GO
SET NOCOUNT ON;
INSERT dbo.lead_details VALUES
    ('L1', 'APP1', 'SALES', GETDATE(), GETDATE()),
    ('L2', 'APP2', 'CREDIT', GETDATE(), GETDATE()),
    ('L3', 'APP1', 'OPS', GETDATE(), GETDATE());
INSERT dbo.FRM_service_request VALUES
    (1, 'CAT1', 'SUB1', 'OPEN', 'APP1'),
    (2, 'CAT2', 'SUB2', 'REVIEW', 'APP1'),
    (3, 'CAT3', 'SUB3', 'OTHER', 'APP3');
INSERT dbo.lead_details_finance VALUES
    ('L1', 45.26000000000000000001, 17, 48.65, 80, 'HF49', 'HF47'),
    ('L2', 40, 12, NULL, 70, 'HF48', 'HF47'),
    ('L3', NULL, NULL, NULL, 60, 'HF48', 'HF47');
IF (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit) <> 2
    THROW 51000, 'Inserts / all-NULL no-change handling failed.', 1;
IF (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit_ServiceRequest) <> 2
    THROW 51000, 'Multi-SR or missing-SR handling failed.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_ChangeAudit WHERE ApplicationID = 'APP2')
    THROW 51000, 'Missing service request incorrectly suppressed an audit.', 1;

UPDATE dbo.lead_details_finance SET LEAD_DSR = LEAD_DSR, lead_ftv = 81;
UPDATE dbo.lead_details SET lead_stage = 'CREDIT' WHERE Lead_No = 'L1';
IF (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit) <> 2
    THROW 51000, 'No-op, FTV-only or stage-only writes created events.', 1;

UPDATE dbo.lead_details_finance SET LEAD_DSR = LEAD_DSR + 1 WHERE Lead_No IN ('L1', 'L2');
IF (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit WHERE ChangeType = 'U') <> 2
    THROW 51000, 'Multi-row DSR update was not fully audited.', 1;
IF NOT EXISTS
(
    SELECT 1 FROM dbo.DSR_ChangeAudit
    WHERE Lead_No = 'L1' AND ChangeType = 'U' AND LeadStage = 'CREDIT'
      AND OldLEAD_DSR = 45.26000000000000000001
      AND NewLEAD_DSR = 46.26000000000000000001
      AND ChangedAtUtc BETWEEN DATEADD(MINUTE, -1, SYSUTCDATETIME()) AND SYSUTCDATETIME()
)
    THROW 51000, 'Exact values, stage or UTC time not captured.', 1;

UPDATE dbo.FRM_service_request SET CAS_stage = 'CLOSED', Category = 'NEW' WHERE SRNo = 1;
DELETE dbo.FRM_service_request WHERE SRNo = 2;
IF (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit_ServiceRequest WHERE CAS_stage IN ('OPEN', 'REVIEW')) <> 4
    THROW 51000, 'Historical service request snapshots changed with live rows.', 1;

UPDATE dbo.lead_details_finance SET Lead_Stress_DSR = 0 WHERE Lead_No = 'L2';
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_ChangeAudit WHERE Lead_No = 'L2'
    AND OldLead_Stress_DSR IS NULL AND NewLead_Stress_DSR = 0)
    THROW 51000, 'NULL-to-zero was missed.', 1;
UPDATE dbo.lead_details_finance SET Lead_Stress_DSR = NULL WHERE Lead_No = 'L2';
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_ChangeAudit WHERE Lead_No = 'L2'
    AND OldLead_Stress_DSR = 0 AND NewLead_Stress_DSR IS NULL)
    THROW 51000, 'Zero-to-NULL was missed.', 1;
UPDATE dbo.lead_details_finance SET LEAD_DSR_PRODUCT = 18 WHERE Lead_No = 'L1';
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_ChangeAudit WHERE Lead_No = 'L1'
    AND OldLEAD_DSR_PRODUCT = 17 AND NewLEAD_DSR_PRODUCT = 18)
    THROW 51000, 'Product-only DSR update was missed.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_ChangeAudit_ServiceRequest WHERE CAS_stage = 'CLOSED')
    THROW 51000, 'New events did not capture the new CAS stage.', 1;

DECLARE @Before INT = (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit);
DECLARE @BeforeSR INT = (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit_ServiceRequest);
BEGIN TRANSACTION;
UPDATE dbo.lead_details_finance SET LEAD_DSR = 99;
ROLLBACK;
IF (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit) <> @Before
    OR (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit_ServiceRequest) <> @BeforeSR
    THROW 51000, 'Rolled-back change left audit data behind.', 1;

DECLARE @From BIGINT = (SELECT MIN(AuditId) FROM dbo.DSR_ChangeAudit WHERE Lead_No = 'L1');
DECLARE @To BIGINT = (SELECT MAX(AuditId) FROM dbo.DSR_ChangeAudit WHERE Lead_No = 'L1');
-- Returns history, historical service requests and three comparison rows.
EXEC dbo.Proc_DSR_GetHistory 'APP1', @From, @To;

DECLARE @Rejected BIT = 0;
BEGIN TRY
    EXEC dbo.Proc_DSR_GetHistory 'APP2', @From, @To;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() <> 50000 THROW;
    SET @Rejected = 1;
END CATCH;
IF @Rejected = 0 THROW 51000, 'Cross-application comparison was accepted.', 1;

UPDATE dbo.lead_details_finance SET LEAD_DSR = 10 WHERE Lead_No = 'L3';
SET @To = (SELECT MAX(AuditId) FROM dbo.DSR_ChangeAudit WHERE Lead_No = 'L3');
SET @Rejected = 0;
BEGIN TRY
    EXEC dbo.Proc_DSR_GetHistory 'APP1', @From, @To;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() <> 50000 THROW;
    SET @Rejected = 1;
END CATCH;
IF @Rejected = 0 THROW 51000, 'Cross-lead comparison was accepted.', 1;

-- Lead and SR context may be missing independently.
INSERT dbo.lead_details_finance VALUES ('ORPHAN', 5, NULL, NULL, NULL, NULL, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_ChangeAudit WHERE Lead_No = 'ORPHAN' AND ApplicationID IS NULL)
    THROW 51000, 'Missing lead context suppressed an audit.', 1;
DELETE dbo.lead_details_finance WHERE Lead_No = 'L1';
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_ChangeAudit WHERE Lead_No = 'L1'
    AND ChangeType = 'D' AND OldLEAD_DSR_PRODUCT = 18 AND NewLEAD_DSR_PRODUCT IS NULL)
    THROW 51000, 'Deletion was not audited.', 1;
PRINT 'PASS: DSR audit SQL integration assertions.';
GO
