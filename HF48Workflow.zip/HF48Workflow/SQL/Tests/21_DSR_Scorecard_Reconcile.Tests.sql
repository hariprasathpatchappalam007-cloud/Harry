-- SQLCMD mode from workspace root; use a NEW disposable DSR_Reconcile_Test_* database.
-- Source lookups are redirected to fixture tables IN THIS DATABASE before any execution.
:ON ERROR EXIT
IF DB_NAME() NOT LIKE N'DSR[_]Reconcile[_]Test[_]%'
    THROW 51300, 'Tests require a disposable DSR_Reconcile_Test_* database.', 1;
DECLARE @CompatibilitySql NVARCHAR(300) =
    N'ALTER DATABASE ' + QUOTENAME(DB_NAME()) + N' SET COMPATIBILITY_LEVEL = 100;';
EXEC sys.sp_executesql @CompatibilitySql;
GO
CREATE TABLE dbo.lead_details
(
    lead_no VARCHAR(30) NOT NULL PRIMARY KEY,
    app_ref_no VARCHAR(50) NULL,
    lead_stage VARCHAR(50) NULL,
    Createdon_date DATETIME2(7) NULL,
    updatedon_date DATETIME2(7) NULL
);
CREATE TABLE dbo.lead_details_finance
(
    lead_no VARCHAR(30) NOT NULL PRIMARY KEY,
    LEAD_DSR NUMERIC(28,20) NULL
);
CREATE TABLE dbo.Test_OldScorecards
(
    lead_no VARCHAR(30) NOT NULL,
    method_name VARCHAR(50) NOT NULL,
    createdon_date DATETIME2(7) NOT NULL,
    RequestXML NVARCHAR(MAX) NULL
);
CREATE TABLE dbo.Test_ArchiveScorecards
(
    lead_no VARCHAR(30) NOT NULL,
    method_name VARCHAR(50) NOT NULL,
    createdon_date DATETIME2(7) NOT NULL,
    RequestXML NVARCHAR(MAX) NULL
);
CREATE TABLE dbo.Test_FinanceWrites
(
    lead_no VARCHAR(30), OldDSR NUMERIC(28,20), NewDSR NUMERIC(28,20)
);
GO
CREATE TRIGGER dbo.Test_FinanceTrigger ON dbo.lead_details_finance AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT dbo.Test_FinanceWrites
    SELECT i.lead_no, d.LEAD_DSR, i.LEAD_DSR
    FROM inserted i INNER JOIN deleted d ON d.lead_no = i.lead_no;
END;
GO
:r .\SQL\21_DSR_Scorecard_Reconcile.sql
:r .\SQL\21_DSR_Scorecard_Reconcile.sql
GO
DECLARE @Definition NVARCHAR(MAX) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.Proc_DSR_Scorecard_ReconcileMonth'));
SET @Definition = REPLACE(@Definition, N'CREATE PROCEDURE', N'ALTER PROCEDURE');
IF @Definition NOT LIKE N'%[[]tamweel_old]%' OR @Definition NOT LIKE N'%[[]tamweel_archival]%'
    THROW 51300, 'Expected production source references missing.', 1;
SET @Definition = REPLACE(@Definition,
    N'[tamweel_old].[dbo].[SOA_CallLog_SCORECARD]', N'dbo.Test_OldScorecards');
SET @Definition = REPLACE(@Definition,
    N'[tamweel_archival].[dbo].[SOA_CallLog_SCORECARD]', N'dbo.Test_ArchiveScorecards');
EXEC sys.sp_executesql @Definition;
GO
SET NOCOUNT ON;
INSERT dbo.lead_details VALUES
    ('L1', 'APP1', 'CUST_OL_ACCEPT', '20140101', '20260101'),
    ('L2', 'APP2', 'OPS_PMU', '20140105', '20260101'),
    ('L3', 'APP3', 'OPS_LODGMENT', '20140106', '20260101'),
    ('L4', 'APP4', 'End_Of_Process', '20140107', '20260101'),
    ('L5', 'APP5', 'OPS_PMU', '20140108', '20260101'),
    ('L6', 'APP6', 'OPS_PMU', '20140109', '20260101'),
    ('L7', 'APP7', 'OPS_PMU', '20140110', '20260101'),
    ('L8', 'APP8', 'OPS_PMU', '20140111', '20260101'),
    ('L9', 'APP9', 'OPS_PMU', '20140112', '20260101'),
    ('L10', 'APP10', 'OTHER', '20140113', '20140113'),
    ('L11', 'APP11', 'OPS_PMU', '20140201', '20140101'),
    ('L12', 'APP12', 'OPS_PMU', '20131231', '20140101'),
    ('L13', 'APP13', 'OPS_PMU', '2014-01-31T23:59:59.9999999', '20260101'),
    ('L14', 'APP14', 'OPS_PMU', '20140115', '20260101'),
    ('L15', 'APP15', 'OPS_PMU', '20140116', '20260101');
INSERT dbo.lead_details_finance
SELECT lead_no, CASE WHEN lead_no = 'L9' THEN NULL WHEN lead_no = 'L3' THEN 44 ELSE 10 END
FROM dbo.lead_details;
INSERT dbo.Test_OldScorecards VALUES
    ('L1', 'SAS_ScoreCard', '20140101', N'<r><Dsr>40</Dsr></r>'),
    ('L1', 'SAS_ScoreCard', '20140102', N'<r><Dsr>42.12345678901234567890</Dsr></r>'),
    ('L2', 'OTHER', '20140103', N'<r><Dsr>99</Dsr></r>'),
    ('L3', 'SAS_ScoreCard', '20140101', N'<r><Dsr>44</Dsr></r>'),
    ('L4', 'SAS_ScoreCard', '20140101', N'<r><Dsr> &#x9; </Dsr></r>'),
    ('L5', 'SAS_ScoreCard', '20140101', N'<r />'),
    ('L6', 'SAS_ScoreCard', '20140101', N'<broken'),
    ('L7', 'SAS_ScoreCard', '20140101', N'<r><Dsr>invalid</Dsr></r>'),
    ('L9', 'SAS_ScoreCard', '20140101', N'<r><Dsr>0</Dsr></r>'),
    ('L10', 'SAS_ScoreCard', '20140101', N'<r><Dsr>50</Dsr></r>'),
    ('L11', 'SAS_ScoreCard', '20140101', N'<r><Dsr>51</Dsr></r>'),
    ('L12', 'SAS_ScoreCard', '20140101', N'<r><Dsr>52</Dsr></r>'),
    ('L13', 'SAS_ScoreCard', '20140101', N'<r xmlns="urn:test"><Dsr>53</Dsr></r>'),
    ('L14', 'SAS_ScoreCard', '20140101', NULL),
    ('L15', 'SAS_ScoreCard', '20140101', N'<r><Dsr>1.123456789012345678901</Dsr></r>');
INSERT dbo.Test_ArchiveScorecards VALUES
    ('L1', 'SAS_ScoreCard', '20260101', N'<r><Dsr>99</Dsr></r>'),
    ('L2', 'SAS_ScoreCard', '20140101', N'<r><Dsr>42</Dsr></r>'),
    ('L2', 'SAS_ScoreCard', '20140102', N'<r><Dsr>43</Dsr></r>'),
    ('L4', 'SAS_ScoreCard', '20260101', N'<r><Dsr>94</Dsr></r>');

EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_State WHERE NextMonthStart = '20140201')
    THROW 51300, 'First month did not advance to February.', 1;
IF NOT EXISTS
(
    SELECT 1 FROM dbo.DSR_Scorecard_Run WHERE RunId = 1 AND RunStatus = 'Succeeded'
      AND MonthStart = '20140101' AND ToDateExclusive = '20140201'
      AND UpdatedCount = 4 AND AlreadyMatchedCount = 1 AND DeferredCount = 0 AND SkippedCount = 7 AND CandidateCount = 12
)
    THROW 51300, 'January run counts incorrect.', 1;
IF NOT EXISTS
(
    SELECT 1 FROM dbo.DSR_Scorecard_Audit
    WHERE lead_no = 'L1' AND app_ref_no = 'APP1' AND OldFinDSR = 10
      AND NewFinDSR = 42.12345678901234567890 AND SCC_DSR = NewFinDSR
      AND ScorecardDatabase = 'tamweel_old' AND IsCompleted = 1 AND Outcome = 'Updated'
      AND RecordedAtUtc BETWEEN DATEADD(MINUTE, -1, SYSUTCDATETIME()) AND SYSUTCDATETIME()
      AND RecordedAtServerTime IS NOT NULL
)
    THROW 51300, 'Precise before/after DSR, source, application or timestamps missing.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'L2'
    AND NewFinDSR = 43 AND ScorecardDatabase = 'tamweel_archival')
    THROW 51300, 'Latest archival fallback failed.', 1;
IF EXISTS (SELECT 1 FROM dbo.Test_FinanceWrites WHERE lead_no = 'L3')
    THROW 51300, 'Already-matching finance row was written.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'L3'
    AND Outcome = 'AlreadyMatched' AND IsCompleted = 1)
    THROW 51300, 'Already-matching row not marked completed.', 1;
IF EXISTS (SELECT 1 FROM dbo.lead_details_finance WHERE lead_no IN ('L4', 'L5', 'L6', 'L7', 'L8', 'L14', 'L15') AND LEAD_DSR <> 10)
    THROW 51300, 'Blank/invalid/missing source changed finance.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'L4' AND Outcome = 'BlankDSR' AND IsCompleted = 1)
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'L6' AND Outcome = 'InvalidXML')
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'L7' AND Outcome = 'InvalidDSR')
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'L8' AND Outcome = 'MissingScorecard')
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'L15' AND Outcome = 'InvalidDSR')
    THROW 51300, 'Terminal skip reasons incorrect.', 1;
IF EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE IsCompleted <> 1)
    THROW 51300, 'A logged outcome was not permanently completed.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.lead_details_finance WHERE lead_no = 'L9' AND LEAD_DSR = 0)
    THROW 51300, 'Valid zero DSR was treated as blank.', 1;
IF EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no IN ('L10', 'L11', 'L12'))
    THROW 51300, 'Stage/creation-date filters failed.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.lead_details_finance WHERE lead_no = 'L13' AND LEAD_DSR = 53)
    THROW 51300, 'End of month or namespaced XML failed.', 1;

-- A revisit must skip completed leads, even if an external process changes finance afterward.
UPDATE dbo.lead_details_finance SET LEAD_DSR = 11 WHERE lead_no IN ('L1', 'L3');
UPDATE dbo.Test_OldScorecards SET RequestXML = N'<r><Dsr>54</Dsr></r>'
WHERE lead_no IN ('L4', 'L5', 'L6', 'L7', 'L14', 'L15');
INSERT dbo.Test_OldScorecards VALUES ('L8', 'SAS_ScoreCard', '20140101', N'<r><Dsr>54</Dsr></r>');
DECLARE @AuditCount INT = (SELECT COUNT(*) FROM dbo.DSR_Scorecard_Audit);
DECLARE @WriteCount INT = (SELECT COUNT(*) FROM dbo.Test_FinanceWrites);
UPDATE dbo.DSR_Scorecard_State SET NextMonthStart = '20140101';
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
IF (SELECT COUNT(*) FROM dbo.DSR_Scorecard_Audit WHERE lead_no IN ('L1', 'L3')) <> 2
    THROW 51300, 'Completed leads were processed again.', 1;
IF EXISTS (SELECT 1 FROM dbo.lead_details_finance WHERE lead_no IN ('L1', 'L3') AND LEAD_DSR <> 11)
    THROW 51300, 'Permanently completed lead was updated again.', 1;
IF EXISTS (SELECT 1 FROM dbo.lead_details_finance
    WHERE lead_no IN ('L4', 'L5', 'L6', 'L7', 'L8', 'L14', 'L15') AND LEAD_DSR <> 10)
    OR (SELECT COUNT(*) FROM dbo.DSR_Scorecard_Audit) <> @AuditCount
    OR (SELECT COUNT(*) FROM dbo.Test_FinanceWrites) <> @WriteCount
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Run WHERE RunId = 2 AND CandidateCount = 0 AND SkippedCount = 0)
    THROW 51300, 'Previously missing, blank or invalid scorecard was processed again after correction.', 1;

EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
IF NOT EXISTS (SELECT 1 FROM dbo.lead_details_finance WHERE lead_no = 'L11' AND LEAD_DSR = 51)
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_State WHERE NextMonthStart = '20140301')
    THROW 51300, 'Second calendar-month progression failed.', 1;
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Run WHERE MonthStart = '20140301' AND CandidateCount = 0 AND RunStatus = 'Succeeded')
    THROW 51300, 'Empty month did not complete successfully.', 1;

-- A finance trigger failure must roll back both earlier writes and completion records.
INSERT dbo.lead_details VALUES ('FAIL1', 'APP_FAIL1', 'OPS_PMU', '20140401', '20260101');
INSERT dbo.lead_details_finance VALUES ('FAIL1', 10);
INSERT dbo.Test_OldScorecards VALUES ('FAIL1', 'SAS_ScoreCard', '20140401', N'<r><Dsr>60</Dsr></r>');
GO
CREATE TRIGGER dbo.Test_RejectFinance ON dbo.lead_details_finance AFTER UPDATE
AS
BEGIN
    IF EXISTS (SELECT 1 FROM inserted WHERE lead_no = 'FAIL1')
        THROW 51301, 'Deliberate finance trigger failure.', 1;
END;
GO
DECLARE @Caught BIT = 0;
BEGIN TRY
    EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() <> 51301 THROW;
    SET @Caught = 1;
END CATCH;
IF @Caught = 0 THROW 51300, 'Expected trigger failure did not occur.', 1;
IF EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'FAIL1')
    OR EXISTS (SELECT 1 FROM dbo.lead_details_finance WHERE lead_no = 'FAIL1' AND LEAD_DSR <> 10)
    OR EXISTS (SELECT 1 FROM dbo.Test_FinanceWrites WHERE lead_no = 'FAIL1')
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_State WHERE NextMonthStart = '20140401')
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Run WHERE MonthStart = '20140401'
        AND RunStatus = 'Failed' AND ErrorNumber = 51301 AND FinishedAtUtc IS NOT NULL)
    THROW 51300, 'Failed month left finance/audit changes, lost cursor or missing failure log.', 1;
DROP TRIGGER dbo.Test_RejectFinance;
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'FAIL1' AND Outcome = 'Updated')
    THROW 51300, 'Failed month could not be retried.', 1;

-- Destination overflow: preserve entire month and log the failure.
INSERT dbo.lead_details VALUES ('OVERFLOW', 'APP_OVERFLOW', 'OPS_PMU', '20140501', '20260101');
INSERT dbo.lead_details_finance VALUES ('OVERFLOW', 10);
INSERT dbo.Test_OldScorecards VALUES ('OVERFLOW', 'SAS_ScoreCard', '20140501', N'<r><Dsr>100000000</Dsr></r>');
SET @Caught = 0;
BEGIN TRY
    EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() <> 8115 THROW;
    SET @Caught = 1;
END CATCH;
IF @Caught = 0 OR EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'OVERFLOW')
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_State WHERE NextMonthStart = '20140501')
    THROW 51300, 'Overflow was not atomic/retryable.', 1;
UPDATE dbo.Test_OldScorecards SET RequestXML = N'<r><Dsr>61</Dsr></r>' WHERE lead_no = 'OVERFLOW';
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;

-- Tied latest source timestamps cannot choose an arbitrary value for an update.
INSERT dbo.lead_details VALUES ('TIE', 'APP_TIE', 'OPS_PMU', '20140601', '20260101');
INSERT dbo.lead_details_finance VALUES ('TIE', 10);
INSERT dbo.Test_OldScorecards VALUES
    ('TIE', 'SAS_ScoreCard', '20140601', N'<r><Dsr>62</Dsr></r>'),
    ('TIE', 'SAS_ScoreCard', '20140601', N'<r><Dsr>63</Dsr></r>');
SET @Caught = 0;
BEGIN TRY
    EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() <> 51109 THROW;
    SET @Caught = 1;
END CATCH;
IF @Caught = 0 OR EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'TIE')
    THROW 51300, 'Ambiguous latest scorecard was updated.', 1;
DELETE dbo.Test_OldScorecards WHERE lead_no = 'TIE' AND RequestXML LIKE '%63%';
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;

-- A lower-scale destination must fail rather than round the selected DSR.
ALTER TABLE dbo.lead_details_finance ALTER COLUMN LEAD_DSR NUMERIC(28,2) NULL;
INSERT dbo.lead_details VALUES ('SCALE', 'APP_SCALE', 'OPS_PMU', '20140701', '20260101');
INSERT dbo.lead_details_finance VALUES ('SCALE', 10);
INSERT dbo.Test_OldScorecards VALUES ('SCALE', 'SAS_ScoreCard', '20140701', N'<r><Dsr>62.123</Dsr></r>');
SET @Caught = 0;
BEGIN TRY
    EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() <> 51106 THROW;
    SET @Caught = 1;
END CATCH;
IF @Caught = 0 OR EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'SCALE')
    OR EXISTS (SELECT 1 FROM dbo.lead_details_finance WHERE lead_no = 'SCALE' AND LEAD_DSR <> 10)
    THROW 51300, 'Destination precision loss was not rejected.', 1;
ALTER TABLE dbo.lead_details_finance ALTER COLUMN LEAD_DSR NUMERIC(28,20) NULL;
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;

-- Archival ties must also fail the month, not choose an arbitrary value.
INSERT dbo.lead_details VALUES ('ARCH_TIE', 'APP_ARCH_TIE', 'OPS_PMU', '20140801', '20260101');
INSERT dbo.lead_details_finance VALUES ('ARCH_TIE', 10);
INSERT dbo.Test_ArchiveScorecards VALUES
    ('ARCH_TIE', 'SAS_ScoreCard', '20140801', N'<r><Dsr>63</Dsr></r>'),
    ('ARCH_TIE', 'SAS_ScoreCard', '20140801', N'<r><Dsr>64</Dsr></r>');
SET @Caught = 0;
BEGIN TRY
    EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() NOT IN (2601, 2627) THROW;
    SET @Caught = 1;
END CATCH;
IF @Caught = 0 OR EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'ARCH_TIE')
    THROW 51300, 'Ambiguous archival scorecard was updated.', 1;
DELETE dbo.Test_ArchiveScorecards WHERE lead_no = 'ARCH_TIE' AND RequestXML LIKE '%64%';
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;

-- An AUDIT write failure must roll back a successful finance write too.
INSERT dbo.lead_details VALUES ('AUDIT_FAIL', 'APP_AUDIT_FAIL', 'OPS_PMU', '20140901', '20260101');
INSERT dbo.lead_details_finance VALUES ('AUDIT_FAIL', 10);
INSERT dbo.Test_OldScorecards VALUES ('AUDIT_FAIL', 'SAS_ScoreCard', '20140901', N'<r><Dsr>64</Dsr></r>');
GO
CREATE TRIGGER dbo.Test_RejectAudit ON dbo.DSR_Scorecard_Audit AFTER INSERT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM inserted WHERE lead_no = 'AUDIT_FAIL')
        THROW 51302, 'Deliberate audit trigger failure.', 1;
END;
GO
DECLARE @Caught BIT = 0;
BEGIN TRY
    EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() <> 51302 THROW;
    SET @Caught = 1;
END CATCH;
IF @Caught = 0 OR EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'AUDIT_FAIL')
    OR EXISTS (SELECT 1 FROM dbo.lead_details_finance WHERE lead_no = 'AUDIT_FAIL' AND LEAD_DSR <> 10)
    OR EXISTS (SELECT 1 FROM dbo.Test_FinanceWrites WHERE lead_no = 'AUDIT_FAIL')
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_State WHERE NextMonthStart = '20140901')
    THROW 51300, 'Audit failure did not roll back finance, completion and cursor.', 1;
DROP TRIGGER dbo.Test_RejectAudit;
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;

-- Compatibility-100 parsing must preserve long Unicode XML and reject oversized DSR text.
INSERT dbo.lead_details VALUES
    ('LONG_XML', 'APP_LONG_XML', 'OPS_PMU', '20141001', '20260101'),
    ('LONG_BAD_XML', 'APP_LONG_BAD_XML', 'OPS_PMU', '20141001', '20260101'),
    ('LONG_DSR', 'APP_LONG_DSR', 'OPS_PMU', '20141001', '20260101');
INSERT dbo.lead_details_finance VALUES ('LONG_XML', 10), ('LONG_BAD_XML', 10), ('LONG_DSR', 10);
INSERT dbo.Test_OldScorecards VALUES
    ('LONG_XML', 'SAS_ScoreCard', '20141001',
        N'<r><padding>' + REPLICATE(CONVERT(NVARCHAR(MAX), NCHAR(937) + NCHAR(20013)), 5000)
        + N'</padding><Dsr>66.125</Dsr></r>'),
    ('LONG_BAD_XML', 'SAS_ScoreCard', '20141001',
        N'<r><padding>' + REPLICATE(CONVERT(NVARCHAR(MAX), N'x'), 10000)),
    ('LONG_DSR', 'SAS_ScoreCard', '20141001',
        N'<r><Dsr>7' + REPLICATE(CONVERT(NVARCHAR(MAX), N' '), 5000) + N'bad</Dsr></r>');
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit
    WHERE lead_no = 'LONG_XML' AND NewFinDSR = 66.125 AND Outcome = 'Updated' AND IsCompleted = 1)
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit
    WHERE lead_no = 'LONG_BAD_XML' AND Outcome = 'InvalidXML' AND IsCompleted = 1)
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit
    WHERE lead_no = 'LONG_DSR' AND Outcome = 'InvalidDSR' AND IsCompleted = 1 AND SCC_DSR IS NULL)
    OR EXISTS (SELECT 1 FROM dbo.lead_details_finance
    WHERE lead_no IN ('LONG_BAD_XML', 'LONG_DSR') AND LEAD_DSR <> 10)
    THROW 51300, 'Long XML/DSR compatibility regression: truncation, lost Unicode or incorrect completion.', 1;

-- Current month includes all of today, excludes tomorrow, and wraps back to January 2014.
DECLARE @Today DATE = CONVERT(DATE, GETDATE());
DECLARE @CurrentMonth DATE = DATEFROMPARTS(YEAR(@Today), MONTH(@Today), 1);
INSERT dbo.lead_details VALUES
    ('TODAY', 'APP_TODAY', 'OPS_PMU', CONVERT(DATETIME2, @Today), '20140101'),
    ('FUTURE', 'APP_FUTURE', 'OPS_PMU', DATEADD(DAY, 1, CONVERT(DATETIME2, @Today)), '20140101');
INSERT dbo.lead_details_finance VALUES ('TODAY', 10), ('FUTURE', 10);
INSERT dbo.Test_OldScorecards VALUES
    ('TODAY', 'SAS_ScoreCard', @Today, N'<r><Dsr>64</Dsr></r>'),
    ('FUTURE', 'SAS_ScoreCard', @Today, N'<r><Dsr>65</Dsr></r>');
UPDATE dbo.DSR_Scorecard_State SET NextMonthStart = @CurrentMonth;
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'TODAY' AND Outcome = 'Updated')
    OR EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit WHERE lead_no = 'FUTURE')
    OR NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_State WHERE NextMonthStart = '20140101')
    THROW 51300, 'Current-date boundary or cursor cycle failed.', 1;

-- Recover a previous terminated run and reject ambient transactions without changing them.
INSERT dbo.DSR_Scorecard_Run
    (MonthStart, ToDateExclusive, StartedAtUtc, RunStatus, DatabaseLogin)
VALUES ('20140101', '20140201', SYSUTCDATETIME(), 'Running', ORIGINAL_LOGIN());
DECLARE @AbandonedRun BIGINT = SCOPE_IDENTITY();
EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
IF NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Run WHERE RunId = @AbandonedRun AND RunStatus = 'Failed' AND ErrorNumber = 51104)
    THROW 51300, 'Abandoned run not marked failed.', 1;
SET @Caught = 0;
BEGIN TRANSACTION;
BEGIN TRY
    EXEC dbo.Proc_DSR_Scorecard_ReconcileMonth;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() <> 51101
    BEGIN
        ROLLBACK TRANSACTION;
        THROW;
    END;
    SET @Caught = 1;
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
IF @Caught = 0 THROW 51300, 'Ambient transaction was accepted.', 1;

-- Simulate legacy deferred history, including repeated attempts for the same lead.
UPDATE dbo.DSR_Scorecard_Audit SET IsCompleted = 0
WHERE Outcome IN ('MissingScorecard', 'BlankDSR', 'InvalidXML', 'InvalidDSR');
ALTER TABLE dbo.DSR_Scorecard_Audit DROP CONSTRAINT CK_DSR_Scorecard_Audit_Outcome;
ALTER TABLE dbo.DSR_Scorecard_Audit ADD CONSTRAINT CK_DSR_Scorecard_Audit_Outcome CHECK
(
    (IsCompleted = 1 AND Outcome IN ('Updated', 'AlreadyMatched') AND SCC_DSR IS NOT NULL)
    OR (IsCompleted = 0 AND Outcome IN ('MissingScorecard', 'BlankDSR', 'InvalidXML', 'InvalidDSR'))
);
INSERT dbo.DSR_Scorecard_Audit
(
    RunId, lead_no, app_ref_no, lead_stage, LeadCreatedOn, OldFinDSR, NewFinDSR,
    SCC_DSR, ScorecardDsrText, ScorecardDatabase, ScorecardCreatedOn,
    RecordedAtUtc, RecordedAtServerTime, Outcome, IsCompleted, Detail
)
SELECT RunId, lead_no, app_ref_no, lead_stage, LeadCreatedOn, OldFinDSR, NewFinDSR,
    SCC_DSR, ScorecardDsrText, ScorecardDatabase, ScorecardCreatedOn,
    RecordedAtUtc, RecordedAtServerTime, Outcome, IsCompleted, Detail
FROM dbo.DSR_Scorecard_Audit WHERE lead_no IN ('L4', 'L8');
ALTER TABLE dbo.DSR_Scorecard_Run DROP COLUMN SkippedCount;
SELECT COUNT(*) AS AuditCount INTO #MigrationSnapshot FROM dbo.DSR_Scorecard_Audit;
SELECT NextMonthStart, LastRunId INTO #CursorSnapshot FROM dbo.DSR_Scorecard_State;
GO
:r .\SQL\21_DSR_Scorecard_Reconcile.sql
:r .\SQL\21_DSR_Scorecard_Reconcile.sql
GO
IF (SELECT COUNT(*) FROM dbo.DSR_Scorecard_Audit) <> (SELECT AuditCount FROM #MigrationSnapshot)
    THROW 51300, 'Terminal-policy migration changed the audit history row count.', 1;
IF EXISTS
(
    SELECT 1 FROM dbo.DSR_Scorecard_Audit a
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DSR_Scorecard_Audit done
        WHERE done.lead_no = a.lead_no AND done.IsCompleted = 1)
)
    THROW 51300, 'Legacy audited lead was not permanently completed.', 1;
IF EXISTS
(
    SELECT 1 FROM dbo.DSR_Scorecard_Audit a
    WHERE a.Outcome IN ('MissingScorecard', 'BlankDSR', 'InvalidXML', 'InvalidDSR') AND a.IsCompleted = 1
      AND a.AuditId <> (SELECT MAX(lastAttempt.AuditId) FROM dbo.DSR_Scorecard_Audit lastAttempt WHERE lastAttempt.lead_no = a.lead_no)
)
    THROW 51300, 'Migration did not complete the most recent legacy attempt.', 1;
IF EXISTS
(
    SELECT NextMonthStart, LastRunId FROM dbo.DSR_Scorecard_State
    EXCEPT SELECT NextMonthStart, LastRunId FROM #CursorSnapshot
)
    OR COL_LENGTH(N'dbo.DSR_Scorecard_Run', N'SkippedCount') IS NULL
    THROW 51300, 'Migration changed the cursor or failed to add the terminal-skip counter.', 1;
PRINT 'PASS: compatibility 100, long Unicode XML, oversized DSR, all outcomes terminal, legacy history migration, monthly processing, precision, rollback and recovery.';
GO
