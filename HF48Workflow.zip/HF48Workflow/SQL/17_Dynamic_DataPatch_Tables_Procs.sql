USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Script 17: Dynamic Data Patch Maker/Checker
-- =============================================

IF OBJECT_ID('[dbo].[DDP_Audit]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[DDP_Audit]
    (
        AuditId       INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        EntityName    NVARCHAR(100) NOT NULL,
        EntityId      INT NULL,
        ActionName    NVARCHAR(50) NOT NULL,
        ActionBy      NVARCHAR(100) NOT NULL,
        ActionOn      DATETIME NOT NULL DEFAULT GETDATE(),
        Remarks       NVARCHAR(1000) NULL,
        OldData       NVARCHAR(MAX) NULL,
        NewData       NVARCHAR(MAX) NULL
    )
END
GO

IF OBJECT_ID('[dbo].[DDP_UserAccess]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[DDP_UserAccess]
    (
        AccessId      INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        LoginId       NVARCHAR(100) NOT NULL UNIQUE,
        CanAdmin      BIT NOT NULL DEFAULT 0,
        CanMake       BIT NOT NULL DEFAULT 0,
        CanCheck      BIT NOT NULL DEFAULT 0,
        IsActive      BIT NOT NULL DEFAULT 1,
        CreatedBy     NVARCHAR(100) NULL,
        CreatedOn     DATETIME NOT NULL DEFAULT GETDATE(),
        UpdatedBy     NVARCHAR(100) NULL,
        UpdatedOn     DATETIME NULL
    )
END
GO

IF OBJECT_ID('[dbo].[DDP_TableConfig]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[DDP_TableConfig]
    (
        ConfigId          INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        SchemaName        SYSNAME NOT NULL DEFAULT 'dbo',
        TableName         SYSNAME NOT NULL,
        FriendlyName      NVARCHAR(200) NOT NULL,
        PrimaryKeyColumn  SYSNAME NOT NULL,
        DisplayColumnsCsv NVARCHAR(1000) NULL,
        IsActive          BIT NOT NULL DEFAULT 1,
        CreatedBy         NVARCHAR(100) NULL,
        CreatedOn         DATETIME NOT NULL DEFAULT GETDATE(),
        UpdatedBy         NVARCHAR(100) NULL,
        UpdatedOn         DATETIME NULL,
        CONSTRAINT UQ_DDP_TableConfig UNIQUE (SchemaName, TableName)
    )
END
GO

IF OBJECT_ID('[dbo].[DDP_FieldConfig]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[DDP_FieldConfig]
    (
        FieldConfigId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        ConfigId      INT NOT NULL,
        ColumnName    SYSNAME NOT NULL,
        DisplayName   NVARCHAR(200) NOT NULL,
        DataType      NVARCHAR(100) NOT NULL,
        IsEditable    BIT NOT NULL DEFAULT 0,
        IsRequired    BIT NOT NULL DEFAULT 0,
        SortOrder     INT NOT NULL DEFAULT 0,
        CreatedOn     DATETIME NOT NULL DEFAULT GETDATE(),
        UpdatedOn     DATETIME NULL,
        CONSTRAINT FK_DDP_FieldConfig_TableConfig FOREIGN KEY (ConfigId) REFERENCES [dbo].[DDP_TableConfig](ConfigId),
        CONSTRAINT UQ_DDP_FieldConfig UNIQUE (ConfigId, ColumnName)
    )
END
GO

IF OBJECT_ID('[dbo].[DDP_Request]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[DDP_Request]
    (
        RequestId       INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        ConfigId        INT NOT NULL,
        PrimaryKeyValue NVARCHAR(500) NOT NULL,
        RecordCaption   NVARCHAR(1000) NULL,
        MakerLoginId    NVARCHAR(100) NOT NULL,
        CheckerLoginId  NVARCHAR(100) NOT NULL,
        StatusCode      CHAR(1) NOT NULL DEFAULT 'P',
        MakerRemarks    NVARCHAR(1000) NULL,
        CheckerRemarks  NVARCHAR(1000) NULL,
        SubmittedOn     DATETIME NOT NULL DEFAULT GETDATE(),
        CheckedOn       DATETIME NULL,
        CONSTRAINT FK_DDP_Request_TableConfig FOREIGN KEY (ConfigId) REFERENCES [dbo].[DDP_TableConfig](ConfigId)
    )
END
GO

IF OBJECT_ID('[dbo].[DDP_RequestDetail]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[DDP_RequestDetail]
    (
        DetailId      INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        RequestId     INT NOT NULL,
        FieldConfigId INT NOT NULL,
        ColumnName    SYSNAME NOT NULL,
        DisplayName   NVARCHAR(200) NOT NULL,
        OldValue      NVARCHAR(MAX) NULL,
        NewValue      NVARCHAR(MAX) NULL,
        CONSTRAINT FK_DDP_RequestDetail_Request FOREIGN KEY (RequestId) REFERENCES [dbo].[DDP_Request](RequestId),
        CONSTRAINT FK_DDP_RequestDetail_FieldConfig FOREIGN KEY (FieldConfigId) REFERENCES [dbo].[DDP_FieldConfig](FieldConfigId)
    )
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetUsers]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetUsers]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetUsers]
    @OnlyCheckers BIT = 0
AS
BEGIN
    SET NOCOUNT ON

    SELECT DISTINCT u.LoginId
    FROM [dbo].[FRM_user] u
    LEFT JOIN [dbo].[DDP_UserAccess] a ON a.LoginId = u.LoginId AND a.IsActive = 1
    WHERE ISNULL(u.LoginId, '') <> ''
      AND (@OnlyCheckers = 0 OR a.CanCheck = 1)
    ORDER BY u.LoginId
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetUserAccess]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetUserAccess]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetUserAccess]
AS
BEGIN
    SET NOCOUNT ON

    SELECT a.AccessId, a.LoginId, a.CanAdmin, a.CanMake, a.CanCheck, a.IsActive,
           a.CreatedBy, a.CreatedOn, a.UpdatedBy, a.UpdatedOn
    FROM [dbo].[DDP_UserAccess] a
    ORDER BY a.LoginId
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_SaveUserAccess]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_SaveUserAccess]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_SaveUserAccess]
    @LoginId   NVARCHAR(100),
    @CanAdmin  BIT,
    @CanMake   BIT,
    @CanCheck  BIT,
    @IsActive  BIT,
    @ActionBy  NVARCHAR(100),
    @Status    NVARCHAR(50) OUTPUT,
    @Message   NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    IF NOT EXISTS (SELECT 1 FROM [dbo].[FRM_user] WHERE LoginId = @LoginId)
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'LoginId does not exist in FRM_user.'
        RETURN
    END

    IF EXISTS (SELECT 1 FROM [dbo].[DDP_UserAccess] WHERE LoginId = @LoginId)
        UPDATE [dbo].[DDP_UserAccess]
        SET CanAdmin = @CanAdmin, CanMake = @CanMake, CanCheck = @CanCheck,
            IsActive = @IsActive, UpdatedBy = @ActionBy, UpdatedOn = GETDATE()
        WHERE LoginId = @LoginId
    ELSE
        INSERT INTO [dbo].[DDP_UserAccess]
            (LoginId, CanAdmin, CanMake, CanCheck, IsActive, CreatedBy, CreatedOn)
        VALUES
            (@LoginId, @CanAdmin, @CanMake, @CanCheck, @IsActive, @ActionBy, GETDATE())

    INSERT INTO [dbo].[DDP_Audit](EntityName, EntityId, ActionName, ActionBy, Remarks, NewData)
    VALUES('DDP_UserAccess', NULL, 'SAVE_USER_ACCESS', @ActionBy, @LoginId,
           'CanAdmin=' + CAST(@CanAdmin AS NVARCHAR(1)) + ';CanMake=' + CAST(@CanMake AS NVARCHAR(1)) + ';CanCheck=' + CAST(@CanCheck AS NVARCHAR(1)))

    SET @Status = 'SUCCESS'
    SET @Message = 'User access saved.'
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetAvailableTables]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetAvailableTables]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetAvailableTables]
AS
BEGIN
    SET NOCOUNT ON

    SELECT s.name AS SchemaName, t.name AS TableName,
           s.name + '.' + t.name AS FullTableName,
           CASE WHEN c.ConfigId IS NULL THEN 0 ELSE 1 END AS IsConfigured
    FROM sys.tables t
    INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
    LEFT JOIN [dbo].[DDP_TableConfig] c ON c.SchemaName = s.name AND c.TableName = t.name
    WHERE t.is_ms_shipped = 0
      AND t.name NOT LIKE 'DDP[_]%'
    ORDER BY s.name, t.name
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetTableColumns]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetTableColumns]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetTableColumns]
    @SchemaName SYSNAME,
    @TableName  SYSNAME
AS
BEGIN
    SET NOCOUNT ON

    SELECT c.COLUMN_NAME AS ColumnName,
           c.DATA_TYPE AS DataType,
           CASE WHEN pk.COLUMN_NAME IS NULL THEN 0 ELSE 1 END AS IsPrimaryKey
    FROM INFORMATION_SCHEMA.COLUMNS c
    LEFT JOIN (
        SELECT ku.TABLE_SCHEMA, ku.TABLE_NAME, ku.COLUMN_NAME
        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
        INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE ku
            ON tc.CONSTRAINT_NAME = ku.CONSTRAINT_NAME
           AND tc.TABLE_SCHEMA = ku.TABLE_SCHEMA
           AND tc.TABLE_NAME = ku.TABLE_NAME
        WHERE tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
    ) pk ON pk.TABLE_SCHEMA = c.TABLE_SCHEMA AND pk.TABLE_NAME = c.TABLE_NAME AND pk.COLUMN_NAME = c.COLUMN_NAME
    WHERE c.TABLE_SCHEMA = @SchemaName
      AND c.TABLE_NAME = @TableName
      AND c.DATA_TYPE NOT IN ('image', 'timestamp', 'rowversion', 'varbinary', 'binary')
    ORDER BY c.ORDINAL_POSITION
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetTableConfig]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetTableConfig]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetTableConfig]
    @OnlyActive BIT = 0
AS
BEGIN
    SET NOCOUNT ON

    SELECT ConfigId, SchemaName, TableName, FriendlyName, PrimaryKeyColumn, DisplayColumnsCsv,
           IsActive, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn,
           SchemaName + '.' + TableName AS FullTableName
    FROM [dbo].[DDP_TableConfig]
    WHERE @OnlyActive = 0 OR IsActive = 1
    ORDER BY FriendlyName
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_SaveTableConfig]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_SaveTableConfig]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_SaveTableConfig]
    @ConfigId          INT = 0,
    @SchemaName        SYSNAME,
    @TableName         SYSNAME,
    @FriendlyName      NVARCHAR(200),
    @PrimaryKeyColumn  SYSNAME,
    @DisplayColumnsCsv NVARCHAR(1000) = NULL,
    @IsActive          BIT,
    @ActionBy          NVARCHAR(100),
    @SavedConfigId     INT OUTPUT,
    @Status            NVARCHAR(50) OUTPUT,
    @Message           NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @PrimaryKeyColumn)
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'Primary key column is not valid for selected table.'
        RETURN
    END

    IF @ConfigId = 0
    BEGIN
        IF EXISTS (SELECT 1 FROM [dbo].[DDP_TableConfig] WHERE SchemaName = @SchemaName AND TableName = @TableName)
            SELECT @ConfigId = ConfigId FROM [dbo].[DDP_TableConfig] WHERE SchemaName = @SchemaName AND TableName = @TableName
    END

    IF ISNULL(@ConfigId, 0) = 0
    BEGIN
        INSERT INTO [dbo].[DDP_TableConfig]
            (SchemaName, TableName, FriendlyName, PrimaryKeyColumn, DisplayColumnsCsv, IsActive, CreatedBy, CreatedOn)
        VALUES
            (@SchemaName, @TableName, @FriendlyName, @PrimaryKeyColumn, @DisplayColumnsCsv, @IsActive, @ActionBy, GETDATE())

        SET @SavedConfigId = SCOPE_IDENTITY()
    END
    ELSE
    BEGIN
        UPDATE [dbo].[DDP_TableConfig]
        SET SchemaName = @SchemaName, TableName = @TableName, FriendlyName = @FriendlyName,
            PrimaryKeyColumn = @PrimaryKeyColumn, DisplayColumnsCsv = @DisplayColumnsCsv,
            IsActive = @IsActive, UpdatedBy = @ActionBy, UpdatedOn = GETDATE()
        WHERE ConfigId = @ConfigId

        SET @SavedConfigId = @ConfigId
    END

    INSERT INTO [dbo].[DDP_Audit](EntityName, EntityId, ActionName, ActionBy, Remarks, NewData)
    VALUES('DDP_TableConfig', @SavedConfigId, 'SAVE_TABLE_CONFIG', @ActionBy, @SchemaName + '.' + @TableName, @FriendlyName)

    SET @Status = 'SUCCESS'
    SET @Message = 'Table configuration saved. Configure editable fields below.'
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_RefreshFieldConfig]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_RefreshFieldConfig]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_RefreshFieldConfig]
    @ConfigId INT,
    @ActionBy NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @SchemaName SYSNAME, @TableName SYSNAME, @PrimaryKeyColumn SYSNAME
    SELECT @SchemaName = SchemaName, @TableName = TableName, @PrimaryKeyColumn = PrimaryKeyColumn
    FROM [dbo].[DDP_TableConfig]
    WHERE ConfigId = @ConfigId

    INSERT INTO [dbo].[DDP_FieldConfig]
        (ConfigId, ColumnName, DisplayName, DataType, IsEditable, IsRequired, SortOrder)
    SELECT @ConfigId, c.COLUMN_NAME, c.COLUMN_NAME, c.DATA_TYPE,
           CASE WHEN c.COLUMN_NAME = @PrimaryKeyColumn THEN 0 ELSE 1 END,
           0,
           c.ORDINAL_POSITION
    FROM INFORMATION_SCHEMA.COLUMNS c
    WHERE c.TABLE_SCHEMA = @SchemaName
      AND c.TABLE_NAME = @TableName
      AND c.DATA_TYPE NOT IN ('image', 'timestamp', 'rowversion', 'varbinary', 'binary')
      AND NOT EXISTS (
          SELECT 1 FROM [dbo].[DDP_FieldConfig] f
          WHERE f.ConfigId = @ConfigId AND f.ColumnName = c.COLUMN_NAME
      )

    INSERT INTO [dbo].[DDP_Audit](EntityName, EntityId, ActionName, ActionBy, Remarks)
    VALUES('DDP_FieldConfig', @ConfigId, 'REFRESH_FIELDS', @ActionBy, 'Field list refreshed from INFORMATION_SCHEMA')
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetFieldConfig]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetFieldConfig]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetFieldConfig]
    @ConfigId INT,
    @OnlyEditable BIT = 0
AS
BEGIN
    SET NOCOUNT ON

    SELECT FieldConfigId, ConfigId, ColumnName, DisplayName, DataType, IsEditable, IsRequired, SortOrder
    FROM [dbo].[DDP_FieldConfig]
    WHERE ConfigId = @ConfigId
      AND (@OnlyEditable = 0 OR IsEditable = 1)
    ORDER BY SortOrder, ColumnName
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_SaveFieldConfig]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_SaveFieldConfig]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_SaveFieldConfig]
    @FieldConfigId INT,
    @DisplayName   NVARCHAR(200),
    @IsEditable    BIT,
    @IsRequired    BIT,
    @SortOrder     INT,
    @ActionBy      NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON

    UPDATE [dbo].[DDP_FieldConfig]
    SET DisplayName = @DisplayName,
        IsEditable = @IsEditable,
        IsRequired = @IsRequired,
        SortOrder = @SortOrder,
        UpdatedOn = GETDATE()
    WHERE FieldConfigId = @FieldConfigId

    INSERT INTO [dbo].[DDP_Audit](EntityName, EntityId, ActionName, ActionBy, Remarks)
    VALUES('DDP_FieldConfig', @FieldConfigId, 'SAVE_FIELD_CONFIG', @ActionBy, @DisplayName)
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetRecordForPatch]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetRecordForPatch]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetRecordForPatch]
    @ConfigId INT,
    @PrimaryKeyValue NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @SchemaName SYSNAME, @TableName SYSNAME, @PrimaryKeyColumn SYSNAME
    SELECT @SchemaName = SchemaName, @TableName = TableName, @PrimaryKeyColumn = PrimaryKeyColumn
    FROM [dbo].[DDP_TableConfig]
    WHERE ConfigId = @ConfigId AND IsActive = 1

    IF @SchemaName IS NULL RETURN

    CREATE TABLE #PatchFields
    (
        FieldConfigId INT,
        ColumnName SYSNAME,
        DisplayName NVARCHAR(200),
        DataType NVARCHAR(100),
        IsRequired BIT,
        OldValue NVARCHAR(MAX) NULL
    )

    DECLARE @FieldConfigId INT, @ColumnName SYSNAME, @DisplayName NVARCHAR(200), @DataType NVARCHAR(100), @IsRequired BIT
    DECLARE field_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT FieldConfigId, ColumnName, DisplayName, DataType, IsRequired
        FROM [dbo].[DDP_FieldConfig]
        WHERE ConfigId = @ConfigId AND IsEditable = 1
        ORDER BY SortOrder, ColumnName

    OPEN field_cursor
    FETCH NEXT FROM field_cursor INTO @FieldConfigId, @ColumnName, @DisplayName, @DataType, @IsRequired
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @Value NVARCHAR(MAX), @Sql NVARCHAR(MAX)
        SET @Sql = N'SELECT @Value = CONVERT(NVARCHAR(MAX), ' + QUOTENAME(@ColumnName) + N') FROM ' +
                   QUOTENAME(@SchemaName) + N'.' + QUOTENAME(@TableName) +
                   N' WHERE CONVERT(NVARCHAR(500), ' + QUOTENAME(@PrimaryKeyColumn) + N') = @Pk'

        EXEC sp_executesql @Sql, N'@Pk NVARCHAR(500), @Value NVARCHAR(MAX) OUTPUT', @PrimaryKeyValue, @Value OUTPUT

        INSERT INTO #PatchFields(FieldConfigId, ColumnName, DisplayName, DataType, IsRequired, OldValue)
        VALUES(@FieldConfigId, @ColumnName, @DisplayName, @DataType, @IsRequired, @Value)

        FETCH NEXT FROM field_cursor INTO @FieldConfigId, @ColumnName, @DisplayName, @DataType, @IsRequired
    END
    CLOSE field_cursor
    DEALLOCATE field_cursor

    SELECT FieldConfigId, ColumnName, DisplayName, DataType, IsRequired, OldValue
    FROM #PatchFields
    ORDER BY FieldConfigId
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_SubmitRequest]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_SubmitRequest]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_SubmitRequest]
    @ConfigId          INT,
    @PrimaryKeyValue   NVARCHAR(500),
    @CheckerLoginId    NVARCHAR(100),
    @MakerLoginId      NVARCHAR(100),
    @MakerRemarks      NVARCHAR(1000) = NULL,
    @ChangedFieldsXml  XML,
    @RequestId         INT OUTPUT,
    @Status            NVARCHAR(50) OUTPUT,
    @Message           NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    BEGIN TRY
        BEGIN TRANSACTION T_DDP_SUBMIT

        IF NOT EXISTS (SELECT 1 FROM [dbo].[DDP_UserAccess] WHERE LoginId = @MakerLoginId AND CanMake = 1 AND IsActive = 1)
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'Current user is not configured as maker.'
            ROLLBACK TRANSACTION T_DDP_SUBMIT
            RETURN
        END

        IF NOT EXISTS (SELECT 1 FROM [dbo].[DDP_UserAccess] WHERE LoginId = @CheckerLoginId AND CanCheck = 1 AND IsActive = 1)
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'Selected user is not configured as checker.'
            ROLLBACK TRANSACTION T_DDP_SUBMIT
            RETURN
        END

        IF @MakerLoginId = @CheckerLoginId
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'Maker and checker cannot be the same user.'
            ROLLBACK TRANSACTION T_DDP_SUBMIT
            RETURN
        END

        DECLARE @SchemaName SYSNAME, @TableName SYSNAME, @PrimaryKeyColumn SYSNAME, @FriendlyName NVARCHAR(200)
        SELECT @SchemaName = SchemaName, @TableName = TableName, @PrimaryKeyColumn = PrimaryKeyColumn, @FriendlyName = FriendlyName
        FROM [dbo].[DDP_TableConfig]
        WHERE ConfigId = @ConfigId AND IsActive = 1

        IF @SchemaName IS NULL
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'Selected table is not configured for data patch.'
            ROLLBACK TRANSACTION T_DDP_SUBMIT
            RETURN
        END

        IF EXISTS (SELECT 1 FROM [dbo].[DDP_Request] WHERE ConfigId = @ConfigId AND PrimaryKeyValue = @PrimaryKeyValue AND StatusCode = 'P')
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'A pending request already exists for this record.'
            ROLLBACK TRANSACTION T_DDP_SUBMIT
            RETURN
        END

        INSERT INTO [dbo].[DDP_Request]
            (ConfigId, PrimaryKeyValue, RecordCaption, MakerLoginId, CheckerLoginId, StatusCode, MakerRemarks, SubmittedOn)
        VALUES
            (@ConfigId, @PrimaryKeyValue, @FriendlyName + ' / ' + @PrimaryKeyValue, @MakerLoginId, @CheckerLoginId, 'P', @MakerRemarks, GETDATE())

        SET @RequestId = SCOPE_IDENTITY()

        DECLARE @Input TABLE(FieldConfigId INT NOT NULL, NewValue NVARCHAR(MAX) NULL)
        INSERT INTO @Input(FieldConfigId, NewValue)
        SELECT X.F.value('@FieldConfigId', 'INT'), X.F.value('@NewValue', 'NVARCHAR(4000)')
        FROM @ChangedFieldsXml.nodes('/Fields/Field') X(F)

        DECLARE @FieldConfigId INT, @ColumnName SYSNAME, @DisplayName NVARCHAR(200), @NewValue NVARCHAR(MAX), @OldValue NVARCHAR(MAX), @IsRequired BIT
        DECLARE submit_cursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT f.FieldConfigId, f.ColumnName, f.DisplayName, i.NewValue, f.IsRequired
            FROM @Input i
            INNER JOIN [dbo].[DDP_FieldConfig] f ON f.FieldConfigId = i.FieldConfigId
            WHERE f.ConfigId = @ConfigId AND f.IsEditable = 1

        OPEN submit_cursor
        FETCH NEXT FROM submit_cursor INTO @FieldConfigId, @ColumnName, @DisplayName, @NewValue, @IsRequired
        WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @IsRequired = 1 AND ISNULL(@NewValue, '') = ''
            BEGIN
                SET @Status = 'FAILURE'
                SET @Message = @DisplayName + ' is required.'
                CLOSE submit_cursor
                DEALLOCATE submit_cursor
                ROLLBACK TRANSACTION T_DDP_SUBMIT
                RETURN
            END

            DECLARE @Sql NVARCHAR(MAX)
            SET @Sql = N'SELECT @OldValue = CONVERT(NVARCHAR(MAX), ' + QUOTENAME(@ColumnName) + N') FROM ' +
                       QUOTENAME(@SchemaName) + N'.' + QUOTENAME(@TableName) +
                       N' WHERE CONVERT(NVARCHAR(500), ' + QUOTENAME(@PrimaryKeyColumn) + N') = @Pk'

            SET @OldValue = NULL
            EXEC sp_executesql @Sql, N'@Pk NVARCHAR(500), @OldValue NVARCHAR(MAX) OUTPUT', @PrimaryKeyValue, @OldValue OUTPUT

            IF ISNULL(@OldValue, '') <> ISNULL(@NewValue, '')
            BEGIN
                INSERT INTO [dbo].[DDP_RequestDetail]
                    (RequestId, FieldConfigId, ColumnName, DisplayName, OldValue, NewValue)
                VALUES
                    (@RequestId, @FieldConfigId, @ColumnName, @DisplayName, @OldValue, @NewValue)
            END

            FETCH NEXT FROM submit_cursor INTO @FieldConfigId, @ColumnName, @DisplayName, @NewValue, @IsRequired
        END
        CLOSE submit_cursor
        DEALLOCATE submit_cursor

        IF NOT EXISTS (SELECT 1 FROM [dbo].[DDP_RequestDetail] WHERE RequestId = @RequestId)
        BEGIN
            DELETE FROM [dbo].[DDP_Request] WHERE RequestId = @RequestId
            SET @Status = 'FAILURE'
            SET @Message = 'No changed values were submitted.'
            ROLLBACK TRANSACTION T_DDP_SUBMIT
            RETURN
        END

        INSERT INTO [dbo].[DDP_Audit](EntityName, EntityId, ActionName, ActionBy, Remarks, NewData)
        VALUES('DDP_Request', @RequestId, 'SUBMIT', @MakerLoginId, @MakerRemarks, 'Checker=' + @CheckerLoginId)

        COMMIT TRANSACTION T_DDP_SUBMIT
        SET @Status = 'SUCCESS'
        SET @Message = 'Data patch request submitted to ' + @CheckerLoginId + '. Request Id: ' + CAST(@RequestId AS NVARCHAR(20))
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_DDP_SUBMIT
        SET @Status = 'FAILURE'
        SET @Message = ERROR_MESSAGE()
    END CATCH
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetRequests]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetRequests]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetRequests]
    @LoginId NVARCHAR(100) = NULL,
    @Mode NVARCHAR(20) = 'ALL'
AS
BEGIN
    SET NOCOUNT ON

    SELECT r.RequestId, r.PrimaryKeyValue, r.RecordCaption,
           t.FriendlyName, t.SchemaName + '.' + t.TableName AS FullTableName,
           r.MakerLoginId, r.CheckerLoginId,
           r.StatusCode,
           CASE r.StatusCode WHEN 'P' THEN 'Pending with ' + r.CheckerLoginId WHEN 'A' THEN 'Approved' WHEN 'R' THEN 'Rejected' ELSE r.StatusCode END AS StatusDesc,
           r.MakerRemarks, r.CheckerRemarks, r.SubmittedOn, r.CheckedOn,
           (SELECT COUNT(1) FROM [dbo].[DDP_RequestDetail] d WHERE d.RequestId = r.RequestId) AS ChangedFieldCount
    FROM [dbo].[DDP_Request] r
    INNER JOIN [dbo].[DDP_TableConfig] t ON t.ConfigId = r.ConfigId
    WHERE (@Mode = 'ALL')
       OR (@Mode = 'MAKER' AND r.MakerLoginId = @LoginId)
       OR (@Mode = 'CHECKER' AND r.CheckerLoginId = @LoginId AND r.StatusCode = 'P')
    ORDER BY r.SubmittedOn DESC
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetRequestDetail]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetRequestDetail]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetRequestDetail]
    @RequestId INT
AS
BEGIN
    SET NOCOUNT ON

    SELECT d.DetailId, d.RequestId, d.ColumnName, d.DisplayName, d.OldValue, d.NewValue
    FROM [dbo].[DDP_RequestDetail] d
    WHERE d.RequestId = @RequestId
    ORDER BY d.DetailId
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_CheckRequest]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_CheckRequest]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_CheckRequest]
    @RequestId      INT,
    @CheckerLoginId NVARCHAR(100),
    @Decision       CHAR(1),
    @Remarks        NVARCHAR(1000) = NULL,
    @Status         NVARCHAR(50) OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    BEGIN TRY
        BEGIN TRANSACTION T_DDP_CHECK

        DECLARE @ConfigId INT, @AssignedChecker NVARCHAR(100), @CurrentStatus CHAR(1), @MakerLoginId NVARCHAR(100)
        SELECT @ConfigId = ConfigId, @AssignedChecker = CheckerLoginId, @CurrentStatus = StatusCode, @MakerLoginId = MakerLoginId
        FROM [dbo].[DDP_Request]
        WHERE RequestId = @RequestId

        IF @ConfigId IS NULL
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'Request not found.'
            ROLLBACK TRANSACTION T_DDP_CHECK
            RETURN
        END

        IF @CurrentStatus <> 'P'
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'Only pending requests can be checked.'
            ROLLBACK TRANSACTION T_DDP_CHECK
            RETURN
        END

        IF @AssignedChecker <> @CheckerLoginId
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'This request is pending with ' + @AssignedChecker + '.'
            ROLLBACK TRANSACTION T_DDP_CHECK
            RETURN
        END

        IF @Decision = 'R'
        BEGIN
            UPDATE [dbo].[DDP_Request]
            SET StatusCode = 'R', CheckerRemarks = @Remarks, CheckedOn = GETDATE()
            WHERE RequestId = @RequestId

            INSERT INTO [dbo].[DDP_Audit](EntityName, EntityId, ActionName, ActionBy, Remarks)
            VALUES('DDP_Request', @RequestId, 'REJECT', @CheckerLoginId, @Remarks)

            COMMIT TRANSACTION T_DDP_CHECK
            SET @Status = 'SUCCESS'
            SET @Message = 'Request rejected.'
            RETURN
        END

        IF @Decision <> 'A'
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'Decision must be A or R.'
            ROLLBACK TRANSACTION T_DDP_CHECK
            RETURN
        END

        DECLARE @SchemaName SYSNAME, @TableName SYSNAME, @PrimaryKeyColumn SYSNAME, @PrimaryKeyValue NVARCHAR(500)
        SELECT @SchemaName = t.SchemaName, @TableName = t.TableName, @PrimaryKeyColumn = t.PrimaryKeyColumn, @PrimaryKeyValue = r.PrimaryKeyValue
        FROM [dbo].[DDP_Request] r
        INNER JOIN [dbo].[DDP_TableConfig] t ON t.ConfigId = r.ConfigId
        WHERE r.RequestId = @RequestId

        DECLARE @ColumnName SYSNAME, @NewValue NVARCHAR(MAX)
        DECLARE approve_cursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT d.ColumnName, d.NewValue
            FROM [dbo].[DDP_RequestDetail] d
            INNER JOIN [dbo].[DDP_FieldConfig] f ON f.FieldConfigId = d.FieldConfigId
            WHERE d.RequestId = @RequestId AND f.IsEditable = 1

        OPEN approve_cursor
        FETCH NEXT FROM approve_cursor INTO @ColumnName, @NewValue
        WHILE @@FETCH_STATUS = 0
        BEGIN
            DECLARE @Sql NVARCHAR(MAX)
            SET @Sql = N'UPDATE ' + QUOTENAME(@SchemaName) + N'.' + QUOTENAME(@TableName) +
                       N' SET ' + QUOTENAME(@ColumnName) + N' = @Value WHERE CONVERT(NVARCHAR(500), ' + QUOTENAME(@PrimaryKeyColumn) + N') = @Pk'
            EXEC sp_executesql @Sql, N'@Value NVARCHAR(MAX), @Pk NVARCHAR(500)', @NewValue, @PrimaryKeyValue

            FETCH NEXT FROM approve_cursor INTO @ColumnName, @NewValue
        END
        CLOSE approve_cursor
        DEALLOCATE approve_cursor

        UPDATE [dbo].[DDP_Request]
        SET StatusCode = 'A', CheckerRemarks = @Remarks, CheckedOn = GETDATE()
        WHERE RequestId = @RequestId

        INSERT INTO [dbo].[DDP_Audit](EntityName, EntityId, ActionName, ActionBy, Remarks)
        VALUES('DDP_Request', @RequestId, 'APPROVE_APPLY', @CheckerLoginId, @Remarks)

        COMMIT TRANSACTION T_DDP_CHECK
        SET @Status = 'SUCCESS'
        SET @Message = 'Request approved and main table updated.'
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_DDP_CHECK
        SET @Status = 'FAILURE'
        SET @Message = ERROR_MESSAGE()
    END CATCH
END
GO

IF OBJECT_ID('[dbo].[Proc_DDP_GetAuditHistory]', 'P') IS NOT NULL DROP PROCEDURE [dbo].[Proc_DDP_GetAuditHistory]
GO
CREATE PROCEDURE [dbo].[Proc_DDP_GetAuditHistory]
    @RequestId INT = NULL
AS
BEGIN
    SET NOCOUNT ON

    IF @RequestId IS NULL
    BEGIN
        SELECT TOP 500 AuditId, EntityName, EntityId, ActionName, ActionBy, ActionOn, Remarks, OldData, NewData
        FROM [dbo].[DDP_Audit]
        ORDER BY ActionOn DESC, AuditId DESC
    END
    ELSE
    BEGIN
        SELECT AuditId, EntityName, EntityId, ActionName, ActionBy, ActionOn, Remarks, OldData, NewData
        FROM [dbo].[DDP_Audit]
        WHERE EntityName = 'DDP_Request' AND EntityId = @RequestId
        ORDER BY ActionOn DESC, AuditId DESC
    END
END
GO