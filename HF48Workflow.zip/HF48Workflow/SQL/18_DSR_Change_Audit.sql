-- Run in the application database. SQL Server 2012+; no historical backfill.
-- Keep lead_details.Lead_No and lead_details_finance.Lead_No unique and immutable.
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'dbo.lead_details', N'U') IS NULL
    OR OBJECT_ID(N'dbo.lead_details_finance', N'U') IS NULL
    OR OBJECT_ID(N'dbo.FRM_service_request', N'U') IS NULL
BEGIN
    RAISERROR('DSR audit requires the three source tables in dbo.', 16, 1);
    RETURN;
END;
GO

IF OBJECT_ID(N'dbo.DSR_ChangeAudit', N'U') IS NULL
BEGIN
    -- Derive value types from the real schema, including nullable before/after values.
    SELECT TOP (0)
        IDENTITY(BIGINT, 1, 1) AS AuditId,
        CAST(NULL AS DATETIME2(7)) AS ChangedAtUtc,
        CAST(NULL AS CHAR(1)) AS ChangeType,
        f.Lead_No,
        CAST(NULL AS NVARCHAR(450)) AS ApplicationID,
        ld.lead_stage AS LeadStage,
        ld.CreatedOn_Date AS LeadCreatedOn,
        ld.UpdatedOn_date AS LeadUpdatedOn,
        CASE WHEN 1 = 0 THEN f.LEAD_DSR ELSE NULL END AS OldLEAD_DSR,
        CASE WHEN 1 = 0 THEN f.LEAD_DSR ELSE NULL END AS NewLEAD_DSR,
        CASE WHEN 1 = 0 THEN f.LEAD_DSR_PRODUCT ELSE NULL END AS OldLEAD_DSR_PRODUCT,
        CASE WHEN 1 = 0 THEN f.LEAD_DSR_PRODUCT ELSE NULL END AS NewLEAD_DSR_PRODUCT,
        CASE WHEN 1 = 0 THEN f.Lead_Stress_DSR ELSE NULL END AS OldLead_Stress_DSR,
        CASE WHEN 1 = 0 THEN f.Lead_Stress_DSR ELSE NULL END AS NewLead_Stress_DSR,
        CASE WHEN 1 = 0 THEN f.lead_ftv ELSE NULL END AS OldLeadFTV,
        CASE WHEN 1 = 0 THEN f.lead_ftv ELSE NULL END AS NewLeadFTV,
        CASE WHEN 1 = 0 THEN f.LEAD_Product_ISTINSNA ELSE NULL END AS OldIstisnaProduct,
        CASE WHEN 1 = 0 THEN f.LEAD_Product_ISTINSNA ELSE NULL END AS NewIstisnaProduct,
        CASE WHEN 1 = 0 THEN f.Lead_Conversion_Product ELSE NULL END AS OldConversionProduct,
        CASE WHEN 1 = 0 THEN f.Lead_Conversion_Product ELSE NULL END AS NewConversionProduct,
        CAST(NULL AS NVARCHAR(128)) AS DatabaseLogin,
        CAST(NULL AS NVARCHAR(128)) AS ClientHost,
        CAST(NULL AS NVARCHAR(128)) AS ClientProgram
    INTO dbo.DSR_ChangeAudit
    FROM dbo.lead_details_finance f
    LEFT JOIN dbo.lead_details ld ON ld.Lead_No = f.Lead_No;

    ALTER TABLE dbo.DSR_ChangeAudit ADD CONSTRAINT PK_DSR_ChangeAudit PRIMARY KEY (AuditId);
    ALTER TABLE dbo.DSR_ChangeAudit ADD CONSTRAINT CK_DSR_ChangeAudit_Event
        CHECK (ChangedAtUtc IS NOT NULL AND ChangeType IS NOT NULL AND ChangeType IN ('I', 'U', 'D'));
    CREATE INDEX IX_DSR_ChangeAudit_Application ON dbo.DSR_ChangeAudit(ApplicationID, AuditId);
END;
GO

IF OBJECT_ID(N'dbo.DSR_ChangeAudit_ServiceRequest', N'U') IS NULL
BEGIN
    SELECT TOP (0)
        CAST(0 AS BIGINT) AS AuditId,
        sr.SRNo, sr.Category, sr.SubCategory, sr.CAS_stage, sr.ApplicationID
    INTO dbo.DSR_ChangeAudit_ServiceRequest
    FROM dbo.FRM_service_request sr;

    ALTER TABLE dbo.DSR_ChangeAudit_ServiceRequest ADD CONSTRAINT FK_DSR_Audit_ServiceRequest
        FOREIGN KEY (AuditId) REFERENCES dbo.DSR_ChangeAudit(AuditId);
    CREATE INDEX IX_DSR_Audit_ServiceRequest ON dbo.DSR_ChangeAudit_ServiceRequest(AuditId);
END;
GO

IF OBJECT_ID(N'dbo.TR_lead_details_finance_DSR_Audit', N'TR') IS NULL
    EXEC(N'CREATE TRIGGER dbo.TR_lead_details_finance_DSR_Audit
        ON dbo.lead_details_finance AFTER UPDATE AS BEGIN SET NOCOUNT ON; END');
GO
ALTER TRIGGER dbo.TR_lead_details_finance_DSR_Audit
ON dbo.lead_details_finance
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
        RETURN;

    DECLARE @ChangedAtUtc DATETIME2(7) = SYSUTCDATETIME();
    DECLARE @Events TABLE (AuditId BIGINT NOT NULL PRIMARY KEY);

    IF EXISTS
    (
        SELECT 1
        FROM dbo.lead_details ld
        WHERE DATALENGTH(CONVERT(NVARCHAR(MAX), ld.APP_REF_NO)) > 900
          AND (EXISTS (SELECT 1 FROM inserted i WHERE i.Lead_No = ld.Lead_No)
            OR EXISTS (SELECT 1 FROM deleted d WHERE d.Lead_No = ld.Lead_No))
    )
    BEGIN
        RAISERROR('Application ID exceeds the DSR audit limit of 450 characters.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;

    INSERT dbo.DSR_ChangeAudit
    (
        ChangedAtUtc, ChangeType, Lead_No, ApplicationID, LeadStage, LeadCreatedOn, LeadUpdatedOn,
        OldLEAD_DSR, NewLEAD_DSR, OldLEAD_DSR_PRODUCT, NewLEAD_DSR_PRODUCT,
        OldLead_Stress_DSR, NewLead_Stress_DSR, OldLeadFTV, NewLeadFTV,
        OldIstisnaProduct, NewIstisnaProduct, OldConversionProduct, NewConversionProduct,
        DatabaseLogin, ClientHost, ClientProgram
    )
    OUTPUT inserted.AuditId INTO @Events(AuditId)
    SELECT
        @ChangedAtUtc,
        CASE WHEN d.Lead_No IS NULL THEN 'I' WHEN i.Lead_No IS NULL THEN 'D' ELSE 'U' END,
        COALESCE(i.Lead_No, d.Lead_No), CONVERT(NVARCHAR(450), ld.APP_REF_NO),
        ld.lead_stage, ld.CreatedOn_Date, ld.UpdatedOn_date,
        d.LEAD_DSR, i.LEAD_DSR, d.LEAD_DSR_PRODUCT, i.LEAD_DSR_PRODUCT,
        d.Lead_Stress_DSR, i.Lead_Stress_DSR, d.lead_ftv, i.lead_ftv,
        d.LEAD_Product_ISTINSNA, i.LEAD_Product_ISTINSNA,
        d.Lead_Conversion_Product, i.Lead_Conversion_Product,
        ORIGINAL_LOGIN(), HOST_NAME(), APP_NAME()
    FROM inserted i
    FULL OUTER JOIN deleted d ON d.Lead_No = i.Lead_No
    LEFT JOIN dbo.lead_details ld ON ld.Lead_No = COALESCE(i.Lead_No, d.Lead_No)
    WHERE EXISTS
    (
        SELECT i.LEAD_DSR, i.LEAD_DSR_PRODUCT, i.Lead_Stress_DSR
        EXCEPT
        SELECT d.LEAD_DSR, d.LEAD_DSR_PRODUCT, d.Lead_Stress_DSR
    );

    -- Every matching request is copied; no request is required for a DSR audit event.
    INSERT dbo.DSR_ChangeAudit_ServiceRequest
        (AuditId, SRNo, Category, SubCategory, CAS_stage, ApplicationID)
    SELECT a.AuditId, sr.SRNo, sr.Category, sr.SubCategory, sr.CAS_stage, sr.ApplicationID
    FROM @Events e
    JOIN dbo.DSR_ChangeAudit a ON a.AuditId = e.AuditId
    JOIN dbo.FRM_service_request sr ON sr.ApplicationID = a.ApplicationID;
END;
GO

IF OBJECT_ID(N'dbo.Proc_DSR_GetHistory', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Proc_DSR_GetHistory AS BEGIN SET NOCOUNT ON; END');
GO
ALTER PROCEDURE dbo.Proc_DSR_GetHistory
    @ApplicationID NVARCHAR(450),
    @FromAuditId BIGINT = NULL,
    @ToAuditId BIGINT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF NULLIF(LTRIM(RTRIM(@ApplicationID)), N'') IS NULL
    BEGIN
        RAISERROR('An application ID is required.', 16, 1);
        RETURN;
    END;
    IF (@FromAuditId IS NULL AND @ToAuditId IS NOT NULL)
        OR (@FromAuditId IS NOT NULL AND @ToAuditId IS NULL)
    BEGIN
        RAISERROR('Select both snapshots for comparison.', 16, 1);
        RETURN;
    END;
    IF @FromAuditId IS NOT NULL AND NOT EXISTS
    (
        SELECT 1 FROM dbo.DSR_ChangeAudit a
        JOIN dbo.DSR_ChangeAudit b ON a.Lead_No = b.Lead_No
        WHERE a.AuditId = @FromAuditId AND b.AuditId = @ToAuditId
          AND a.ApplicationID = @ApplicationID AND b.ApplicationID = @ApplicationID
    )
    BEGIN
        RAISERROR('Both snapshots must belong to this application and the same lead.', 16, 1);
        RETURN;
    END;

    SELECT a.*,
        (SELECT COUNT(*) FROM dbo.DSR_ChangeAudit_ServiceRequest s WHERE s.AuditId = a.AuditId)
            AS ServiceRequestCount
    FROM dbo.DSR_ChangeAudit a
    WHERE a.ApplicationID = @ApplicationID
    ORDER BY a.ChangedAtUtc, a.AuditId;

    SELECT s.AuditId, a.ChangedAtUtc, a.LeadStage,
        s.SRNo, s.Category, s.SubCategory, s.CAS_stage, s.ApplicationID
    FROM dbo.DSR_ChangeAudit a
    JOIN dbo.DSR_ChangeAudit_ServiceRequest s ON s.AuditId = a.AuditId
    WHERE a.ApplicationID = @ApplicationID
    ORDER BY a.ChangedAtUtc, a.AuditId, s.SRNo;

    -- Compare the post-change values of any two events, not the current source rows.
    SELECT a.AuditId AS FromAuditId, a.ChangedAtUtc AS FromTimeUtc, a.LeadStage AS FromStage,
        b.AuditId AS ToAuditId, b.ChangedAtUtc AS ToTimeUtc, b.LeadStage AS ToStage,
        v.FieldName, v.FromValue, v.ToValue, v.Delta,
        CASE WHEN EXISTS (SELECT v.FromValue EXCEPT SELECT v.ToValue)
            THEN 'Changed' ELSE 'Unchanged' END AS Result
    FROM dbo.DSR_ChangeAudit a
    JOIN dbo.DSR_ChangeAudit b ON b.Lead_No = a.Lead_No
    CROSS APPLY
    (
        VALUES
        ('LEAD_DSR', CONVERT(NVARCHAR(100), a.NewLEAD_DSR),
            CONVERT(NVARCHAR(100), b.NewLEAD_DSR),
            CONVERT(NVARCHAR(100), b.NewLEAD_DSR - a.NewLEAD_DSR)),
        ('LEAD_DSR_PRODUCT', CONVERT(NVARCHAR(100), a.NewLEAD_DSR_PRODUCT),
            CONVERT(NVARCHAR(100), b.NewLEAD_DSR_PRODUCT),
            CONVERT(NVARCHAR(100), b.NewLEAD_DSR_PRODUCT - a.NewLEAD_DSR_PRODUCT)),
        ('Lead_Stress_DSR', CONVERT(NVARCHAR(100), a.NewLead_Stress_DSR),
            CONVERT(NVARCHAR(100), b.NewLead_Stress_DSR),
            CONVERT(NVARCHAR(100), b.NewLead_Stress_DSR - a.NewLead_Stress_DSR))
    ) v(FieldName, FromValue, ToValue, Delta)
    WHERE a.AuditId = @FromAuditId AND b.AuditId = @ToAuditId
      AND a.ApplicationID = @ApplicationID AND b.ApplicationID = @ApplicationID;
END;
GO
