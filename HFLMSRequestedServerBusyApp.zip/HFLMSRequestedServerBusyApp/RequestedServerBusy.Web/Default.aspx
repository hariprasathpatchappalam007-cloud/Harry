<%@ Page Language="C#" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>HTTP 503 - Browser Demo</title>
    <style>
        body { font: 16px/1.6 "Segoe UI", sans-serif; max-width: 860px; margin: 40px auto; padding: 0 20px; color: #172635; }
        h1 { line-height: 1.2; }
        code, pre { background: #eef2f6; padding: 3px 6px; }
        pre { padding: 16px; overflow-x: auto; }
        .warning { border-left: 4px solid #ab6200; padding: 12px 18px; background: #fff5e3; }
        a { color: #0758a5; }
        button { background: #0758a5; color: white; border: 0; border-radius: 4px; padding: 12px 20px; font: inherit; cursor: pointer; }
        button:disabled { opacity: 0.6; cursor: wait; }
        button:focus { outline: 3px solid #ab6200; outline-offset: 3px; }
        section { margin: 20px 0; border: 1px solid #ccd5de; padding: 0 18px 12px; }
        pre { white-space: pre-wrap; overflow-wrap: break-word; }
        .busy { color: #a12616; }
        .healthy { color: #176638; }
    </style>
</head>
<body>
    <h1>HTTP 503: Server Busy Browser Demo</h1>
    <p>Click the button to receive an actual HTTP 503 response and view it here,
        without leaving this page or running a console application.</p>
    <p class="warning"><strong>Application-generated demonstration:</strong> this does not
        overload the server or reproduce native IIS 503.2. Only the demo endpoint returns
        503; the rest of the application remains available.</p>
    <button id="run-demo" type="button" disabled>Trigger HTTP 503</button>
    <noscript><p>Enable JavaScript to run the browser demo.</p></noscript>
    <p>If the button stays disabled, check that BrowserDemo.js was deployed and is allowed to load.</p>
    <p id="demo-status" role="status" aria-live="polite">Ready. Each click sends one demo request followed by one health check.</p>
    <section id="busy-panel" aria-labelledby="busy-title" hidden>
        <h2 id="busy-title">Server response</h2>
        <p id="busy-status"></p>
        <pre id="busy-body"></pre>
    </section>
    <section id="health-panel" aria-labelledby="health-title" hidden>
        <h2 id="health-title">Recovery check</h2>
        <p id="health-status"></p>
        <pre id="health-body"></pre>
    </section>
    <h2>How this browser demo works</h2>
    <ol>
        <li>The browser requests Busy.ashx, which immediately returns HTTP 503 with Retry-After: 5.</li>
        <li>This page displays the actual HTTP status, handler marker, and response body.</li>
        <li>A separate Health.ashx request verifies that the application still returns HTTP 200.
            Retry-After is shown as response metadata; there is no five-second server outage.</li>
    </ol>
    <p>Works through your existing IIS site URL, including an IIS application subfolder.
        No console, PowerShell, concurrent-request setting, or remote access to Hold.ashx is required.</p>
    <p><a href="Help.html">Hosting and troubleshooting help</a></p>
    <h2>Separate native IIS 503.2 test</h2>
    <p>The existing local-only Hold.ashx endpoint and console probe are unchanged.
        That advanced test requires a dedicated IIS concurrent-request limit of 2.
        It is not run by this button. Do not apply that limit to a shared or production site.</p>
    <script src="BrowserDemo.js"></script>
</body>
</html>
