using System.Web;

namespace RequestedServerBusy.Web
{
    public sealed class HealthHandler : IHttpHandler
    {
        public bool IsReusable { get { return true; } }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            context.Response.Cache.SetNoStore();
            context.Response.Headers["X-BusyDemo-Handler"] = "Health";
            context.Response.Write("Healthy. The application returned HTTP 200.");
        }
    }
}
