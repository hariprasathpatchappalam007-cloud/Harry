using System.Web;

namespace RequestedServerBusy.Web
{
    public sealed class BusyHandler : IHttpHandler
    {
        public bool IsReusable { get { return true; } }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            context.Response.Cache.SetNoStore();
            context.Response.StatusCode = 503;
            context.Response.TrySkipIisCustomErrors = true;
            context.Response.Headers["X-BusyDemo-Handler"] = "SimulatedBusy";
            context.Response.Headers["Retry-After"] = "5";
            context.Response.Write("HTTP 503 - Service Unavailable\n" +
                "The application deliberately returned this server-busy response for demonstration.\n" +
                "This is not a native IIS 503.2 rejection or actual server overload.");
        }
    }
}
