(function () {
    "use strict";

    var button = document.getElementById("run-demo");
    var status = document.getElementById("demo-status");

    function request(path, complete) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", path + "?demo=" + new Date().getTime(), true);
        xhr.timeout = 15000;
        xhr.onload = function () {
            complete(null, {
                status: xhr.status,
                marker: xhr.getResponseHeader("X-BusyDemo-Handler"),
                retryAfter: xhr.getResponseHeader("Retry-After"),
                body: xhr.responseText
            });
        };
        xhr.onerror = function () {
            complete("Network request failed. Check the IIS site, network, and browser developer tools.");
        };
        xhr.ontimeout = function () {
            complete("Request timed out after 15 seconds. Check IIS availability.");
        };
        xhr.onabort = function () {
            complete("The request was cancelled.");
        };
        xhr.send();
    }

    function render(prefix, error, result, expectedStatus, expectedMarker) {
        var summary = document.getElementById(prefix + "-status");
        var body = document.getElementById(prefix + "-body");
        document.getElementById(prefix + "-panel").hidden = false;
        if (error) {
            summary.className = "busy";
            summary.textContent = "Request failed";
            body.textContent = error;
            return false;
        }

        var matched = result.status === expectedStatus && result.marker === expectedMarker;
        summary.className = matched && expectedStatus === 200 ? "healthy" : "busy";
        summary.textContent = "HTTP " + result.status +
            "; handler: " + (result.marker || "(missing)") +
            (result.retryAfter ? "; Retry-After: " + result.retryAfter : "") +
            (matched ? "" : " - unexpected response");
        body.textContent = result.body;
        return matched;
    }

    button.addEventListener("click", function () {
        if (button.disabled) {
            return;
        }
        button.disabled = true;
        document.getElementById("busy-panel").hidden = true;
        document.getElementById("health-panel").hidden = true;
        status.textContent = "Requesting an application-generated HTTP 503...";

        request("Busy.ashx", function (error, result) {
            var busyMatched = render("busy", error, result, 503, "SimulatedBusy");
            status.textContent = "Checking application recovery...";
            request("Health.ashx", function (healthError, healthResult) {
                var healthy = render("health", healthError, healthResult, 200, "Health");
                status.textContent = busyMatched && healthy
                    ? "Demo complete: application-generated HTTP 503 received; health check returned HTTP 200."
                    : "Demo failed: an expected response was not received. Inspect the results below for IIS, authentication, or network errors.";
                button.disabled = false;
            });
        });
    });

    button.disabled = false;
}());
