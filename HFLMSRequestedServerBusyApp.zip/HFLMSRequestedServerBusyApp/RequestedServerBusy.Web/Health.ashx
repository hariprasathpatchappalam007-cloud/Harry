<%@ WebHandler Language="C#" Class="RequestedServerBusy.Web.HealthHandler" %>
