using System.Threading.Tasks;
using System.Web;

namespace RequestedServerBusy.Web
{
    public sealed class HoldHandler : HttpTaskAsyncHandler
    {
        public override async Task ProcessRequestAsync(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            context.Response.Cache.SetNoStore();

            if (!context.Request.IsLocal)
            {
                context.Response.StatusCode = 403;
                context.Response.Write("This diagnostic endpoint is local-only.");
                return;
            }

            context.Response.Headers["X-BusyDemo-Handler"] = "Hold";
            await Task.Delay(5000);
            context.Response.Write("Hold completed after 5 seconds. The application returned HTTP 200.");
        }
    }
}
