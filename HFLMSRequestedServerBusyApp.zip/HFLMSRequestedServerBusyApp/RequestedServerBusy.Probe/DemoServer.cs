using System;
using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace RequestedServerBusy.Probe
{
    internal sealed class DemoServer : IDisposable
    {
        private readonly Process process;

        private DemoServer(Process process)
        {
            this.process = process;
        }

        internal static DemoServer Start(int port)
        {
            foreach (var endpoint in IPGlobalProperties.GetIPGlobalProperties().GetActiveTcpListeners())
            {
                if (endpoint.Port == port)
                    throw new InvalidOperationException("Port " + port +
                        " is already in use. Choose another port with --demo <port>; do not stop unrelated servers.");
            }

            string root = FindSolutionRoot();
            string web = Path.Combine(root, "RequestedServerBusy.Web");
            if (!File.Exists(Path.Combine(web, "bin", "RequestedServerBusy.Web.dll")))
                throw new FileNotFoundException("Build the entire solution in Visual Studio before running --demo.");

            string iis = FindIisExpress();
            string local = Path.Combine(root, ".local", "console-" + Guid.NewGuid().ToString("N"));
            string logs = Path.Combine(local, "logs");
            Directory.CreateDirectory(logs);

            var config = new XmlDocument { XmlResolver = null };
            config.Load(Path.Combine(Path.GetDirectoryName(iis),
                @"config\templates\PersonalWebServer\applicationhost.config"));
            XmlNode pools = Required(config, "/configuration/system.applicationHost/applicationPools");
            RemoveChildren(pools, "add");
            Add(config, pools, "add", "name", "BusyDemoPool",
                "managedRuntimeVersion", "v4.0", "managedPipelineMode", "Integrated");

            XmlNode sites = Required(config, "/configuration/system.applicationHost/sites");
            RemoveChildren(sites, "site");
            XmlElement site = Add(config, sites, "site", "name", "BusyDemo", "id", "1");
            XmlElement application = Add(config, site, "application", "path", "/",
                "applicationPool", "BusyDemoPool");
            Add(config, application, "virtualDirectory", "path", "/", "physicalPath", web);
            XmlElement bindings = Add(config, site, "bindings");
            Add(config, bindings, "binding", "protocol", "http",
                "bindingInformation", "*:" + port + ":localhost");
            Add(config, site, "logFile", "directory", logs, "logFormat", "W3C",
                "logExtFileFlags", "Date,Time,ClientIP,Method,UriStem,HttpStatus,HttpSubStatus,Win32Status,TimeTaken");

            XmlNode webServer = Required(config, "/configuration/system.webServer");
            XmlElement runtime = webServer.SelectSingleNode("serverRuntime") as XmlElement;
            if (runtime == null)
                runtime = Add(config, webServer, "serverRuntime");
            runtime.SetAttribute("appConcurrentRequestLimit", "2");
            string configPath = Path.Combine(local, "applicationhost.config");
            config.Save(configPath);

            Console.WriteLine("Isolated IIS config: " + configPath);
            Console.WriteLine("Local logs: " + logs);
            Console.WriteLine("Starting IIS Express; no PowerShell or machine-wide IIS changes.");
            Process started = Process.Start(new ProcessStartInfo
            {
                FileName = iis,
                Arguments = "/config:\"" + configPath + "\" /site:BusyDemo /systray:false",
                UseShellExecute = false,
                CreateNoWindow = false
            });
            if (started == null)
                throw new InvalidOperationException("IIS Express could not be started.");
            return new DemoServer(started);
        }

        internal async Task WaitUntilReadyAsync(int port)
        {
            var timer = Stopwatch.StartNew();
            Exception lastError = null;
            using (var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(30)))
            using (var handler = new HttpClientHandler { UseProxy = false, AllowAutoRedirect = false })
            using (var client = new HttpClient(handler) { Timeout = Timeout.InfiniteTimeSpan })
            {
                while (timer.Elapsed < TimeSpan.FromSeconds(30))
                {
                    EnsureRunning();
                    try
                    {
                        using (HttpResponseMessage response =
                            await client.GetAsync("http://localhost:" + port + "/Health.ashx", deadline.Token))
                        {
                            EnsureRunning();
                            if (response.IsSuccessStatusCode && response.Headers.Contains("X-BusyDemo-Handler"))
                                return;
                            string details = "IIS startup health check returned HTTP " +
                                (int)response.StatusCode + ":\n" + await response.Content.ReadAsStringAsync();
                            if ((int)response.StatusCode != 503)
                                throw new InvalidOperationException(details);

                            // IIS can briefly reject requests while the application starts.
                            lastError = new InvalidOperationException(details);
                            Console.Error.WriteLine("IIS startup returned HTTP 503; retrying within the 30-second startup deadline.");
                        }
                    }
                    catch (HttpRequestException exception)
                    {
                        lastError = exception;
                    }
                    catch (TaskCanceledException exception)
                    {
                        lastError = exception;
                    }
                    await Task.Delay(250);
                }
            }
            throw new TimeoutException("IIS Express was not ready within 30 seconds. Last startup error: " +
                (lastError == null ? "none" : lastError.Message), lastError);
        }

        private void EnsureRunning()
        {
            if (process.HasExited)
                throw new InvalidOperationException("IIS Express exited with code " + process.ExitCode +
                    ". Inspect its output; the port may already be in use.");
        }

        private static string FindSolutionRoot()
        {
            for (var directory = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
                directory != null; directory = directory.Parent)
            {
                if (File.Exists(Path.Combine(directory.FullName, "RequestedServerBusy.sln")) &&
                    Directory.Exists(Path.Combine(directory.FullName, "RequestedServerBusy.Web")))
                    return directory.FullName;
            }
            throw new DirectoryNotFoundException(
                "Cannot find the solution and web project above this executable. Run from the original build output folder.");
        }

        private static string FindIisExpress()
        {
            foreach (string variable in new[] { "ProgramW6432", "ProgramFiles", "ProgramFiles(x86)" })
            {
                string folder = Environment.GetEnvironmentVariable(variable);
                if (string.IsNullOrEmpty(folder))
                    continue;
                string candidate = Path.Combine(folder, "IIS Express", "iisexpress.exe");
                if (File.Exists(candidate))
                    return candidate;
            }
            throw new FileNotFoundException(
                "Install IIS Express (included with Visual Studio Web Developer tools) before running --demo.");
        }

        private static XmlNode Required(XmlDocument config, string path)
        {
            XmlNode node = config.SelectSingleNode(path);
            if (node == null)
                throw new InvalidOperationException("The IIS Express configuration template is missing " + path);
            return node;
        }

        private static void RemoveChildren(XmlNode parent, string name)
        {
            foreach (XmlNode child in parent.SelectNodes(name))
                parent.RemoveChild(child);
        }

        private static XmlElement Add(XmlDocument config, XmlNode parent, string name, params string[] attributes)
        {
            XmlElement element = config.CreateElement(name);
            for (int i = 0; i < attributes.Length; i += 2)
                element.SetAttribute(attributes[i], attributes[i + 1]);
            parent.AppendChild(element);
            return element;
        }

        public void Dispose()
        {
            try
            {
                if (!process.HasExited)
                {
                    // Only terminate the IIS Express instance created by this run.
                    process.Kill();
                    process.WaitForExit();
                }
                Console.WriteLine("Demo IIS Express stopped.");
            }
            finally
            {
                process.Dispose();
            }
        }
    }
}
