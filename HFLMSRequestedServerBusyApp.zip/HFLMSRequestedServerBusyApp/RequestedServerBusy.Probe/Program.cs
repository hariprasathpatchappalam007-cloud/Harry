using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace RequestedServerBusy.Probe
{
    internal static class Program
    {
        private sealed class Result
        {
            public int Status;
            public bool HandlerRan;
            public bool IsIis503Point2;
        }

        private static int Main(string[] args)
        {
            int port = 8085;
            if (args.Length > 1 || (args.Length == 1 &&
                (!int.TryParse(args[0], out port) || port < 1024 || port > 65535)))
            {
                Console.Error.WriteLine("Usage: RequestedServerBusy.Probe.exe [local port: 1024-65535]");
                return 2;
            }

            try
            {
                return RunAsync(port).GetAwaiter().GetResult();
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine("Probe failed: " + exception);
                return 1;
            }
        }

        private static async Task<int> RunAsync(int port)
        {
            ServicePointManager.DefaultConnectionLimit = 16;
            using (var handler = new HttpClientHandler { UseProxy = false, AllowAutoRedirect = false })
            using (var client = new HttpClient(handler))
            {
                client.BaseAddress = new Uri("http://localhost:" + port + "/");
                client.Timeout = TimeSpan.FromSeconds(20);
                Console.WriteLine("Local-only probe: " + client.BaseAddress);

                Result warmup = await SendAsync(client, "Health.ashx", "Warm-up");
                if (warmup.Status != 200 || !warmup.HandlerRan)
                {
                    Console.Error.WriteLine("Warm-up failed. Start the sample and resolve the hosting error first.");
                    return 1;
                }

                var requests = new List<Task<Result>>();
                for (int i = 1; i <= 2; i++)
                    requests.Add(SendAsync(client, "Hold.ashx", "Holder " + i));

                await Task.Delay(1000);
                for (int i = 1; i <= 6; i++)
                    requests.Add(SendAsync(client, "Hold.ashx", "Overflow " + i));

                Result[] results = await Task.WhenAll(requests);
                Result recovery = await SendAsync(client, "Health.ashx", "Recovery");
                int accepted = results.Count(result => result.Status == 200 && result.HandlerRan);
                int rejected = results.Count(result => result.Status == 503 &&
                    !result.HandlerRan && result.IsIis503Point2);
                bool passed = accepted > 0 && rejected > 0 &&
                    accepted + rejected == results.Length &&
                    recovery.Status == 200 && recovery.HandlerRan;

                Console.WriteLine("Accepted: {0}; confirmed native IIS 503.2: {1}; total: {2}",
                    accepted, rejected, results.Length);
                Console.WriteLine(passed
                    ? "PASS: native IIS rejection and automatic recovery verified."
                    : "FAIL: expected 200 responses, native IIS 503.2 responses, and recovery. " +
                      "Use the supplied IIS configuration, enable local detailed errors, and close other demo tabs.");
                return passed ? 0 : 1;
            }
        }

        private static async Task<Result> SendAsync(HttpClient client, string path, string label)
        {
            using (HttpResponseMessage response = await client.GetAsync(path))
            {
                string body = await response.Content.ReadAsStringAsync();
                var result = new Result
                {
                    Status = (int)response.StatusCode,
                    HandlerRan = response.Headers.Contains("X-BusyDemo-Handler"),
                    IsIis503Point2 = body.IndexOf("503.2", StringComparison.OrdinalIgnoreCase) >= 0
                };
                Console.WriteLine("{0}: HTTP {1}; handler ran: {2}; IIS 503.2 page: {3}",
                    label, result.Status, result.HandlerRan, result.IsIis503Point2);
                if (result.Status != 200 && !(result.Status == 503 && result.IsIis503Point2))
                    Console.Error.WriteLine("{0} unexpected response:\n{1}", label, body);
                return result;
            }
        }
    }
}
