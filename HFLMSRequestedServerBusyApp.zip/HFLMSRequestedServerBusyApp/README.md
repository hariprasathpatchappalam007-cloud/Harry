# HTTP 503 browser demo and native IIS 503.2 diagnostic

ASP.NET Web Application targeting **.NET Framework 4.5**, using **C# 5** syntax
and a **Visual Studio 2013** solution. No NuGet packages or ASP.NET Core required.

Two separate demonstrations are included:

- **Host and click:** the web page requests an application-generated **HTTP 503**
  and displays its status/body, then checks health. Works from a remote browser
  using ordinary IIS hosting; no console, PowerShell, or low request limit needed.
- **Advanced local diagnostic:** the console probe reproduces native IIS
  **HTTP 503.2: Concurrent request limit exceeded** using a dedicated low limit.
  This is bounded and local-only, not a stress-testing tool.

The browser demo deliberately simulates server-busy behavior. It does not prove
native IIS overload, and it does not cause an outage or change any IIS settings.

## Host in full IIS and click the button

1. Build the solution in Visual Studio, preferably **Release**.
2. Deploy the contents of `RequestedServerBusy.Web` to your dedicated IIS
   application folder, including:
   - `Default.aspx`, `BrowserDemo.js`, `Busy.ashx`, `Health.ashx`, `Hold.ashx`
   - `Web.config`, `Help.html` (copied into the web project during build)
   - `bin\RequestedServerBusy.Web.dll`
   The console EXE, source files, and `obj` folder are not needed for this mode.
3. Use an application pool with **.NET CLR v4.0**, **Integrated** pipeline and
   ASP.NET 4.x IIS features installed. Give the pool identity the normal
   Read & Execute permissions. Configure site binding, authentication, and
   approved network/firewall access as for any ordinary IIS application.
4. Open your site's existing URL from your browser. For example:
   `http://10.224.3.14/Default.aspx`, or
   `http://10.224.3.14/YourApplication/Default.aspx` for an application subfolder.
   Include the configured port if it is not 80. Use the hostname/HTTPS URL instead
   if that is what your site's binding requires.
5. Click **Trigger HTTP 503**. The page displays the actual HTTP 503 response,
   `SimulatedBusy` handler marker, `Retry-After: 5`, and its response body,
   followed by a separate HTTP 200 health check.

There are just two sequential requests per click and no automatic retries.
Do **not** apply the native concurrent-request limit of 2 for this browser demo.
If you previously applied it to a dedicated test site, have its administrator
restore the prior setting before using this as an ordinary hosted application.
Existing IIS/organizational access restrictions are not bypassed.

The browser endpoint `Busy.ashx` intentionally permits remote requests and
immediately returns a lightweight, application-generated 503. It sets
`TrySkipIisCustomErrors` to preserve its response. If IIS, a proxy, or an
authentication gateway replaces it, the page displays the actual response and
reports failure rather than claiming success. No global custom-error change is
required. The `Retry-After` header is metadata, not a five-second outage.

`Hold.ashx` remains **local-only** for the separate native diagnostic and is
never called by the button. A remote 403 from it does not affect the browser demo.
All browser requests use application-relative URLs; no server IP is hardcoded.
Use a JavaScript-enabled browser. [Help.html](Help.html) also documents this flow.

## Requirements

- Windows, .NET Framework 4.5 or a compatible later 4.x runtime.
- Visual Studio 2013 with Web Developer tools and the .NET Framework 4.5 targeting
  pack (or compatible MSBuild and reference assemblies).
- Full IIS with ASP.NET 4.x enabled for browser hosting; IIS Express is optional.
- IIS Express 8 or later is required only for the console's `--demo` mode.
- No PowerShell is required for either browser or console demo.

## Advanced native IIS test (Visual Studio console application, no PowerShell)

1. Open [RequestedServerBusy.sln](RequestedServerBusy.sln) in Visual Studio.
2. Select **Build > Build Solution** to build both projects.
3. Right-click **RequestedServerBusy.Probe** and select **Set as StartUp Project**.
4. In that project's **Properties > Debug > Command line arguments**, enter
   `--demo` (or `--demo 8086` for another port).
5. Press **Ctrl+F5**. The console prepares an isolated IIS Express configuration,
   starts the site, waits for readiness, runs the probe, and stops its server.

Open [Help.html](Help.html) in a browser for the standalone HTML help. It is also
copied beside the console executable in both Debug and Release builds.

Alternatively, after building in Visual Studio, run directly from **Command
Prompt (cmd.exe)** in the solution directory:

```bat
RequestedServerBusy.Probe\bin\Debug\RequestedServerBusy.Probe.exe --demo
```

For Release use `bin\Release` instead of `bin\Debug`. Keep the EXE in its
original output folder: demo mode locates the solution/web project above it.
It does not build the web project; rebuild the entire solution after web changes.
No administrator rights, script execution, or execution-policy changes are needed.
Application-control policy must still allow the console EXE and IIS Express.

The default site address is **http://localhost:8085/**; the server runs only for
the demo's duration. No arguments (or just a port) retains the original
probe-only behavior against an already-running site. `--help` or `/?` prints usage.

The probe warms up the app, opens two 5-second requests, waits one second, and
sends six additional requests. It sends only eight requests in the reproduction
burst, disables proxies/redirects, and only targets localhost. It exits 0 only if:

1. Some held requests complete with HTTP 200 and the application handler marker.
2. Some requests return HTTP 503 with an IIS **503.2** detailed error page and
   **without** the application handler marker.
3. Every burst response is one of these expected results.
4. A subsequent health request returns HTTP 200.

Typical output (ordering may vary):

```text
Warm-up: HTTP 200; handler ran: True; IIS 503.2 page: False
Overflow 1: HTTP 503; handler ran: False; IIS 503.2 page: True
...
Holder 1: HTTP 200; handler ran: True; IIS 503.2 page: False
Holder 2: HTTP 200; handler ran: True; IIS 503.2 page: False
Recovery: HTTP 200; handler ran: True; IIS 503.2 page: False
Accepted: 2; confirmed native IIS 503.2: 6; total: 8
PASS: native IIS rejection and automatic recovery verified.
```

Close other demo tabs while testing; the limit applies to all requests for this
application, including its home page and health endpoint. The probe does not run
automatically from a browser. Demo mode stops only its own IIS Express process,
including on handled failures. Ctrl+C lets the bounded probe finish and clean up;
closing the window or forcibly terminating the console may leave the server running.
There are no persistent machine-wide IIS changes to undo.

For another port, pass `--demo 8086`. Configuration and W3C access logs are retained
in a unique `.local\console-<run-id>` directory printed on each run; look for
`sc-status=503` and `sc-substatus=2` using the log's `#Fields` column order.
Log writes may be buffered; stopping the server may leave final entries unflushed.
PASS is determined from responses, not log availability. Once the server stops,
the printed run directory may be deleted if its diagnostics are no longer needed.

The existing [PowerShell launcher](scripts/Start-IisExpress.ps1) remains optional
for environments that permit it; it is not used by the console demo.

## Open in Visual Studio 2013

Open [RequestedServerBusy.sln](RequestedServerBusy.sln), build, and run the
**Probe** startup project with `--demo` as above. Ordinary web-project F5 uses Visual Studio's own
IIS Express configuration, **not** the isolated low-limit configuration, so
ordinary F5 alone is not expected to reproduce the error.

The conditional Web Application targets import permits a command-line C# build
on machines without Visual Studio Web targets. To use Visual Studio's Web
Application tooling/publishing, install its Web Developer tools.

## Why the native console test produces a genuine IIS 503.2

The console demo copies IIS Express's configuration template into a private
configuration and sets this **server-level** setting there:

```xml
<system.webServer>
  <serverRuntime appConcurrentRequestLimit="2" />
</system.webServer>
```

Do not put it into the application's Web.config: the section is normally locked
at the server level. `Hold.ashx` uses `Task.Delay(5000)` to keep accepted requests
in flight without exhausting the CLR thread pool. IIS's native concurrent-request
gate rejects excess requests before the ASP.NET handler executes. Neither
`Hold.ashx` nor `Health.ashx` sets status 503, and no application-level semaphore
simulates rejection. The separate `Busy.ashx` endpoint deliberately sets status
503 for the browser demo; the native console probe never calls it.

### Distinguish the different queues

These settings are **not interchangeable**:

| Mechanism | Setting | This sample |
|---|---|---|
| IIS per-application concurrent-request queue/gate | `system.webServer/serverRuntime@appConcurrentRequestLimit` | **Used: 2; HTTP 503.2** |
| ASP.NET integrated-mode process-wide queue | `applicationPool@requestQueueLimit`, `maxConcurrentRequestsPerCPU` in aspnet.config | Not changed |
| HTTP.sys application-pool kernel queue | Application pool `queueLength` | Not changed |
| Stopped/disabled application pool | Pool state / rapid-fail protection | Not used |

A kernel queue overflow is generally investigated with HTTPERR logs (for example
`QueueFull`); stopping a pool can also produce a 503 but does not demonstrate queue
overflow. This sample proves the **IIS native concurrent-request limit** case,
not HTTP.sys kernel queue exhaustion or an ASP.NET process-wide queue overflow.
Error wording varies with IIS version/localization; HTTP 503 plus IIS substatus 2
is the diagnostic identifier. This is not a reproduction of every possible 503.

## Native 503.2 full IIS alternative (dedicated local test site only)

Use IIS Manager as administrator on a development machine:

1. Enable the ASP.NET 4.x, .NET Extensibility 4.x, ISAPI Extensions, and ISAPI
   Filters IIS features.
2. Build the solution. Create a **new dedicated** application pool named
   `BusyDemoPool`, .NET CLR v4.0, Integrated pipeline.
3. Create a **new dedicated** site named `BusyDemo`, physical path
   `RequestedServerBusy.Web`, pool `BusyDemoPool`, HTTP port `8085`,
   host name `localhost`. Do not add a remote binding.
4. Give `IIS AppPool\BusyDemoPool` Read & Execute access to that web directory,
   including `bin`, and required parent-directory traversal. Prefer a dedicated
   deployment directory, not access to an entire user profile.
5. In an elevated **Command Prompt**, apply the setting **only to this site**:

   ```bat
   "%WINDIR%\System32\inetsrv\appcmd.exe" set config "BusyDemo" /section:system.webServer/serverRuntime /appConcurrentRequestLimit:2 /commit:apphost
   ```

6. Browse the site locally, then run the probe **without `--demo`**:
   `RequestedServerBusy.Probe\bin\Debug\RequestedServerBusy.Probe.exe 8085`.
   Keep detailed errors enabled
   for local requests (the supplied Web.config uses `DetailedLocalOnly`).
7. Check the site's W3C IIS logs for `503 2`. The health endpoint must recover
   after the held requests finish. No pool restart should be necessary.

For rollback, remove only the dedicated `BusyDemo` site and `BusyDemoPool` pool
and any test-directory ACL you added. Never apply the low limit to shared sites,
Default Web Site, a shared pool, or the machine-level defaults.

## Troubleshooting

- **All requests are 200:** probably running plain F5 or the wrong port/config.
  Run the console with `--demo`. The default IIS limit is much higher.
- **500.19:** read the configuration error details. Check ASP.NET installation,
  configuration locks, permissions, and whether the native limit was put in
  Web.config instead of applicationhost.config.
- **503 without 503.2:** check pool state and IIS/HTTPERR logs. This probe
  deliberately fails rather than reporting any arbitrary 503 as a successful
  queue-limit reproduction.
- **Connection refused:** IIS Express is not running or failed to bind. Inspect
  its console output. Choose a free port.
- **Build reports missing framework reference assemblies:** install the .NET
  Framework 4.5 targeting pack / Visual Studio 2013 developer tools.

## Verification performed

- Browser demo: Debug and Release builds passed. Local IIS Express integration
  checks confirmed real HTTP 503.0, `SimulatedBusy`, `Retry-After: 5`, noncached
  response content, and HTTP 200 recovery, at both site root and an application
  subfolder with normal concurrency settings.
- Browser automation confirmed same-page results, only two requests per click,
  double-click protection, repeat runs, safe text rendering, and visible failures
  for replaced 503 pages, unexpected 200/403, failed recovery, network errors, and
  the 15-second timeout.
- The unchanged native console probe still passed with two accepted responses,
  six native IIS 503.2 rejections, and recovery after adding the browser demo.
- These new checks used local IIS Express, not deployment to the remote full IIS
  server. Site bindings, permissions and network access on that server must be
  verified during deployment.
- Debug and Release builds passed against the installed .NET Framework 4.5
  reference assemblies, using the Framework MSBuild/C# compiler fallback.
- IIS Express returned two HTTP 200 held responses and six native HTTP 503.2
  responses during the eight-request burst; none of the rejected requests
  carried the application handler marker.
- The recovery endpoint and ASP.NET home page returned HTTP 200.
- The probe rejected an invalid port with exit code 2.
- The script-free console `--demo` mode passed in Debug on port 8085 and Release
  on port 8086, with two accepted requests, six confirmed native IIS 503.2
  rejections, and successful recovery in each run. Both ports were unreachable
  after cleanup.
- Invalid low/high ports and extra demo arguments returned exit code 2.
- HTML help opened in a browser with working section links; output copies beside
  the Debug and Release executables matched the original.

Visual Studio 2013 itself was not installed on the verification machine; opening
the solution in that IDE was not tested. The solution/project format and source
target Visual Studio 2013, C# 5, and .NET Framework 4.5.

## Microsoft references

- [IIS serverRuntime and appConcurrentRequestLimit](https://learn.microsoft.com/en-us/iis/configuration/system.webserver/serverruntime)
- [IIS application pool settings and queueLength](https://learn.microsoft.com/en-us/iis/configuration/system.applicationhost/applicationpools/add/)
- [ASP.NET applicationPool settings in aspnet.config](https://learn.microsoft.com/en-us/dotnet/framework/configure-apps/file-schema/web/applicationpool-element-web-settings)
