param(
    [ValidateRange(1024, 65535)]
    [int]$Port = 8085,
    [switch]$PrepareOnly
)

$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$iis = Join-Path $env:ProgramFiles 'IIS Express\iisexpress.exe'
if (-not (Test-Path $iis)) {
    $iis = Join-Path ${env:ProgramFiles(x86)} 'IIS Express\iisexpress.exe'
}
if (-not (Test-Path $iis)) {
    throw 'Install IIS Express (included with Visual Studio 2013 Web Developer tools).'
}

$msbuildCommand = Get-Command MSBuild.exe -ErrorAction SilentlyContinue
if ($msbuildCommand) {
    $msbuild = $msbuildCommand.Source
} else {
    $msbuild = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\MSBuild.exe'
}
if (-not (Test-Path $msbuild)) {
    throw 'MSBuild was not found. Run from a Visual Studio Developer PowerShell or install .NET Framework build tools.'
}
& $msbuild (Join-Path $root 'RequestedServerBusy.sln') /t:Build /p:Configuration=Debug /nologo /verbosity:minimal
if ($LASTEXITCODE -ne 0) {
    throw "Build failed with exit code $LASTEXITCODE. Install the .NET Framework 4.5 targeting pack."
}

$local = Join-Path $root '.local'
$logs = Join-Path $local 'logs'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
$template = Join-Path (Split-Path $iis -Parent) 'config\templates\PersonalWebServer\applicationhost.config'
[xml]$config = Get-Content -LiteralPath $template -Raw
$pools = $config.configuration.'system.applicationHost'.applicationPools
foreach ($pool in @($pools.SelectNodes('add'))) {
    $pools.RemoveChild($pool) | Out-Null
}
$pool = $config.CreateElement('add')
$pool.SetAttribute('name', 'BusyDemoPool')
$pool.SetAttribute('managedRuntimeVersion', 'v4.0')
$pool.SetAttribute('managedPipelineMode', 'Integrated')
$pools.AppendChild($pool) | Out-Null

$sites = $config.configuration.'system.applicationHost'.sites
foreach ($site in @($sites.SelectNodes('site'))) {
    $sites.RemoveChild($site) | Out-Null
}
$site = $config.CreateElement('site')
$site.SetAttribute('name', 'BusyDemo')
$site.SetAttribute('id', '1')
$application = $config.CreateElement('application')
$application.SetAttribute('path', '/')
$application.SetAttribute('applicationPool', 'BusyDemoPool')
$directory = $config.CreateElement('virtualDirectory')
$directory.SetAttribute('path', '/')
$directory.SetAttribute('physicalPath', (Join-Path $root 'RequestedServerBusy.Web'))
$application.AppendChild($directory) | Out-Null
$site.AppendChild($application) | Out-Null
$bindings = $config.CreateElement('bindings')
$binding = $config.CreateElement('binding')
$binding.SetAttribute('protocol', 'http')
$binding.SetAttribute('bindingInformation', "*:${Port}:localhost")
$bindings.AppendChild($binding) | Out-Null
$site.AppendChild($bindings) | Out-Null
$log = $config.CreateElement('logFile')
$log.SetAttribute('directory', $logs)
$log.SetAttribute('logFormat', 'W3C')
$log.SetAttribute('logExtFileFlags', 'Date,Time,ClientIP,Method,UriStem,HttpStatus,HttpSubStatus,Win32Status,TimeTaken')
$site.AppendChild($log) | Out-Null
$sites.AppendChild($site) | Out-Null

$webServer = $config.configuration.'system.webServer'
$runtime = $webServer.SelectSingleNode('serverRuntime')
if (-not $runtime) {
    $runtime = $config.CreateElement('serverRuntime')
    $webServer.AppendChild($runtime) | Out-Null
}
$runtime.SetAttribute('appConcurrentRequestLimit', '2')
$configPath = Join-Path $local 'applicationhost.config'
$config.Save($configPath)
Write-Host "Isolated IIS config: $configPath"
Write-Host "Open http://localhost:$Port/ ; run the probe in a second terminal."
Write-Host 'The native IIS concurrent-request queue limit is 2. No machine-wide configuration was changed.'
if (-not $PrepareOnly) {
    & $iis "/config:$configPath" '/site:BusyDemo' '/systray:false'
    if ($LASTEXITCODE -ne 0) {
        throw "IIS Express exited with code $LASTEXITCODE."
    }
}
