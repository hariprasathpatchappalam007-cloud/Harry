/* =====================================================================================
   02 - Migrate data from SOA_CallLog_Core into the segregated tables
   - Copies in SrNo-range batches (small transactions, low log/lock pressure).
   - SrNo values are preserved. Re-runnable: rows already copied are skipped,
     so it can be run once now (bulk) and again at cut-over (delta).
   - Source table is NOT modified.
   ===================================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.SOA_CallLog_Core', N'U') IS NULL
BEGIN
    RAISERROR(N'dbo.SOA_CallLog_Core is not a table (already cut over?). Migration aborted.', 16, 1);
    RETURN;
END

DECLARE @BatchSize int = 50000;
DECLARE @MinSrNo int, @MaxSrNo int, @From int, @To int, @Rows int, @T sysname, @Sql nvarchar(max);

/* Service_Name -> target table map (driven by the same CASE function used by the proc) */
IF OBJECT_ID(N'tempdb..#Map') IS NOT NULL DROP TABLE #Map;
SELECT  DISTINCT
        Service_Name = ISNULL(Service_Name, N''),
        TableName    = dbo.fn_SOA_CallLog_Core_GetTable(Service_Name)
INTO    #Map
FROM    dbo.SOA_CallLog_Core;

CREATE CLUSTERED INDEX CX_Map ON #Map (TableName, Service_Name);

SELECT @MinSrNo = MIN(SrNo), @MaxSrNo = MAX(SrNo) FROM dbo.SOA_CallLog_Core;
SET @From = @MinSrNo;

WHILE @From <= @MaxSrNo
BEGIN
    SET @To = @From + @BatchSize - 1;

    DECLARE cur CURSOR LOCAL FAST_FORWARD FOR SELECT DISTINCT TableName FROM #Map;
    OPEN cur;
    FETCH NEXT FROM cur INTO @T;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @Sql = N'
INSERT INTO dbo.' + QUOTENAME(@T) + N'
    (SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message,
     Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date)
SELECT s.SrNo, s.Lead_No, s.XREF, s.Service_Code, s.RequestXML, s.ResponseXML, s.Status_Message,
       s.Method_Name, s.Service_Name, s.CreatedBy_User, s.CreatedOn_Date, s.UpdatedBy_User, s.UpdatedOn_Date
FROM   dbo.SOA_CallLog_Core s
JOIN   #Map m ON m.Service_Name = ISNULL(s.Service_Name, N'''') AND m.TableName = @T
WHERE  s.SrNo BETWEEN @From AND @To
  AND  NOT EXISTS (SELECT 1 FROM dbo.' + QUOTENAME(@T) + N' t WHERE t.SrNo = s.SrNo);
SET @Rows = @@ROWCOUNT;';

        BEGIN TRAN;
            EXEC sys.sp_executesql @Sql, N'@T sysname, @From int, @To int, @Rows int OUTPUT',
                 @T = @T, @From = @From, @To = @To, @Rows = @Rows OUTPUT;
        COMMIT;

        IF @Rows > 0
            RAISERROR(N'%s : SrNo %d - %d : %d rows', 0, 1, @T, @From, @To, @Rows) WITH NOWAIT;

        FETCH NEXT FROM cur INTO @T;
    END
    CLOSE cur;
    DEALLOCATE cur;

    SET @From = @To + 1;
END
GO

/* ---------- Validation: source vs target row counts per table ---------- */
;WITH Src AS
(
    SELECT TableName = dbo.fn_SOA_CallLog_Core_GetTable(Service_Name), Cnt = COUNT_BIG(*)
    FROM   dbo.SOA_CallLog_Core
    GROUP BY dbo.fn_SOA_CallLog_Core_GetTable(Service_Name)
),
Tgt AS
(
    SELECT TableName = t.name, Cnt = SUM(p.rows)
    FROM   sys.tables t
    JOIN   sys.partitions p ON p.object_id = t.object_id AND p.index_id IN (0, 1)
    WHERE  t.name LIKE N'SOA[_]CallLog[_]Core[_]%' AND t.name <> N'SOA_CallLog_Core_Legacy'
    GROUP BY t.name
)
SELECT  TableName   = COALESCE(s.TableName, t.TableName),
        SourceRows  = ISNULL(s.Cnt, 0),
        TargetRows  = ISNULL(t.Cnt, 0),
        Status      = CASE WHEN ISNULL(s.Cnt, 0) = ISNULL(t.Cnt, 0) THEN 'OK' ELSE 'MISMATCH' END
FROM    Src s
FULL JOIN Tgt t ON t.TableName = s.TableName
ORDER BY 1;
GO
