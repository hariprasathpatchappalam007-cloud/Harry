/* =====================================================================================
   03 - Cut-over (run in a maintenance window with the application stopped)
     Step 1 : Re-run 02_Migrate_Data.sql (delta copy) and confirm all rows = 'OK'.
     Step 2 : Run this script.
     Step 3 : Deploy the updated procedure (04_SOA_Calllog_Core_Insertion_Segregated.sql).

   After this script:
     - Original table is renamed to SOA_CallLog_Core_Legacy (kept as backup, drop later).
     - A UNION ALL view named SOA_CallLog_Core replaces it, so existing SELECTs / reports
       / lookups such as "select top 1 lead_no from SOA_Calllog_Core where XREF = ..."
       continue to work unchanged. INSERT/UPDATE must go through the routed proc logic.

   Before running, list other objects that WRITE to the table (they must be changed too):
       SELECT OBJECT_SCHEMA_NAME(object_id) + '.' + OBJECT_NAME(object_id)
       FROM sys.sql_modules WHERE definition LIKE '%SOA[_]CallLog[_]Core%';
   ===================================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRAN;

/* ---------- Guard: every source row must exist in a segregated table ---------- */
DECLARE @Missing bigint;
SELECT @Missing = COUNT_BIG(*)
FROM   dbo.SOA_CallLog_Core s WITH (TABLOCKX, HOLDLOCK)
WHERE  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_ContractBookingService   t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_CreateAmortSchedule      t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_CreateDDARegistration    t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_DDACallbackService       t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_DDACancelCallbackService t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_DDACancellation          t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_DDADocumentUpload        t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_Dedupe                   t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_FetchContractDetails     t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_FetchPSCalcBalloonPay    t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_IjaraInitiation          t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_QRDocumentUpload         t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_QueryAccountBalance      t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_UpdateIjaraInitiation    t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_UpdatePropertyDetails    t WHERE t.SrNo = s.SrNo)
  AND  NOT EXISTS (SELECT 1 FROM dbo.SOA_CallLog_Core_Others                   t WHERE t.SrNo = s.SrNo);

IF @Missing > 0
BEGIN
    ROLLBACK;
    RAISERROR(N'%I64d rows not yet migrated. Re-run 02_Migrate_Data.sql first.', 16, 1, @Missing);
    SET NOEXEC ON;  -- skip the rest of the script
END

/* ---------- Restart the shared sequence after the highest migrated SrNo ---------- */
DECLARE @Next bigint = ISNULL((SELECT MAX(SrNo) FROM dbo.SOA_CallLog_Core), 0) + 1;
DECLARE @Sql nvarchar(max) =
    N'ALTER SEQUENCE dbo.Seq_SOA_CallLog_Core_SrNo RESTART WITH ' + CAST(@Next AS nvarchar(20)) + N';';
EXEC sys.sp_executesql @Sql;

/* ---------- Rename original table (kept as backup) ---------- */
EXEC sys.sp_rename N'dbo.SOA_CallLog_Core', N'SOA_CallLog_Core_Legacy', N'OBJECT';

COMMIT;
GO

/* ---------- Compatibility view with the original name (read-only usage) ---------- */
CREATE OR ALTER VIEW dbo.SOA_CallLog_Core
AS
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_ContractBookingService
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_CreateAmortSchedule
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_CreateDDARegistration
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_DDACallbackService
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_DDACancelCallbackService
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_DDACancellation
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_DDADocumentUpload
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_Dedupe
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_FetchContractDetails
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_FetchPSCalcBalloonPay
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_IjaraInitiation
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_QRDocumentUpload
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_QueryAccountBalance
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_UpdateIjaraInitiation
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_UpdatePropertyDetails
UNION ALL
SELECT SrNo, Lead_No, XREF, Service_Code, RequestXML, ResponseXML, Status_Message, Method_Name, Service_Name, CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date FROM dbo.SOA_CallLog_Core_Others;
GO

/* ---------- Rollback (only if needed, before new rows are written) ----------
DROP VIEW dbo.SOA_CallLog_Core;
EXEC sys.sp_rename N'dbo.SOA_CallLog_Core_Legacy', N'SOA_CallLog_Core', N'OBJECT';
------------------------------------------------------------------------------- */
SET NOEXEC OFF;
GO
