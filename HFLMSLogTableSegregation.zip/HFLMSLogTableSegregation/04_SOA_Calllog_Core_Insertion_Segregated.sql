/* =====================================================================================
   04 - Replacement for the INSERT / UPDATE blocks in the SOA_CallLog_Core procedure
   - Target table is chosen by CASE on @Service_Name (dbo.fn_SOA_CallLog_Core_GetTable).
   - Table name comes only from the fixed CASE list + QUOTENAME, all values are passed
     as sp_executesql parameters (no SQL injection).
   - Lead_No lookups read the dbo.SOA_CallLog_Core view, so the referenced XREF is found
     whichever service table it lives in.
   - Apply the same pattern to any other ENTRY_TYPE in the proc that writes to the table.
   ===================================================================================== */

/* ---------- Add once, near the top of the procedure body ---------- */
DECLARE @TargetTable  sysname,
        @Sql          nvarchar(max),
        @NewSrNo      int,
        @RefLeadNo    nvarchar(100),
        @ReqXmlText   nvarchar(max) = CAST(@RequestXML  AS nvarchar(max)),
        @RespXmlText  nvarchar(max) = CAST(@ResponseXML AS nvarchar(max));


IF @ENTRY_TYPE = 'INSERT_SOA_REQUEST_CORE_DDA_Callback'
BEGIN
    SET @TargetTable = dbo.fn_SOA_CallLog_Core_GetTable(@Service_Name);

    SELECT TOP 1 @RefLeadNo = Lead_No FROM dbo.SOA_CallLog_Core WHERE XREF = @Service_Code;

    SET @NewSrNo = NEXT VALUE FOR dbo.Seq_SOA_CallLog_Core_SrNo;

    SET @Sql = N'
    INSERT INTO dbo.' + QUOTENAME(@TargetTable) + N'
    (
        SrNo, Lead_No, XREF, Service_Code, RequestXML, [Status_Message],
        Method_Name, [Service_Name], CreatedBy_User, CreatedOn_Date
    )
    VALUES
    (
        @SrNo, @Lead_No, @XREF, NULL, @RequestXML, @Status_Message,
        @Method_Name, @Service_Name, @User_ID, GETDATE()
    );';

    EXEC sys.sp_executesql @Sql,
        N'@SrNo int, @Lead_No nvarchar(100), @XREF nvarchar(100), @RequestXML nvarchar(max),
          @Status_Message nvarchar(1000), @Method_Name nvarchar(140), @Service_Name nvarchar(100),
          @User_ID nvarchar(100)',
        @SrNo           = @NewSrNo,
        @Lead_No        = @RefLeadNo,
        @XREF           = @XREF,
        @RequestXML     = @ReqXmlText,
        @Status_Message = @Status_Message,
        @Method_Name    = @Method_Name,
        @Service_Name   = @Service_Name,
        @User_ID        = @User_ID;

    SELECT SrNo = @NewSrNo;
END

IF @ENTRY_TYPE = 'UPDATE_SOA_RESPONSE_CORE_DDA_Callback'
BEGIN
    -- Caller may not pass @Service_Name on update: resolve it from the row being updated
    IF NULLIF(LTRIM(RTRIM(@Service_Name)), '') IS NULL
        SELECT TOP 1 @Service_Name = Service_Name
        FROM   dbo.SOA_CallLog_Core
        WHERE  XREF = @XREF
          AND  (ISNULL(@SrNo, 0) = 0 OR SrNo = @SrNo)
        ORDER BY SrNo DESC;

    SET @TargetTable = dbo.fn_SOA_CallLog_Core_GetTable(@Service_Name);

    SELECT TOP 1 @RefLeadNo = Lead_No FROM dbo.SOA_CallLog_Core WHERE XREF = @Lead_No;

    SET @Sql = N'
    UPDATE dbo.' + QUOTENAME(@TargetTable) + N' SET
        ResponseXML      = CASE ISNULL(@ResponseXML, '''') WHEN '''' THEN ResponseXML ELSE @ResponseXML END,
        [Status_Message] = @Status_Message,
        UpdatedOn_Date   = GETDATE(),
        UpdatedBy_User   = @User_ID,
        Lead_No          = @Lead_No
    WHERE XREF = @XREF
      AND (ISNULL(@SrNo, 0) = 0 OR SrNo = @SrNo);';

    EXEC sys.sp_executesql @Sql,
        N'@ResponseXML nvarchar(max), @Status_Message nvarchar(1000), @User_ID nvarchar(100),
          @Lead_No nvarchar(100), @XREF nvarchar(100), @SrNo int',
        @ResponseXML    = @RespXmlText,
        @Status_Message = @Status_Message,
        @User_ID        = @User_ID,
        @Lead_No        = @RefLeadNo,
        @XREF           = @XREF,
        @SrNo           = @SrNo;
END
