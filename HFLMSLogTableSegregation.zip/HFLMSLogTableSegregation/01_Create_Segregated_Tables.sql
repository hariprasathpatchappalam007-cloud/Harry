/* =====================================================================================
   01 - Create sequence, routing function and segregated SOA_CallLog_Core_* tables
   - One table per service in service_name.txt + SOA_CallLog_Core_Others (catch-all).
   - SrNo comes from one shared SEQUENCE so it stays unique across all tables
     (existing SrNo values are preserved during migration).
   - Requires SQL Server 2016 SP1+ (CREATE OR ALTER). Safe to re-run.
   ===================================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* ---------- 1. Shared sequence for SrNo (restarted at cut-over, see script 03) ---------- */
IF OBJECT_ID(N'dbo.Seq_SOA_CallLog_Core_SrNo', N'SO') IS NULL
BEGIN
    DECLARE @Start bigint = ISNULL((SELECT MAX(SrNo) FROM dbo.SOA_CallLog_Core), 0) + 1;
    DECLARE @Sql nvarchar(max) =
        N'CREATE SEQUENCE dbo.Seq_SOA_CallLog_Core_SrNo AS int START WITH '
        + CAST(@Start AS nvarchar(20)) + N' INCREMENT BY 1 CACHE 100;';
    EXEC sys.sp_executesql @Sql;
END
GO

/* ---------- 2. Routing function: Service_Name -> table name (CASE based) ---------- */
CREATE OR ALTER FUNCTION dbo.fn_SOA_CallLog_Core_GetTable (@Service_Name nvarchar(100))
RETURNS sysname
WITH SCHEMABINDING
AS
BEGIN
    RETURN CASE UPPER(LTRIM(RTRIM(ISNULL(@Service_Name, N''))))
        WHEN N'CONTRACTBOOKINGSERVICE'   THEN N'SOA_CallLog_Core_ContractBookingService'
        WHEN N'CREATEAMORTSCHEDULE'      THEN N'SOA_CallLog_Core_CreateAmortSchedule'
        WHEN N'CREATEDDAREGISTRATION'    THEN N'SOA_CallLog_Core_CreateDDARegistration'
        WHEN N'DDACALLBACKSERVICE'       THEN N'SOA_CallLog_Core_DDACallbackService'
        WHEN N'DDACANCELCALLBACKSERVICE' THEN N'SOA_CallLog_Core_DDACancelCallbackService'
        WHEN N'DDACANCELLATION'          THEN N'SOA_CallLog_Core_DDACancellation'
        WHEN N'DDADOCUMENTUPLOAD'        THEN N'SOA_CallLog_Core_DDADocumentUpload'
        WHEN N'DEDUPE'                   THEN N'SOA_CallLog_Core_Dedupe'
        WHEN N'FETCH_CONTRACT_DETAILS'   THEN N'SOA_CallLog_Core_FetchContractDetails'
        WHEN N'FETCH_PSCALC_BALLOON_PAY' THEN N'SOA_CallLog_Core_FetchPSCalcBalloonPay'
        WHEN N'IJARA_INITIATION'         THEN N'SOA_CallLog_Core_IjaraInitiation'
        WHEN N'QRDOCUMENTUPLOAD'         THEN N'SOA_CallLog_Core_QRDocumentUpload'
        WHEN N'QUERY ACCOUNT BALANCE'    THEN N'SOA_CallLog_Core_QueryAccountBalance'
        WHEN N'UPDATE_IJARA_INITIATION'  THEN N'SOA_CallLog_Core_UpdateIjaraInitiation'
        WHEN N'UPDATE_PROPERTY_DETAILS'  THEN N'SOA_CallLog_Core_UpdatePropertyDetails'
        ELSE                                  N'SOA_CallLog_Core_Others'
    END;
END
GO

/* ---------- 3. Tables + indexes (same structure as SOA_CallLog_Core) ---------- */
DECLARE @Tables TABLE (TableName sysname PRIMARY KEY);
INSERT INTO @Tables (TableName) VALUES
    (N'SOA_CallLog_Core_ContractBookingService'),
    (N'SOA_CallLog_Core_CreateAmortSchedule'),
    (N'SOA_CallLog_Core_CreateDDARegistration'),
    (N'SOA_CallLog_Core_DDACallbackService'),
    (N'SOA_CallLog_Core_DDACancelCallbackService'),
    (N'SOA_CallLog_Core_DDACancellation'),
    (N'SOA_CallLog_Core_DDADocumentUpload'),
    (N'SOA_CallLog_Core_Dedupe'),
    (N'SOA_CallLog_Core_FetchContractDetails'),
    (N'SOA_CallLog_Core_FetchPSCalcBalloonPay'),
    (N'SOA_CallLog_Core_IjaraInitiation'),
    (N'SOA_CallLog_Core_QRDocumentUpload'),
    (N'SOA_CallLog_Core_QueryAccountBalance'),
    (N'SOA_CallLog_Core_UpdateIjaraInitiation'),
    (N'SOA_CallLog_Core_UpdatePropertyDetails'),
    (N'SOA_CallLog_Core_Others');

DECLARE @T sysname, @Sql nvarchar(max);
DECLARE cur CURSOR LOCAL FAST_FORWARD FOR SELECT TableName FROM @Tables;
OPEN cur;
FETCH NEXT FROM cur INTO @T;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF OBJECT_ID(N'dbo.' + QUOTENAME(@T), N'U') IS NULL
    BEGIN
        SET @Sql = N'
CREATE TABLE dbo.' + QUOTENAME(@T) + N'
(
    SrNo            int            NOT NULL CONSTRAINT ' + QUOTENAME(N'DF_' + @T + N'_SrNo') + N' DEFAULT (NEXT VALUE FOR dbo.Seq_SOA_CallLog_Core_SrNo),
    Lead_No         nvarchar(100)  NULL,
    XREF            nvarchar(100)  NULL,
    Service_Code    nvarchar(100)  NULL,
    RequestXML      xml            NULL,
    ResponseXML     xml            NULL,
    Status_Message  nvarchar(1000) NULL,
    Method_Name     nvarchar(140)  NULL,
    Service_Name    nvarchar(100)  NULL,
    CreatedBy_User  nvarchar(100)  NULL,
    CreatedOn_Date  datetime       NULL,
    UpdatedBy_User  nvarchar(100)  NULL,
    UpdatedOn_Date  datetime       NULL,
    CONSTRAINT ' + QUOTENAME(N'PK_' + @T) + N' PRIMARY KEY CLUSTERED (SrNo)
);

CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'IX_' + @T + N'_XREF') + N'
    ON dbo.' + QUOTENAME(@T) + N' (XREF) INCLUDE (Lead_No);

CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'IX_' + @T + N'_Lead_No') + N'
    ON dbo.' + QUOTENAME(@T) + N' (Lead_No);

CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'IX_' + @T + N'_CreatedOn_Date') + N'
    ON dbo.' + QUOTENAME(@T) + N' (CreatedOn_Date);';

        EXEC sys.sp_executesql @Sql;
        PRINT N'Created ' + @T;
    END
    FETCH NEXT FROM cur INTO @T;
END
CLOSE cur;
DEALLOCATE cur;
GO
