/*==============================================================================
  LMS Archival - Configuration setup
  Run in: LMS_DEV (database that owns FRM_GNARR and the archival procedure)
==============================================================================*/
USE [LMS_DEV];
GO

/*------------------------------------------------------------------------------
  1. Global settings in FRM_GNARR  (Code = 'ARCHIVAL')
------------------------------------------------------------------------------*/
;WITH cfg (Code, Value, DisplayValue) AS
(
    SELECT N'ARCHIVAL', N'SOURCE_DB',             N'LMS_DEV'          UNION ALL
    SELECT N'ARCHIVAL', N'ARCHIVAL_DB',           N'Tamweel_Archival' UNION ALL
    SELECT N'ARCHIVAL', N'LEAD_TABLE',            N'Lead_Details'     UNION ALL
    SELECT N'ARCHIVAL', N'LEAD_KEY_COLUMN',       N'Lead_Id'          UNION ALL  -- verify: PK column of Lead_Details
    SELECT N'ARCHIVAL', N'LEAD_STAGE_COLUMN',     N'Lead_Stage'       UNION ALL
    SELECT N'ARCHIVAL', N'MAX_RUN_MINUTES',       N'240'              UNION ALL  -- 0 = no time window
    SELECT N'ARCHIVAL', N'BATCH_DELAY',           N'00:00:00.100'     UNION ALL  -- pause between batches (hh:mm:ss.mmm)
    SELECT N'ARCHIVAL', N'AUTO_CREATE_ARCH_TABLE',N'Y'                           -- create missing archive tables
)
INSERT INTO dbo.FRM_GNARR (Code, Value, DisplayValue, Status, createdby_User, createdon_date)
SELECT c.Code, c.Value, c.DisplayValue, N'Active', N'SYSTEM', GETDATE()
FROM cfg AS c
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR g WHERE g.Code = c.Code AND g.Value = c.Value);
GO

/*------------------------------------------------------------------------------
  2. Lead stages eligible for archival (Code = 'ARCHIVAL_LEAD_STAGE')
     Values containing '%' are matched with LIKE, others with equality.
     Set Status <> 'Active' to exclude a stage.
------------------------------------------------------------------------------*/
;WITH stg (Value) AS
(
    SELECT N'OPS_PMU'             UNION ALL
    SELECT N'OPS_LODGMENT'        UNION ALL
    SELECT N'End_Of_Process'      UNION ALL
    SELECT N'CUST_OL_DECLINED'    UNION ALL
    SELECT N'REJECTED_BY_POLICY'  UNION ALL
    SELECT N'Decline'             UNION ALL
    SELECT N'OPS_DEAL_CANCELLED'  UNION ALL
    SELECT N'Cancelled%'
)
INSERT INTO dbo.FRM_GNARR (Code, Value, DisplayValue, Status, createdby_User, createdon_date)
SELECT N'ARCHIVAL_LEAD_STAGE', s.Value, s.Value, N'Active', N'SYSTEM', GETDATE()
FROM stg AS s
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR g WHERE g.Code = N'ARCHIVAL_LEAD_STAGE' AND g.Value = s.Value);
GO

/*------------------------------------------------------------------------------
  3. Per-table configuration
------------------------------------------------------------------------------*/
IF OBJECT_ID(N'dbo.ARCHIVAL_TABLE_CONFIG', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ARCHIVAL_TABLE_CONFIG
    (
        ConfigId          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ARCHIVAL_TABLE_CONFIG PRIMARY KEY,
        SchemaName        SYSNAME       NOT NULL CONSTRAINT DF_ATC_Schema    DEFAULT (N'dbo'),
        TableName         SYSNAME       NOT NULL,
        LeadJoinColumn    SYSNAME       NULL,     -- column joined to Lead_Details key; NULL = date-only archival
        DateColumn        SYSNAME       NOT NULL, -- column compared against retention cutoff
        KeyColumn         SYSNAME       NULL,     -- unique key for batching; NULL = auto-detect PK/identity
        RetentionMonths   INT           NOT NULL CONSTRAINT DF_ATC_Retention DEFAULT (6),
        BatchSize         INT           NOT NULL CONSTRAINT DF_ATC_Batch     DEFAULT (4000),
        MaxRowsPerRun     BIGINT        NOT NULL CONSTRAINT DF_ATC_MaxRows   DEFAULT (0),  -- 0 = unlimited
        IsEnabled         BIT           NOT NULL CONSTRAINT DF_ATC_Enabled   DEFAULT (1),
        ProcessOrder      INT           NOT NULL CONSTRAINT DF_ATC_Order     DEFAULT (100),
        LastRunOn         DATETIME      NULL,
        LastRowsArchived  BIGINT        NULL,
        ModifiedBy        NVARCHAR(100) NULL,
        ModifiedOn        DATETIME      NULL,
        CONSTRAINT UQ_ARCHIVAL_TABLE_CONFIG UNIQUE (SchemaName, TableName),
        CONSTRAINT CK_ATC_Retention CHECK (RetentionMonths > 0),
        CONSTRAINT CK_ATC_Batch     CHECK (BatchSize BETWEEN 1 AND 50000),
        CONSTRAINT CK_ATC_MaxRows   CHECK (MaxRowsPerRun >= 0)
    );
END;
GO

/*------------------------------------------------------------------------------
  4. Run log
------------------------------------------------------------------------------*/
IF OBJECT_ID(N'dbo.ARCHIVAL_RUN_LOG', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ARCHIVAL_RUN_LOG
    (
        LogId         BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ARCHIVAL_RUN_LOG PRIMARY KEY,
        RunId         UNIQUEIDENTIFIER NOT NULL,
        TableName     NVARCHAR(300)    NOT NULL,
        ProcessMode   VARCHAR(10)      NULL,
        CutoffDate    DATETIME         NULL,
        StartTime     DATETIME         NOT NULL,
        EndTime       DATETIME         NULL,
        RowsStaged    BIGINT           NULL,
        RowsArchived  BIGINT           NULL,
        Status        VARCHAR(20)      NOT NULL,
        ErrorMessage  NVARCHAR(4000)   NULL
    );
    CREATE INDEX IX_ARCHIVAL_RUN_LOG_RunId ON dbo.ARCHIVAL_RUN_LOG (RunId);
    CREATE INDEX IX_ARCHIVAL_RUN_LOG_Start ON dbo.ARCHIVAL_RUN_LOG (StartTime);
END;
GO

/*------------------------------------------------------------------------------
  5. Seed tables
     !! LeadJoinColumn / DateColumn are placeholders - verify against each table
        (see discovery query below). The procedure validates the columns and
        logs a FAILED row (no data touched) if a column does not exist.
     Note: SOA_CallLog_Salama_Docs / SOA_Calllog_Salama_Docs are the same table
           under the case-insensitive collation, so it is seeded once.
------------------------------------------------------------------------------*/
;WITH t (TableName, ProcessOrder) AS
(
    SELECT N'SOA_CallLog_Salama_Docs',          10 UNION ALL
    SELECT N'SOA_CallLog_SCORECARD',            10 UNION ALL
    SELECT N'SOA_CallLog_Contactless',          10 UNION ALL
    SELECT N'SOA_CallLog_Vymo',                 10 UNION ALL
    SELECT N'SOA_CallLog',                      10 UNION ALL
    SELECT N'SOA_Calllog_Statement',            10 UNION ALL
    SELECT N'SOA_CallLog_CRAT',                 10 UNION ALL
    SELECT N'SOA_CALLLOG_CUSTQUERY',            10 UNION ALL
    SELECT N'SOA_CallLog_CustomerScreening',    10 UNION ALL
    SELECT N'SOA_CallLog_Evaluation',           10 UNION ALL
    SELECT N'SOA_CallLog_CRAT_Enquiry',         10 UNION ALL
    SELECT N'SOA_Calllog_Core',                 10 UNION ALL
    SELECT N'Lead_Details_AmortSchedule',       20 UNION ALL
    SELECT N'CAS_AMORT_SCHEDULE',               20 UNION ALL
    SELECT N'LEAD_DETAILS_AUDIT',               20 UNION ALL
    SELECT N'LEAD_EVALUATION_REQUEST_AUDIT',    20 UNION ALL
    SELECT N'LEAD_DETAILS_DOC_HISTORY',         20 UNION ALL
    SELECT N'Bank_Statement_Detail',            20 UNION ALL
    SELECT N'ERROR_LOG',                        30 UNION ALL
    SELECT N'PERFORMANCE_TRACE_LOG',            30 UNION ALL
    SELECT N'FRM_MESSAGES',                     30
)
INSERT INTO dbo.ARCHIVAL_TABLE_CONFIG
    (SchemaName, TableName, LeadJoinColumn, DateColumn, KeyColumn, RetentionMonths, BatchSize, MaxRowsPerRun, IsEnabled, ProcessOrder, ModifiedBy, ModifiedOn)
SELECT N'dbo', t.TableName, N'Lead_Id', N'Created_On', NULL, 6, 4000, 0, 1, t.ProcessOrder, N'SYSTEM', GETDATE()
FROM t
WHERE NOT EXISTS (SELECT 1 FROM dbo.ARCHIVAL_TABLE_CONFIG c WHERE c.SchemaName = N'dbo' AND c.TableName = t.TableName);
GO

/*------------------------------------------------------------------------------
  Discovery helper: candidate lead / date / key columns for configured tables
------------------------------------------------------------------------------*/
-- SELECT cfg.TableName, c.name AS ColumnName, TYPE_NAME(c.system_type_id) AS DataType,
--        c.is_identity,
--        CASE WHEN EXISTS (SELECT 1 FROM sys.index_columns ic JOIN sys.indexes i ON i.object_id = ic.object_id AND i.index_id = ic.index_id
--                          WHERE i.is_primary_key = 1 AND ic.object_id = c.object_id AND ic.column_id = c.column_id) THEN 1 ELSE 0 END AS IsPK
-- FROM dbo.ARCHIVAL_TABLE_CONFIG cfg
-- JOIN sys.columns c ON c.object_id = OBJECT_ID(QUOTENAME(cfg.SchemaName) + N'.' + QUOTENAME(cfg.TableName))
-- WHERE c.name LIKE N'%lead%' OR TYPE_NAME(c.system_type_id) IN (N'date', N'datetime', N'datetime2', N'smalldatetime') OR c.is_identity = 1
-- ORDER BY cfg.TableName, c.column_id;

/*------------------------------------------------------------------------------
  Examples
------------------------------------------------------------------------------*/
-- 3-month retention for a table:
--   UPDATE dbo.ARCHIVAL_TABLE_CONFIG SET RetentionMonths = 3, ModifiedBy = SUSER_SNAME(), ModifiedOn = GETDATE() WHERE TableName = N'SOA_CallLog';
-- Stop archival for a table:
--   UPDATE dbo.ARCHIVAL_TABLE_CONFIG SET IsEnabled = 0, ModifiedBy = SUSER_SNAME(), ModifiedOn = GETDATE() WHERE TableName = N'FRM_MESSAGES';
-- Date-only archival (no Lead_Details filter):
--   UPDATE dbo.ARCHIVAL_TABLE_CONFIG SET LeadJoinColumn = NULL WHERE TableName = N'PERFORMANCE_TRACE_LOG';
-- Change archival DB:
--   UPDATE dbo.FRM_GNARR SET DisplayValue = N'Tamweel_Archival' WHERE Code = N'ARCHIVAL' AND Value = N'ARCHIVAL_DB';
