/*==============================================================================
  LMS Archival - Configuration setup
  Run in: LMS_DEV (database that owns FRM_GNARR and the archival procedure)
==============================================================================*/
USE [LMS_DEV];
GO

/*------------------------------------------------------------------------------
  1. Global settings in FRM_GNARR  (Code = 'ARCHIVAL')
------------------------------------------------------------------------------*/
;WITH cfg (Code, Value, DisplayValue) AS
(
    SELECT N'ARCHIVAL', N'SOURCE_DB',             N'LMS_DEV'          UNION ALL
    SELECT N'ARCHIVAL', N'ARCHIVAL_DB',           N'Tamweel_Archival' UNION ALL
    SELECT N'ARCHIVAL', N'LEAD_STAGE_COLUMN',     N'Lead_Stage'       UNION ALL  -- used when ApplyStageFilter = 1
    SELECT N'ARCHIVAL', N'MAX_RUN_MINUTES',       N'240'              UNION ALL  -- 0 = no time window
    SELECT N'ARCHIVAL', N'BATCH_DELAY',           N'00:00:00.100'     UNION ALL  -- pause between batches (hh:mm:ss.mmm)
    SELECT N'ARCHIVAL', N'AUTO_CREATE_ARCH_TABLE',N'Y'                           -- create missing archive tables
)
INSERT INTO dbo.FRM_GNARR (Code, Value, DisplayValue, Status, createdby_User, createdon_date)
SELECT c.Code, c.Value, c.DisplayValue, N'A', N'SYSTEM', GETDATE()
FROM cfg AS c
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR g WHERE g.Code = c.Code AND g.Value = c.Value);
GO

/*------------------------------------------------------------------------------
  2. Lead stages eligible for archival (Code = 'ARCHIVAL_LEAD_STAGE')
     Values containing '%' are matched with LIKE, others with equality.
     Set Status <> 'Active' to exclude a stage.
------------------------------------------------------------------------------*/
;WITH stg (Value) AS
(
    SELECT N'OPS_PMU'             UNION ALL
    SELECT N'OPS_LODGMENT'        UNION ALL
    SELECT N'End_Of_Process'      UNION ALL
    SELECT N'CUST_OL_DECLINED'    UNION ALL
    SELECT N'REJECTED_BY_POLICY'  UNION ALL
    SELECT N'Decline'             UNION ALL
    SELECT N'OPS_DEAL_CANCELLED'  UNION ALL
    SELECT N'Cancelled%'
)
INSERT INTO dbo.FRM_GNARR (Code, Value, DisplayValue, Status, createdby_User, createdon_date)
SELECT N'ARCHIVAL_LEAD_STAGE', s.Value, s.Value, N'A', N'SYSTEM', GETDATE()
FROM stg AS s
WHERE NOT EXISTS (SELECT 1 FROM dbo.FRM_GNARR g WHERE g.Code = N'ARCHIVAL_LEAD_STAGE' AND g.Value = s.Value);
GO

/*------------------------------------------------------------------------------
  3. Per-table configuration
------------------------------------------------------------------------------*/
IF OBJECT_ID(N'dbo.ARCHIVAL_TABLE_CONFIG', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ARCHIVAL_TABLE_CONFIG
    (
        ConfigId          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ARCHIVAL_TABLE_CONFIG PRIMARY KEY,
        SchemaName        SYSNAME       NOT NULL CONSTRAINT DF_ATC_Schema    DEFAULT (N'dbo'),
        TableName         SYSNAME       NOT NULL,
        ParentTable       SYSNAME       NULL,     -- table to join (e.g. Lead_Details); NULL = no join
        ParentJoinColumn  SYSNAME       NULL,     -- join column on ParentTable
        ChildJoinColumn   SYSNAME       NULL,     -- join column on this table
        ChildJoinColumn2  SYSNAME       NULL,     -- 2nd join: child column (default ChildJoinColumn)
        ParentJoinColumn2 SYSNAME       NULL,     -- 2nd join: parent column (default ParentJoinColumn)
        Join2Mode         VARCHAR(10)   NOT NULL CONSTRAINT DF_ATC_Join2Mode DEFAULT ('EXACT'), -- EXACT | PREFIXNUM
        DateSource        VARCHAR(6)    NOT NULL CONSTRAINT DF_ATC_DateSource DEFAULT ('SELF'), -- SELF | PARENT
        DateColumn        SYSNAME       NOT NULL, -- column compared against retention cutoff
        ApplyStageFilter  BIT           NOT NULL CONSTRAINT DF_ATC_Stage DEFAULT (0), -- Lead_Details stage filter
        KeyColumn         SYSNAME       NULL,     -- unique key for batching; NULL = auto-detect PK/identity
        RetentionMonths   INT           NOT NULL CONSTRAINT DF_ATC_Retention DEFAULT (6),
        BatchSize         INT           NOT NULL CONSTRAINT DF_ATC_Batch     DEFAULT (4000),
        MaxRowsPerRun     BIGINT        NOT NULL CONSTRAINT DF_ATC_MaxRows   DEFAULT (0),  -- 0 = unlimited
        IsEnabled         BIT           NOT NULL CONSTRAINT DF_ATC_Enabled   DEFAULT (1),
        ProcessOrder      INT           NOT NULL CONSTRAINT DF_ATC_Order     DEFAULT (100),
        LastRunOn         DATETIME      NULL,
        LastRowsArchived  BIGINT        NULL,
        ModifiedBy        NVARCHAR(100) NULL,
        ModifiedOn        DATETIME      NULL,
        CONSTRAINT UQ_ARCHIVAL_TABLE_CONFIG UNIQUE (SchemaName, TableName),
        CONSTRAINT CK_ATC_Retention CHECK (RetentionMonths > 0),
        CONSTRAINT CK_ATC_Batch     CHECK (BatchSize BETWEEN 1 AND 50000),
        CONSTRAINT CK_ATC_MaxRows   CHECK (MaxRowsPerRun >= 0),
        CONSTRAINT CK_ATC_DateSource CHECK (DateSource IN ('SELF', 'PARENT')),
        CONSTRAINT CK_ATC_Join2Mode  CHECK (Join2Mode IN ('EXACT', 'PREFIXNUM'))
    );
END;
GO

/*------------------------------------------------------------------------------
  3b. Upgrade an existing ARCHIVAL_TABLE_CONFIG (created by the first version)
------------------------------------------------------------------------------*/
IF COL_LENGTH(N'dbo.ARCHIVAL_TABLE_CONFIG', N'LeadJoinColumn') IS NOT NULL
   AND COL_LENGTH(N'dbo.ARCHIVAL_TABLE_CONFIG', N'ChildJoinColumn') IS NULL
    EXEC sp_rename N'dbo.ARCHIVAL_TABLE_CONFIG.LeadJoinColumn', N'ChildJoinColumn', N'COLUMN';

IF COL_LENGTH(N'dbo.ARCHIVAL_TABLE_CONFIG', N'ParentTable') IS NULL
    ALTER TABLE dbo.ARCHIVAL_TABLE_CONFIG ADD ParentTable SYSNAME NULL;

IF COL_LENGTH(N'dbo.ARCHIVAL_TABLE_CONFIG', N'ParentJoinColumn') IS NULL
    ALTER TABLE dbo.ARCHIVAL_TABLE_CONFIG ADD ParentJoinColumn SYSNAME NULL;

IF COL_LENGTH(N'dbo.ARCHIVAL_TABLE_CONFIG', N'ChildJoinColumn2') IS NULL
    ALTER TABLE dbo.ARCHIVAL_TABLE_CONFIG ADD ChildJoinColumn2 SYSNAME NULL;

IF COL_LENGTH(N'dbo.ARCHIVAL_TABLE_CONFIG', N'DateSource') IS NULL
    ALTER TABLE dbo.ARCHIVAL_TABLE_CONFIG ADD DateSource VARCHAR(6) NOT NULL CONSTRAINT DF_ATC_DateSource DEFAULT ('SELF');

IF COL_LENGTH(N'dbo.ARCHIVAL_TABLE_CONFIG', N'ApplyStageFilter') IS NULL
    ALTER TABLE dbo.ARCHIVAL_TABLE_CONFIG ADD ApplyStageFilter BIT NOT NULL CONSTRAINT DF_ATC_Stage DEFAULT (0);

IF COL_LENGTH(N'dbo.ARCHIVAL_TABLE_CONFIG', N'ParentJoinColumn2') IS NULL
    ALTER TABLE dbo.ARCHIVAL_TABLE_CONFIG ADD ParentJoinColumn2 SYSNAME NULL;

IF COL_LENGTH(N'dbo.ARCHIVAL_TABLE_CONFIG', N'Join2Mode') IS NULL
    ALTER TABLE dbo.ARCHIVAL_TABLE_CONFIG ADD Join2Mode VARCHAR(10) NOT NULL CONSTRAINT DF_ATC_Join2Mode DEFAULT ('EXACT');
GO

IF OBJECT_ID(N'dbo.CK_ATC_DateSource', N'C') IS NULL
    ALTER TABLE dbo.ARCHIVAL_TABLE_CONFIG ADD CONSTRAINT CK_ATC_DateSource CHECK (DateSource IN ('SELF', 'PARENT'));

IF OBJECT_ID(N'dbo.CK_ATC_Join2Mode', N'C') IS NULL
    ALTER TABLE dbo.ARCHIVAL_TABLE_CONFIG ADD CONSTRAINT CK_ATC_Join2Mode CHECK (Join2Mode IN ('EXACT', 'PREFIXNUM'));
GO

/*------------------------------------------------------------------------------
  4. Run log
------------------------------------------------------------------------------*/
IF OBJECT_ID(N'dbo.ARCHIVAL_RUN_LOG', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ARCHIVAL_RUN_LOG
    (
        LogId         BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ARCHIVAL_RUN_LOG PRIMARY KEY,
        RunId         UNIQUEIDENTIFIER NOT NULL,
        TableName     NVARCHAR(300)    NOT NULL,
        ProcessMode   VARCHAR(10)      NULL,
        CutoffDate    DATETIME         NULL,
        StartTime     DATETIME         NOT NULL,
        EndTime       DATETIME         NULL,
        RowsStaged    BIGINT           NULL,
        RowsArchived  BIGINT           NULL,
        Status        VARCHAR(20)      NOT NULL,
        ErrorMessage  NVARCHAR(4000)   NULL
    );
    CREATE INDEX IX_ARCHIVAL_RUN_LOG_RunId ON dbo.ARCHIVAL_RUN_LOG (RunId);
    CREATE INDEX IX_ARCHIVAL_RUN_LOG_Start ON dbo.ARCHIVAL_RUN_LOG (StartTime);
END;
GO

/*------------------------------------------------------------------------------
  5. Table rules (upsert). Only these tables are archived; any other row in
     ARCHIVAL_TABLE_CONFIG is disabled (IsEnabled = 0).

     DateSource = SELF   -> <Table>.DateColumn       < today - RetentionMonths
     DateSource = PARENT -> <ParentTable>.DateColumn < today - RetentionMonths
     Join  : Parent.ParentJoinColumn = Child.ChildJoinColumn
             [OR Parent.ISNULL(ParentJoinColumn2, ParentJoinColumn)
                 = f(Child.ISNULL(ChildJoinColumn2, ChildJoinColumn))]
             Join2Mode EXACT     -> f(x) = x
             Join2Mode PREFIXNUM -> f(x) = prefix + first digit run, suffix dropped
                                    MF147710-MBRE / MF147710MBRE / MF130802_CNV
                                    / MF30112-1811 / MF33103-USF8 -> MF147710 ...
     Join columns with different data types (nvarchar vs numeric) are aligned
     automatically by the procedure.
     ApplyStageFilter = 1 -> Lead_Details.Lead_Stage must also be in ARCHIVAL_LEAD_STAGE
------------------------------------------------------------------------------*/
DECLARE @Rules TABLE
(
    TableName         SYSNAME     NOT NULL,
    ParentTable       SYSNAME     NULL,
    ParentJoinColumn  SYSNAME     NULL,
    ChildJoinColumn   SYSNAME     NULL,
    ChildJoinColumn2  SYSNAME     NULL,
    DateSource        VARCHAR(6)  NOT NULL,
    DateColumn        SYSNAME     NOT NULL,
    ApplyStageFilter  BIT         NOT NULL,
    RetentionMonths   INT         NOT NULL,
    ProcessOrder      INT         NOT NULL,
    ParentJoinColumn2 SYSNAME     NULL,
    Join2Mode         VARCHAR(10) NOT NULL DEFAULT ('EXACT')
);

INSERT INTO @Rules (TableName, ParentTable, ParentJoinColumn, ChildJoinColumn, ChildJoinColumn2,
                    DateSource, DateColumn, ApplyStageFilter, RetentionMonths, ProcessOrder)
VALUES
 -- no join, own date column
 (N'FRM_MESSAGES',                  NULL, NULL, NULL, NULL, 'SELF', N'CreatedOn_Date', 0, 3, 30),
 (N'PERFORMANCE_TRACE_LOG',         NULL, NULL, NULL, NULL, 'SELF', N'CREATEDON_DATE', 0, 3, 30),
 (N'ERROR_LOG',                     NULL, NULL, NULL, NULL, 'SELF', N'CREATEDON_DATE', 0, 3, 30),
 (N'Bank_Statement_Detail',         NULL, NULL, NULL, NULL, 'SELF', N'Posting_Date',   0, 3, 20),
 (N'SOA_Calllog_Evaluation',        NULL, NULL, NULL, NULL, 'SELF', N'CreatedOn_Date', 0, 3, 10),
 (N'LEAD_DETAILS_AUDIT',            NULL, NULL, NULL, NULL, 'SELF', N'CreatedOn_Date', 0, 3, 20),
 (N'SOA_Calllog_CRAT_Enquiry',      NULL, NULL, NULL, NULL, 'SELF', N'CreatedOn_Date', 0, 3, 10),
 (N'SOA_CALLLOG_CUSTQUERY',         NULL, NULL, NULL, NULL, 'SELF', N'CreatedOn_Date', 0, 3, 10),
 (N'SOA_Calllog_CustomerScreening', NULL, NULL, NULL, NULL, 'SELF', N'CreatedOn_Date', 0, 3, 10),
 (N'SOA_Calllog',                   NULL, NULL, NULL, NULL, 'SELF', N'CreatedOn_Date', 0, 3, 10),
 -- join Lead_Details, Lead_Details.CreatedOn_Date drives retention
 (N'LEAD_EVALUATION_REQUEST_AUDIT', N'Lead_Details', N'Customer_SRNO', N'Customer_SRNO', NULL,         'PARENT', N'CreatedOn_Date', 1, 3, 20),
 (N'Lead_Details_AmortSchedule',    N'Lead_Details', N'Lead_No',       N'Lead_No',       NULL,         'PARENT', N'CreatedOn_Date', 1, 3, 20),
 (N'LEAD_DETAILS_DOC_HISTORY',      N'Lead_Details', N'Lead_No',       N'Lead_No',       NULL,         'PARENT', N'CreatedOn_Date', 1, 3, 20),
 (N'SOA_Calllog_Core',              N'Lead_Details', N'Lead_No',       N'Lead_No',       NULL,         'PARENT', N'CreatedOn_Date', 1, 3, 10),
 -- join FRM_SERVICE_REQUEST, own date column
 (N'CAS_AMORT_SCHEDULE',            N'FRM_SERVICE_REQUEST', N'ApplicationID', N'user_ref_no', NULL,   'SELF',   N'CreatedOn_Date', 0, 3, 20);

-- SOA_Calllog_Core.Lead_No holds either a lead no (LD-000124434) or an App_Ref_No with a suffix (MF147710-MBRE).
UPDATE @Rules
SET    ParentJoinColumn2 = N'App_Ref_No', Join2Mode = 'PREFIXNUM'
WHERE  TableName = N'SOA_Calllog_Core';

UPDATE c
SET    c.ParentTable       = r.ParentTable,
       c.ParentJoinColumn  = r.ParentJoinColumn,
       c.ChildJoinColumn   = r.ChildJoinColumn,
       c.ChildJoinColumn2  = r.ChildJoinColumn2,
       c.ParentJoinColumn2 = r.ParentJoinColumn2,
       c.Join2Mode         = r.Join2Mode,
       c.DateSource       = r.DateSource,
       c.DateColumn       = r.DateColumn,
       c.ApplyStageFilter = r.ApplyStageFilter,
       c.RetentionMonths  = r.RetentionMonths,
       c.ProcessOrder     = r.ProcessOrder,
       c.IsEnabled        = 1,
       c.ModifiedBy       = SUSER_SNAME(),
       c.ModifiedOn       = GETDATE()
FROM dbo.ARCHIVAL_TABLE_CONFIG AS c
JOIN @Rules AS r ON r.TableName = c.TableName
WHERE c.SchemaName = N'dbo';

INSERT INTO dbo.ARCHIVAL_TABLE_CONFIG
    (SchemaName, TableName, ParentTable, ParentJoinColumn, ChildJoinColumn, ChildJoinColumn2, ParentJoinColumn2, Join2Mode, DateSource, DateColumn,
     ApplyStageFilter, KeyColumn, RetentionMonths, BatchSize, MaxRowsPerRun, IsEnabled, ProcessOrder, ModifiedBy, ModifiedOn)
SELECT N'dbo', r.TableName, r.ParentTable, r.ParentJoinColumn, r.ChildJoinColumn, r.ChildJoinColumn2, r.ParentJoinColumn2, r.Join2Mode, r.DateSource, r.DateColumn,
       r.ApplyStageFilter, NULL, r.RetentionMonths, 4000, 0, 1, r.ProcessOrder, SUSER_SNAME(), GETDATE()
FROM @Rules AS r
WHERE NOT EXISTS (SELECT 1 FROM dbo.ARCHIVAL_TABLE_CONFIG c WHERE c.SchemaName = N'dbo' AND c.TableName = r.TableName);

UPDATE c
SET    c.IsEnabled = 0, c.ModifiedBy = SUSER_SNAME(), c.ModifiedOn = GETDATE()
FROM dbo.ARCHIVAL_TABLE_CONFIG AS c
WHERE c.IsEnabled = 1
  AND NOT EXISTS (SELECT 1 FROM @Rules r WHERE r.TableName = c.TableName);
GO

/*------------------------------------------------------------------------------
  Discovery helper: candidate lead / date / key columns for configured tables
------------------------------------------------------------------------------*/
-- SELECT cfg.TableName, c.name AS ColumnName, TYPE_NAME(c.system_type_id) AS DataType,
--        c.is_identity,
--        CASE WHEN EXISTS (SELECT 1 FROM sys.index_columns ic JOIN sys.indexes i ON i.object_id = ic.object_id AND i.index_id = ic.index_id
--                          WHERE i.is_primary_key = 1 AND ic.object_id = c.object_id AND ic.column_id = c.column_id) THEN 1 ELSE 0 END AS IsPK
-- FROM dbo.ARCHIVAL_TABLE_CONFIG cfg
-- JOIN sys.columns c ON c.object_id = OBJECT_ID(QUOTENAME(cfg.SchemaName) + N'.' + QUOTENAME(cfg.TableName))
-- WHERE c.name LIKE N'%lead%' OR TYPE_NAME(c.system_type_id) IN (N'date', N'datetime', N'datetime2', N'smalldatetime') OR c.is_identity = 1
-- ORDER BY cfg.TableName, c.column_id;

/*------------------------------------------------------------------------------
  Examples
------------------------------------------------------------------------------*/
-- 3-month retention for a table:
--   UPDATE dbo.ARCHIVAL_TABLE_CONFIG SET RetentionMonths = 3, ModifiedBy = SUSER_SNAME(), ModifiedOn = GETDATE() WHERE TableName = N'SOA_CallLog';
-- Stop archival for a table:
--   UPDATE dbo.ARCHIVAL_TABLE_CONFIG SET IsEnabled = 0, ModifiedBy = SUSER_SNAME(), ModifiedOn = GETDATE() WHERE TableName = N'FRM_MESSAGES';
-- Lead_Details joins on date only (ignore Lead_Stage):
--   UPDATE dbo.ARCHIVAL_TABLE_CONFIG SET ApplyStageFilter = 0 WHERE ParentTable = N'Lead_Details';
-- Change archival DB:
--   UPDATE dbo.FRM_GNARR SET DisplayValue = N'Tamweel_Archival' WHERE Code = N'ARCHIVAL' AND Value = N'ARCHIVAL_DB';
