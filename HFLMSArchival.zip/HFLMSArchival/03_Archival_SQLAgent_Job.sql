/*==============================================================================
  LMS Archival - Daily SQL Agent job (01:00 every day)
==============================================================================*/
USE [msdb];
GO

DECLARE @JobName SYSNAME = N'LMS_Daily_Archival';

IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = @JobName)
    EXEC msdb.dbo.sp_delete_job @job_name = @JobName, @delete_unused_schedule = 1;

EXEC msdb.dbo.sp_add_job
     @job_name = @JobName,
     @enabled = 1,
     @description = N'Moves closed/cancelled lead data from LMS to the archival DB (config: FRM_GNARR / ARCHIVAL_TABLE_CONFIG).',
     @owner_login_name = N'sa';

EXEC msdb.dbo.sp_add_jobstep
     @job_name = @JobName,
     @step_name = N'Run archival',
     @subsystem = N'TSQL',
     @database_name = N'LMS_DEV',
     @command = N'EXEC dbo.usp_LMS_Archival_Run;',
     @retry_attempts = 0,
     @on_success_action = 1,
     @on_fail_action = 2;

EXEC msdb.dbo.sp_add_jobschedule
     @job_name = @JobName,
     @name = N'LMS_Daily_Archival_0100',
     @freq_type = 4,              -- daily
     @freq_interval = 1,
     @active_start_time = 010000; -- 01:00:00

EXEC msdb.dbo.sp_add_jobserver @job_name = @JobName, @server_name = N'(local)';
GO

/*==============================================================================
  Recommended supporting indexes (run in LMS_DEV, adjust names per table)
  The staging query filters on DateColumn and semi-joins on LeadJoinColumn,
  so this index makes it a range seek instead of a full scan:

  CREATE NONCLUSTERED INDEX IX_SOA_CallLog_Archival
      ON dbo.SOA_CallLog (Created_On) INCLUDE (Lead_Id)
      WITH (ONLINE = ON, DATA_COMPRESSION = PAGE);   -- ONLINE requires Enterprise

  Lead_Details: CREATE INDEX IX_Lead_Details_Stage ON dbo.Lead_Details (Lead_Stage) INCLUDE (Lead_Id);
==============================================================================*/
