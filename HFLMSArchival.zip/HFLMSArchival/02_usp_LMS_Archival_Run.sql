/*==============================================================================
  LMS Archival - Daily batch procedure
  Run in: LMS_DEV

  Flow
    1. Read SOURCE_DB / ARCHIVAL_DB / run settings from FRM_GNARR (Code='ARCHIVAL').
    2. Load active lead stages (used only by tables with ApplyStageFilter = 1).
    3. For every enabled row in ARCHIVAL_TABLE_CONFIG (by ProcessOrder):
         - validate table / parent / columns, auto-detect key, verify archive table columns
         - filter: date (own table or parent table) < cutoff, optional EXISTS join to parent
           (with optional OR-alternate child column) and optional Lead_Stage filter
         - stage qualifying keys in key order
         - loop: DELETE src ... OUTPUT deleted.* INTO archive  (atomic move per batch)
    4. Every step is logged in ARCHIVAL_RUN_LOG; a failure on one table does not stop others.

  Usage
    EXEC dbo.usp_LMS_Archival_Run;                                  -- full run
    EXEC dbo.usp_LMS_Archival_Run @TableName = N'SOA_CallLog';       -- single table
    EXEC dbo.usp_LMS_Archival_Run @WhatIf = 1;                       -- count only, no changes
==============================================================================*/
USE [LMS_DEV];
GO

-- Stub + ALTER keeps existing permissions on re-deploy (SQL Server 2008 compatible).
IF OBJECT_ID(N'dbo.usp_LMS_Archival_Run', N'P') IS NULL
    EXEC (N'CREATE PROCEDURE dbo.usp_LMS_Archival_Run AS RETURN 0;');
GO

ALTER PROCEDURE dbo.usp_LMS_Archival_Run
    @TableName SYSNAME = NULL,
    @WhatIf    BIT     = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    -- Archival should always be the deadlock victim, never the application.
    SET DEADLOCK_PRIORITY LOW;

    DECLARE @RunId      UNIQUEIDENTIFIER = NEWID(),
            @RunStart   DATETIME         = GETDATE(),
            @LockResult INT;

    EXEC @LockResult = sys.sp_getapplock
         @Resource = N'LMS_ARCHIVAL_RUN', @LockMode = N'Exclusive',
         @LockOwner = N'Session', @LockTimeout = 0;

    IF @LockResult < 0
    BEGIN
        RAISERROR(N'Archival is already running in another session.', 16, 1);
        RETURN;
    END;

    DECLARE @SourceDB       SYSNAME,
            @ArchDB         SYSNAME,
            @LeadStageCol   SYSNAME,
            @MaxRunMinutes  INT,
            @BatchDelay     VARCHAR(12),
            @AutoCreate     NCHAR(1),
            @StopAt         DATETIME,
            @StageCount     INT,
            @StageCollation SYSNAME,
            @Dummy          NVARCHAR(300),
            @TypeSql        NVARCHAR(MAX),
            @sql            NVARCHAR(MAX),
            @msg            NVARCHAR(4000),
            @LogId          BIGINT;

    -- per-table variables
    DECLARE @CfgId         INT,
            @Schema        SYSNAME,
            @Table         SYSNAME,
            @ParentTable   SYSNAME,
            @ParentCol     SYSNAME,
            @ChildCol      SYSNAME,
            @ChildCol2     SYSNAME,
            @ParentCol2    SYSNAME,
            @Join2Mode     VARCHAR(10),
            @J             INT,
            @PCol          SYSNAME,
            @CCol          SYSNAME,
            @JMode         VARCHAR(10),
            @PColl         SYSNAME,
            @CColl         SYSNAME,
            @PType         NVARCHAR(300),
            @CType         NVARCHAR(300),
            @CExpr         NVARCHAR(MAX),
            @Pred          NVARCHAR(MAX),
            @JoinWhere     NVARCHAR(MAX),
            @DateSource    VARCHAR(6),
            @DateCol       SYSNAME,
            @ApplyStage    BIT,
            @KeyCol        SYSNAME,
            @Retention     INT,
            @BatchSize     INT,
            @MaxRows       BIGINT,
            @SrcObj        NVARCHAR(776),
            @ParentObj     NVARCHAR(776),
            @ArchObj       NVARCHAR(776),
            @ParentFilter  NVARCHAR(MAX),
            @KeyType       NVARCHAR(300),
            @Mode          VARCHAR(10),
            @Cols          NVARCHAR(MAX),
            @DelCols       NVARCHAR(MAX),
            @MissingCols   NVARCHAR(MAX),
            @HasIdentity   BIT,
            @ArchExists    BIT,
            @Cutoff        DATETIME,
            @Where         NVARCHAR(MAX),
            @Staged        BIGINT,
            @Archived      BIGINT,
            @Status        VARCHAR(20),
            @Note          NVARCHAR(4000);

    BEGIN TRY
        /*----------------------------------------------------------------------
          1. Global configuration
        ----------------------------------------------------------------------*/
        SELECT @SourceDB      = MAX(CASE WHEN Value = N'SOURCE_DB'              THEN LTRIM(RTRIM(DisplayValue)) END),
               @ArchDB        = MAX(CASE WHEN Value = N'ARCHIVAL_DB'            THEN LTRIM(RTRIM(DisplayValue)) END),
               @LeadStageCol  = MAX(CASE WHEN Value = N'LEAD_STAGE_COLUMN'      THEN LTRIM(RTRIM(DisplayValue)) END),
               @MaxRunMinutes = MAX(CASE WHEN Value = N'MAX_RUN_MINUTES'
                                          AND LEN(LTRIM(RTRIM(DisplayValue))) BETWEEN 1 AND 6
                                          AND LTRIM(RTRIM(DisplayValue)) NOT LIKE N'%[^0-9]%'
                                         THEN CAST(LTRIM(RTRIM(DisplayValue)) AS INT) END),
               @BatchDelay    = MAX(CASE WHEN Value = N'BATCH_DELAY'            THEN LTRIM(RTRIM(DisplayValue)) END),
               @AutoCreate    = MAX(CASE WHEN Value = N'AUTO_CREATE_ARCH_TABLE' THEN UPPER(LEFT(LTRIM(DisplayValue), 1)) END)
        FROM dbo.FRM_GNARR
        WHERE Code = N'ARCHIVAL'
          AND Status = N'A';

        SET @LeadStageCol  = ISNULL(@LeadStageCol, N'Lead_Stage');
        SET @MaxRunMinutes = ISNULL(@MaxRunMinutes, 0);
        SET @AutoCreate    = ISNULL(@AutoCreate, N'N');
        SET @StopAt        = CASE WHEN @MaxRunMinutes > 0 THEN DATEADD(MINUTE, @MaxRunMinutes, @RunStart) ELSE '99991231' END;

        -- Accept only hh:mm:ss or hh:mm:ss.fff; anything else (or zero) disables the pause.
        IF NOT (   @BatchDelay LIKE '[0-2][0-9]:[0-5][0-9]:[0-5][0-9]'
                OR @BatchDelay LIKE '[0-2][0-9]:[0-5][0-9]:[0-5][0-9].[0-9][0-9][0-9]')
           OR @BatchDelay IN ('00:00:00', '00:00:00.000')
           OR @BatchDelay IS NULL
            SET @BatchDelay = NULL;

        IF @SourceDB IS NULL OR DB_ID(@SourceDB) IS NULL
        BEGIN
            SET @msg = N'Source DB not configured or not found: ' + ISNULL(@SourceDB, N'<NULL>');
            RAISERROR(N'%s', 16, 1, @msg);
        END;

        IF @ArchDB IS NULL OR DB_ID(@ArchDB) IS NULL
        BEGIN
            SET @msg = N'Archival DB not configured or not found: ' + ISNULL(@ArchDB, N'<NULL>');
            RAISERROR(N'%s', 16, 1, @msg);
        END;

        IF DB_ID(@SourceDB) = DB_ID(@ArchDB)
            RAISERROR(N'Source DB and Archival DB must be different.', 16, 1);

        -- Resolves a source column's full data type (incl. collation) so temp tables match exactly (no implicit conversions).
        SET @TypeSql = N'
SELECT @DataType =
         ty.name
       + CASE
             WHEN ty.name IN (N''varchar'', N''char'', N''varbinary'', N''binary'')
                 THEN N''('' + CASE WHEN c.max_length = -1 THEN N''max'' ELSE CAST(c.max_length AS NVARCHAR(10)) END + N'')''
             WHEN ty.name IN (N''nvarchar'', N''nchar'')
                 THEN N''('' + CASE WHEN c.max_length = -1 THEN N''max'' ELSE CAST(c.max_length / 2 AS NVARCHAR(10)) END + N'')''
             WHEN ty.name IN (N''decimal'', N''numeric'')
                 THEN N''('' + CAST(c.precision AS NVARCHAR(5)) + N'','' + CAST(c.scale AS NVARCHAR(5)) + N'')''
             WHEN ty.name IN (N''datetime2'', N''time'', N''datetimeoffset'')
                 THEN N''('' + CAST(c.scale AS NVARCHAR(5)) + N'')''
             ELSE N''''
         END
       + CASE WHEN c.collation_name IS NOT NULL THEN N'' COLLATE '' + c.collation_name ELSE N'''' END,
       @Collation = c.collation_name
FROM ' + QUOTENAME(@SourceDB) + N'.sys.columns AS c
JOIN ' + QUOTENAME(@SourceDB) + N'.sys.types   AS ty ON ty.user_type_id = c.system_type_id
WHERE c.object_id = OBJECT_ID(@Obj)
  AND c.name = @Col;';

        /*----------------------------------------------------------------------
          2. Lead stages (only used by tables with ApplyStageFilter = 1)
        ----------------------------------------------------------------------*/
        CREATE TABLE #Stages
        (
            StageValue NVARCHAR(200) NOT NULL,
            IsPattern  BIT           NOT NULL
        );

        INSERT INTO #Stages (StageValue, IsPattern)
        SELECT DISTINCT LTRIM(RTRIM(Value)),
               CASE WHEN CHARINDEX(N'%', Value) > 0 THEN 1 ELSE 0 END
        FROM dbo.FRM_GNARR
        WHERE Code = N'ARCHIVAL_LEAD_STAGE'
          AND Status = N'A'
          AND LTRIM(RTRIM(Value)) <> N'';

        SET @StageCount = @@ROWCOUNT;

        /*----------------------------------------------------------------------
          3. Per-table archival
        ----------------------------------------------------------------------*/
        DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
            SELECT ConfigId, SchemaName, TableName, ParentTable, ParentJoinColumn, ChildJoinColumn, ChildJoinColumn2,
                   ParentJoinColumn2, Join2Mode,
                   DateSource, DateColumn, ApplyStageFilter, KeyColumn, RetentionMonths, BatchSize, MaxRowsPerRun
            FROM dbo.ARCHIVAL_TABLE_CONFIG
            WHERE IsEnabled = 1
              AND (@TableName IS NULL OR TableName = @TableName)
            ORDER BY ProcessOrder, ConfigId;

        OPEN cur;

        WHILE 1 = 1
        BEGIN
            FETCH NEXT FROM cur INTO @CfgId, @Schema, @Table, @ParentTable, @ParentCol, @ChildCol, @ChildCol2,
                                     @ParentCol2, @Join2Mode,
                                     @DateSource, @DateCol, @ApplyStage, @KeyCol, @Retention, @BatchSize, @MaxRows;
            IF @@FETCH_STATUS <> 0 BREAK;

            SELECT @SrcObj      = QUOTENAME(@SourceDB) + N'.' + QUOTENAME(@Schema) + N'.' + QUOTENAME(@Table),
                   @ArchObj     = QUOTENAME(@ArchDB)   + N'.' + QUOTENAME(@Schema) + N'.' + QUOTENAME(@Table),
                   @ParentObj   = CASE WHEN @ParentTable IS NOT NULL
                                       THEN QUOTENAME(@SourceDB) + N'.' + QUOTENAME(@Schema) + N'.' + QUOTENAME(@ParentTable) END,
                   @ParentFilter = NULL, @StageCollation = NULL,
                   @KeyType     = NULL, @Mode = NULL, @Cols = NULL, @DelCols = NULL, @MissingCols = NULL,
                   @HasIdentity = 0, @ArchExists = 1, @Staged = 0, @Archived = 0, @Status = NULL, @Note = NULL,
                   @Cutoff      = DATEADD(MONTH, -@Retention, CAST(CAST(GETDATE() AS DATE) AS DATETIME));

            INSERT INTO dbo.ARCHIVAL_RUN_LOG (RunId, TableName, CutoffDate, StartTime, Status)
            VALUES (@RunId, @SrcObj, @Cutoff, GETDATE(), 'RUNNING');
            SET @LogId = SCOPE_IDENTITY();

            IF GETDATE() >= @StopAt
            BEGIN
                UPDATE dbo.ARCHIVAL_RUN_LOG
                SET EndTime = GETDATE(), Status = 'SKIPPED', ErrorMessage = N'Run time window (MAX_RUN_MINUTES) exceeded.'
                WHERE LogId = @LogId;
                CONTINUE;
            END;

            BEGIN TRY
                /*--- validation ---*/
                IF OBJECT_ID(@SrcObj, N'U') IS NULL
                BEGIN
                    SET @msg = N'Source table not found: ' + @SrcObj;
                    RAISERROR(N'%s', 16, 1, @msg);
                END;

                IF COL_LENGTH(@SrcObj, @DateCol) IS NULL AND @DateSource = 'SELF'
                BEGIN
                    SET @msg = N'DateColumn not found on ' + @SrcObj + N': ' + @DateCol;
                    RAISERROR(N'%s', 16, 1, @msg);
                END;

                IF @ParentTable IS NOT NULL
                BEGIN
                    IF OBJECT_ID(@ParentObj, N'U') IS NULL
                    BEGIN
                        SET @msg = N'Parent table not found: ' + @ParentObj;
                        RAISERROR(N'%s', 16, 1, @msg);
                    END;

                    IF @ParentCol IS NULL OR @ChildCol IS NULL
                        RAISERROR(N'ParentJoinColumn and ChildJoinColumn are required when ParentTable is set.', 16, 1);

                    IF COL_LENGTH(@ParentObj, @ParentCol) IS NULL
                       OR (@ParentCol2 IS NOT NULL AND COL_LENGTH(@ParentObj, @ParentCol2) IS NULL)
                    BEGIN
                        SET @msg = N'ParentJoinColumn(2) not found on ' + @ParentObj + N': ' + @ParentCol + ISNULL(N', ' + @ParentCol2, N'');
                        RAISERROR(N'%s', 16, 1, @msg);
                    END;

                    IF COL_LENGTH(@SrcObj, @ChildCol) IS NULL
                       OR (@ChildCol2 IS NOT NULL AND COL_LENGTH(@SrcObj, @ChildCol2) IS NULL)
                    BEGIN
                        SET @msg = N'ChildJoinColumn(2) not found on ' + @SrcObj + N': ' + @ChildCol + ISNULL(N', ' + @ChildCol2, N'');
                        RAISERROR(N'%s', 16, 1, @msg);
                    END;

                    IF @DateSource = 'PARENT' AND COL_LENGTH(@ParentObj, @DateCol) IS NULL
                    BEGIN
                        SET @msg = N'DateColumn not found on ' + @ParentObj + N': ' + @DateCol;
                        RAISERROR(N'%s', 16, 1, @msg);
                    END;

                    IF @ApplyStage = 1
                    BEGIN
                        IF @StageCount = 0
                            RAISERROR(N'ApplyStageFilter = 1 but no active ARCHIVAL_LEAD_STAGE values in FRM_GNARR.', 16, 1);

                        EXEC sys.sp_executesql @TypeSql,
                             N'@Obj NVARCHAR(776), @Col SYSNAME, @DataType NVARCHAR(300) OUTPUT, @Collation SYSNAME OUTPUT',
                             @Obj = @ParentObj, @Col = @LeadStageCol, @DataType = @Dummy OUTPUT, @Collation = @StageCollation OUTPUT;

                        IF @StageCollation IS NULL
                        BEGIN
                            SET @msg = N'Stage column ' + @LeadStageCol + N' not found (or not character) on ' + @ParentObj;
                            RAISERROR(N'%s', 16, 1, @msg);
                        END;
                    END;
                END
                ELSE IF @DateSource = 'PARENT' OR @ApplyStage = 1
                    RAISERROR(N'DateSource = PARENT / ApplyStageFilter = 1 require ParentTable.', 16, 1);

                IF @KeyCol IS NOT NULL AND COL_LENGTH(@SrcObj, @KeyCol) IS NULL
                BEGIN
                    SET @msg = N'KeyColumn not found: ' + @KeyCol;
                    RAISERROR(N'%s', 16, 1, @msg);
                END;

                /*--- key detection: single-column PK, else identity column ---*/
                IF @KeyCol IS NULL
                BEGIN
                    SET @sql = N'
SELECT @Key = MAX(c.name)
FROM ' + QUOTENAME(@SourceDB) + N'.sys.indexes AS i
JOIN ' + QUOTENAME(@SourceDB) + N'.sys.index_columns AS ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.key_ordinal > 0
JOIN ' + QUOTENAME(@SourceDB) + N'.sys.columns AS c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(@Obj) AND i.is_primary_key = 1
HAVING COUNT(*) = 1;

IF @Key IS NULL
    SELECT @Key = c.name
    FROM ' + QUOTENAME(@SourceDB) + N'.sys.columns AS c
    WHERE c.object_id = OBJECT_ID(@Obj) AND c.is_identity = 1;';

                    EXEC sys.sp_executesql @sql, N'@Obj NVARCHAR(776), @Key SYSNAME OUTPUT',
                         @Obj = @SrcObj, @Key = @KeyCol OUTPUT;
                END;

                SET @Mode = CASE WHEN @KeyCol IS NULL THEN 'TOPN' ELSE 'KEY' END;

                IF @Mode = 'KEY'
                    EXEC sys.sp_executesql @TypeSql,
                         N'@Obj NVARCHAR(776), @Col SYSNAME, @DataType NVARCHAR(300) OUTPUT, @Collation SYSNAME OUTPUT',
                         @Obj = @SrcObj, @Col = @KeyCol, @DataType = @KeyType OUTPUT, @Collation = @Dummy OUTPUT;

                /*--- archive table ---*/
                IF OBJECT_ID(@ArchObj, N'U') IS NULL
                BEGIN
                    IF @WhatIf = 1
                        SELECT @ArchExists = 0, @Note = N'Archive table does not exist.';
                    ELSE IF @AutoCreate = N'Y'
                    BEGIN
                        -- UNION ALL drops the IDENTITY property so archived ids are kept as-is.
                        SET @sql = N'SELECT TOP (0) * INTO ' + @ArchObj + N' FROM ' + @SrcObj
                                 + N' UNION ALL SELECT TOP (0) * FROM ' + @SrcObj + N';';
                        EXEC sys.sp_executesql @sql;
                        SET @Note = N'Archive table auto-created.';
                    END
                    ELSE
                    BEGIN
                        SET @msg = N'Archive table not found and AUTO_CREATE_ARCH_TABLE <> Y: ' + @ArchObj;
                        RAISERROR(N'%s', 16, 1, @msg);
                    END;
                END;

                /*--- column mapping (guards against silent data loss) ---*/
                IF @ArchExists = 1
                BEGIN
                    SET @sql = N'
SELECT @Missing = STUFF((
    SELECT N'', '' + s.name
    FROM ' + QUOTENAME(@SourceDB) + N'.sys.columns AS s
    WHERE s.object_id = OBJECT_ID(@Src) AND s.is_computed = 0 AND s.system_type_id <> 189
      AND NOT EXISTS (SELECT 1 FROM ' + QUOTENAME(@ArchDB) + N'.sys.columns AS a
                      WHERE a.object_id = OBJECT_ID(@Arch)
                        AND a.name COLLATE DATABASE_DEFAULT = s.name COLLATE DATABASE_DEFAULT)
    ORDER BY s.column_id
    FOR XML PATH(''''), TYPE).value(''.'', ''NVARCHAR(MAX)''), 1, 2, N'''');

SELECT @Cols = STUFF((
           SELECT N'','' + QUOTENAME(a.name)
           FROM ' + QUOTENAME(@ArchDB) + N'.sys.columns AS a
           WHERE a.object_id = OBJECT_ID(@Arch) AND a.is_computed = 0 AND a.system_type_id <> 189
             AND EXISTS (SELECT 1 FROM ' + QUOTENAME(@SourceDB) + N'.sys.columns AS s
                         WHERE s.object_id = OBJECT_ID(@Src)
                           AND s.name COLLATE DATABASE_DEFAULT = a.name COLLATE DATABASE_DEFAULT)
           ORDER BY a.column_id
           FOR XML PATH(''''), TYPE).value(''.'', ''NVARCHAR(MAX)''), 1, 1, N''''),
       @DelCols = STUFF((
           SELECT N'',deleted.'' + QUOTENAME(a.name)
           FROM ' + QUOTENAME(@ArchDB) + N'.sys.columns AS a
           WHERE a.object_id = OBJECT_ID(@Arch) AND a.is_computed = 0 AND a.system_type_id <> 189
             AND EXISTS (SELECT 1 FROM ' + QUOTENAME(@SourceDB) + N'.sys.columns AS s
                         WHERE s.object_id = OBJECT_ID(@Src)
                           AND s.name COLLATE DATABASE_DEFAULT = a.name COLLATE DATABASE_DEFAULT)
           ORDER BY a.column_id
           FOR XML PATH(''''), TYPE).value(''.'', ''NVARCHAR(MAX)''), 1, 1, N''''),
       @HasIdentity = CASE WHEN EXISTS (
           SELECT 1 FROM ' + QUOTENAME(@ArchDB) + N'.sys.columns AS a
           WHERE a.object_id = OBJECT_ID(@Arch) AND a.is_identity = 1
             AND EXISTS (SELECT 1 FROM ' + QUOTENAME(@SourceDB) + N'.sys.columns AS s
                         WHERE s.object_id = OBJECT_ID(@Src)
                           AND s.name COLLATE DATABASE_DEFAULT = a.name COLLATE DATABASE_DEFAULT)) THEN 1 ELSE 0 END;';

                    EXEC sys.sp_executesql @sql,
                         N'@Src NVARCHAR(776), @Arch NVARCHAR(776), @Missing NVARCHAR(MAX) OUTPUT, @Cols NVARCHAR(MAX) OUTPUT, @DelCols NVARCHAR(MAX) OUTPUT, @HasIdentity BIT OUTPUT',
                         @Src = @SrcObj, @Arch = @ArchObj, @Missing = @MissingCols OUTPUT,
                         @Cols = @Cols OUTPUT, @DelCols = @DelCols OUTPUT, @HasIdentity = @HasIdentity OUTPUT;

                    IF @MissingCols IS NOT NULL
                    BEGIN
                        SET @msg = N'Archive table ' + @ArchObj + N' is missing columns: ' + @MissingCols;
                        RAISERROR(N'%s', 16, 1, @msg);
                    END;
                END;

                /*--- filter ---*/
                IF @ParentTable IS NOT NULL
                BEGIN
                    -- Conditions evaluated on the parent row (date and/or stage).
                    SET @ParentFilter =
                          CASE WHEN @DateSource = 'PARENT'
                               THEN N' AND p.' + QUOTENAME(@DateCol) + N' < @Cutoff' ELSE N'' END
                        + CASE WHEN @ApplyStage = 1
                               THEN N' AND (p.' + QUOTENAME(@LeadStageCol) + N' IN (SELECT st.StageValue COLLATE ' + @StageCollation + N' FROM #Stages AS st WHERE st.IsPattern = 0)'
                                  + N' OR EXISTS (SELECT 1 FROM #Stages AS st WHERE st.IsPattern = 1 AND p.' + QUOTENAME(@LeadStageCol) + N' LIKE st.StageValue COLLATE ' + @StageCollation + N'))'
                               ELSE N'' END;

                    -- Join 1: ParentJoinColumn = ChildJoinColumn (exact).
                    -- Join 2 (optional): ParentJoinColumn2 = f(ChildJoinColumn2), f per Join2Mode.
                    -- Each join is its own EXISTS so each side can use an index seek on the parent.
                    SELECT @JoinWhere = NULL, @J = 1;

                    WHILE @J <= 2
                    BEGIN
                        IF @J = 2 AND @ParentCol2 IS NULL AND @ChildCol2 IS NULL
                            BREAK;

                        SELECT @PCol  = CASE WHEN @J = 1 THEN @ParentCol ELSE ISNULL(@ParentCol2, @ParentCol) END,
                               @CCol  = CASE WHEN @J = 1 THEN @ChildCol  ELSE ISNULL(@ChildCol2,  @ChildCol)  END,
                               @JMode = CASE WHEN @J = 1 THEN 'EXACT'    ELSE ISNULL(@Join2Mode, 'EXACT') END,
                               @PColl = NULL, @CColl = NULL, @PType = NULL, @CType = NULL;

                        EXEC sys.sp_executesql @TypeSql,
                             N'@Obj NVARCHAR(776), @Col SYSNAME, @DataType NVARCHAR(300) OUTPUT, @Collation SYSNAME OUTPUT',
                             @Obj = @ParentObj, @Col = @PCol, @DataType = @PType OUTPUT, @Collation = @PColl OUTPUT;

                        EXEC sys.sp_executesql @TypeSql,
                             N'@Obj NVARCHAR(776), @Col SYSNAME, @DataType NVARCHAR(300) OUTPUT, @Collation SYSNAME OUTPUT',
                             @Obj = @SrcObj, @Col = @CCol, @DataType = @CType OUTPUT, @Collation = @CColl OUTPUT;

                        SET @CExpr = N's.' + QUOTENAME(@CCol);

                        -- PREFIXNUM: keep text up to the end of the first digit run (MF147710-MBRE -> MF147710).
                        IF @JMode = 'PREFIXNUM' AND @CColl IS NOT NULL
                            SET @CExpr = N'CASE WHEN PATINDEX(N''%[0-9]%'', ' + @CExpr + N') = 0 THEN LTRIM(RTRIM(' + @CExpr + N'))'
                                       + N' ELSE LEFT(' + @CExpr + N', PATINDEX(N''%[0-9]%'', ' + @CExpr + N') - 1'
                                       + N' + PATINDEX(N''%[^0-9]%'', SUBSTRING(' + @CExpr + N', PATINDEX(N''%[0-9]%'', ' + @CExpr + N'), 4000) + N''X'') - 1) END';

                        -- Align data types without risking nvarchar -> numeric conversion errors.
                        IF @PColl IS NOT NULL AND @CColl IS NULL
                            SET @Pred = N'p.' + QUOTENAME(@PCol) + N' = CONVERT(NVARCHAR(100), ' + @CExpr + N') COLLATE ' + @PColl;
                        ELSE IF @PColl IS NULL AND @CColl IS NOT NULL
                            SET @Pred = N'p.' + QUOTENAME(@PCol) + N' = CASE WHEN LEN(LTRIM(RTRIM(' + @CExpr + N'))) BETWEEN 1 AND 38'
                                      + N' AND LTRIM(RTRIM(' + @CExpr + N')) NOT LIKE N''%[^0-9]%'''
                                      + N' THEN CAST(LTRIM(RTRIM(' + @CExpr + N')) AS DECIMAL(38, 0)) END';
                        ELSE IF @PColl IS NOT NULL
                            SET @Pred = N'p.' + QUOTENAME(@PCol) + N' = ' + @CExpr + N' COLLATE ' + @PColl;
                        ELSE
                            SET @Pred = N'p.' + QUOTENAME(@PCol) + N' = ' + @CExpr;

                        SET @JoinWhere = ISNULL(@JoinWhere + N'
   OR ', N'') + N'EXISTS (SELECT 1 FROM ' + @ParentObj + N' AS p WHERE ' + @Pred + @ParentFilter + N')';

                        SET @J += 1;
                    END;

                    SET @Where = N'(' + @JoinWhere + N')'
                               + CASE WHEN @DateSource = 'SELF'
                                      THEN N'
  AND s.' + QUOTENAME(@DateCol) + N' < @Cutoff' ELSE N'' END;
                END
                ELSE
                    SET @Where = N's.' + QUOTENAME(@DateCol) + N' < @Cutoff';

                /*--- build batch ---*/
                IF @Mode = 'KEY'
                BEGIN
                    -- Keys are staged once in key order, then moved by RowNo ranges:
                    -- no re-scan of the source per batch and seeks on the source key.
                    SET @sql = N'
CREATE TABLE #Keys
(
    RowNo  BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    KeyVal ' + @KeyType + N' NOT NULL
);

INSERT INTO #Keys WITH (TABLOCK) (KeyVal)
SELECT ' + CASE WHEN @MaxRows > 0 THEN N'TOP (@MaxRows) ' ELSE N'' END + N's.' + QUOTENAME(@KeyCol) + N'
FROM ' + @SrcObj + N' AS s
WHERE s.' + QUOTENAME(@KeyCol) + N' IS NOT NULL
  AND ' + @Where + N'
ORDER BY s.' + QUOTENAME(@KeyCol) + N';

SET @Staged = ROWCOUNT_BIG();';

                    IF @WhatIf = 0
                        SET @sql += N'
' + CASE WHEN @HasIdentity = 1 THEN N'SET IDENTITY_INSERT ' + @ArchObj + N' ON;' ELSE N'' END + N'

DECLARE @From BIGINT = 1;

WHILE @From <= @Staged AND GETDATE() < @StopAt
BEGIN
    DELETE s
    OUTPUT ' + @DelCols + N'
    INTO ' + @ArchObj + N' (' + @Cols + N')
    FROM ' + @SrcObj + N' AS s
    INNER JOIN #Keys AS k ON k.KeyVal = s.' + QUOTENAME(@KeyCol) + N'
    WHERE k.RowNo >= @From
      AND k.RowNo <  @From + @BatchSize;

    SET @Archived += ROWCOUNT_BIG();
    SET @From     += @BatchSize;

    IF @BatchDelay IS NOT NULL AND @From <= @Staged
        WAITFOR DELAY @BatchDelay;
END;
' + CASE WHEN @HasIdentity = 1 THEN N'SET IDENTITY_INSERT ' + @ArchObj + N' OFF;' ELSE N'' END;
                END
                ELSE
                BEGIN
                    -- No usable key: repeated DELETE TOP (n) on the filter.
                    IF @WhatIf = 1
                        SET @sql = N'
SELECT @Staged = ' + CASE WHEN @MaxRows > 0 THEN N'CASE WHEN COUNT_BIG(*) > @MaxRows THEN @MaxRows ELSE COUNT_BIG(*) END' ELSE N'COUNT_BIG(*)' END + N'
FROM ' + @SrcObj + N' AS s
WHERE ' + @Where + N';';
                    ELSE
                        SET @sql = N'
' + CASE WHEN @HasIdentity = 1 THEN N'SET IDENTITY_INSERT ' + @ArchObj + N' ON;' ELSE N'' END + N'

DECLARE @Rows BIGINT = 1, @Take BIGINT;

WHILE @Rows > 0 AND GETDATE() < @StopAt
BEGIN
    SET @Take = CASE WHEN @MaxRows > 0 AND @MaxRows - @Archived < @BatchSize
                     THEN @MaxRows - @Archived ELSE @BatchSize END;
    IF @Take <= 0 BREAK;

    DELETE TOP (@Take) s
    OUTPUT ' + @DelCols + N'
    INTO ' + @ArchObj + N' (' + @Cols + N')
    FROM ' + @SrcObj + N' AS s
    WHERE ' + @Where + N';

    SET @Rows      = ROWCOUNT_BIG();
    SET @Archived += @Rows;

    IF @BatchDelay IS NOT NULL AND @Rows > 0
        WAITFOR DELAY @BatchDelay;
END;

SET @Staged = @Archived;
' + CASE WHEN @HasIdentity = 1 THEN N'SET IDENTITY_INSERT ' + @ArchObj + N' OFF;' ELSE N'' END;
                END;

                IF @sql IS NULL
                    RAISERROR(N'Failed to build archival statement (unresolved column list or key type).', 16, 1);

                EXEC sys.sp_executesql @sql,
                     N'@Cutoff DATETIME, @MaxRows BIGINT, @BatchSize INT, @StopAt DATETIME, @BatchDelay VARCHAR(12), @Staged BIGINT OUTPUT, @Archived BIGINT OUTPUT',
                     @Cutoff = @Cutoff, @MaxRows = @MaxRows, @BatchSize = @BatchSize, @StopAt = @StopAt,
                     @BatchDelay = @BatchDelay, @Staged = @Staged OUTPUT, @Archived = @Archived OUTPUT;

                SET @Status = CASE
                                  WHEN @WhatIf = 1 THEN 'WHATIF'
                                  WHEN @Mode = 'KEY'  AND @Archived < @Staged THEN 'PARTIAL'
                                  WHEN @Mode = 'TOPN' AND GETDATE() >= @StopAt THEN 'PARTIAL'
                                  ELSE 'SUCCESS'
                              END;

                IF @Status = 'PARTIAL'
                    SET @Note = ISNULL(@Note + N' ', N'') + N'Stopped by run time window; remaining rows will be picked up next run.';

                UPDATE dbo.ARCHIVAL_RUN_LOG
                SET EndTime = GETDATE(), ProcessMode = @Mode, RowsStaged = @Staged, RowsArchived = @Archived,
                    Status = @Status, ErrorMessage = @Note
                WHERE LogId = @LogId;

                IF @WhatIf = 0
                    UPDATE dbo.ARCHIVAL_TABLE_CONFIG
                    SET LastRunOn = GETDATE(), LastRowsArchived = @Archived
                    WHERE ConfigId = @CfgId;
            END TRY
            BEGIN CATCH
                IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;

                SET @msg = ERROR_MESSAGE();

                IF @HasIdentity = 1
                BEGIN
                    BEGIN TRY
                        SET @sql = N'SET IDENTITY_INSERT ' + @ArchObj + N' OFF;';
                        EXEC sys.sp_executesql @sql;
                    END TRY
                    BEGIN CATCH
                        SET @HasIdentity = 0;
                    END CATCH;
                END;

                -- Each batch is an atomic DELETE...OUTPUT INTO, so rows already moved are consistent.
                UPDATE dbo.ARCHIVAL_RUN_LOG
                SET EndTime = GETDATE(), ProcessMode = @Mode, Status = 'FAILED', ErrorMessage = LEFT(@msg, 4000)
                WHERE LogId = @LogId;
            END CATCH;
        END;

        CLOSE cur;
        DEALLOCATE cur;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;

        SET @msg = ERROR_MESSAGE();

        UPDATE dbo.ARCHIVAL_RUN_LOG
        SET EndTime = GETDATE(), Status = 'FAILED', ErrorMessage = LEFT(@msg, 4000)
        WHERE RunId = @RunId AND Status = 'RUNNING';

        INSERT INTO dbo.ARCHIVAL_RUN_LOG (RunId, TableName, StartTime, EndTime, Status, ErrorMessage)
        VALUES (@RunId, N'*RUN*', @RunStart, GETDATE(), 'FAILED', LEFT(@msg, 4000));

        EXEC sys.sp_releaseapplock @Resource = N'LMS_ARCHIVAL_RUN', @LockOwner = N'Session';
        RAISERROR(N'%s', 16, 1, @msg);
        RETURN;
    END CATCH;

    EXEC sys.sp_releaseapplock @Resource = N'LMS_ARCHIVAL_RUN', @LockOwner = N'Session';

    SELECT LogId, TableName, ProcessMode, CutoffDate, StartTime, EndTime,
           RowsStaged, RowsArchived, Status, ErrorMessage
    FROM dbo.ARCHIVAL_RUN_LOG
    WHERE RunId = @RunId
    ORDER BY LogId;

    -- Fail the Agent job step if any table failed, so it is visible in job history.
    IF EXISTS (SELECT 1 FROM dbo.ARCHIVAL_RUN_LOG WHERE RunId = @RunId AND Status = 'FAILED')
        RAISERROR(N'Archival completed with one or more FAILED tables. See ARCHIVAL_RUN_LOG.', 16, 1);
END;
GO
