using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32;

internal static class Program
{
    private const string DefaultFingerprint =
        "07b8d2f330e83abecb0f11b254eafaba8266dab858ddc092ea28122651dfc13a";
    private static int inspectionErrors;

    [DllImport("crypt32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CryptVerifyCertificateSignatureEx(
        IntPtr provider, uint encoding, uint subjectType, IntPtr subject,
        uint issuerType, IntPtr issuer, uint flags, IntPtr extra);

    private static int Main(string[] args)
    {
        try
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT)
                throw new PlatformNotSupportedException("This diagnostic requires Windows.");

            string expected = DefaultFingerprint;
            string file = null;
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--help")
                {
                    Console.WriteLine("CertificateDiagnostic.exe [--sha256 HEX] [--file public.cer]");
                    Console.WriteLine("Without --file, inspect Current User and Local Machine certificate stores.");
                    return 0;
                }
                if ((args[i] != "--sha256" && args[i] != "--file") || i + 1 >= args.Length)
                    throw new ArgumentException("Use --sha256 HEX or --file public.cer, or --help.");
                string option = args[i++];
                if (option == "--sha256") expected = args[i];
                else file = args[i];
            }
            if (!Regex.IsMatch(expected, @"\A[0-9a-fA-F]{64}\z"))
                throw new ArgumentException("The SHA-256 fingerprint must contain exactly 64 hexadecimal characters.");

            using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
            {
                Console.WriteLine("Windows account: " + identity.Name);
                Console.WriteLine("Administrator token: " +
                    new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator));
            }
            Console.WriteLine("Workstation clock UTC: " + DateTime.UtcNow.ToString("o"));
            Console.WriteLine("Expected certificate SHA-256: " + expected.ToLowerInvariant());
            Console.WriteLine("READ ONLY: no imports, elevation, network requests or trust changes.");
            Console.WriteLine();

            int matches;
            if (file != null)
            {
                X509Certificate2 certificate = LoadPublicCertificate(file);
                try
                {
                    Report(certificate, "PUBLIC FILE: " + Path.GetFullPath(file), expected);
                    matches = Fingerprint(certificate).Equals(expected, StringComparison.OrdinalIgnoreCase) ? 1 : 0;
                    Console.WriteLine("A public certificate file does not establish that it is installed.");
                }
                finally { certificate.Reset(); }
            }
            else
            {
                matches = InspectStores(expected);
                Console.WriteLine("Matching store-view entries: " + matches);
                if (matches == 0)
                    Console.WriteLine("No exact match in successfully inspected stores. Other accounts, stores and browser exceptions were not checked.");
            }

            Console.WriteLine();
            Console.WriteLine("INTERPRETATION");
            Console.WriteLine("SelfSignedConfirmed=True verifies the signature with its own public key and matching subject/issuer names.");
            Console.WriteLine("A CurrentUser store view can include inherited machine certificates.");
            Console.WriteLine("A direct HKEY_CURRENT_USER record identifies user-profile storage, NOT who imported it.");
            Console.WriteLine("A policy record indicates policy storage; its absence does NOT exclude IT or management tools.");
            Console.WriteLine("Certificate records do not reliably identify the installer or installation date.");
            Console.WriteLine("Issued/valid-from dates are NOT installation dates.");
            Console.WriteLine("No live HTTPS, hostname, chain-trust, revocation or import-permission test was performed.");
            Console.WriteLine("The coworker hostname AFNA1 differs from the CETFalcon hostname HFNA2.");
            Console.WriteLine("No private keys or certificate bytes were exported.");
            if (inspectionErrors != 0)
                Console.WriteLine("RESULT INCOMPLETE: " + inspectionErrors + " inspection error(s); see ERROR messages.");
            return inspectionErrors != 0 ? 2 : matches == 0 ? 1 : 0;
        }
        catch (ArgumentException error) { return Failure(error); }
        catch (FormatException error) { return Failure(error); }
        catch (CryptographicException error) { return Failure(error); }
        catch (SecurityException error) { return Failure(error); }
        catch (UnauthorizedAccessException error) { return Failure(error); }
        catch (IOException error) { return Failure(error); }
        catch (PlatformNotSupportedException error) { return Failure(error); }
        finally
        {
            if (!Console.IsInputRedirected && !Console.IsOutputRedirected)
            {
                Console.WriteLine();
                Console.Write("Press Enter to close...");
                Console.ReadLine();
            }
        }
    }

    private static int Failure(Exception error)
    {
        Console.Error.WriteLine("ERROR: " + error.GetType().Name + ": " + error.Message);
        return 2;
    }

    private static int InspectStores(string expected)
    {
        int matches = 0;
        foreach (StoreLocation scope in new[] { StoreLocation.CurrentUser, StoreLocation.LocalMachine })
        {
            foreach (string name in new[] { "Root", "CA", "My", "TrustedPeople", "AuthRoot" })
            {
                X509Store store = new X509Store(name, scope);
                try
                {
                    store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);
                    X509Certificate2Collection certificates = store.Certificates;
                    try
                    {
                        foreach (X509Certificate2 certificate in certificates)
                        {
                            if (!Fingerprint(certificate).Equals(expected, StringComparison.OrdinalIgnoreCase)) continue;
                            matches++;
                            Report(certificate, @"Cert:\" + scope + @"\" + name, expected);
                            RegistryHive hive = scope == StoreLocation.CurrentUser ? RegistryHive.CurrentUser : RegistryHive.LocalMachine;
                            string suffix = @"\SystemCertificates\" + name + @"\Certificates\" + certificate.Thumbprint;
                            ReportRegistry(hive, @"Software\Microsoft" + suffix, "Direct registry record");
                            ReportRegistry(hive, @"Software\Policies\Microsoft" + suffix, "Group Policy registry record");
                            Console.WriteLine();
                        }
                    }
                    finally
                    {
                        foreach (X509Certificate2 certificate in certificates) certificate.Reset();
                    }
                }
                catch (CryptographicException error) { InspectionError("Cert:\\" + scope + "\\" + name, error); }
                catch (SecurityException error) { InspectionError("Cert:\\" + scope + "\\" + name, error); }
                catch (UnauthorizedAccessException error) { InspectionError("Cert:\\" + scope + "\\" + name, error); }
                finally { store.Close(); }
            }
        }
        return matches;
    }

    private static void Report(X509Certificate2 certificate, string location, string expected)
    {
        bool selfIssued = certificate.SubjectName.RawData.SequenceEqual(certificate.IssuerName.RawData);
        bool signatureValid = CryptVerifyCertificateSignatureEx(
            IntPtr.Zero, 65537, 2, certificate.Handle, 2, certificate.Handle, 0, IntPtr.Zero);
        int signatureError = signatureValid ? 0 : Marshal.GetLastWin32Error();
        string hash = Fingerprint(certificate);
        Console.WriteLine("Location: " + location);
        Console.WriteLine("Subject: " + certificate.Subject);
        Console.WriteLine("Issuer: " + certificate.Issuer);
        Console.WriteLine("Friendly name: " + certificate.FriendlyName);
        Console.WriteLine("Certificate SHA-256: " + hash);
        Console.WriteLine("ExactSHA256Match: " + hash.Equals(expected, StringComparison.OrdinalIgnoreCase));
        Console.WriteLine("SelfIssued: " + selfIssued);
        Console.WriteLine("SignatureValidUsingOwnPublicKey: " + signatureValid);
        if (!signatureValid)
            Console.WriteLine("Signature verification Windows error: 0x" + signatureError.ToString("X8"));
        Console.WriteLine("SelfSignedConfirmed: " + (selfIssued && signatureValid));
        Console.WriteLine("Valid from UTC: " + certificate.NotBefore.ToUniversalTime().ToString("o"));
        Console.WriteLine("Expires UTC: " + certificate.NotAfter.ToUniversalTime().ToString("o"));
        DateTime now = DateTime.UtcNow;
        Console.WriteLine("WithinValidityPeriod: " +
            (now >= certificate.NotBefore.ToUniversalTime() && now <= certificate.NotAfter.ToUniversalTime()));
        foreach (X509Extension extension in certificate.Extensions)
            if (extension.Oid.Value == "2.5.29.17")
                Console.WriteLine("Subject alternative names: " + extension.Format(true).Trim());
    }

    private static void ReportRegistry(RegistryHive hive, string path, string label)
    {
        try
        {
            using (RegistryKey root = RegistryKey.OpenBaseKey(hive, RegistryView.Default))
            using (RegistryKey key = root.OpenSubKey(path, false))
                Console.WriteLine(label + ": " + (key == null ? "Absent" : "Present") +
                    " [" + (hive == RegistryHive.CurrentUser ? "HKEY_CURRENT_USER" : "HKEY_LOCAL_MACHINE") + "\\" + path + "]");
        }
        catch (SecurityException error) { InspectionError(label, error); }
        catch (UnauthorizedAccessException error) { InspectionError(label, error); }
        catch (IOException error) { InspectionError(label, error); }
    }

    private static void InspectionError(string location, Exception error)
    {
        inspectionErrors++;
        Console.Error.WriteLine("ERROR inspecting " + location + ": " + error.Message + " [result incomplete]");
    }

    private static string Fingerprint(X509Certificate2 certificate)
    {
        using (SHA256 sha = SHA256.Create())
            return BitConverter.ToString(sha.ComputeHash(certificate.RawData)).Replace("-", "").ToLowerInvariant();
    }

    private static X509Certificate2 LoadPublicCertificate(string path)
    {
        FileInfo file = new FileInfo(path);
        if (!file.Exists || file.Length > 65536)
            throw new ArgumentException("Select an existing public certificate file no larger than 64 KiB.");
        byte[] bytes = File.ReadAllBytes(file.FullName);
        string text = Encoding.ASCII.GetString(bytes);
        if (text.Contains("PRIVATE KEY")) throw new ArgumentException("Private-key files are not accepted.");
        if (text.Contains("-----BEGIN CERTIFICATE-----"))
        {
            Match pem = Regex.Match(text, @"\A\s*-----BEGIN CERTIFICATE-----\s*([A-Za-z0-9+/=\s]+)-----END CERTIFICATE-----\s*\z");
            if (!pem.Success) throw new ArgumentException("Select one public certificate, not a bundle.");
            bytes = Convert.FromBase64String(pem.Groups[1].Value);
        }
        if (X509Certificate2.GetCertContentType(bytes) != X509ContentType.Cert)
            throw new ArgumentException("Only a public CER/CRT/PEM certificate is accepted, not PFX/P12 or bundles.");
        return new X509Certificate2(bytes);
    }
}
